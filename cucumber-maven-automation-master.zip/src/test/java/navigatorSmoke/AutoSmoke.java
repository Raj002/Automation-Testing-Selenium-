package navigatorSmoke;


import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import businessComponents.TabBar;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import functionalLibrary.DataStorage;
import functionalLibrary.Hooks;
import functionalLibrary.ObjectMethods;
import functionalLibrary.WebDriverFactory;
import pageObjects.ButtonScriptless;
import pageObjects.Conventional;
import pageObjects.LabelScriptless;
import pageObjects.LinkScriptless;
import pageObjects.LoginDV;
import pageObjects.RadioInputScriptless;
import pageObjects.RangeInputScriptless;
import pageObjects.SideMenuScriptless;
import pageObjects.TableActionScriptless;
import pageObjects.TextAreaInputScriptless;
import pageObjects.TextInputScriptless;
import cucumber.api.Scenario;

public class AutoSmoke {


	static Logger log = Logger.getLogger(AutoSmoke.class);
	

	/** The driver. */
	WebDriverFactory webDriverFactory;
	WebDriver driver;	
	ButtonScriptless button;
	TextInputScriptless textInput;
	SideMenuScriptless sideMenuScriptless;
	RangeInputScriptless rangeInput;
	TextAreaInputScriptless textArea;
	LoginDV loginDv;
	TabBar tabBar;
	RadioInputScriptless radioInputScriptless;
	TableActionScriptless tableAction;
	LinkScriptless link;
	LabelScriptless label;
	RadioInputScriptless radioInput;
	TextAreaInputScriptless textAreaInput;
	Conventional conventional;
	Hooks hooks;
	Scenario scenario;
	

	
	
	
	
	/** Page objects Initialization */
	public AutoSmoke (){
		
		driver = WebDriverFactory.getWebDriver(prop.getProperty("webdriver.browserType"));
		hooks = new Hooks(driver);
		button = new ButtonScriptless(driver);
		textInput = new TextInputScriptless(driver);
		sideMenuScriptless = new SideMenuScriptless(driver);
		rangeInput = new RangeInputScriptless(driver);
		textArea = new TextAreaInputScriptless(driver);
		loginDv = new LoginDV(driver);
		tabBar = new TabBar(driver);
		radioInputScriptless = new RadioInputScriptless(driver);
		tableAction = new TableActionScriptless(driver);
		link = new LinkScriptless(driver);
		label = new LabelScriptless(driver);
		radioInput = new RadioInputScriptless(driver);
		textAreaInput = new TextAreaInputScriptless(driver);
		conventional = new Conventional(driver);
		hooks = new Hooks (driver);
		
	}
	
	ObjectMethods objectMethods = new ObjectMethods();	
	Properties prop = DataStorage.loadProperties();
	String  url = prop.getProperty("landing.page.url");
	
	@Before
	public void before(Scenario scenario) {
	    this.scenario = scenario;
	}
	@After
	public void captureFailureScreens(Scenario scenario){
		
		hooks.afterScenario(scenario);		
	}
	
	@Given("^Login to Navigator as a user with previleges to write check$")
	public void login_to_Navigator_as_a_user_with_previleges_to_write_check() throws Throwable {
		driver.get(url);
		loginDv.setUserName("n9986485");
		loginDv.setPassword("pmcng928");
		loginDv.clickSubmitButton();
		driver.manage().window().maximize();
		button.clickNewClaim();
		
	    
	}

	@When("^Create an Auto claim$")
	public void create_an_Auto_claim() throws Throwable {
		radioInput.clickRadioInputWhereLabelAndChoice("Create New Claim:", "Auto");
		radioInput.clickRadioInputWhereLabelAndChoice("Policy Provider:", "Liberty");
		textInput.enterTextinputWhereLabelFirstOccurence("Date of Loss", "03/05/2012");
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Time of Loss", "03:30 AM");
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Loss State", "Maine");
		radioInput.clickRadioInputWhereChoice("Policy #");
		textInput.enterTextinputWhereLabelFirstOccurence("Policy #", "AO524334270675");
		button.clickButtonWhereAnyLetterUnderLined("Search", "S");
		Thread.sleep(5000);
		button.clickButtonWhereLabel("Next >");
		button.clickButtonWhereAnyLetterUnderLined("Close", "e");
		button.clickButtonWhereLabel("Next >");

		rangeInput.enterRangeInputWhereLabelFirstOccurence("Name", "MORRIS SMITH");
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Relation to Insured", "Self");
		button.clickButtonWhereLabel("Next >");

		rangeInput.enterRangeInputWhereLabelFirstOccurence("Loss Category", "Single-Vehicle Accident");
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Loss Cause", "Hit Animal");
		textAreaInput.enterTextAreaInputWhereLabelFirstOccurence("Loss Description", "Test");
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Fault Rating", "Insured at fault");
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Location", "45 HILL STREET, DULUTH, MN 55816");
		conventional.clickAddVehicle();
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Select Vehicle", "2007 HOND ACCORD");
		objectMethods.hardWait(2000);
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Point of First Impact", "06 - Rear");
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Severity", "Minor");
		textAreaInput.enterTextAreaInputWhereLabelFirstOccurence("Damage Description", "Test");
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Airbags Deployed?", "Yes");
		radioInput.clickRadioInputWhereLabelAndChoice("Vehicle Operable?", "No");
		textAreaInput.enterTextAreaInputWhereLabelFirstOccurence("Pre-existing Damage?", "Test");
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Vehicle towed from scene of accident?", "No");
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Was there a child safety seat in the vehicle?", "No");
		conventional.selectVehicleLocation("Home, 45 HILL STREET, DULUTH, MN, 55816");
		button.clickButtonWhereLabel("Add Driver");
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Driver Name", "MORRIS SMITH");
		radioInput.clickRadioInputWhereLabelAndChoice("Injured?", "No");
		button.clickButtonWhereLabel("OK");
		textInput.enterTextinputWhereLabelFirstOccurence("Vehicle Mileage", "12345");
		button.clickButtonWhereLabel("OK");
		button.clickButtonWhereLabel("Next >");

		Thread.sleep(1000);
		button.clickButtonWhereLabel("Next >");

		rangeInput.enterRangeInputWhereLabelFirstOccurence("Decline Reason", "Prefers Check");
		button.clickButtonWhereAnyLetterUnderLined("Finish", "F");
		conventional.clickViewNewlySavedClaim();
	    
	}

	@When("^Write a check to the Insured$")
	public void write_a_check_to_the_Insured() throws Throwable {
	    
		Thread.sleep(30000);
		conventional.clickActions();
		conventional.clickCheck();
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Reserve Line",
				"(1) 1st Party Vehicle - MORRIS SMITH; Comprehensive/Non-Medical Loss/-");
		textInput.enterTextinputWhereLabelFirstOccurence("Amount", "100");
		button.clickButtonWhereLabel("Apply Deductible");
		button.clickButtonWhereLabel("Next >");
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Type", "Insured");
		button.clickButtonWhereLabel("Next >");
		button.clickButtonWhereLabel("Finish");
	
	}

	@Then("^Validate the Check is created to the Insured in Auto claim$")
	public void validate_the_Check_is_created_to_the_Insured_in_Auto_claim() throws Throwable {
	   
		System.out.println("Check has been crreated successfully");
	}
}
