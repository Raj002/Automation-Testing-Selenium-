package navigatorSmoke;


import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import businessComponents.TabBar;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import functionalLibrary.DataStorage;
import functionalLibrary.ObjectMethods;
import functionalLibrary.WebDriverFactory;

import pageObjects.ButtonScriptless;
import pageObjects.CheckBoxScriptless;
import pageObjects.Conventional;
import pageObjects.LabelScriptless;
import pageObjects.LinkScriptless;
import pageObjects.LoginDV;
import pageObjects.RadioInputScriptless;
import pageObjects.RangeInputScriptless;
import pageObjects.SideMenuScriptless;
import pageObjects.TableActionScriptless;
import pageObjects.TextAreaInputScriptless;
import pageObjects.TextInputScriptless;
public class HomeSmoke {

	static Logger log = Logger.getLogger(HomeSmoke.class);

	/** The driver. */
	WebDriverFactory webDriverFactory;
	WebDriver driver;
	
	ButtonScriptless button;
	TextInputScriptless textInput;
	SideMenuScriptless sideMenuScriptless;
	RangeInputScriptless rangeInput;
	TextAreaInputScriptless textArea;
	LoginDV loginDv;
	TabBar tabBar;
	RadioInputScriptless radioInputScriptless;
	TableActionScriptless tableAction;
	LinkScriptless link;
	LabelScriptless label;
	RadioInputScriptless radioInput;
	TextAreaInputScriptless textAreaInput;
	Conventional conventional;
	CheckBoxScriptless checkBox;

	ObjectMethods objectMethods = new ObjectMethods();
	Properties prop = DataStorage.loadProperties();
	String  url = prop.getProperty("landing.page.url");
	
	/** Page objects Initialization */
	public HomeSmoke (){
		
		driver = WebDriverFactory.getWebDriver(prop.getProperty("webdriver.browserType"));
		button = new ButtonScriptless(driver);
		textInput = new TextInputScriptless(driver);
		sideMenuScriptless = new SideMenuScriptless(driver);
		rangeInput = new RangeInputScriptless(driver);
		textArea = new TextAreaInputScriptless(driver);
		loginDv = new LoginDV(driver);
		tabBar = new TabBar(driver);
		radioInputScriptless = new RadioInputScriptless(driver);
		tableAction = new TableActionScriptless(driver);
		link = new LinkScriptless(driver);
		label = new LabelScriptless(driver);
		radioInput = new RadioInputScriptless(driver);
		textAreaInput = new TextAreaInputScriptless(driver);
		conventional = new Conventional(driver);
		checkBox = new CheckBoxScriptless(driver);
		
	}
	
	@Given("^Login to Navigator as an Adjuster$")
	public void login_to_Navigator_as_an_Adjuster() throws Throwable {
	    
		driver.get(url);
		loginDv.setUserName("n9986530");
		loginDv.setPassword("pmcng928");
		loginDv.clickSubmitButton();
		driver.manage().window().maximize();
	}

	@When("^Create an Home claim$")
	public void create_an_Home_claim() throws Throwable {
		button.clickNewClaim();
		radioInput.clickRadioInputWhereLabelAndChoice("Create New Claim:", "Property");
		radioInput.clickRadioInputWhereLabelAndChoice("Policy Provider:", "Liberty");
		textInput.enterTextinputWhereLabelFirstOccurence("Date of Loss", "10/01/2014");
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Time of Loss", "03:30 AM");
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Loss State", "Maine");
		radioInput.clickRadioInputWhereChoice("Policy #");
		textInput.enterTextinputWhereLabelFirstOccurence("Policy #", "H6524301798340");
		button.clickButtonWhereAnyLetterUnderLined("Search", "S");
		Thread.sleep(5000);
		button.clickButtonWhereLabel("Next >");
		button.clickButtonWhereAnyLetterUnderLined("Close", "e");
		button.clickButtonWhereLabel("Next >"); 
		
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Name", "CONDO ABP NEBRASKA");
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Relation to Insured", "Self");
		button.clickButtonWhereLabel("Next >");
		
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Loss Category", "Wind");
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Loss Cause", "Wind");
		objectMethods.hardWait(2000);
		textAreaInput.enterTextAreaInputWhereLabelFirstOccurence("Loss Description", "Test");
		
		radioInput.clickRadioInputWhereLabelAndChoice("Is a Contractor identified to perform repairs?","No");
		checkBox.checkCheckBoxWhereLabelFirstOccurence("Personal Property");
		textAreaInput.enterTextAreaInputWhereLabelFirstOccurence("Damage Description","Test");
		radioInput.clickRadioInputWhereLabelAndChoice("Incident Only?","No");
		checkBox.checkCheckBoxWhereLabelFirstOccurence("Electronics/Appliances");
		button.clickButtonWhereLabel("Next >");
		
		objectMethods.hardWait(2000);
		button.clickButtonWhereLabel("Next >");
		
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Decline Reason", "Prefers Check");
		button.clickButtonWhereAnyLetterUnderLined("Finish", "F");
		
		objectMethods.hardWait(5000);
		conventional.clickViewNewlySavedClaim();
		
	    
	}

	@Then("^Validate the Home Claim is created as expeected$")
	public void validate_the_Home_Claim_is_created_as_expeected() throws Throwable {
		System.out.println("Claim submitted successfully");
	    
	}
	
}
