package testRunners.SmokeRunners;

import java.io.File;

import org.junit.AfterClass;
import org.junit.runner.RunWith;


import com.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;

import cucumber.api.junit.Cucumber;
import functionalLibrary.DataStorage;


@RunWith(Cucumber.class)
@CucumberOptions(
		features = "Feature/NavigatorSmoke"
		, glue = { "navigatorSmoke" }
		//,tags = {"@SmokeTest"}
		,plugin = { "com.cucumber.listener.ExtentCucumberFormatter:target/Extent-reports/NavSmokeTest.html"}
		)
public class SmokExtentRunner {
	@AfterClass
	public static void writeExtentReport() {
		Reporter.loadXMLConfig(new File(DataStorage.getReportConfigPath()));
		//Reporter.
		  Reporter.setSystemInfo("User Name", System.getProperty("user.name"));
		    Reporter.setSystemInfo("Time Zone", System.getProperty("user.timezone"));
		    Reporter.setSystemInfo("Machine", 	"Windows 10" + "64 Bit");
		    Reporter.setSystemInfo("Selenium", "3.7.0");
		    Reporter.setSystemInfo("Maven", "3.5.2");
		    Reporter.setSystemInfo("Java Version", "1.8.0_151");
	}
	
	
	
	
	
	
}
