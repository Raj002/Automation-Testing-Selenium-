package ciccTest;





import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


import ciccObjectRepo.ButtonCicc;
import ciccObjectRepo.LabelCicc;
import ciccObjectRepo.PickerCicc;
import ciccObjectRepo.RadioCicc;
import ciccObjectRepo.RangeInputCicc;
import ciccObjectRepo.TextAreaCicc;
import ciccObjectRepo.TextInputCicc;
import ciccObjectRepo.TopHeaderCicc;
import ciccObjectRepo.WebTableCicc;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import functionalLibrary.DataStorage;
import functionalLibrary.Hooks;
import functionalLibrary.ObjectMethods;
import functionalLibrary.WebDriverFactory;

import pageObjects.LoginDV;
import cucumber.api.Scenario;

public class CreateClaimOnUnverifiedPolicy {

	//static Logger log = Logger.getLogger(CreateClaimOnUnverifiedPolicy.class);
	

	/** Declare The driver and Cucumber Hooks  */
	WebDriverFactory webDriverFactory;
	WebDriver driver;	
	Hooks hooks;
	Scenario scenario;
	
	// Declare the Object Repository
	LoginDV loginDv;
	ButtonCicc buttonCicc;
	RadioCicc radioCicc;
	RangeInputCicc rangeInputCicc;
	TextInputCicc textInputCicc;
	WebTableCicc webTableCicc;
	PickerCicc pickerCicc;
	TopHeaderCicc topHeaderCicc;
	LabelCicc labelCicc;
	TextAreaCicc textAreaCicc;
	
	// Initialize Object wait and Properties file
	ObjectMethods objectMethods = new ObjectMethods();	
	Properties prop = DataStorage.loadProperties();
	String  url = prop.getProperty("landing.page.url.cicc");
	
	
	/** Page objects Initialization */
	public CreateClaimOnUnverifiedPolicy (){
		
		// Initialize the driver & hooks
		driver = WebDriverFactory.getWebDriver(prop.getProperty("webdriver.browserType"));
		hooks = new Hooks (driver);		
		
		// Initialize the Object Repository
		loginDv = new LoginDV(driver);
		buttonCicc = new ButtonCicc(driver);
		radioCicc = new RadioCicc(driver);
		rangeInputCicc = new RangeInputCicc(driver);
		textInputCicc = new TextInputCicc(driver);
		webTableCicc = new WebTableCicc(driver);
		pickerCicc = new PickerCicc(driver);
		topHeaderCicc = new TopHeaderCicc(driver);
		labelCicc = new LabelCicc (driver);
		textAreaCicc = new TextAreaCicc(driver);
	}
	
	
	
	@Before
	public void before(Scenario scenario) {
	    this.scenario = scenario;
	}
	@After
	public void captureFailureScreens(Scenario scenario){
		
		hooks.afterScenario(scenario);		
	}
	
	@Given("^Login to CICC$")
	public void login_to_CICC() throws Throwable {
		driver.get(url);
		driver.manage().window().maximize();
		loginDv.setUserName("n9989163");
		loginDv.setPassword("csrtest1");
		loginDv.clickSubmitButton();		
	   
	}

	@When("^Create an BZS claim$")
	public void create_an_BZS_claim() throws Throwable {
		/*
		topHeaderCicc.clickTopBarMenu("AdminTab");
		ArrayList<String> assertFields = new ArrayList<String>();

		assertFields.add("Name");
		assertFields.add("Type");
		webTableCicc.validateTableContent("GroupDetailPage:GroupDetailScreen:GroupDetailDV",assertFields);
		*/
		
		// Step 1: Search or Create Policy
		//Page 1 - Section 1
		buttonCicc.clickNewClaim();
		radioCicc.clickRadioInputWhereChoice("Create Unverified Policy");
		rangeInputCicc.enterRangeInputWhereLabelFirstOccurence("Source System", "OCAS");		
		textInputCicc.enterTextinputWhereLabelFirstOccurence("Policy Symbol", "BZS");
		textInputCicc.enterTextinputWhereLabelFirstOccurence("Policy Account Number", "12345678");		
		rangeInputCicc.enterRangeInputWhereLabelFirstOccurence("Type", "Business Owners Policy");
		driver.switchTo().alert().accept();
		textInputCicc.enterTextinputWhereLabelFirstOccurence("Loss Date", "02/07/2018");
		textInputCicc.clearTextinputWhereLabelFirstOccurence("Time");		
		//Basic Information
		
		textInputCicc.enterTextinputWhereLabelFirstOccurence("Effective Date", "02/07/2018");
		textInputCicc.enterTextinputWhereLabelFirstOccurence("Expiration Date", "02/07/2019");
		textInputCicc.enterTextinputWhereLabelFirstOccurence("Original Effective Date", "02/07/2018");		
		//Insured
		rangeInputCicc.enterRangeInputWhereLabelFirstOccurence("Policy State", "Washington");		
		//Underwriting
		rangeInputCicc.enterRangeInputWhereLabelFirstOccurence("Underwriting Company", "Ohio Casualty");		
		//Policy-level coverage
		buttonCicc.jsClickAddButton("PolicyCoverages");
		webTableCicc.enterRangeInputInWebTable("PolicyCoverages", "Type", "Business Liability");
		textInputCicc.clearTextinputWhereLabelFirstOccurence("Time");		
		//PickerMenu - Add Insured Name
		pickerCicc.clickPickerArrowWhereLabelFirstOccurence("Insured_Name");
		pickerCicc.clickPickerLink("Insured_Name", "NewPerson");				
		textInputCicc.enterTextinputWhereLabelFirstOccurence("Last name", "Ram");
		textInputCicc.enterTextinputWhereLabelFirstOccurence("First name", "Pothi");
		buttonCicc.clickButtonWhereLabelFirstOccurence("OK");					
		//Agent
		textInputCicc.enterTextinputWhereLabelFirstOccurence("Agency Code", "490360");
		textInputCicc.clearTextinputWhereLabelFirstOccurence("Time");
		buttonCicc.jsClickButtonWhereLabel("Validate Agency Code");
		System.out.print("Clicked AG code  ");
		labelCicc.waitUntilLabelDisplayed("Agency Verified", "Yes");
		System.out.print("YES Displayed");
		textInputCicc.clearTextinputWhereLabelFirstOccurence("Time");		
		//Click Next
		buttonCicc.clickButtonWhereLabelFirstOccurence("Next >");
		
		
		// Step 2 of 6: BasicInformation
		rangeInputCicc.enterRangeInputWhereLabelFirstOccurence("Name", "Pothi Ram");
		buttonCicc.clickButtonWhereLabelFirstOccurence("Next >");
		buttonCicc.clickButtonWhereLabelFirstOccurence("Next >");
		buttonCicc.clickButtonWhereAnyLetterUnderLined("Close","e");
		buttonCicc.clickButtonWhereLabelFirstOccurence("Next >");
		
		//Step 3 of 6: Add claim information
		textAreaCicc.enterTextAreaWhereLabelFirstOccurence("Loss Description", "Test Description");
		rangeInputCicc.enterRangeInputWhereLabelFirstOccurence("Loss Cause", "Breakage");
		rangeInputCicc.enterRangeInputWhereLabelFirstOccurence("Detailed Loss Cause", "Breakage");
		rangeInputCicc.enterRangeInputWhereLabelFirstOccurence("How Reported", "Phone");
		textInputCicc.enterTextinputWhereLabelFirstOccurence("City", "PORTLAND");
		objectMethods.hardWait(5000);
		rangeInputCicc.enterRangeInputWhereLabelFirstOccurence("State", "Maine");
		radioCicc.clickRadioInputWhereLabelAndChoiceisYesOrNo("On Premises?", "No");
		radioCicc.clickRadioInputWhereLabelAndChoiceisYesOrNo("Involves Heavy Equipment?", "No");
		buttonCicc.clickButtonWhereLabelFirstOccurence("Next >");
		
		//Step 4 of 6: Manage parties involved
		buttonCicc.clickButtonWhereLabelFirstOccurence("Next >");
		
		//Step 6 of 6: Save and Assign Claim
		buttonCicc.clickButtonWhereAnyLetterUnderLined("Finish","F");
		
		
		
	}

	@Then("^Validate the Claim Creation$")
	public void validate_the_Claim_Creation() throws Throwable {
	    
		String actualString = driver.findElement(By.xpath("//*[contains(@id,'NewClaimSavedDV:Header')]")).getText();
		System.out.println(actualString);
		assertTrue(actualString.contains("has been successfully saved"));
	}


}
