package functionalLibrary;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.cucumber.listener.Reporter;


import cucumber.api.Scenario;

public class Hooks {
	
WebDriver driver;
	
	public Hooks(WebDriver driver) {
		this.driver = driver;
	}
	
	
	public void afterScenario(Scenario scenario) {
		
		if (scenario.isFailed()) {
			String screenshotName = scenario.getName().replaceAll(" ", "_");
			try {
				//This takes a screenshot from the driver at save it to the specified location
				File sourcePath = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				
				//Also make sure to create a folder 'screenshots' with in the cucumber-report folder
				File destinationPath = new File(System.getProperty("user.dir") + "/target/Extent-screenshots/" + screenshotName + ".png");
		
				//Copy taken screenshot from source location to destination location
				
				FileUtils.copyFile(sourcePath, destinationPath);
		
				//This attach the specified screenshot to the test
				Reporter.addScreenCaptureFromPath(destinationPath.toString());
		
			} catch (IOException e) {
			} 
		}
	}
	
	

}
