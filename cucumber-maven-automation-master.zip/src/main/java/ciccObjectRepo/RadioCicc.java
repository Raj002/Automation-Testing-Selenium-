package ciccObjectRepo;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import functionalLibrary.ObjectMethods;





public class RadioCicc {
	
	WebDriver driver;

	public RadioCicc (WebDriver driver) {
		this.driver = driver;
	}

	ObjectMethods objectMethods = new ObjectMethods();

	private static final Logger LOG = LogManager.getLogger(RadioCicc.class);
	
	   public void jsClick(WebElement element){
	    	
	    	
	    	JavascriptExecutor executor = (JavascriptExecutor)driver;
	    	executor.executeScript("arguments[0].click();", element);
	    }
	
	 public RadioCicc clickRadioInputWhereLabelAndChoiceisYesOrNo(String labelName, String value)
	    {

	        boolean isFlagged = false;

	        while (!isFlagged)
	        {
	            try
	            {
	            	if(value == "No") {
	            		
	            		By radioInputele = By.xpath("//input[@class='radio' and @label = '" + labelName + "' and contains(@id , 'false')]");
		            	objectMethods.findObject(driver, radioInputele, 30);          	            
		                WebElement radioInput = driver.findElement(radioInputele);
		                jsClick(radioInput);
		                //radioInput.click();
	            	}
	            	else if (value == "Yes") {
	            		driver.switchTo().frame("top_frame"); 
	            		By radioInputele = By.xpath("//input[@class='radio' and @label = '" + labelName + "' and contains(@id , 'true')]");
		            	objectMethods.findObject(driver, radioInputele, 30);          	            
		                WebElement radioInput = driver.findElement(radioInputele);
		                jsClick(radioInput);
		                //radioInput.click();
	            	}
	            	
	                
	               
	                break;
	            }
	            catch (StaleElementReferenceException e)
	            {
	                LOG.info("Into Stale");
	                continue;
	            }
	        }

	        return this;

	    }

	    public RadioCicc clickRadioInputWhereChoice(String value)
	    {

	        boolean isFlagged = false;
	        while (!isFlagged)
	        {
	            try
	            {
	            	driver.switchTo().activeElement();
	            	By radioInputele = By.xpath("//span[text()='" + value + "']/preceding :: input[@type='radio'][1]");
	                objectMethods.findObject(driver, radioInputele, 30);
	                WebElement radioInput = driver.findElement(radioInputele);
	                //jsClick(radioInput);
	                radioInput.click();
	                break;
	            }
	            catch (StaleElementReferenceException e)
	            {
	                LOG.info("Into Stale");
	            }
	        }

	        return this;

	    }

}
