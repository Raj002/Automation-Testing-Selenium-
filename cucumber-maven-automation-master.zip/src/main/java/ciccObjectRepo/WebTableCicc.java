package ciccObjectRepo;


import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import functionalLibrary.DataStorage;
import functionalLibrary.ObjectMethods;


public class WebTableCicc {

	WebDriver driver;

	public WebTableCicc(WebDriver driver) {
		this.driver = driver;
	}

	ObjectMethods objectMethods = new ObjectMethods();

	private static final Logger LOG = LogManager.getLogger(WebTableCicc.class);
	
	Properties prop = DataStorage.loadProperties();

	public void jsClick(WebElement element) {

		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", element);
	}

	public WebTableCicc enterRangeInputInWebTable(String tableId, String headerName, String value) {

		boolean isFlagged = false;
		while (!isFlagged) {
			try {

				Select oSelect = new Select(driver.findElement(
						By.xpath("//table[contains(@id, '" + tableId + "')]//select[@label = '" + headerName + "']")));
				oSelect.selectByVisibleText(value);

				break;
			} catch (StaleElementReferenceException e) {
				LOG.info("Into Stale");
				continue;
			}
		}

		return this;

	}
	
	public void validateTableContent(String tableId, ArrayList<String> assertFields) {
		Map<String, String> tabelContent = getTableContent(tableId);
		//Get length of asserFields
		int fieldCount = assertFields.size();
		
		for (int i = 0 ; i < fieldCount ; i ++) {
			
			System.out.println("FIELD VALIDATION ************" + assertFields.get(i));
			String actualValue = tabelContent.get(assertFields.get(i));
			String expectedValue = prop.getProperty("adminScreen.expected."+ assertFields.get(i));
			System.out.println("PASS");
			assertEquals(actualValue,expectedValue);
			
		}
		
		
		String actualValue = tabelContent.get("Name");
		String expectedValue = "LM Commercial Insurance";
		assertEquals(actualValue,expectedValue);
		
		
		
	}

	public Map<String, String> getTableContent(String tableId) {
		
		Map<String, String> map = new HashMap<String, String>();
		boolean isFlagged = false;
		while (!isFlagged) {
			try {

				// Get the Table locator

				By elementBy = By.xpath("//table[contains(@id,'" + tableId + "') and @class = 'dvColumn']//tr");
				objectMethods.findObject(driver, elementBy, 60);
				List<WebElement> element = driver.findElements(elementBy);

				// Get Number of Rows
				int rowcount = element.size();

				//Declare a Map Variable
				//Map<String, String> map = new HashMap<String, String>();

				// Get the field Names and Values in all the Rows
				for (int i = 1; i <= rowcount; i++) {

					// FieldName

					By fieldNameBy = By.xpath("//table[contains(@id,'" + tableId + "') and @class = 'dvColumn']"
							+ "//tr[" + i + "]/td[@class= 'inputLabel']/label");
					objectMethods.findObject(driver, fieldNameBy, 60);
					WebElement fieldNameEle = driver.findElement(fieldNameBy);

					// FieldValues

					By fieldValueBy = By.xpath("//table[contains(@id,'" + tableId + "') and @class = 'dvColumn']"
							+ "//tr[" + i + "]/td[@class= 'inputContent']");
					objectMethods.findObject(driver, fieldValueBy, 60);
					WebElement fieldValueEle = driver.findElement(fieldValueBy);

					map.put(fieldNameEle.getText(), fieldValueEle.getText());

				}

				
				break;
			} catch (StaleElementReferenceException e) {
				LOG.info("Into Stale");
				continue;
			}
		}

		return map;

	}
	
	

}
