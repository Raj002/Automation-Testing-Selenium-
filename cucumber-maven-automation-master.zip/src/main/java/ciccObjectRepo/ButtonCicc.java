package ciccObjectRepo;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import functionalLibrary.ObjectMethods;



public class ButtonCicc {
	
	WebDriver driver;
	
	public ButtonCicc (WebDriver driver) {
		this.driver = driver;
	}
	
	ObjectMethods objectMethods = new ObjectMethods();
	
	private static final Logger LOG = LogManager.getLogger(ButtonCicc.class);
	
    
   public void jsClick(WebElement element){
    	
    	
    	JavascriptExecutor executor = (JavascriptExecutor)driver;
    	executor.executeScript("arguments[0].click();", element);
    }

	public ButtonCicc clickNewClaim() throws InterruptedException
	   {

	       boolean isFlagged = false;

	       while (!isFlagged)
	       {
	           try
	           {
	        	   
	        	   driver.switchTo().frame("top_frame"); 
	        	   By buttonBy =  By.xpath("//input[@name = 'QuickJump']"); 	      
	        	   System.out.println("Object Found");
	        	   objectMethods.findObject(driver, buttonBy, 60);    	   
	        	          	   
	        	   
	        	   WebElement buttonEle = driver.findElement(buttonBy);
	        	   buttonEle.sendKeys("NewClaim");
	        	   driver.switchTo().activeElement().sendKeys(Keys.chord(Keys.ENTER)); 
	        	   
	               break;
	           }
	           catch (StaleElementReferenceException e)
	           {
	               LOG.info("Into Stale");
	               continue;
	           }
	       }

	       return this;

	   }
	
	public ButtonCicc clickButtonWhereLabelFirstOccurence(String labelName)
			throws InterruptedException {

		clickButtonWhereLabelNthOccurence(labelName, "1");

		return this;

	}
	
	  public ButtonCicc clickButtonWhereLabelNthOccurence(String labelName, String occurnence)
	    {

	        boolean isFlagged = false;

	        while (!isFlagged)
	        {
	            try
	            {

	            	By buttonBy =  By.xpath("(//*[contains(text(),'" + labelName + "')]/parent :: a[@class = 'button'])["
	                        + occurnence + "]");
	            	objectMethods.findObject(driver, buttonBy, 30);          	            
	                WebElement buttonEle = driver.findElement(buttonBy);
	                buttonEle.isDisplayed();
	                ((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+buttonEle.getLocation().y+")");
	                 buttonEle.click();
	                
	               
	                break;
	         
	            }
	            catch (StaleElementReferenceException e)
	            {
	                LOG.info("Into Stale");
	                continue;
	            }
	        }

	        return this;

	    }
	    
	    public ButtonCicc clickButtonWhereAnyLetterUnderLined(String labelName, String underLinedLetter)
	    {

	        boolean isFlagged = false;

	        while (!isFlagged)
	        {
	            try
	            {

	            	By buttonBy =  By.xpath("//span[@class='underlined' and text() = '" + underLinedLetter + "']");
	            	objectMethods.findObject(driver, buttonBy, 30);          	            
	                WebElement buttonEle = driver.findElement(buttonBy);
	                buttonEle.click();
	                
	               
	                break;
	            }
	            catch (StaleElementReferenceException e)
	            {
	                LOG.info("Into Stale");
	                continue;
	            }
	        }

	        return this;

	    }
	    
		public ButtonCicc jsClickButtonWhereLabel(String labelName)
	    {

			jsClickButtonWhereLabelNthOccurence(labelName, "1");
	        return this;

	    }
	    
	    
	    public ButtonCicc jsClickButtonWhereLabelNthOccurence(String labelName, String occurnence)
	    {

	        boolean isFlagged = false;

	        while (!isFlagged)
	        {
	            try
	            {

	            	By buttonBy =  By.xpath("(//*[contains(text(),'" + labelName+ "')]/parent :: a[@class = 'button'])["
	                        + occurnence + "]");
	            	objectMethods.findObject(driver, buttonBy, 30);          	            
	                WebElement buttonEle = driver.findElement(buttonBy);
	                jsClick(buttonEle);                
	               
	                break;
	            }
	            catch (StaleElementReferenceException e)
	            {
	                LOG.info("Into Stale");
	                continue;
	            }
	        }

	        return this;

	    }
	    
	    public ButtonCicc jsClickAddButton(String labelName)
	    {

	        boolean isFlagged = false;

	        while (!isFlagged)
	        {
	            try
	            {

	            	By buttonBy =  By.xpath("//div[contains(@id,'" + labelName+ "')]//a//span[contains(text(),'Add')]");
	            	objectMethods.findObject(driver, buttonBy, 30);          	            
	                WebElement buttonEle = driver.findElement(buttonBy);
	                jsClick(buttonEle);                
	               
	                break;
	            }
	            catch (StaleElementReferenceException e)
	            {
	                LOG.info("Into Stale");
	                continue;
	            }
	        }

	        return this;

	    }

	
}
