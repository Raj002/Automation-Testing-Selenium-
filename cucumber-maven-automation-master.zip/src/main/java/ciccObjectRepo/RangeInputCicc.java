package ciccObjectRepo;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import functionalLibrary.ObjectMethods;


public class RangeInputCicc {
	
	WebDriver driver;

	public RangeInputCicc (WebDriver driver) {
		this.driver = driver;
	}

	ObjectMethods objectMethods = new ObjectMethods();

	private static final Logger LOG = LogManager.getLogger(RangeInputCicc.class);
	
	public void jsClick(WebElement element) {

		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", element);
	}
	
	public RangeInputCicc enterRangeInputWhereLabelFirstOccurence(String labelName, String value) {

		enterRangeInputWhereLabelNthOccurence(labelName, value, "1");
		return this;

	}

	public RangeInputCicc enterRangeInputWhereLabelNthOccurence(String labelName, String value,
			String occurnence) {

		boolean isFlagged = false;
		while (!isFlagged) {
			try {
								
				Select oSelect = new Select(driver.findElement(By.xpath("//select[@label = '" + labelName + "'][" + occurnence + "]")));
				oSelect.selectByVisibleText(value);				
				
				break;
			} catch (StaleElementReferenceException e) {
				LOG.info("Into Stale");
				continue;
			}
		}

		return this;

	}

}
