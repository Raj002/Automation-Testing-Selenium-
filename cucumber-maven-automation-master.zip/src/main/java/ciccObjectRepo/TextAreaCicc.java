package ciccObjectRepo;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import functionalLibrary.ObjectMethods;

public class TextAreaCicc {
	WebDriver driver;

	public TextAreaCicc (WebDriver driver) {
		this.driver = driver;
	}

	ObjectMethods objectMethods = new ObjectMethods();

	private static final Logger LOG = LogManager.getLogger(TextAreaCicc.class);
	
	   public void jsClick(WebElement element){
	    	
	    	
	    	JavascriptExecutor executor = (JavascriptExecutor)driver;
	    	executor.executeScript("arguments[0].click();", element);
	    }
	   
	   public TextAreaCicc enterTextAreaWhereLabelFirstOccurence(String labelName, String value)
				throws InterruptedException {

		   enterTextAreaWhereLabelNthOccurence(labelName, value, "1");

			return this;

		}

		public TextAreaCicc enterTextAreaWhereLabelNthOccurence(String labelName, String value, String occurnence)
				throws InterruptedException {

			boolean isFlagged = false;

			while (!isFlagged) {
				try {
					
					By textInputBy = By.xpath("//textarea[@label = '" + labelName+ "']");
					objectMethods.findObject(driver, textInputBy, 30);
					Thread.sleep(2000);
					WebElement textInputele = driver.findElement(textInputBy);
					textInputele.isDisplayed();
					

					((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + textInputele.getLocation().y + ")");
					//textInputele.clear();
					textInputele.sendKeys(Keys.CONTROL + "a");
					textInputele.sendKeys(Keys.DELETE);
					textInputele.sendKeys(value);
					textInputele.sendKeys(Keys.TAB);
					break;
				} catch (StaleElementReferenceException e) {
					LOG.info("Into Stale");
					continue;

				}

			}
			return this;

		}

}
