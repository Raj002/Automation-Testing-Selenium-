package ciccObjectRepo;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import functionalLibrary.ObjectMethods;

public class PickerCicc {
	WebDriver driver;

	public PickerCicc (WebDriver driver) {
		this.driver = driver;
	}

	ObjectMethods objectMethods = new ObjectMethods();

	private static final Logger LOG = LogManager.getLogger(PickerCicc.class);
	
	   public void jsClick(WebElement element){
	    	
	    	
	    	JavascriptExecutor executor = (JavascriptExecutor)driver;
	    	executor.executeScript("arguments[0].click();", element);
	    }
	   
	   public PickerCicc clickPickerArrowWhereLabelFirstOccurence(String labelName)
				throws InterruptedException {

		   clickPickerArrowWhereLabelNthOccurence(labelName, "1");

			return this;

		}
		
		  public PickerCicc clickPickerArrowWhereLabelNthOccurence(String labelName, String occurnence)
		    {

		        boolean isFlagged = false;

		        while (!isFlagged)
		        {
		            try
		            {

		            	By buttonBy =  By.xpath("(//span[contains(@id , '" + labelName+ "MenuIcon')]//a[contains(@id, '" + labelName+ 
		            			"MenuIcon')]/img)["
		                        + occurnence + "]");
		            	objectMethods.findObject(driver, buttonBy, 30);          	            
		                WebElement buttonEle = driver.findElement(buttonBy);
		                ((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+buttonEle.getLocation().y+")");
		                 buttonEle.click();
		                
		               
		                break;
		         
		            }
		            catch (StaleElementReferenceException e)
		            {
		                LOG.info("Into Stale");
		                continue;
		            }
		        }

		        return this;

		    }
		  
		  public PickerCicc clickPickerLink(String labelName, String pickerLink)
		    {

		        boolean isFlagged = false;

		        while (!isFlagged)
		        {
		            try
		            {

		            	By buttonBy =  By.xpath("//a[contains(@id , '" + labelName+ "') and contains (@id , '" + pickerLink+ "')]");
		            	objectMethods.findObject(driver, buttonBy, 30);          	            
		                WebElement buttonEle = driver.findElement(buttonBy);
		                ((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+buttonEle.getLocation().y+")");
		                 buttonEle.click();
		                
		               
		                break;
		         
		            }
		            catch (StaleElementReferenceException e)
		            {
		                LOG.info("Into Stale");
		                continue;
		            }
		        }

		        return this;

		    }

}
