package pageObjects;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.interactions.Actions;

import functionalLibrary.ObjectMethods;

public class Conventional {

	WebDriver driver;

	public Conventional(WebDriver driver) {
		this.driver = driver;
	}

	ObjectMethods objectMethods = new ObjectMethods();

	private static final Logger LOG = LogManager.getLogger(Conventional.class);

	// Common Objects

	

	public void jsClick(WebElement element) {

		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", element);
	}

	public Conventional selectVehicleLocation(String value) {

		boolean isFlagged = false;

		while (!isFlagged) {
			try {

				By rangeInput = By.xpath("//input[contains(@id,'VehicleLocDuringBusHrs_RangeInput')]");
				objectMethods.findObject(driver, rangeInput, 30);
				WebElement rangeInputele = driver.findElement(rangeInput);
				rangeInputele.clear();
				rangeInputele.sendKeys(value);
				rangeInputele.sendKeys(Keys.TAB);
				// Select dropList=new Select(rangeInputele);
				// dropList.selectByValue(value);
				break;
			} catch (StaleElementReferenceException e) {
				LOG.info("Into Stale");
				continue;
			}
		}
		return this;

	}

	public Conventional clickAddVehicle() {

		boolean isFlagged = false;

		while (!isFlagged) {
			try {
				By buttonBy = By.xpath("//span[contains(@id,'AddVehicleButton-btnInnerEl')]");
				objectMethods.findObject(driver, buttonBy, 30);
				WebElement buttonEle = driver.findElement(buttonBy);
				jsClick(buttonEle);
				break;
			} catch (StaleElementReferenceException e) {
				LOG.info("Into Stale");
				continue;
			}
		}
		return this;

	}

	public Conventional clickViewNewlySavedClaim() {

		boolean isFlagged = false;

		while (!isFlagged) {
			try {
				By linkBy = By.xpath("//a[contains(@id,'GoToTheClaim')]");
				objectMethods.findObject(driver, linkBy, 30);
				WebElement linknEle = driver.findElement(linkBy);
				jsClick(linknEle);
				break;
			} catch (StaleElementReferenceException e) {
				LOG.info("Into Stale");
				continue;
			}
		}
		return this;

	}

	public Conventional clickActions() {

		boolean isFlagged = false;

		while (!isFlagged) {
			try {
				By buttonBy = By.xpath("//span[contains(@id,'ClaimMenuActions-btnInnerEl')]");
				objectMethods.findObject(driver, buttonBy, 30);
				WebElement buttonEle = driver.findElement(buttonBy);
				jsClick(buttonEle);
				break;
			} catch (StaleElementReferenceException e) {
				LOG.info("Into Stale");
				continue;
			}
		}
		return this;
	}

	public Conventional clickPickerToAddNewPerson() {

		boolean isFlagged = false;

		while (!isFlagged) {
			try {
				By buttonBy = By.xpath("//a[contains(@id,'InjuryInputAuto:Vehicle:VehicleMenuIcon')]");
				objectMethods.findObject(driver, buttonBy, 30);
				WebElement buttonEle = driver.findElement(buttonBy);
				jsClick(buttonEle);

				objectMethods.hardWait(2000);

				buttonBy = By.xpath("//*[contains(text(),'Add New Person to Vehicle')]");
				objectMethods.findObject(driver, buttonBy, 30);
				buttonEle = driver.findElement(buttonBy);
				jsClick(buttonEle);

				break;
			} catch (StaleElementReferenceException e) {
				LOG.info("Into Stale");
				continue;
			}
		}
		return this;
	}

	public Conventional clickCheck() {
		boolean isFlagged = false;

		while (!isFlagged) {
			try {
				By buttonBy = By.xpath("//span[contains(@id,'ClaimMenuActions_NewTransaction_CheckSet')]");
				objectMethods.findObject(driver, buttonBy, 30);
				WebElement buttonEle = driver.findElement(buttonBy);
				jsClick(buttonEle);
				break;
			} catch (StaleElementReferenceException e) {
				LOG.info("Into Stale");
				continue;
			}
		}
		return this;
	}

//	public Conventional editNewAvilableReserve(String expData, String reseveValue) {
//		List<WebElement> rows = driver
//				.findElements(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
//						+ "EditableReservesLV-body']" + "/div/table/tbody/tr"));
//		int row = rows.size();
//		//NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:EditableReservesLV-body
//		//old // 
//		for (int i = 1; i <= row; i++) {
//
//			String strAmt = driver
//					.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
//							+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[3]"))
//					.getText().trim();
//
//			if (strAmt.contentEquals(expData.trim())) {
//
//				driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
//						+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[7]")).click();
//				objectMethods.hardWait(4000);
//				driver.switchTo().activeElement().clear();
//				driver.switchTo().activeElement().sendKeys(reseveValue);
//				driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
//						+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[3]")).click();
//				objectMethods.hardWait(4000);
//				return this;
//			}
//		}
//		return this;
//
//	}
//
//	public Conventional editReserveComment(String expData, String reserveComment) {
//
//		List<WebElement> rows = driver
//				.findElements(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
//						+ "EditableReservesLV-body']" + "/div/table/tbody/tr"));
//		int row = rows.size();
//
//		for (int i = 1; i <= row; i++) {
//
//			String strAmt = driver
//					.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
//							+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[3]"))
//					.getText().trim();
//
//			if (strAmt.contentEquals(expData.trim())) {
//
//				driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
//						+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[10]")).click();
//				objectMethods.hardWait(4000);
//				driver.switchTo().activeElement().clear();
//				driver.switchTo().activeElement().sendKeys(reserveComment);
//				driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
//						+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[3]")).click();
//				objectMethods.hardWait(4000);
//				return this;
//			}
//		}
//		return this;
//
//	}
//
//	public Conventional editReserveReason(String expData, String reserveReason) {
//
//		List<WebElement> rows = driver
//				.findElements(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
//						+ "EditableReservesLV-body']" + "/div/table/tbody/tr"));
//		int row = rows.size();
//
//		for (int i = 1; i <= row; i++) {
//
//			String strAmt = driver
//					.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
//							+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[3]"))
//					.getText().trim();
//
//			if (strAmt.contentEquals(expData.trim())) {
//
//				driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
//						+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[9]")).click();
//				objectMethods.hardWait(4000);
//				driver.switchTo().activeElement().clear();
//				driver.switchTo().activeElement().sendKeys(reserveReason);
//				driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
//						+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[3]")).click();
//				objectMethods.hardWait(4000);
//				return this;
//			}
//		}
//		return this;
//
//	}

	public Conventional selectReserveReason(String value) {
		List<WebElement> rows = driver
				.findElements(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
						+ "EditableReservesLV-body']" + "/div/table/tbody/tr"));
		int row = rows.size();
		String rowVal = Integer.toString(row);
		driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
				+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + rowVal + "]/td[9]")).click();
		objectMethods.hardWait(4000);
		driver.switchTo().activeElement().clear();
		driver.switchTo().activeElement().sendKeys(value);
		driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
				+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + rowVal + "]/td[8]")).click();
		objectMethods.hardWait(4000);
		return this;
	}

	/**
	 * Select exposure to add
	 * 
	 * @param value
	 */

	public Conventional selectExposureToAdd(String value) {
		List<WebElement> rows = driver
				.findElements(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
						+ "EditableReservesLV-body']" + "/div/table/tbody/tr"));
		int row = rows.size();
		String rowVal = Integer.toString(row);
		driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
				+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + rowVal + "]/td[2]")).click();

		objectMethods.hardWait(4000);
		List<WebElement> exposuresVisible = driver.findElements(By.tagName("li"));
		if (exposuresVisible.isEmpty()) {
			Actions actions = new Actions(driver);
			actions.moveToElement(
					driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
							+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + rowVal + "]/td[2]")));
			actions.click();
			actions.doubleClick();
			actions.build().perform();
		}

		objectMethods.hardWait(2000);
		List<WebElement> exposures = driver.findElements(By.xpath("//body/div/div/ul[@class='x-list-plain']/li"));
		for (int i = 1; i <= exposures.size(); i++) {
			WebElement listItem = driver
					.findElement(By.xpath("//body/div/div/ul[@class='x-list-plain']/li[@class='x-boundlist-item']["
							+ Integer.toString(i) + "]"));

			if (listItem.getText().contains(value)) {

				Actions actions = new Actions(driver);
				actions.moveToElement(listItem);
				actions.click(listItem);
				actions.build().perform();

				break;
			}
		}
		objectMethods.hardWait(2000);
		driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
				+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + rowVal + "]/td[3]")).click();
		objectMethods.hardWait(2000);

		return this;
	}

	/**
	 * Select Cost Type
	 * 
	 * @param value
	 */

	public Conventional selectCostType(String value) {
		List<WebElement> rows = driver
				.findElements(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
						+ "EditableReservesLV-body']" + "/div/table/tbody/tr"));
		int row = rows.size();
		String rowVal = Integer.toString(row);
		driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
				+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + rowVal + "]/td[4]")).click();
		objectMethods.hardWait(4000);
		driver.switchTo().activeElement().clear();
		driver.switchTo().activeElement().sendKeys(value);
		driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
				+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + rowVal + "]/td[3]")).click();
		objectMethods.hardWait(4000);
		return this;
	}

	/**
	 * Enter's Value into New Available Reserves Edit.
	 * 
	 * @param value
	 */

	public Conventional setNewAvailableReserves(String value) {
		List<WebElement> reservesTableRows = driver.findElements(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
				+ "EditableReservesLV-body']" + "/div/table/tbody/tr"));
		int row = reservesTableRows.size();
		String rowVal = Integer.toString(row);
		driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
				+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + rowVal + "]/td[7]")).click();
		objectMethods.hardWait(4000);
		driver.switchTo().activeElement().clear();
		driver.switchTo().activeElement().sendKeys(value);
		driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
				+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + rowVal + "]/td[3]")).click();
		objectMethods.hardWait(4000);
		return this;
	}

	/**
	 * Enter's Comment
	 * 
	 * @param value
	 */

	public Conventional setComment(String value) {
		List<WebElement> rows = driver
				.findElements(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
						+ "EditableReservesLV-body']" + "/div/table/tbody/tr"));
		int row = rows.size();
		String rowVal = Integer.toString(row);
		driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
				+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + rowVal + "]/td[10]")).click();
		objectMethods.hardWait(4000);
		// WebElement element = driver.findElement(By.name("Comments"));
		driver.switchTo().activeElement().clear();
		driver.switchTo().activeElement().sendKeys(value);
		// element.sendKeys(value);
		driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
				+ "EditableReservesLV-body']" + "/div/table/tbody/tr[" + rowVal + "]/td[3]")).click();
		objectMethods.hardWait(4000);
		return this;
	}
	
	public Conventional clickClaimCard()
	{
		boolean isFlagged = false;

	    while (!isFlagged)
	    {
	        try
	        {
		By buttonBy =  By.xpath("//span[contains(@id,'ClaimMenuActions_NewTransaction_ClaimCard')]");
		objectMethods.findObject(driver, buttonBy, 30);          	            
	    WebElement buttonEle = driver.findElement(buttonBy);
	    jsClick(buttonEle);
	    break;
	        }
	        catch (StaleElementReferenceException e)
	        {
	            LOG.info("Into Stale");
	            continue;
	        }
	    }
	    return this;
	}

	public Conventional clickReserve()
	{
		boolean isFlagged = false;

	    while (!isFlagged)
	    {
	        try
	        {
		By buttonBy =  By.xpath("//span[contains(@id,'ClaimMenuActions_NewTransaction_ReserveSet')]");
		objectMethods.findObject(driver, buttonBy, 30);          	            
	    WebElement buttonEle = driver.findElement(buttonBy);
	    jsClick(buttonEle);
	    break;
	        }
	        catch (StaleElementReferenceException e)
	        {
	            LOG.info("Into Stale");
	            continue;
	        }
	    }
	    return this;
	}

	public Conventional clickPayeeNameMenuIconAndSearch() throws InterruptedException
	{
		boolean isFlagged = false;

	    while (!isFlagged)
	    {
	        try
	        {
		By buttonBy =  By.xpath("//img[contains(@id,'PayeeNameMenuIcon')]");
		objectMethods.findObject(driver, buttonBy, 30);          	            
	    WebElement buttonEle = driver.findElement(buttonBy);
	    jsClick(buttonEle);
	    
	    Thread.sleep(4000);
	    By buttonSearchBy =  By.xpath("//span[contains(@id,'SearchMenuItem')]");
		objectMethods.findObject(driver, buttonSearchBy, 30);          	            
	    WebElement buttonSearchEle = driver.findElement(buttonSearchBy);
	    jsClick(buttonSearchEle);
	    
	    break;
	        }
	        catch (StaleElementReferenceException e)
	        {
	            LOG.info("Into Stale");
	            continue;
	        }
	    }
	    return this;
	}

	public Conventional editReserveReason(String expData, String reserveReason) throws InterruptedException
	{
		List<WebElement> rows =
	            driver.findElements(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
	                + "EditableReservesLV-body']" + "/div/table/tbody/tr"));
	        int row = rows.size();

	        for (int i = 1; i <= row; i++)
	        {

	            String strAmt =
	                driver
	                    .findElement(
	                        By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
	                            + "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[3]")).getText().trim();

	            if (strAmt.contentEquals(expData.trim()))
	            {

	                driver.findElement(
	                    By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
	                        + "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[9]")).click();
	               Thread.sleep(4000);
	                driver.switchTo().activeElement().clear();
	                driver.switchTo().activeElement().sendKeys(reserveReason);
	                driver.findElement(
	                    By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
	                        + "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[3]")).click();
	                Thread.sleep(4000);
	                return this;
	            }
	        }
	        return this;
	}

	public Conventional editReserveComment(String expData, String reserveComment) throws InterruptedException
	{

	    List<WebElement> rows =
	        driver.findElements(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
	            + "EditableReservesLV-body']" + "/div/table/tbody/tr"));
	    int row = rows.size();

	    for (int i = 1; i <= row; i++)
	    {

	        String strAmt =
	            driver
	                .findElement(
	                    By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
	                        + "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[3]")).getText().trim();

	        if (strAmt.contentEquals(expData.trim()))
	        {

	            driver.findElement(
	                By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
	                    + "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[10]")).click();
	            Thread.sleep(4000);
	            driver.switchTo().activeElement().clear();
	            driver.switchTo().activeElement().sendKeys(reserveComment);
	            driver.findElement(
	                By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
	                    + "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[3]")).click();
	            Thread.sleep(4000);
	            return this;
	        }
	    }
	    return this;

	}

	public Conventional editNewAvilableReserve(String expData, String reseveValue) throws InterruptedException
	{
	    List<WebElement> rows =
	        driver.findElements(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
	            + "EditableReservesLV-body']" + "/div/table/tbody/tr"));
	    int row = rows.size();

	    for (int i = 1; i <= row; i++)
	    {

	        String strAmt =
	            driver
	                .findElement(
	                    By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
	                        + "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[3]")).getText().trim();

	        if (strAmt.contentEquals(expData.trim()))
	        {

	            driver.findElement(
	                By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
	                    + "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[7]")).click();
	            Thread.sleep(4000);
	            driver.switchTo().activeElement().clear();
	            driver.switchTo().activeElement().sendKeys(reseveValue);
	            driver.findElement(
	                By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
	                    + "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[3]")).click();
	            Thread.sleep(4000);
	            return this;
	        }
	    }
	    return this;

	}
}