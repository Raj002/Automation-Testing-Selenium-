# Automation Framework
![](src/main/resources/images/AutomationFramework.PNG)