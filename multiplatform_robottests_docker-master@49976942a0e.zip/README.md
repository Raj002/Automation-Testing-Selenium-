# Multiplatform_RobotTests_Docker

<!-- shields -->

<!-- /shields -->

* * *

### Description
This project serves as a starting point for developers looking to create applications that leverage Docker. It includes basic manifest files for the Forge Manifest Processor Bamboo task.

### Project Structure

**[/src/main/deployment/](./src/main/deployment/)** - contains Docker manifest files for each of your deployment environments

### Typical Usage
Developers will typically need to add a pom.xml file and a Dockerfile in the base directory of this repository.  The pom.xml file provides vaules used for creating the name and version of the Docker image. If Maven is not needed, the build plan will require updates to set the name/version of the Docker image to different values and to remove the maven specific tasks.


### Related Resources
 - [Docker Pipeline Deployment details](https://wiki.lmig.com/display/CPCA/Docker+Pipeline+Deployment)
 - [Forge Manifest Processor Task](https://forge.lmig.com/wiki/display/CLOUDFORGE/Forge+Manifest+Processor+Task)
 - [Getting Started with Docker](https://wiki.lmig.com/display/CPCA/CaaS+Onboarding%3A+Getting+Started)
 - [Sample Docker Commands](https://wiki.lmig.com/display/CPCA/Docker+Commands)


### Author
 - Arun Karthick (arunkarthick.paranikumar@libertymutual.com)