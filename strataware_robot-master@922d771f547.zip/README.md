# Multiplatform_RobotTests_Docker

<!-- shields -->

<!-- /shields -->

* * *

### Description
This project contains automation test scripts for Web, Windows and Mainframe Applications which runs within Docker container (i.e. for Web and Mainframe). the execution can be triggered with the pipeline definition created for Jenkins.

### Project Structure

**[/Mainframe3270/](.[/Mainframe3270/)** - contains Mainframe Emulator library for automating Mainframe Application
**[/src/](./src/)** - contains source code of the test execution developed using Robot framework.
**[/Dockerfile](./Dockerfile)** - contains script for executing the test created using Robot framework within Docker Container.
**[/Jenkinsfile](./Jenkinsfile)** - contains the pipeline script for running the testcase via docker containers


### Related Resources
 - [Docker Pipeline Deployment details](https://wiki.lmig.com/display/CPCA/Docker+Pipeline+Deployment)
 - [Forge Manifest Processor Task](https://forge.lmig.com/wiki/display/CLOUDFORGE/Forge+Manifest+Processor+Task)
 - [Getting Started with Docker](https://wiki.lmig.com/display/CPCA/CaaS+Onboarding%3A+Getting+Started)
 - [Sample Docker Commands](https://wiki.lmig.com/display/CPCA/Docker+Commands)


### Author
 - Arun Karthick (arunkarthick.paranikumar@libertymutual.com)