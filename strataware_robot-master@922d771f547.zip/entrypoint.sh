#!/bin/sh

export DISPLAY=:1.0
Xvfb :1.0 -screen 0 1152x900x8&
x11vnc -passwd TestVNC -display :1.0 -N -bg -q -forever &

if [ ! -z $1 ]
then
   singleTest="--suite $1"
fi

# hostname -i     # Command to identify the ipaddress of the docker container
robot $singleTest --logLevel TRACE:INFO /tests 
# wait