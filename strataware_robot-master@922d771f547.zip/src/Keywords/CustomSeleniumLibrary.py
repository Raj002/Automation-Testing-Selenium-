# CustomSeleniumLibrary.py
from Selenium2Library import Selenium2Library
from SeleniumLibrary.base import keyword
from selenium import webdriver
from pynput.keyboard import Key, Controller
from pdfquery import pdfquery
import glob
import os
import time


class CustomSeleniumLibrary(Selenium2Library):
    __alert = None

    @keyword
    def get_chrome_option(self):
        opt = webdriver.ChromeOptions()
        opt.add_argument('--disable-extensions')
        opt.add_argument('--headless')
        opt.add_argument('--disable-gpu')
        opt.add_argument('--no-sandbox')
        opt.add_argument('download.default_directory=/reports')
        return opt

    @keyword
    def select_alert(self):
        try:
            if self.__alert is None:
                self.__alert = self._current_browser().switch_to_alert()

        except Exception:
            raise RuntimeError("There were no Alerts")

    @keyword
    def insert_into_prompt(self, text):
        try:
            self.__alert = self._current_browser().switch_to_alert()
            self.__alert.send_keys(text)

        except Exception:
            raise RuntimeError("Unable to find the Alert box")

    @keyword
    def insert_robot_key(self, text):
        keyboard = Controller()
        key = self._map_ascii_key_code_to_key(int(text[1:]))
        keyboard.press(key)

    @keyword
    def insert_robot_text(self, text):
        keyboard = Controller()
        keyboard.type(text)

    @keyword
    def get_latest_file_in_folder(self, directory):
        pdfFile = max(glob.iglob(directory + '*.pdf'), key=os.path.getctime)
        file_prop = os.stat(pdfFile)
        if (file_prop.st_ctime > time.time()-100):
            return pdfFile
        #     # return None
        # else:
        #     return file_prop

    @keyword
    def get_value_for_field_in_pdf(self, pdf_loc, page, text):
        return int(self.extract_cells(pdf_loc, page, text).strip())

    @keyword
    def get_long(self, text):
        return int(text.strip())

    @keyword
    def get_string(self, text):
        return str(text)

    def extract_cells(self, pdf_loc, page, header):
        pdf = pdfquery.PDFQuery(pdf_loc)
        pdf.load()
        name_element = pdf.pq(
            'LTPage[pageid=\'%s\'] LTTextLineHorizontal:contains("%s")' % (page, header))[0]
        ind = name_element.text.find(header)
        fcut = name_element.text[ind:len(name_element.text)]
        scut = fcut[fcut.find(": ") + 2: len(fcut)]
        return scut[:scut.find(" ")]

    def _map_ascii_key_code_to_key(self, key_code):
        map = {
            8: Key.backspace,
            9: Key.tab,
            13: Key.enter,
            27: Key.esc,
            32: Key.space
        }
        key = map.get(key_code)
        if key is None:
            key = chr(key_code)
        return key
