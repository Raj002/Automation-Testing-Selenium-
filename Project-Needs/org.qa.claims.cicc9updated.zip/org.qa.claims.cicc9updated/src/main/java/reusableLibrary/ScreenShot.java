package reusableLibrary;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import functionalLibrary.WebDriverFactory;

public class ScreenShot {
	static WebDriver driver = WebDriverFactory.driver;

	public static void TakeScreenShot(String testname) {
		try {
			String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
			TakesScreenshot ts = ((TakesScreenshot) driver);
			File scrfile = ts.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrfile, new File("D:\\Updated GW CC\\Guidewire Claim Center\\Screenshot\\Failure_"
					+ testname + "_" + timeStamp + ".png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
