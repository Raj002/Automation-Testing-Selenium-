package functionalLibrary;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class currentDateAndTime {
	  
	static String timeStamp;
	public static String getDateTime()
	{
		timeStamp = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(Calendar.getInstance().getTime());
		return timeStamp;
	}
	
}
