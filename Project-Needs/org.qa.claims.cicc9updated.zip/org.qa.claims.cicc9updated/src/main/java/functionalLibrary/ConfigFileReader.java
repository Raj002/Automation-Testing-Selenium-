package functionalLibrary;

import java.util.Properties;

public class ConfigFileReader {

	static Properties prop=DataStorage.loadProperties();
			public static String getReportCofigPath()
			{
			
				String reportConfigPath=prop.getProperty("reportConfigPath");
				if(reportConfigPath!=null)
				return reportConfigPath;
				else
			    throw new RuntimeException("Report path is not specified in ");
			}	
}
