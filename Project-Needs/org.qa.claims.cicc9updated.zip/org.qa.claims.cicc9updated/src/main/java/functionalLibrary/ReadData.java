package functionalLibrary;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadData {
	XSSFWorkbook wb;
	XSSFSheet sheet;
	String testCaseName;
	int testrownum;
	public Map<String,String> getData(String datadetail)
	{
		String[] detail=datadetail.split("_");
		Map<String ,String> map = new HashMap<String,String>();
		
		String	sheetName=detail[1];
		testCaseName=detail[2];
		String docname=detail[0];
		try 
		{
			FileInputStream fis=new FileInputStream("C:\\Users\\n0323482\\Desktop\\Framework\\Guidewire Claim Center\\src\\main\\resources\\Data\\"+docname+".xlsx");
			wb=new XSSFWorkbook(fis);
		} 
		catch (Exception e) 
		{
			System.out.println("Problem with sheet");
			e.printStackTrace();
		}
		sheet=wb.getSheet(sheetName);
	    
	    //System.out.println(testCaseName);
	    
	    for(int i=1;i<=sheet.getPhysicalNumberOfRows();i++)
	    {
	    	String testname=sheet.getRow(i).getCell(0).getStringCellValue();
	    	if(testname.equals(testCaseName))
	    	{
	    		XSSFRow row=sheet.getRow(i);
	    		for(int j=1;j<row.getPhysicalNumberOfCells();j++)
	    		{
	    			System.out.println(i);
	    			XSSFCell cell=row.getCell(j);
	    			map.put(sheet.getRow(0).getCell(j).getStringCellValue(),cell.getStringCellValue());
	    		}
	    		break;
	    	}
	    	
	    }
	
	    return map;
	}
		
}
