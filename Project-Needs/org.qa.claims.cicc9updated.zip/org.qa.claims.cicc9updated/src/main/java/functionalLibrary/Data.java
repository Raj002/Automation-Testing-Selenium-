package functionalLibrary;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbookType;

public class Data {
	XSSFWorkbook wb;
	XSSFSheet sheet;
	String testCaseName;
	FileInputStream fis;
	FileOutputStream fout;
	int testrownum;
	public Map<String,String> getdata(String datadetail)
	{
		String[] detail=datadetail.split("_");
		Map<String ,String> map = new HashMap<String,String>();
		System.out.println(datadetail);
		String	sheetName=detail[1];
		testCaseName=detail[2];
		String docname=detail[0]; 
		try 
		{
			FileInputStream fis=new FileInputStream("src/main/resources/Data/"+docname+".xlsx");
			wb=new XSSFWorkbook(fis);
			
			/*FileOutputStream fout=new FileOutputStream(new File("src/main/resources/Data/"+docname+".xlsx"));
			wb=new XSSFWorkbook();
			wb.write(fout);*/
			
			
			sheet=wb.getSheet(sheetName);
		    
		    for(int i=1;i<=sheet.getPhysicalNumberOfRows();i++)
		    {
		    	String testname=sheet.getRow(i).getCell(0).getStringCellValue();
		    	if(testname.equals(testCaseName))
		    	{
		    		XSSFRow row=sheet.getRow(i);
		    		for(int j=1;j<row.getPhysicalNumberOfCells();j++)
		    		{
		    			XSSFCell cell=row.getCell(j);
		    			map.put(sheet.getRow(0).getCell(j).getStringCellValue(),cell.getStringCellValue());
		  
		    		}
		    		break;
		    	}
		    } 
		    
		} 
		catch (Exception e) 
		{
			
			e.printStackTrace();
		}
		finally 
		{
			if (fis != null) 
			{
				try
				{
					fis.close();
				}
				catch (IOException e) 
				{
					e.printStackTrace();
				}
			}
		}
		
	    return map;
	}
		
}