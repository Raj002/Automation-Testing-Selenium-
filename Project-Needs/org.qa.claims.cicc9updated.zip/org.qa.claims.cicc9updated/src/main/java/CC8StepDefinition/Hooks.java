package CC8StepDefinition;

import java.util.Properties;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import functionalLibrary.*;
import pageObjects.LoginDV;

public class Hooks {
	public static WebDriver driver;
	Properties prop=DataStorage.loadProperties();
	LoginDV loginDv;
	@BeforeClass
	public void setup() throws InterruptedException{
		
		driver=WebDriverFactory.getWebDriver(prop.getProperty("webdriver.browserType"));
		driver.get(prop.getProperty("landing.page.url"));
		/*driver.findElement(By.name("Login:LoginScreen:LoginDV:username")).sendKeys("su");;
		driver.findElement(By.name("Login:LoginScreen:LoginDV:password")).sendKeys("LIUClaims123");
		driver.findElement(By.id("Login:LoginScreen:LoginDV:submit-btnInnerEl")).click();*/
		Thread.sleep(3000);
		driver.manage().window().maximize();
	}
	
	@AfterClass
	public void tearDown()
	{
		driver.quit();
	}

}
