package CC9StepDefinition;

import org.openqa.selenium.WebDriver;

import businessComponents.ChecksCreation;
import businessComponents.ClaimCreationCC8;
import businessComponents.ClaimCreationCC9;
import businessComponents.ClaimCreationCICC9;
import businessComponents.Notes;
import businessComponents.PartiesInvolved;
import businessComponents.Reserves;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.ButtonScriptless;
import pageObjects.Conventional;

/**
 *@author N0323482
 *Created a New Class to call the Methods in all Main Class where defined the fields in the application
 */
public class CC9PartiesInvolvedStep
{
	
/**
* Initializing the driver (For Eg;Chrome)
 */
WebDriver driver;
	 
	 
/**
*Creating the Objects for each Class file
*/	 
ClaimCreationCC8 ClaimCC8;
ClaimCreationCC9 ClaimCC9;
ClaimCreationCICC9 ClaimCICC9;
PartiesInvolved Contact;
Notes Note;

/**
* Declaring the "Given" method in the Feature file
* @Param LOB - Identifies the Claim LOB to be created
* @Param ClaimData - Used to fetch each fields/values from the test data sheet to create the claim 
*/

@Given("^Launch the application and load the test data for the ([^\"]*) claim ([^\"]*) for Contact$")
	public void launch_the_application_and_load_test_data_for_the_claim_for_Contact(String LOB, String ClaimData) throws Throwable 
	{
	
	/**
	* Calling the Driver to launch it by fetching the details in the Hooks File 
	* Hooks File contains the annotations
	*/	
	driver=Hooks.driver;
			 	
			 	
	/**
	  *Instantiation it with the respective Class File
	*/	
	
	ClaimCC8 = new ClaimCreationCC8(driver,ClaimData);
	ClaimCC9 = new ClaimCreationCC9(driver,ClaimData);
	ClaimCICC9 = new ClaimCreationCICC9(driver,ClaimData);
	Contact = new PartiesInvolved(driver);

	
	/**
	* CC9 - The below "If Case" will check for Casualty LOB/Data declaration is present in feature file
	* CC9 - If given LOB/Data matches it will call methods in a respective class file and create the Casualty Claim
	*/
	if(LOB.equalsIgnoreCase("GSCasualty"))
	{
		ClaimCC9.login_CC9();
		/*ClaimCC9.policySearchWithPoilcyNumber_CC9();
		ClaimCC9.addClaimInformationCasualty_CC9();
		ClaimCC9.manageExposuresGeneralDamage_CC9();
		ClaimCC9.generalDamage_CC9();
		ClaimCC9.saveAndAssignClaim_CC9();
		ClaimCC9.reviewAndSaveClaim_CC9();*/
		ClaimCC9.searchClaimCC9("BOSCAS210188518");
	}
			    
	/**
	* CC9 - The below "If Case" will check for Property LOB/Data declaration is present in feature file
	* CC9 - If given LOB/Data matches it will call methods in a respective class file and create the Property Claim
	*/
	
	if(LOB.equalsIgnoreCase("GSProperty"))
	{
		ClaimCC9.login_CC9();
		ClaimCC9.policySearchWithPoilcyNumber_CC9();
		ClaimCC9.addClaimInformationProperty_CC9();
		ClaimCC9.manageExposuresPropertyDamage_CC9();
		ClaimCC9.PropertyDamage_CC9();
		ClaimCC9.saveAndAssignClaim_CC9();
		ClaimCC9.reviewAndSaveClaim_CC9();
		ClaimCC9.searchClaimCC9("ATLPRO210188521");
	}
	}

	@When("^Add Contact for the created claim ([^\"]*) for Contact$")
	 public void add_Note_for_the_created_claim_for_Contact(String ContactData) throws Throwable 
	 {
		Contact.createContact_CC9(ContactData);
	 }
}
	