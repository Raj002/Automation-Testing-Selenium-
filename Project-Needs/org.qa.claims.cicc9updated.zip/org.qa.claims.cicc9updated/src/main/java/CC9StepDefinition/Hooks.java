package CC9StepDefinition;

import java.io.File;                                                             
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.mongodb.MapReduceCommand.OutputType;
import com.sun.jna.platform.FileUtils;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import functionalLibrary.*;
import pageObjects.LoginDV;
import testRunners.CommonTestRunnersCC9;
import testRunners.NewRunner;

public class Hooks {
	public static WebDriver driver;
	
	public static WebDriver driver1;
	
	//public static WebDriver driver1;
	
	static String timestamp="";
	
	Properties prop=DataStorage.loadProperties();
	LoginDV loginDv;
	@Before
	public void setup() throws InterruptedException, IOException{
		
		driver=WebDriverFactory.getWebDriver(prop.getProperty("webdriver.browserType"));
		driver.get(prop.getProperty("landing.page.url"));
		/*driver.findElement(By.name("Login:LoginScreen:LoginDV:username")).sendKeys("su");;
		driver.findElement(By.name("Login:LoginScreen:LoginDV:password")).sendKeys("LIUClaims123");
		driver.findElement(By.id("Login:LoginScreen:LoginDV:submit-btnInnerEl")).click();*/
		Thread.sleep(3000);
		driver.manage().window().maximize();
	}
	
	@After
	public void tearDown() throws InterruptedException, IOException
	{
		//driver.get("E:/Workspace/Guidewire Claim Center/output/report.html");
		//driver.quit();
		
		//Runtime.getRuntime().exec("taskkill /f /IM chrome.exe");
			String reportfileName=NewRunner.timestamp;
			String dir = System.getProperty("user.dir");
			
			//System.setProperty("webdriver.chrome.driver", "E:\\Workspace\\Guidewire Claim Center\\src\\main\\resources\\drivers\\chromedriver-2.40.exe");
			//WebDriver driver1 = new ChromeDriver();
			//driver1.get(prop.getProperty("user.dir") + "/output/"+reportfileName+"/report/extend_report.html");*/
			System.out.println(reportfileName);
			driver1=WebDriverFactory.getWebDriver(prop.getProperty("webdriver.browserType"));
			driver1.manage().timeouts().pageLoadTimeout(10000, TimeUnit.MILLISECONDS);
			driver1.manage().window().maximize();
			//Thread.sleep(5000);
			System.out.println(dir + "/output/"+reportfileName+"/report/extend_report.html");
			String reportURL = dir + "/output/"+reportfileName+"/report/extend_report.html";			
			//driver1.get(reportURL);
			
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			String url = reportURL;
			String URLPath = "window.location =\'" + url +"\'";
			js.executeScript(URLPath);
			System.out.println("JS URL : " + driver.getCurrentUrl());
			
			Thread.sleep(7000);
			/*driver1.navigate().back();
			Thread.sleep(2000);
			driver1.navigate().forward();*/
		
			/*System.out.println(System.getProperty("user.dir") + "/output/"+reportfileName+"/report/extend_report.html");
			String reportURL = System.getProperty("user.dir") + "/output/"+reportfileName+"/report/extend_report.html";
			driver1.navigate().to(reportURL);*/
			//driver1.navigate().refresh();		
			/*JavascriptExecutor js = ((JavascriptExecutor) driver1);
			js.executeScript(System.getProperty("user.dir")+"/output/"+reportfileName+"/report/extend_report.html",reload());*/
			/*driver1.navigate().back();
			driver1.navigate().forward();*/
			//driver.quit();
			//driver1.executeScript("file:///E:/Workspace/Guidewire%20Claim%20Center/output/"+timestamp+"/report/extend_report.html.reload()");
			//Thread.sleep(5000);
			//driver1.get(System.getProperty("user.dir")+"/output/"+reportfileName+"/report/extend_report.html");
			//Thread.sleep(3000);
			//driver.navigate().refresh();
			/*System.out.println(System.getProperty("user.dir") + "/output/"+reportfileName+"/report/extend_report.html");
			driver.get(System.getProperty("user.dir") + "/output/"+reportfileName+"/report/extend_report.html");*/
		}
}
