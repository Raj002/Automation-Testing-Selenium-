package CC9StepDefinition;

import org.openqa.selenium.WebDriver;

import businessComponents.ChecksCreation;
import businessComponents.ClaimCreationCC8;
import businessComponents.ClaimCreationCC9;
import businessComponents.ClaimCreationCICC9;
import businessComponents.Notes;
import businessComponents.PartiesInvolved;
import businessComponents.Reserves;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.ButtonScriptless;
import pageObjects.Conventional;

/**
 *@author N0323482
 *Created a New Class to call the Methods in all Main Class where defined the fields in the application
 */
public class CC9ReserveStep 
{
	
/**
* Initializing the driver (For Eg;Chrome)
 */
WebDriver driver;
	 	 
/**
*Creating the Objects for required Class file
*/	 

ClaimCreationCC9 ClaimCC9;
Reserves Reserve;

/**
* Declaring the "Given" method in the Feature file
* @Param LOB - Identifies the Claim LOB to be created
* @Param ClaimData - Used to fetch each fields/values from the test data sheet to create the claim  
*/	 
@Given("^Launch the application and load the test data for the ([^\"]*) claim ([^\"]*) for Reserve$")
	public void launch_the_application_and_load_the_test_data_for_the_claim_for_Reserve(String LOB, String ClaimData) throws Throwable 
	{
	
	/**
	* Calling the Driver to launch it by fetching the details in the Hooks File 
	* Hooks File contains the annotations
	*/	
	driver=Hooks.driver;
			 	
			 	
	/**
	  *Instantiation it with the respective Class File
	*/
	ClaimCC9 = new ClaimCreationCC9(driver,ClaimData);
	Reserve = new Reserves(driver);
		 	
			 	
	/**
	* CC9 - The below "If Case" will check for Casualty LOB/Data declaration is present in feature file
	* CC9 - If given LOB/Data matches it will call methods in a respective class file and create the Casualty Claim
	*/ 
	if(LOB.equalsIgnoreCase("GSCasualty"))
	{
		ClaimCC9.login_CC9();
		/*ClaimCC9.policySearchWithPoilcyNumber_CC9();
		ClaimCC9.addClaimInformationCasualty_CC9();
		ClaimCC9.manageExposuresGeneralDamage_CC9();
		ClaimCC9.generalDamage_CC9();
		ClaimCC9.saveAndAssignClaim_CC9();
		ClaimCC9.reviewAndSaveClaim_CC9();*/
		ClaimCC9.searchClaimCC9("ATLCAS210189081");
	}
		    
	/**
	* CC9 - The below "If Case" will check for Property LOB/Data declaration is present in feature file
	* CC9 - If given LOB/Data matches it will call methods in a respective class file and create the Property Claim
	*/
	if(LOB.equalsIgnoreCase("GSProperty"))
	{
		ClaimCC9.login_CC9();
		ClaimCC9.policySearchWithPoilcyNumber_CC9();
		ClaimCC9.addClaimInformationProperty_CC9();
		ClaimCC9.manageExposuresPropertyDamage_CC9();
		ClaimCC9.PropertyDamage_CC9();
		ClaimCC9.saveAndAssignClaim_CC9();
		ClaimCC9.reviewAndSaveClaim_CC9();
		//ClaimCC9.searchClaimCC9("");
	}
}

/**
* Declaring the "When" method in the Feature file
* Calling Methods in a "Reserves" class File to create Reserve for specified application
* Calling Methods in a "ChecksCreation" class File to create Check for specified application
*/

@When("^Add Reserve for the specific exposure ([^\"]*) for Reserve$")
	 public void add_Reserve_for_the_specific_exposure_for_Reserve(String ReserveData) throws Throwable 
	 {
		Reserve.reserveCreation_CC9(ReserveData);
	 }
}