package businessComponents;
/**
 *This class contains methods which used for Claim Creation of CC9 application
 * @author N0323482
 * @Scripted On - 31/08/2018
 */

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.cucumber.listener.Reporter;

import functionalLibrary.Data;
import pageObjects.ButtonScriptless;
import pageObjects.CheckBoxScriptless;
import pageObjects.Conventional;
import pageObjects.LoginDV;
import pageObjects.PickerMenuScriptless;
import pageObjects.RadioInputScriptless;
import pageObjects.RangeInputScriptless;
import pageObjects.TextAreaInputScriptless;
import pageObjects.TextInputScriptless;
import reusableLibrary.ScreenShot;

/**
*Creating new Objects for each script less class
*/

public class ClaimCreationCC9 
{	
	public  WebDriver driver;
	static ButtonScriptless button;
	static TextInputScriptless textInput;
	TextAreaInputScriptless textAreaInput;
	static RangeInputScriptless rangeInput;
	static RadioInputScriptless radioInput;
	CheckBoxScriptless checkBox;
	PickerMenuScriptless pickerMenu;
	LoginDV loginDv; 
	Conventional conventional;
	Data read;
	ScreenShot ts;
	Map<String, String> testData;

/**
*Instantiation using the Constructor
*@param "Data" in each below method is used to fetch the test data for the respective fields
*/
	
public ClaimCreationCC9(WebDriver ldriver,String dataSheet)
{
	this.driver = ldriver;
	button = new ButtonScriptless(driver);
	textInput = new TextInputScriptless(driver);
	textAreaInput=new TextAreaInputScriptless(driver);
	rangeInput = new RangeInputScriptless(driver);
	radioInput = new RadioInputScriptless(driver);
	loginDv = new LoginDV (driver);	
	conventional=new Conventional(driver);
	checkBox=new CheckBoxScriptless(driver);
	pickerMenu=new PickerMenuScriptless(driver);
	read=new Data();
	testData=read.getdata(dataSheet);
	
}

	/**
	 *This method will launch the CC9(GSUpgrade) application with the valid credentials
	 */
	public void login_CC9()
	{
		driver.findElement(By.name("Login:LoginScreen:LoginDV:username")).sendKeys(testData.get("Username"));
		driver.findElement(By.name("Login:LoginScreen:LoginDV:password")).sendKeys(testData.get("Password"));
		driver.findElement(By.id("Login:LoginScreen:LoginDV:submit-btnEl")).click();
		
		Reporter.addStepLog("Successfully Logged in to GS_Upgrade(CC9) Application");
	}

	/**
	 *This Method will retrieve the Policy details (Step 1 of FNOL) - Applicable to all LOB's in CC9 application
	 */
	public void policySearchWithPoilcyNumber_CC9() throws Exception
	{
		button.clickNewClaim();
		textInput.enterTextinputWhereLabelNthOccurence_gs("Policy #",testData.get("Policy#"),"1");
		button.clickButtonWhereAnyLetterUnderLined("Search","S");
		Thread.sleep(5000);
		textInput.enterTextinputWhereLabelNthOccurence_gs("Date of Loss",testData.get("DateofLoss"),"1");
		button.clickButtonWhereLabel("Next >");
		Thread.sleep(8000);
		
		Reporter.addStepLog("The Policy "+testData.get("Policy#")+" had been found.");
	}
	
	
	/**
	 *This Method will enter all mandatory details (Step 2 of FNOL) of Casualty Claim
	 */
	
	public void addClaimInformationCasualty_CC9() throws Exception 
	{
		Thread.sleep(2000);
		textInput.enterTextinputWhereLabelNthOccurence_gs("Claim Title",testData.get("ClaimTitleGs"),"1");
		textInput.enterTextinputWhereLabelNthOccurence_gs("Claim Description",testData.get("LossDescription"),"1");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Severity",testData.get("Severity"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("COL1",testData.get("Col1Gs"),"1");
		Thread.sleep(2000);
		textInput.enterTextinputWhereLabelNthOccurence_gs("Date Received by LIU",testData.get("DateReceivedbyLIU"),"1");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claim Type",testData.get("ClaimType"),"1");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Type",testData.get("LossType"),"1");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("State/Province",testData.get("State"),"1"); 
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claim Type",testData.get("ClaimType"),"1");
		button.clickButtonWhereLabel("Next >");
		
		Reporter.addStepLog("Casualty Claim Infomartion had been added.");
		Thread.sleep(2000);
        if(driver.findElement(By.xpath("//div[@class='message']")).isDisplayed());
        {
    	   button.clickButtonWhereAnyLetterUnderLined("Close ","e");
    	   button.clickButtonWhereLabel("Next >");
    	   Thread.sleep(5000);
        }        		
	}
	
	
	/**
	 *This Method will enter all mandatory details (Step 2 of FNOL) of Property Claim
	*/
	public void addClaimInformationProperty_CC9() throws Exception 
	{
		Thread.sleep(5000);
		textInput.enterTextinputWhereLabelNthOccurence_gs("Claim Title",testData.get("ClaimTitleGs"),"1");
		textInput.enterTextinputWhereLabelNthOccurence_gs("Claim Description",testData.get("LossDescription"),"1");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Severity",testData.get("Severity"),"1");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claim Type",testData.get("ClaimType"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Peril",testData.get("Peril"),"1");
		Thread.sleep(2000);
		textInput.enterTextinputWhereLabelNthOccurence_gs("Date Received by LIU",testData.get("DateReceivedbyLIU"),"1");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("State/Province",testData.get("State"),"1");	 
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claim Type",testData.get("ClaimType"),"1");
		button.clickButtonWhereLabel("Next >");
		
		Reporter.addStepLog("Property Claim Infomartion had been added.");
		Thread.sleep(2000);
        if(driver.findElement(By.xpath("//div[@class='message']")).isDisplayed())
        {
        		button.clickButtonWhereAnyLetterUnderLined("Close ","e");
                button.clickButtonWhereLabel("Next >");
        }	
	}
	
	
	/**
	 * This method will select the menu's to create the General Damage Exposure (Step 3 of FNOL)
	 */
	public void manageExposuresGeneralDamage_CC9() throws Exception
	{
		Thread.sleep(1000);
		button.clickButtonWhereAnyLetterUnderLined("New Exposure","e");
		driver.findElement(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_ExposuresScreen:NewClaimExposuresLV_tb:AddExposure:0:item-textEl")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_ExposuresScreen:NewClaimExposuresLV_tb:AddExposure:0:item:0:item-textEl")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_ExposuresScreen:NewClaimExposuresLV_tb:AddExposure:0:item:0:item:1:item-textEl")).click();
	}
	
	
	/**
	 *This method will create the General Damage Exposure
	 */
	public void generalDamage_CC9() throws InterruptedException
	{
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claimant",testData.get("Claimant"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claimant Representative",testData.get("ClaimantRepresentative"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claimant",testData.get("Claimant"),"1");
		textInput.enterTextinputWhereLabelNthOccurence_gs("Damage Description",testData.get("DamageDescription"),"1");
		button.clickButtonWhereLabel("OK");
		Thread.sleep(2000);
		button.clickButtonWhereLabel("Next >");
		
		Reporter.addStepLog("General Damage Exposure had been added.");
	}
	
	
	/**
	 *This method will select the menus to create the Property Damage Exposure (Step 3 of FNOL)
	 */
	public void manageExposuresPropertyDamage_CC9() throws Exception
	{
		button.clickButtonWhereAnyLetterUnderLined("New Exposure","e");
		driver.findElement(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_ExposuresScreen:NewClaimExposuresLV_tb:AddExposure:0:item-textEl")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_ExposuresScreen:NewClaimExposuresLV_tb:AddExposure:0:item:0:item-textEl")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_ExposuresScreen:NewClaimExposuresLV_tb:AddExposure:0:item:0:item:2:item-textEl")).click();
	}
	
			
	/**
	 *This method will create the Property Damage Exposure
	 */
	public void PropertyDamage_CC9() throws InterruptedException
	{
		pickerMenu.clickPickerMenuWhereLabelNthOccurence("Property Name",1);
		pickerMenu.clickPickerMenuOption("New Property...");
		textInput.enterTextinputWhereLabelNthOccurence_gs("Property Description",testData.get("PropDescription"),"1");
		button.clickButtonWhereLabel("OK");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claimant",testData.get("Claimant"),"1");
		radioInput.clickRadioInputWhereLabelAndChoice_gs("Contact Prohibited?","No");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Type",testData.get("LossType"),"1");
		button.clickButtonWhereLabel("OK");
		Thread.sleep(2000);
		button.clickButtonWhereLabel("Next >");
		
		Reporter.addStepLog("Property Damage Exposure had been added.");
	}
	
	
	/**
	 *This method will select the menus to create the Bodily Injury Exposure (Step 3 of FNOL)
	 */
	public void manageExposuresBodilyInjury_CC9() throws Exception
	{
		button.clickButtonWhereAnyLetterUnderLined("New Exposure","e");
		driver.findElement(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_ExposuresScreen:NewClaimExposuresLV_tb:AddExposure:0:item-textEl")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_ExposuresScreen:NewClaimExposuresLV_tb:AddExposure:0:item:0:item-textEl")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_ExposuresScreen:NewClaimExposuresLV_tb:AddExposure:0:item:0:item:0:item-textEl")).click();
	}
	
			
	/**
	 * This method will create the Bodily Injury Exposure
	 */
	public void BodilyInjury_CC9() throws InterruptedException
	{
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claimant",testData.get("Claimant"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Type",testData.get("Type"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claimant Representative",testData.get("ClaimantRepresentative"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Alternate Contact",testData.get("Alternate Contact"),"1");
		Thread.sleep(2000);
		pickerMenu.clickPickerMenuWhereLabelNthOccurence("Injury",1);
		pickerMenu.clickPickerMenuOption("New Incident...");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Injury Person",testData.get("InjuryPerson"),"1");
		textInput.enterTextinputWhereLabelNthOccurence_gs("Describe Injuries",testData.get("DescribeInjuries"),"1");
		button.clickButtonWhereLabel("OK");
		Thread.sleep(2000);
		button.clickButtonWhereLabel("OK");
		Thread.sleep(2000);
		button.clickButtonWhereLabel("Next >");
		
		Reporter.addStepLog("Bodily Injury Exposure had been added.");
	}
	

	/**
	 *This method will Click on Next in Step 4 of FNOL - Applicable for all LOB's
	 */
	public void managePartiesInvolved_CC9()
	{
		button.clickButtonWhereLabel("Next >");
	}
	
	
	/**
	 *This method will Click on Next in Step 5 of FNOL - Applicable for all LOB's
	 */
	public void saveAndAssignClaim_CC9()
	{
		button.clickButtonWhereLabel("Next >");
	}
	
	
	/**
	 * This method will Click on Finish in Step 6 of FNOL - Applicable for all LOB's
	 */
	public void reviewAndSaveClaim_CC9()
	{
		button.clickButtonWhereAnyLetterUnderLined("Finish","F");
		
		String claimnum = driver.findElement(By.id("NewClaimSaved:NewClaimSavedScreen:NewClaimSavedDV:Header")).getText();
		claimnum=claimnum.substring(6, 21);	    
		driver.findElement(By.xpath("//a[contains(@id,'GoToTheClaim')]|//div[contains(@id,'GoToClaim')]")).click();
		Reporter.addStepLog("The Claim "+claimnum+" has been created.");
	}
	
	/**
	 *This method will search for the given claim and retrieve its details in the respective application
	 */
	public void searchClaimCC9(String claimnum) throws InterruptedException
	{
		System.out.println(driver);
		Thread.sleep(2000);
	    driver.findElement(By.id("TabBar:SearchTab-btnInnerEl")).click();
	    textInput.enterTextinputWhereLabelNthOccurence_gs("Claim #", claimnum, "1");
	    button.clickButtonWhereAnyLetterUnderLined("", "S");
	    Thread.sleep(2000);
	    driver.findElement(By.linkText(claimnum)).click();
	 }	
}