package businessComponents;
/**
 * This class contains methods which used for Check Creation of CC8,CC9,CICC9 application
 * @author N0323482
 * @Scripted On - 
 */

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.cucumber.listener.Reporter;

import functionalLibrary.Data;
import pageObjects.ButtonScriptless;
import pageObjects.CheckBoxScriptless;
import pageObjects.Conventional;
import pageObjects.LoginDV;
import pageObjects.PickerMenuScriptless;
import pageObjects.RadioInputScriptless;
import pageObjects.RangeInputScriptless;
import pageObjects.TextAreaInputScriptless;
import pageObjects.TextInputScriptless;
import reusableLibrary.ScreenShot;

/**
*Creating new Objects for each script less class
*/

public class ChecksCreation 
{	
	public static WebDriver driver;
	static ButtonScriptless button;
	static TextInputScriptless textInput;
	TextAreaInputScriptless textAreaInput;
	static RangeInputScriptless rangeInput;
	static RadioInputScriptless radioInput;
	CheckBoxScriptless checkBox;
	PickerMenuScriptless pickerMenu;
	LoginDV loginDv; 
	Conventional conventional;
	Data read;
	ScreenShot ts;
	Map<String, String> testData;

/**
*Instantiation using the Constructor
*@param "Data" in each below method is used to fetch the test data for the respective fields 
*/

public ChecksCreation(WebDriver ldriver)
{
	this.driver = ldriver;
	button = new ButtonScriptless(driver);
	textInput = new TextInputScriptless(driver);
	textAreaInput=new TextAreaInputScriptless(driver);
	rangeInput = new RangeInputScriptless(driver);
	radioInput = new RadioInputScriptless(driver);
	loginDv = new LoginDV (driver);	
	conventional=new Conventional(driver);
	checkBox=new CheckBoxScriptless(driver);
	pickerMenu=new PickerMenuScriptless(driver);
	read=new Data();

}

	
	/**
	 * Click on Action Menu in Desktop Page
	 */
	public void topmenu()
	{
		conventional.clickActions();
	}

	/**
	 * CC8 - This method will create check for with "Non Medical Loss" CostType
	 */
	public void checkCreationNonMedicalLoss_CC8(String data) throws Throwable 
	{
		Map<String,String> 
		testData=read.getdata(data);
		conventional.clickActions();
		conventional.clickCheck();
		Thread.sleep(3000);
		//System.out.println(testData.get("ReserveLine"));
		rangeInput.enterRangeInputWhereLabelNthOccurence("Reserve Line",testData.get("ReserveLine"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurence("Subcoverage",testData.get("Subcoverage"),"1");
		textInput.enterTextinputWhereLabelFirstOccurence("Amount",testData.get("PaymentAmount"));
		button.clickButtonWhereLabelNthOccurence("Apply Deductible","1");
		button.clickButtonWhereLabel("Next >");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurence("Type",testData.get("CheckType"),"1");
		button.clickButtonWhereLabel("Next >");
		Thread.sleep(2000);
		//rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Payment Type",testData.get("PaymentType"));
		rangeInput.enterRangeInputWhereLabelNthOccurence("Processing Office    ",testData.get("ProcessingOffice"),"1");
		button.clickButtonWhereLabel("Finish");
		Thread.sleep(2000);
		conventional.validateCheckExistCC8(testData.get("PayTo"), testData.get("GrossAmount"),testData.get("Status"));
		
		Reporter.addStepLog("Check is successfully added for Medical loss for Navigator(CC8) Application");
	}
	
	/**
	 * CC8 - This method will create check for with "Expense" CostType
	 */
	public void checkCreationExpense_CC8(String data) throws Throwable 
	{
		Map<String,String> 
		testData=read.getdata(data);
		conventional.clickActions();
		conventional.clickCheck();
		Thread.sleep(3000);
		//System.out.println(testData.get("ReserveLine"));
		rangeInput.enterRangeInputWhereLabelNthOccurence("Reserve Line",testData.get("ReserveLine"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurence("Expense Category",testData.get("PaymentCategory"),"1");
		textInput.enterTextinputWhereLabelFirstOccurence("Amount",testData.get("PaymentAmount"));
		//button.clickButtonWhereLabelNthOccurence("Apply Deductible","1");
		button.clickButtonWhereLabel("Next >");
		rangeInput.enterRangeInputWhereLabelNthOccurence("Type",testData.get("CheckType"),"1");
		button.clickButtonWhereLabel("Next >");
		//rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Payment Type",testData.get("PaymentType"));
		rangeInput.enterRangeInputWhereLabelNthOccurence("Processing Office    ",testData.get("ProcessingOffice"),"1");
		button.clickButtonWhereLabel("Finish");
		conventional.validateCheckExistCC8(testData.get("PayTo"), testData.get("GrossAmount"),testData.get("Status"));
		
		Reporter.addStepLog("Check is successfully added for Expense for Navigator(CC8) Application");
	}
	
	
	/**
	 * CC9 - This method will Create Check whose Claim is having Reserves with USD Currency 
	 * @param data
	 */
	public void checkCreationwithReserve_CC9 (String data) throws Exception
	{
		Map<String,String> 
		testData=read.getdata(data);
		conventional.clickActions();
		conventional.clickCheck();
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Name",testData.get("Name"),"1");
		radioInput.clickRadioInputWhereLabelAndChoice_gs("Payment Method","Check");
		Thread.sleep(2000);
		button.clickButtonWhereLabel("Next >");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Reserve Line",testData.get("ReserveLine"), "1");
		radioInput.clickRadioInputWhereLabelAndChoice_gs("Is this the Final Payment?",testData.get("FinalPayment"));
		Thread.sleep(2000);
		textInput.enterTextinputWhereLabelNthOccurence_gs("Payment Amount",testData.get("PaymentAmount"),"1");
		Thread.sleep(5000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Source Income Location",testData.get("SourceIncomeLocation"),"1");
		Thread.sleep(5000);
		button.clickButtonWhereLabel("Next >");
		button.clickButtonWhereAnyLetterUnderLined("Finish","F");
		conventional.validateCheckExistCC9(testData.get("PayTo"), testData.get("GrossAmount"), testData.get("Status"));
		
		Reporter.addStepLog("Check WithReserve is successfully added for GS_Upgrade Application");
	}
	
	
	/**
	 * CC9 - This method will Create Check whose Claim is having Reserves other than USD Reserves
	 * @param data
	 */
	
	public void checkCreationwithReserve_multicurrencyCC9 (String data) throws Exception
	{
		Map<String,String> 
		testData=read.getdata(data);
		conventional.clickActions();
		conventional.clickCheck();
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Name",testData.get("Name"),"1");
		radioInput.clickRadioInputWhereLabelAndChoice_gs("Payment Method","Check");
		Thread.sleep(2000);
		button.clickButtonWhereLabel("Next >");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Reserve Line",testData.get("ReserveLine"), "1");
		Thread.sleep(1000);
		radioInput.clickRadioInputWhereLabelAndChoice_gs("Is this the Final Payment?",testData.get("FinalPayment"));
		Thread.sleep(2000);
		textInput.enterTextinputWhereLabelNthOccurence_gs("Payment Amount",testData.get("PaymentAmount"),"1");
		Thread.sleep(3000);
		button.clickButtonWhereLabel("Next >");
		button.clickButtonWhereAnyLetterUnderLined("Finish","F");
		conventional.validateCheckExistCC9(testData.get("PayTo"),testData.get("GrossAmount"),testData.get("Status"));
		
		Reporter.addStepLog("Check With Multicurrency Reserve is successfully added for GS_Upgrade Application");
	}
	
	
	/**
	 * CC9 - This method will Create Check with USD currency and Claim is having no Reserves 
	 * @param data
	 */
	public void checkCreationwithoutreserve_CC9(String data) throws Exception
	{
		Map<String,String> 
		testData=read.getdata(data); 
		conventional.clickCheck();
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Name",testData.get("Name"),"1");
		radioInput.clickRadioInputWhereLabelAndChoice_gs("Payment Method","Check");
		Thread.sleep(2000);
		button.clickButtonWhereLabel("Next >");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Reserve Line",testData.get("ReserveLine"), "1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Exposure",testData.get("Exposure"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Cost Type",testData.get("CostType"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Cost Category",testData.get("CostCategory"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Reserving Currency",testData.get("Currency"),"1");
		//rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Reportable Tax Type",testData.get("ReportableTaxType"),"1");
		radioInput.clickRadioInputWhereLabelAndChoice("Is this the Final Payment?",testData.get("FinalPayment"));
		Thread.sleep(2000);
		textInput.enterTextinputWhereLabelNthOccurence_gs("Payment Amount",testData.get("PaymentAmount"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Source Income Location",testData.get("SourceIncomeLocation"), "1");
		button.clickButtonWhereLabel("Next >");
		button.clickButtonWhereAnyLetterUnderLined("Finish","F");
		
		Reporter.addStepLog("Check Without Reserve is successfully added for GS_Upgrade Application");
	}
	
	
	/**
	 * CC9 - This method will Create Check with currencies other than USD and Claim is having no Reserves 
	 * @param data
	 */
	public void checkCreationwithoutreserve_multicurrencyCC9(String data) throws Exception
	{
		Map<String,String> 
		testData=read.getdata(data);
		conventional.clickActions();
		conventional.clickCheck();
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Name",testData.get("Name"),"1");
		radioInput.clickRadioInputWhereLabelAndChoice_gs("Payment Method","Check");
		Thread.sleep(2000);
		button.clickButtonWhereLabel("Next >");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Reserve Line",testData.get("ReserveLine"), "1");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Exposure",testData.get("Exposure"),"1");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Cost Type",testData.get("CostType"),"1");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Cost Category",testData.get("CostCategory"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Reserving Currency",testData.get("Currency"),"1");
		//rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Reportable Tax Type",testData.get("ReportableTaxType"),"1");
		radioInput.clickRadioInputWhereLabelAndChoice("Is this the Final Payment?",testData.get("FinalPayment"));
		Thread.sleep(2000);
		textInput.enterTextinputWhereLabelNthOccurence_gs("Payment Amount",testData.get("PaymentAmount"),"1");
		//rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Source Income Location",testData.get("SourceIncomeLocation"), "1");
		button.clickButtonWhereLabel("Next >");
		button.clickButtonWhereAnyLetterUnderLined("Finish","F");
		
		
		Reporter.addStepLog("MultiCurrency Check Without Reserve is successfully added for GS_Upgrade Application");
	}
	
	
	/**
	 * CICC9 - This method will Create Check with currencies other than USD and Claim is having no Reserves 
	 * @param data
	 */
	public void checkCreation_CICC9(String data) throws Exception
	{ 
		Map<String,String> testData=read.getdata(data);
		conventional.clickActions();
		conventional.clickCheck();
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Name",testData.get("CheckName"),"1");
		button.clickButtonWhereLabel("Next >");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Reserve Line",testData.get("ReserveLine"), "1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Payment Type",testData.get("PaymentType"), "1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Payment Type",testData.get("PaymentType"), "1");
		Thread.sleep(2000);
		conventional.addItemInCheck(testData.get("Costcategory"), testData.get("PaymentAmount"));
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Requested By",testData.get("RequestedBy"), "1");
		button.clickButtonWhereLabel("Next >");
		textInput.enterTextinputWhereLabelNthOccurence_gs("Invoice Number",testData.get("InvoiceNumber"), "1");
		button.clickButtonWhereAnyLetterUnderLined("Finish","F");
		
		Reporter.addStepLog("Check is successfully added for GS_Upgrade(CICC9) Application");
	}
}