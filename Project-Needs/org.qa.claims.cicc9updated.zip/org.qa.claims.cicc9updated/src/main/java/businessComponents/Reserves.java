package businessComponents;
/**
 * This class contains methods which used for Claim Creation of GS Upgrade-CC9
 * @author N0323482
 * @Scripted On - 31/08/2018
 */

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.cucumber.listener.Reporter;

import functionalLibrary.Data;
import pageObjects.ButtonScriptless;
import pageObjects.CheckBoxScriptless;
import pageObjects.Conventional;
import pageObjects.LoginDV;
import pageObjects.PickerMenuScriptless;
import pageObjects.RadioInputScriptless;
import pageObjects.RangeInputScriptless;
import pageObjects.TextAreaInputScriptless;
import pageObjects.TextInputScriptless;
import reusableLibrary.ScreenShot;

/**
*Creating new Objects for each script less class
*/
public class Reserves
{	
	public WebDriver driver;
	static ButtonScriptless button;
	static TextInputScriptless textInput;
	TextAreaInputScriptless textAreaInput;
	static RangeInputScriptless rangeInput;
	static RadioInputScriptless radioInput;
	CheckBoxScriptless checkBox;
	PickerMenuScriptless pickerMenu;
	LoginDV loginDv; 
	Conventional conventional;
	Data read;
	ScreenShot ts;
	Map<String, String> testData;

/**
*Instantiation using the Constructor
*@param "Data" in each below method is used to fetch the test data for the respective fields
*/		
	
public Reserves(WebDriver ldriver)
{
	this.driver = ldriver;
	button = new ButtonScriptless(driver);
	textInput = new TextInputScriptless(driver);
	textAreaInput=new TextAreaInputScriptless(driver);
	rangeInput = new RangeInputScriptless(driver);
	radioInput = new RadioInputScriptless(driver);
	loginDv = new LoginDV (driver);	
	conventional=new Conventional(driver);
	checkBox=new CheckBoxScriptless(driver);
	pickerMenu=new PickerMenuScriptless(driver);
	read=new Data();
	
	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}


	/**
	 * CC8 - This method will create Reserve for Property LOB
	 * @param data
	 */
	public void reserveCreation_CC8(String data) throws Throwable 
	{
		Map<String,String> 
		testData=read.getdata(data);
		conventional.clickActions();
		conventional.clickReserve();
		Thread.sleep(5000);
		button.clickButtonWhereAnyLetterUnderLined("Add","A");
		Thread.sleep(5000);
		System.out.println(testData.get("ReserveCostType"));
		conventional.addNewReserve_Nr(testData.get("ReserveExposure"),testData.get("ReserveCostType"),testData.get("ReserveAmount"),testData.get("ReserveReason"),testData.get("ReserveComments"));
		button.clickButtonWhereLabel("Save");
		conventional.validateReserveCC8(testData.get("Coverage"),testData.get("ReserveAmount"), testData.get("Claimant"), testData.get("ReserveCostType")); 
		
		Reporter.addStepLog("Reserve is successfully added for Navigator(CC8) Application");
		
	}
	
	
	/**
	* CC9 - This method will Create Reserves with any currency for any LOB
	*/
	
	public void reserveCreation_CC9(String data) throws InterruptedException
	{
		Map<String,String> 
		testData=read.getdata(data);
		conventional.clickActions();
		conventional.clickReserve();
		Thread.sleep(2000);
		button.clickButtonWhereAnyLetterUnderLined("Add","A");
		Thread.sleep(5000);
		conventional.addNewReserve(testData.get("ReserveExposure"),testData.get("ReserveCostType"),testData.get("ReserveCostCategory"),testData.get("Currency"),testData.get("ReserveAmount"),testData.get("ReserveComments"));
		button.clickButtonWhereLabel("Save");
		conventional.validateReserveCC9(testData.get("Coverage"),testData.get("ReserveAmount"),testData.get("ReserveCostType"),testData.get("ReserveCostCategory"));
		
		Reporter.addStepLog("Reserve is successfully added for GS_Upgrade(CC9) Application");
	}
	
	/**
	* CICC9 - This method will Create Reserves with any currency for any LOB
	*/
	public void reserveCreation_CICC9(String data)
	{
		Map<String,String> testData=read.getdata(data);
		conventional.clickActions();
		conventional.clickReserve();
		conventional.addNewReserve(testData.get("ReserveExposure"),testData.get("ReserveCostType"),testData.get("ReserveCostCategory"),testData.get("Currency"),testData.get("ReserveAmount"),testData.get("ReserveComments"));
		button.clickButtonWhereLabel("Save");
		
		Reporter.addStepLog("Reserve is successfully added for GS_Upgrade(CICC9) Application");
	}
	
	public void validateReserve_CC8(String data)
	{
		Map<String,String> testData=read.getdata(data);
		conventional.validateReserveCC8(testData.get("CreatedDate"),testData.get("ReserveAmount"), testData.get("Claimant"), testData.get("ReserveCostType"));
	}
	
}