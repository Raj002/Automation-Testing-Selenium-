package businessComponents;
/**
 * This class contains methods which used for Claim Creation of GS Upgrade-CC9
 * @author N0323482
 * @Scripted On - 31/08/2018
 */

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.cucumber.listener.Reporter;

import functionalLibrary.Data;
import pageObjects.ButtonScriptless;
import pageObjects.CheckBoxScriptless;
import pageObjects.Conventional;
import pageObjects.LoginDV;
import pageObjects.PickerMenuScriptless;
import pageObjects.RadioInputScriptless;
import pageObjects.RangeInputScriptless;
import pageObjects.TextAreaInputScriptless;
import pageObjects.TextInputScriptless;
import reusableLibrary.ScreenShot;

/**
*Creating new Objects for each script less class
*/

public class Notes
{	
	public WebDriver driver;
	static ButtonScriptless button;
	static TextInputScriptless textInput;
	TextAreaInputScriptless textAreaInput;
	static RangeInputScriptless rangeInput;
	static RadioInputScriptless radioInput;
	CheckBoxScriptless checkBox;
	PickerMenuScriptless pickerMenu;
	LoginDV loginDv; 
	Conventional conventional;
	Data read;
	ScreenShot ts;
	Map<String, String> testData;

	
/**
*Instantiation using the Constructor
*@param "Data" in each below method is used to fetch the test data for the respective fields
*/

	
public Notes(WebDriver ldriver)
{
	this.driver = ldriver;
	button = new ButtonScriptless(driver);
	textInput = new TextInputScriptless(driver);
	textAreaInput = new TextAreaInputScriptless(driver);
	rangeInput = new RangeInputScriptless(driver);
	radioInput = new RadioInputScriptless(driver);
	loginDv = new LoginDV (driver);	
	conventional = new Conventional(driver);
	checkBox = new CheckBoxScriptless(driver);
	pickerMenu = new PickerMenuScriptless(driver);
	read = new Data();
	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
}
	
	/**
	 * @param data
	 * CC8 - This method is used to create Note
	 */
 
	public void notecreation_CC8(String data) throws Exception
	{
		Map<String,String> 
		testData=read.getdata(data);
		conventional.clickActions();
        conventional.clickNotes();
		rangeInput.enterRangeInputWhereLabelNthOccurence("Topic",testData.get("Topic"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurence("Related To",testData.get("RelatedTo"),"1");
		textInput.enterTextinputWhereLabelNthOccurence("Subject",testData.get("Subject"),"1");
		textAreaInput.enterTextAreaInputWhereLabelNthOccurence("Text (2,500)",testData.get("Note"), "1");
		button.clickButtonWhereAnyLetterUnderLined("Update","U");
		conventional.clickNotesMenu();
		
		Reporter.addStepLog("Note is successfully created for Navigator(CC8) Application");
	}
	
	
	/**
	 * @param data
	 * CC9 - This method is used to create Note
	 */
	
	
	public void notecreation_CC9(String data) throws Exception
	{
		Map<String,String> 
		testData=read.getdata(data);
		conventional.clickActions();
        conventional.clickNotes();
		textInput.enterTextinputWhereLabelNthOccurence_gs("Subject",testData.get("Subject"),"1");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Content Type",testData.get("ContentType"),"1");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Related To",testData.get("RelatedTo"), "1");
		Thread.sleep(2000);
		textInput.enterTextinputWhereLabelNthOccurence_gs("Note",testData.get("Note"), "1");
		button.clickButtonWhereAnyLetterUnderLined("Update","U");
		conventional.clickNotesMenu();
		Thread.sleep(2000);
		conventional.validateNotesCC9(testData.get("Subject"),testData.get("Author"),testData.get("ContentType"),testData.get("RelatedTo"));
		
		Reporter.addStepLog("Note is successfully created for GS_Upgrade(CC9) Application");
		
		Reporter.addStepLog(testData.get("Subject")+testData.get("Author")+testData.get("ContentType")+testData.get("RelatedTo"));
		
	}
	

	/**
	 * @param data
	 * CCICC9 - This method is used to create Note
	 */
	public void notecreation_CICC9(String data) throws Exception
	{
		
		Map<String,String> testData=read.getdata(data);
		conventional.clickActions();
        conventional.clickNotes();
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Topic",testData.get("Topic"),"1");
		textInput.enterTextinputWhereLabelNthOccurence_gs("Subject",testData.get("Subject"),"1");
		//System.out.println(testData.get("RelatedTo"));
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Related To",testData.get("RelatedTo"),"1");
		textInput.enterTextinputWhereLabelNthOccurence_gs("Text",testData.get("Note"), "1");
		button.clickButtonWhereAnyLetterUnderLined("Update","U");
		conventional.clickNotesMenu(); 
		
		Reporter.addStepLog("Note is successfully created for GS_Upgrade(CICC9) Application");
	}	
	
	public void validatenote_CC8(String data) throws Exception
	{
		Map<String,String> 
		testData=read.getdata(data);
		conventional.clickNotesMenu();
		conventional.validateNotesCC8(testData.get("Subject"),testData.get("Topic"),testData.get("RelatedTo"));
	}
	
	
	public void validatenote_CICC9(String data) throws Exception
	{
		Map<String,String> 
		testData=read.getdata(data);
		conventional.clickNotesMenu();
		conventional.validateNotesCICC9(testData.get("Author"),testData.get("Topic"),testData.get("RelatedTo"));
	}
}