package businessComponents;
/**
 * This class contains methods which used for Claim Creation of GS Upgrade-CC9
 * @author N0323482
 * @Scripted On - 31/08/2018
 */

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.cucumber.listener.Reporter;

import functionalLibrary.Data;
import pageObjects.ButtonScriptless;
import pageObjects.CheckBoxScriptless;
import pageObjects.Conventional;
import pageObjects.LoginDV;
import pageObjects.PickerMenuScriptless;
import pageObjects.RadioInputScriptless;
import pageObjects.RangeInputScriptless;
import pageObjects.TextAreaInputScriptless;
import pageObjects.TextInputScriptless;
import reusableLibrary.ScreenShot;


/**
*Creating new Objects for each script less class
*/
public class PartiesInvolved
{	
		public WebDriver driver;
		static ButtonScriptless button;
		static TextInputScriptless textInput;
		TextAreaInputScriptless textAreaInput;
		static RangeInputScriptless rangeInput;
		static RadioInputScriptless radioInput;
		CheckBoxScriptless checkBox;
		PickerMenuScriptless pickerMenu;
		LoginDV loginDv; 
		Conventional conventional;
		Data read;
		ScreenShot ts;
		Map<String, String> testData;
		
/**
*Instantiation using the Constructor
*@param "Data" in each below method is used to fetch the test data for the respective fields
*/		

public PartiesInvolved(WebDriver ldriver)
{
		this.driver = ldriver;
		button = new ButtonScriptless(driver);
		textInput = new TextInputScriptless(driver);
		textAreaInput=new TextAreaInputScriptless(driver);
		rangeInput = new RangeInputScriptless(driver);
		radioInput = new RadioInputScriptless(driver);
		loginDv = new LoginDV (driver);	
		conventional=new Conventional(driver);
		checkBox=new CheckBoxScriptless(driver);
		pickerMenu=new PickerMenuScriptless(driver);
		read=new Data();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
}
	
		/**
		 * @param data
		 * CC8 - This method is used to create Add New contact
		 */
		public void createContact_CC8(String data) throws Exception
		{
			Map<String,String> 
			testData=read.getdata(data);
			Thread.sleep(2000);
			conventional.clickPartiesInvolved();
			button.clickButtonWhereAnyLetterUnderLined("New Contact","N");
			driver.findElement(By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_CreateNewContactButton:ClaimContacts_NewPerson-textEl")).click();
			Thread.sleep(2000);
			textInput.enterTextinputWhereLabelNthOccurence("First Name",testData.get("FirstName"),"1");
			textInput.enterTextinputWhereLabelNthOccurence("Last Name",testData.get("LastName"),"1");
			textInput.enterTextinputWhereLabelNthOccurence("Address 1",testData.get("Address"),"1");
			rangeInput.enterRangeInputWhereLabelNthOccurence("City",testData.get("City"),"1");
			rangeInput.enterRangeInputWhereLabelNthOccurence("State",testData.get("State"),"1");
			//textInput.enterTextinputWhereLabelNthOccurence_gs("ZIP Code",testData.get("ZipCode"),"1");
			button.clickButtonWhereLabelNthOccurence("Add","1");
			conventional.addPartiesRoleNR(testData.get("Role"));
			button.clickButtonWhereLabelNthOccurence("OK","1");
			button.clickButtonWhereLabelNthOccurence("Cleansed Address","1");
			conventional.validateContactCC8(testData.get("Name"),testData.get("Role"),testData.get("Address"),testData.get("City"));
			
			Reporter.addStepLog("Contact is successfully added for Navigator(CC8) Application");
		}
		
	
		/**
		 * @param data
		 * CC9 - This method is used to create Add New contact
		 */
		public void createContact_CC9(String data) throws Exception
		{
			Map<String,String> 
			testData=read.getdata(data);
			Thread.sleep(2000);
			conventional.clickPartiesInvolved();
			//driver.findElement(By.xpath("//td[@id='Claim:MenuLinks:Claim_ClaimPartiesGroup']")).click();
			button.clickButtonWhereAnyLetterUnderLined("New Contact","N");
			driver.findElement(By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_CreateNewContactButton:ClaimContacts_NewPerson-textEl")).click();
			textInput.enterTextinputWhereLabelNthOccurence_gs("First name",testData.get("FirstName"),"1");
			textInput.enterTextinputWhereLabelNthOccurence_gs("Last name",testData.get("LastName"),"1");
			textInput.enterTextinputWhereLabelNthOccurence_gs("Address 1",testData.get("Address"),"1");
			rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("State/Province",testData.get("State"),"1");
			textInput.enterTextinputWhereLabelNthOccurence_gs("City",testData.get("City"),"1");
			textInput.enterTextinputWhereLabelNthOccurence_gs("ZIP Code",testData.get("ZipCode"),"1");
			button.clickButtonWhereLabelNthOccurence("Add","1");
			conventional.addPartiesRole(testData.get("Cgroup"),testData.get("Role"));
			button.clickButtonWhereLabelNthOccurence("OK","1");	
			conventional.validateContactCC9(testData.get("Name"),testData.get("Role"),testData.get("Address"),testData.get("City"));
			
			Reporter.addStepLog("Contact is successfully added for GS_Upgrade(CC9) Application");
		}
		
		/**
		 * @param data
		 * CICC9 - This method is used to create Add New contact
		 */
		public void createContact_CICC9(String data) throws Exception
		{
			Map<String,String> 
			testData=read.getdata(data);
			Thread.sleep(2000);
			conventional.clickPartiesInvolved();
			//driver.findElement(By.xpath("//td[@id='Claim:MenuLinks:Claim_ClaimPartiesGroup']")).click();
			button.clickButtonWhereAnyLetterUnderLined("New Contact","N");
			driver.findElement(By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_CreateNewContactButton:ClaimContacts_NewPerson-textEl")).click();
			textInput.enterTextinputWhereLabelNthOccurence_gs("First name",testData.get("FirstName"),"1");
			textInput.enterTextinputWhereLabelNthOccurence_gs("Last name",testData.get("LastName"),"1");
			textInput.enterTextinputWhereLabelNthOccurence_gs("Address 1",testData.get("Address"),"1");
			rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("State",testData.get("State"),"1");
			textInput.enterTextinputWhereLabelNthOccurence_gs("City",testData.get("City"),"1");
			//textInput.enterTextinputWhereLabelNthOccurence_gs("ZIP Code",testData.get("ZipCode"),"1");
			button.clickButtonWhereAnyLetterUnderLined("Add","A");
			conventional.addPartiesRoleCI(testData.get("Role"));
			button.clickButtonWhereLabelNthOccurence("OK","1");
			
			Reporter.addStepLog("Contact is successfully added for GS_Upgrade(CICC9) Application");
		
		}
		
		public void validateContact_CC8(String data) throws Exception
		{
			Map<String,String> 
			testData=read.getdata(data);
			Thread.sleep(2000);
			conventional.clickPartiesInvolved();
			conventional.validateContactCC8(testData.get("FirstName"),testData.get("Role"),testData.get("Address"),testData.get("City"));
		}
}