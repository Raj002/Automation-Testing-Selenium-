package businessComponents;
/**
* This class contains methods which used for Claim Creation of CC8,CC9 application
* @author N0323482
* @Scripted On - 31/08/2018
*/



import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.cucumber.listener.Reporter;

import functionalLibrary.Data;
import pageObjects.ButtonScriptless;
import pageObjects.CheckBoxScriptless;
import pageObjects.Conventional;
import pageObjects.LoginDV;
import pageObjects.PickerMenuScriptless;
import pageObjects.RadioInputScriptless;
import pageObjects.RangeInputScriptless;
import pageObjects.TextAreaInputScriptless;
import pageObjects.TextInputScriptless;
import reusableLibrary.ScreenShot;

/**
*Creating new Objects for each script less class
*/


public class ClaimCreationCICC9 
{	
	public  WebDriver driver;
	static ButtonScriptless button;
	static TextInputScriptless textInput;
	TextAreaInputScriptless textAreaInput;
	static RangeInputScriptless rangeInput;
	static RadioInputScriptless radioInput;
	CheckBoxScriptless checkBox;
	PickerMenuScriptless pickerMenu;
	LoginDV loginDv; 
	Conventional conventional;
	Data read;
	ScreenShot ts;
	Map<String, String> testData;
	Actions action;
	
/**
*Instantiation using the Constructor
*@param "Data" in each below method is used to fetch the test data for the respective fields
*/
	
public ClaimCreationCICC9(WebDriver ldriver,String dataSheet)
{
	this.driver = ldriver;
	button = new ButtonScriptless(driver);
	textInput = new TextInputScriptless(driver);
	textAreaInput=new TextAreaInputScriptless(driver);
	rangeInput = new RangeInputScriptless(driver);
	radioInput = new RadioInputScriptless(driver);
	loginDv = new LoginDV (driver);	
	conventional=new Conventional(driver);
	checkBox=new CheckBoxScriptless(driver);
	pickerMenu=new PickerMenuScriptless(driver);
	read=new Data();
	testData=read.getdata(dataSheet);

	action=new Actions(driver);
}

	/**
	*This method will launch the CICC9 application with the valid credentials
	*/

	public void login_CICC9()
	{
		driver.findElement(By.name("Login:LoginScreen:LoginDV:username")).sendKeys(testData.get("Username"));
		driver.findElement(By.name("Login:LoginScreen:LoginDV:password")).sendKeys(testData.get("Password"));
		driver.findElement(By.id("Login:LoginScreen:LoginDV:submit-btnEl")).click();
		
		Reporter.addStepLog("Successfully Logged in to GS_Upgrade(CICC9) Application");
	}

	
	/**
	*This Method will retrieve the Policy details (Step 1 of FNOL) - Applicable to all LOB's in CICC9 application
	*/
	
	public void policySearchWithPoilcyNumber_CICC9() throws InterruptedException
	{
		button.clickNewClaim();
		Thread.sleep(2000);
		textInput.enterTextinputWhereLabelNthOccurence_gs("Policy Account Number",testData.get("Policy#"),"1");
		textInput.enterTextinputWhereLabelNthOccurence_gs("Loss Date",testData.get("DateofLoss"),"1");
		button.clickButtonWhereAnyLetterUnderLined("Search","S");
		Thread.sleep(5000);
		button.clickButtonWhereLabel("Next >");
		
		Reporter.addStepLog("The Policy "+testData.get("Policy#")+" had been found.");
	}
	
	
	/**
	*This Method will add ReportingByNewPerson (Step 3 of FNOL)
	*/
	public void AddReportingByNewPerson_CICC9() throws InterruptedException
	{
		
		pickerMenu.PickerMenuWhereLabel("Name");
		pickerMenu.clickPickerMenuOption("New Person");
		textInput.enterTextinputWhereLabelNthOccurence_gs("Last name",testData.get("ReportedName"),"1");
		textInput.enterTextinputWhereLabelNthOccurence_gs("Address 1",testData.get("Address1"),"1");
		button.clickButtonWhereLabel("OK");
		rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Relation to Insured",testData.get("RelationtoInsured"));
		rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Relation to Insured",testData.get("RelationtoInsured"));
		textInput.enterTextinputWhereLabelNthOccurence_gs("Email",testData.get("Email"),"1");
		button.clickButtonWhereLabel("Next >");
		if(driver.findElement(By.xpath("//div[@class='message']/img")).isDisplayed())
		{
			button.clickButtonWhereAnyLetterUnderLined("Close ","e");
			Thread.sleep(1000);
			button.clickButtonWhereLabel("Next >");
	    }
		Thread.sleep(3000);
	}
	
	
	/**
	*This Method will add ReportingPerson (Step 3 of FNOL)
	*/
	 public void AddReportingPerson_CICC9() throws InterruptedException
	 {
		   rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Name",testData.get("ReportedNameName"));
		   rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Relation to Insured",testData.get("RelationtoInsured"));
		   rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Relation to Insured",testData.get("RelationtoInsured"));
		   textInput.enterTextinputWhereLabelNthOccurence_gs("Email",testData.get("Email"),"1");
		   button.clickButtonWhereLabel("Next >");
		   button.clickButtonWhereLabel("Next >");
		   WebElement warning=driver.findElement(By.xpath("//div[@class='message']/img"));
		   if(warning.isDisplayed())
		   {
			   Thread.sleep(1000);
			   button.clickButtonWhereAnyLetterUnderLined("Close ","e");
			   Thread.sleep(1000);
			   button.clickButtonWhereLabel("Next >"); 
		   }
		   Thread.sleep(3000);
	 }
	 
	 
	 /**
	 *This Method will enter all mandatory fields in Step 3 of FNOL for Auto Claim
	 */
	 public void addClaiminfoAuto_CICC9() throws InterruptedException
	 {
		 
		 textInput.enterTextinputWhereLabelNthOccurence_gs("Loss Description",testData.get("LossDescription"),"1");
		 Thread.sleep(2000);
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Loss Cause",testData.get("LossCause"));
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Detailed Loss Cause", testData.get("DetailedLossCause"));
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Detailed Loss Cause", testData.get("DetailedLossCause"));
		 textInput.enterTextinputWhereLabelNthOccurence_gs("Address 1",testData.get("Address1"),"1");
		 rangeInput.enterRangeInputWhereLabelNthOccurence1("City",testData.get("City"),"1");
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("State",testData.get("State"));
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("State",testData.get("State"));
		 
		 Reporter.addStepLog("Loss Details for the Auto Claim had been added.");
	 }
	 
	 
	 /**
	 *This Method will enter all mandatory fields in Step 3 of FNOL for Property Claim
	 */ 
	 public void addClaiminfoProperty_CICC9() throws InterruptedException
	 {
		
		 textInput.enterTextinputWhereLabelNthOccurence_gs("Loss Description",testData.get("LossDescription"),"1");
		 Thread.sleep(3000);
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Loss Cause",testData.get("LossCause"));
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Loss Cause",testData.get("LossCause"));
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Detailed Loss Cause", testData.get("DetailedLossCause"));
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Detailed Loss Cause", testData.get("DetailedLossCause"));
		 Thread.sleep(2000);
		 radioInput.clickRadioInputWhereLabelAndChoice_gs("Involves Heavy Equipment?",testData.get("InvolvesHeavyEquipment"));
		 Thread.sleep(2000);
		 rangeInput.enterRangeInputWhereLabelNthOccurence1("How Reported",testData.get("HowReported"),"1");
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Severity",testData.get("Severity"));
		 radioInput.clickRadioInputWhereLabelAndChoice_gs("On Premises?",testData.get("OnPremises"));
		 if(testData.get("Location").isEmpty())
		 {
			 textInput.enterTextinputWhereLabelNthOccurence_gs("Address 1",testData.get("Address1"),"1");
			 rangeInput.enterRangeInputWhereLabelNthOccurence1("City",testData.get("City"),"1");
			 rangeInput.enterRangeInputWhereLabelNthOccurence1("State",testData.get("State"),"1");
			 rangeInput.enterRangeInputWhereLabelNthOccurence1("State",testData.get("State"),"1");	 
		 }
		 else
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Location",testData.get("Location"));
		 
		 Reporter.addStepLog("Loss Details for the Property Claim had been added.");
	}
	 
	 
	/**
	*This Method will enter all mandatory fields in Step 3 of FNOL for Liability Claim
	*/ 
	 public void addClaiminfoLiability_CICC9() throws InterruptedException
	 {
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("How Reported",testData.get("HowReported"));
		 textInput.enterTextinputWhereLabelNthOccurence_gs("Loss Description",testData.get("LossDescription"),"1");
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Loss Cause",testData.get("LossCause"));
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Detailed Loss Cause", testData.get("DetailedLossCause"));
		 Thread.sleep(1000);
		 if(testData.get("Location").contains("New..."))
		 {
			 Thread.sleep(2000);
			 textInput.enterTextinputWhereLabelNthOccurence_gs("Address 1",testData.get("Address1"),"1");
			 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("City",testData.get("City"));
			 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("State",testData.get("State"));
			 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("State",testData.get("State"));	 
		 }
		 else
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Location",testData.get("Location"));
		 
		 Reporter.addStepLog("Loss Details for the Liability Claim had been added.");
	}
	 
	 
	 /**
	  * This Method will add the details of New Property
	  */
	 public void  addProperty_CICC9() throws InterruptedException
	 {
		 button.clickButtonWhereLabelNthOccurence("Add","3");
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Severity",testData.get("Severity"));
		 textInput.enterTextinputWhereLabelNthOccurence_gs("Property Description",testData.get("AddPropertyDesc"),"1");
		 textInput.enterTextinputWhereLabelNthOccurence_gs("Damage Description",testData.get("AddPropertyDamageDesc"),"1");
		 System.out.println(testData.get("AddPropertyName"));
		 if(testData.get("AddPropertyName").equals("New..."))
		 {
			 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Property Name","New...");
			 textInput.enterTextinputWhereLabelNthOccurence_gs("Address 1",testData.get("AddpropAddress1"),"1");
			 textInput.enterTextinputWhereLabelNthOccurence_gs("Address 2",testData.get("AddpropAddress2"),"1");
			 textInput.enterTextinputWhereLabelNthOccurence_gs("Location Number",testData.get("AddPropLocationNumber"),"1");
			 textInput.enterTextinputWhereLabelNthOccurence_gs("Building Number",testData.get("AddPropBuildingNumber"),"1"); 
		 }
		 else
		 {
			rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Property Name",testData.get("AddPropertyName"));
			Thread.sleep(1000);
		 }

		 button.clickButtonWhereLabel("OK"); 
	 }
	 
	 
	 /**
	  * This Method will edit the Property
	  */
	 public void editProperty() throws InterruptedException
	 {
		 String labelName=testData.get("Property");
		 Thread.sleep(4000);
		 //button.clickButtonWhereLabel("Add");
		 action.click(driver.findElement(By.xpath("//div[contains(@id,'EditableFixedPropertyIncidentsLV')]//tbody//tr/td//a[text()='9823 2ND STREET']"))).build().perform();
		 textInput.enterTextinputWhereLabelNthOccurence_gs("Property Description",testData.get("AddPropertyDesc"),"1");
		 textInput.enterTextinputWhereLabelNthOccurence_gs("Damage Description",testData.get("AddPropertyDamageDesc"),"1");
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Severity",testData.get("Severity"));
		 radioInput.clickRadioInputWhereLabelAndChoice_gs("Is Property Habitable?",testData.get("Homehabitable"));
		 button.clickButtonWhereLabel("OK"); 
	 }
	 
	 
	 /**
	  * This Method will add the New Injury
	  */
	 public void addInjury() throws InterruptedException
	 {
		
		 button.clickButtonWhereLabelNthOccurence("Add", "1");
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Severity",testData.get("Severity"));
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Injured Person",testData.get("InjuredPerson"));
		 rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Loss Party",testData.get("InjuredParty"));
		 button.clickButtonWhereLabelNthOccurence("OK", "1"); 
	 }
	
	 
	 /**
	  * This Method will add the New Vehicle
	  */
	public void addInsuredVehicle()
	{
		button.clickButtonWhereAnyLetterUnderLined("Add Vehicle", "V");
		rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Select vehicle",testData.get("Vehicle"));
		checkBox.checkCheckboxInputWhereLabelNthOccurenceCC9(testData.get("Impact"), "1");
		addDriver(testData.get("InsuredName"));
		
		Reporter.addStepLog("Insured Vehicle had been added.");
	}
	
	
	/**
	  * This Method will add the New ThirdPartyVehicle
	  */
	public void addThridPartyVehicle() throws InterruptedException
	{
		button.clickButtonWhereAnyLetterUnderLined("Add Vehicle", "V");
		rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Vehicle Type",testData.get("ThridPartyVehicleType"));
		textInput.enterTextinputWhereLabelNthOccurence_gs("Year",testData.get("ThridPartyYear"),"1");
		textInput.enterTextinputWhereLabelNthOccurence_gs("Make",testData.get("ThirdPartyMake"),"1");
		textInput.enterTextinputWhereLabelNthOccurence_gs("Model",testData.get("ThirdPartyModel"),"1");
		textInput.enterTextinputWhereLabelNthOccurence_gs("Model",testData.get("ThirdPartyModel"),"1");
		checkBox.checkCheckboxInputWhereLabelNthOccurenceCC9(testData.get("Impact"), "1");
		addDriver(testData.get("ThridPartyDriverName"));
		
		Reporter.addStepLog("ThirdParty Vehicle had been added.");
	}
	
	
	/**
	  * This Method will add the New Driver
	  */
	public ClaimCreationCICC9 addDriver(String Name)
	{
		button.clickButtonWhereLabel("Add Driver");
		rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Person", Name);
		button.clickButtonWhereLabel("OK");
		button.clickButtonWhereLabel("OK");
		return this;
	}
	
	
	/**
	 * This Method will Save and Finish the Claim(Step 4,5,6,7) - Applicable to all LOB's in CICC9 application 
	 */
	public void saveAndAssignClaim_CICC9() throws InterruptedException
	{
		button.clickButtonWhereLabel("Next >");
		button.clickButtonWhereLabel("Next >");
		button.clickButtonWhereAnyLetterUnderLined("Finish", "F");
		Thread.sleep(2000);
		
		String claimnum = driver.findElement(By.id("NewClaimSaved:NewClaimSavedScreen:NewClaimSavedDV:Header")).getText();
		claimnum=claimnum.substring(6, 14);	    
		driver.findElement(By.xpath("//a[contains(@id,'GoToTheClaim')]|//div[contains(@id,'GoToClaim')]")).click(); 
		 
		Reporter.addStepLog("The Claim "+claimnum+" has been created.");
	}
	
	
	/**
	 * This Method will add the details of "Liability Damage Exposure" on Post FNOL
	 */
	public void addExposureDetailsLiabilityDamageExposure_CICC9() throws InterruptedException
	{
		
		rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Claimant",testData.get("Claimant"));
		rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Type",testData.get("ClaimantType"));
		textInput.enterTextinputWhereLabelNthOccurence_gs("Damage Description",testData.get("DamageDescription"),"1");
		radioInput.clickRadioInputWhereLabelAndChoice_gs("Labor Law",testData.get("LaborLaw"));
		button.clickButtonWhereAnyLetterUnderLined("Update", "U");
		
		Reporter.addStepLog("Liability Damage Exposure had been added.");
	}
	
	public void addExposureWithTwoSubType(String data) throws InterruptedException
	{
		Map<String,String> testData=read.getdata(data);
		String vehicle_locationName=testData.get("ExpoLocationName/vehicleName"),exposureName=testData.get("ExposureName"),
	    exposureType=testData.get("ExposureType"),exposureSubType=testData.get("ExposureSubType");
		//System.out.println(vehicle_locationName+" "+exposureName+" "+exposureType);
		conventional.clickActions();
		WebElement element=driver.findElement(By.xpath("//a[contains(@id,'NewExposureMenuItemSet_ByCoverage')]/span[text()='Choose by Policy Coverage']"));
		action.moveToElement(element).build().perform();	
		action.moveToElement(driver.findElement(By.xpath("//a[contains(@id,'NewExposureMenuItemSet_ByCoverage')]/span[text()='Choose by Policy Coverage']"))).build().perform();
		if(!vehicle_locationName.isEmpty())
		{
			action.moveToElement(driver.findElement(By.xpath("//a[contains(@id,'NewExposureMenuItemSet_ByCoverage:')]/span[normalize-space()='" + vehicle_locationName + "']"))).build().perform();
		}
		if(testData.get("ExposureType").isEmpty())
		{
			action.moveToElement(driver.findElement(By.xpath("//a[contains(@id,'item:')]/span[text()='" + exposureName + "']"))).click().build().perform();
		}
		if(testData.get("ExposureSubType").isEmpty())
		{
			action.moveToElement(driver.findElement(By.xpath("//a[contains(@id,'item:')]/span[text()='" + exposureName + "']"))).build().perform();
			driver.findElement(By.xpath("//a[contains(@id,'item:')]/span[text()='"+ exposureType +"']")).click();
			
		}
		if(!testData.get("ExposureSubType").isEmpty()&&!testData.get("ExpoLocationName/vehicleName").isEmpty())
		{
			action.moveToElement(driver.findElement(By.xpath("//a[contains(@id,'item:')]/span[text()='"+ exposureName +"']"))).build().perform();
			action.moveToElement(driver.findElement(By.xpath("//a[contains(@id,'item:')]/span[text()='"+ exposureType +"']"))).build().perform();;
			driver.findElement(By.xpath("//a[contains(@id,'item:')]/span[text()='" + exposureSubType +"']")).click();
		}	
	}
	
	
	/**
	 * This Method will add the details of "Building Property Exposure" on Post FNOL
	 */
	public void addExposureDetailsForBuildingPropertyExposure_CICC9() throws InterruptedException
	{
		rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Claimant",testData.get("Claimant"));
		rangeInput.enterRangeInputWhereLabelFirstOccurenceCC9("Type",testData.get("ClaimantType"));
		button.clickButtonWhereAnyLetterUnderLined("Update", "U");
		Thread.sleep(2000);
		
		Reporter.addStepLog("Building Property Exposure had been added.");
	}
	
	public void searchClaimCICC9(String claimnum) throws InterruptedException
	{
		Thread.sleep(2000);
	    driver.findElement(By.id("TabBar:SearchTab-btnInnerEl")).click();
	    textInput.enterTextinputWhereLabelNthOccurence_gs("Claim #", claimnum, "1");
	    button.clickButtonWhereAnyLetterUnderLined("", "S");
	    Thread.sleep(2000);
	    driver.findElement(By.linkText(claimnum)).click();
	 }	
}	   
