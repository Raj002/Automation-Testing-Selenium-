package businessComponents;
/**
 *This class contains methods which used for Claim Creation of CC8 application
 * @author N0323482
 * @Scripted On - 31/08/2018
 */

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.cucumber.listener.Reporter;

import functionalLibrary.Data;
import pageObjects.ButtonScriptless;
import pageObjects.CheckBoxScriptless;
import pageObjects.Conventional;
import pageObjects.LoginDV;
import pageObjects.PickerMenuScriptless;
import pageObjects.RadioInputScriptless;
import pageObjects.RangeInputScriptless;
import pageObjects.TextAreaInputScriptless;
import pageObjects.TextInputScriptless;
import reusableLibrary.ScreenShot;

/**
*Creating new Objects for each script less class
*/

public class ClaimCreationCC8 
{	
	public  WebDriver driver;
	static ButtonScriptless button;
	static TextInputScriptless textInput;
	TextAreaInputScriptless textAreaInput;
	static RangeInputScriptless rangeInput;
	static RadioInputScriptless radioInput;
	CheckBoxScriptless checkBox;
	PickerMenuScriptless pickerMenu;
	LoginDV loginDv; 
	Conventional conventional;
	Data read;
	ScreenShot ts;
	Map<String, String> testData;

/**
 *Instantiation using the Constructor
 *@param "Data" in each below method is used to fetch the test data for the respective fields
*/
	
public ClaimCreationCC8(WebDriver ldriver,String dataSheet)
{
	this.driver = ldriver;
	button = new ButtonScriptless(driver);
	textInput = new TextInputScriptless(driver);
	textAreaInput=new TextAreaInputScriptless(driver);
	rangeInput = new RangeInputScriptless(driver);
	radioInput = new RadioInputScriptless(driver);
	loginDv = new LoginDV (driver);	
	conventional=new Conventional(driver);
	checkBox=new CheckBoxScriptless(driver);
	pickerMenu=new PickerMenuScriptless(driver);
	read=new Data();
	testData=read.getdata(dataSheet);
	
}

	/**
	 *This method will launch the CC8(Navigator) application with the valid credentials
	*/
	public void login_CC8()
	{
		driver.findElement(By.name("USER")).sendKeys(testData.get("Username"));
		driver.findElement(By.name("PASSWORD")).sendKeys(testData.get("Password"));
		driver.findElement(By.name("submitButton")).click();
		Reporter.addStepLog("Successfully Logged in to Navigator(CC8) Application");
	}
	
	
	/**
	 *This Method will retrieve the Policy details (Step 1 of FNOL) - Applicable to all LOB's in CC8 application
	*/
	public void policySearchWithPoilcyNumber_CC8()
	{
		   try{
			   
			   button.clickNewClaim();
			  
			   radioInput.clickRadioInputWhereLabelAndChoice("Create New Claim:",testData.get("ClaimType"));
			   radioInput.clickRadioInputWhereLabelAndChoice("Policy Provider:",testData.get("PolicyProvider"));
			   textInput.enterTextinputWhereLabelFirstOccurence("Date of Loss",testData.get("DateofLoss"));
			   Thread.sleep(2000);
			   rangeInput.enterRangeInputWhereLabelNthOccurence("Time of Loss",testData.get("TimeofLoss"),"1");
			   rangeInput.enterRangeInputWhereLabelNthOccurence("Loss State",testData.get("State"),"1");
			   radioInput.clickRadioInputWhereChoice("Policy #");
			   textInput.enterTextinputWhereLabelFirstOccurence("Policy #",testData.get("Policy#"));
			   button.clickButtonWhereAnyLetterUnderLined("Search","S");
			   Thread.sleep(3000);
			   button.clickButtonWhereLabel("Next >");
			   Thread.sleep(3000);
			   if(driver.findElement(By.id("NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:NewClaimDuplicatesWorksheet_CloseButton-btnInnerEl")).isDisplayed());
		       {
		        		button.clickButtonWhereAnyLetterUnderLined("Close ","e");
		                button.clickButtonWhereLabel("Next >");
		                Thread.sleep(2000);
		       }       
		       
		       Reporter.addStepLog("The Policy "+testData.get("Policy#")+" had been found.");
		     }
		     catch(Exception e) {}
	}
	

	/**
	 *This Method will retrieve the Policy details (Step 1 of FNOL) with different Insured with Same Policy# - Applicable to all LOB's in CC8 application
	*/
	
	public void policySearchWithPoilcyNumber_differentInsuredCC8()
	{
		   try{
			   
			   button.clickNewClaim();
			  
			   radioInput.clickRadioInputWhereLabelAndChoice("Create New Claim:",testData.get("ClaimType"));
			   radioInput.clickRadioInputWhereLabelAndChoice("Policy Provider:",testData.get("PolicyProvider"));
			   textInput.enterTextinputWhereLabelFirstOccurence("Date of Loss",testData.get("DateofLoss"));
			   Thread.sleep(2000);
			   rangeInput.enterRangeInputWhereLabelNthOccurence("Time of Loss",testData.get("TimeofLoss"),"1");
			   rangeInput.enterRangeInputWhereLabelNthOccurence("Loss State",testData.get("State"),"1");
			   radioInput.clickRadioInputWhereChoice("Policy #");
			   textInput.enterTextinputWhereLabelFirstOccurence("Policy #",testData.get("Policy#"));
			   button.clickButtonWhereAnyLetterUnderLined("Search","S");
			   Thread.sleep(3000);
			   button.clickButtonWhereLabelNthOccurence_Select(testData.get("InsuredNameSelect"));
			   Thread.sleep(3000);
			   button.clickButtonWhereLabel("Next >");
			   Thread.sleep(3000);
			   if(driver.findElement(By.id("NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:NewClaimDuplicatesWorksheet_CloseButton-btnInnerEl")).isDisplayed());
		       {
		        		button.clickButtonWhereAnyLetterUnderLined("Close ","e");
		                button.clickButtonWhereLabel("Next >");
		                Thread.sleep(2000);
		       }       
		       
		       Reporter.addStepLog("The Policy "+testData.get("Policy#")+" had been found.");
		     }
		     catch(Exception e) {}
	}
	
	
	
	
	/**
	 *This Method will enter the basic Info (Step 2 of FNOL) - Applicable to all LOB's in CC8 application
	*/
	public void addBasicInfo_CC8()
	{
		rangeInput.enterRangeInputWhereLabelNthOccurence("Name",testData.get("InsuredName"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurence("Relation to Insured",testData.get("RelationtoInsured"),"1");
		button.clickButtonWhereLabel("Next >");
		
		Reporter.addStepLog("The Insured Name "+testData.get("InsuredName")+" had been added.");
	}
	
	
	/**
	 *This Method is used to enter all mandatory details of Property Claim (Step 3,4,5) and create a Property Claim
	*/
	
	public void addClaimInfo_Property_CC8() throws InterruptedException
	{
		//button.clickNewClaim();
		Thread.sleep(3000);
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Loss Category",testData.get("LossCategory"));	
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Loss Cause",testData.get("LossCause"));
		textAreaInput.enterTextAreaInputWhereLabelFirstOccurence("Loss Description",testData.get("LossDescription"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Was anyone home when the fire started?",testData.get("Wasanyonehomewhenthefirestarted?"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Has the fire department responded?",testData.get("Hasthefiredepartmentresponded?"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Did the loss originate from an appliance or item?",testData.get("Didthelossoriginatefromanapplianceoritem?"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("What type?",testData.get("Whattype?"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Any recent work in the vicinity of the loss?",testData.get("Anyrecentworkinthevicinityoftheloss?"));
		textAreaInput.enterTextAreaInputWhereLabelFirstOccurence("Recent Work Details",testData.get("RecentWorkDetails"));
		radioInput.clickRadioInputWhereLabelAndChoice("Is a Contractor identified to perform repairs?",testData.get("IsaContractoridentifiedtoperformrepairs?"));
		
		Reporter.addStepLog("The basic Property loss Details had been added.");
		
		checkBox.checkCheckboxInputWhereLabelNthOccurence("Dwelling","1");
		textAreaInput.enterTextAreaInputWhereLabelFirstOccurence("Damage Description",testData.get("DamageDescription"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Is the home habitable?",testData.get("Isthehomehabitable?"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("How many rooms are impacted?",testData.get("Howmanyroomsareimpacted?"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Is there currently power to the home?",testData.get("Istherecurrentlypowertothehome?"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Is there standing water?",testData.get("Istherestandingwater?"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Is there a hole in the roof?",testData.get("Isthereaholeintheroof?"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Do windows/doors require boardup?",testData.get("Dowindows/doorsrequireboardup?"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Is the roof damage covered?",testData.get("Istheroofdamagecovered?"));
		button.clickButtonWhereLabel("Next >");
		Thread.sleep(2000);
		button.clickButtonWhereLabel("Next >");
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Decline Reason",testData.get("DeclineReason"));
		Thread.sleep(5000);
		
		Reporter.addStepLog("The Dwelling details for the Proprety Claim had been added.");
		
		button.clickButtonWhereAnyLetterUnderLined("Finish","F");
		
		String claimnum = driver.findElement(By.id("NewClaimSaved:NewClaimSavedScreen:NewClaimSavedDV:Header")).getText();
		claimnum=claimnum.substring(6, 14);
		driver.findElement(By.xpath("//div[contains(@id,'GoToClaim-inputEl')]")).click(); 
			 
		Reporter.addStepLog("The Claim "+claimnum+" has been created.");
	 }


	/**
	 *This Method is used to enter all mandatory details in Step 3 of FNOL for Auto Claim
	*/
	public void addClaimInfoForSingleVechileAccident()
	{
	 	rangeInput.enterRangeInputWhereLabelFirstOccurence("Loss Category",testData.get("LossCategory"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Loss Cause",testData.get("LossCause"));
		textAreaInput.enterTextAreaInputWhereLabelFirstOccurence("Loss Description",testData.get("LossDescription"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Fault Rating",testData.get("FaultRating"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Location",testData.get("Location"));
		
		Reporter.addStepLog("Claim Information for the Single Vehicle Accident had been added.");
	}

	/**
	*This Method is used to enter the First Party details in Vehicle screen and create an Auto Claim (Step 3,4)
	*/
	public void addFristPartyVehicleAndFinishClaim() throws InterruptedException
	{
	 	conventional.clickAddVehicle();
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Select Vehicle",testData.get("Vehicle"));	
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Point of First Impact",testData.get("Impact"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Severity",testData.get("Severity"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Was there a child safety seat in the vehicle?",testData.get("ChildSafetySeat"));
		radioInput.clickRadioInputWhereLabelAndChoice("Vehicle Operable?",testData.get("VehicleOperable"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Airbags Deployed?",testData.get("AirbagsDeployed"));
		textAreaInput.enterTextAreaInputWhereLabelFirstOccurence("Damage Description",testData.get("DamageDescription"));
		textAreaInput.enterTextAreaInputWhereLabelFirstOccurence("Pre-existing Damage?",testData.get("Pre-existingDamage"));
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Vehicle towed from scene of accident?",testData.get("VehicleTow"));
		conventional.selectVehicleLocation(testData.get("VechicleLocation"));
		button.clickButtonWhereLabel("Add Driver");
		rangeInput.enterRangeInputWhereLabelFirstOccurence("Driver Name",testData.get("DriverName"));
		radioInput.clickRadioInputWhereLabelAndChoice("Injured?",testData.get("Injury"));
		button.clickButtonWhereLabel("OK");
		textInput.enterTextinputWhereLabelFirstOccurence("Vehicle Mileage",testData.get("Mileage"));
		button.clickButtonWhereLabel("OK");
		button.clickButtonWhereAnyLetterUnderLined("Finish","F");
		Thread.sleep(4000);
		
		String claimnum = driver.findElement(By.id("NewClaimSaved:NewClaimSavedScreen:NewClaimSavedDV:Header")).getText();
		claimnum=claimnum.substring(6, 14);	    
		driver.findElement(By.xpath("//a[contains(@id,'GoToTheClaim')]|//div[contains(@id,'GoToClaim')]")).click(); 
		 
		Reporter.addStepLog("The Claim "+claimnum+" has been created.");
	}
 
	/**
	* @param claimnum - Parameter to enter/store the claim number (Claim # will be given in the Step Definition file)
	* This method will search for the claim and retrieve its details
	*/
	public void searchClaimCC8(String claimnum) throws InterruptedException
	{
		Thread.sleep(5000);
	    driver.findElement(By.id("TabBar:SearchTab-btnInnerEl")).click();
	    textInput.enterTextinputWhereLabelNthOccurence("Claim #", claimnum, "1");
	    button.clickButtonWhereAnyLetterUnderLined("", "S");
	    Thread.sleep(2000);
	    driver.findElement(By.linkText(claimnum)).click();
	}
}