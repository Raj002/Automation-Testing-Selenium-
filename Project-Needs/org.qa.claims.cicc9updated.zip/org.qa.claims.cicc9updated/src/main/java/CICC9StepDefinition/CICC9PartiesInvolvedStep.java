package CICC9StepDefinition;

import org.openqa.selenium.WebDriver;

import businessComponents.ChecksCreation;
import businessComponents.ClaimCreationCC8;
import businessComponents.ClaimCreationCC9;
import businessComponents.ClaimCreationCICC9;
import businessComponents.Notes;
import businessComponents.PartiesInvolved;
import businessComponents.Reserves;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.ButtonScriptless;
import pageObjects.Conventional;

/**
 *@author N0323482
 *Created a New Class to call the Methods in all Main Class where defined the fields in the application
 */
public class CICC9PartiesInvolvedStep 
{
		
	/**
	* Initializing the driver (For Eg;Chrome)
	*/
		
	WebDriver driver;
		  
	/**
	*Creating the Objects for each Class file
	*/	 

	ClaimCreationCICC9 ClaimCICC9;
	PartiesInvolved Contact;
	
		 
	/**
	* Declaring the "Given" method in the Feature file
	* @Param LOB - Identifies the Claim LOB to be created
	* @Param ClaimData - Used to fetch each fields/values from the test data sheet to create the claim  
	*/

	@Given("^Launch the application and loading test data for the ([^\"]*) claim ([^\"]*) for Contact$")
		public void launch_the_application_and_loading_test_data_for_the_claim_for_Contact(String LOB, String ClaimData) throws Throwable 
		{
		
		/**
		* Calling the Driver to launch it by fetching the details in the Hooks File 
		* Hooks File contains the annotations
		*/
		
		driver= Hooks.driver;
				 	
				 	
		/**
		*Instantiation it with the respective Class File
		*/	
		
		ClaimCICC9 = new ClaimCreationCICC9(driver,ClaimData);
		Contact = new PartiesInvolved(driver);
				 	
				 	
		
		/**
		* CICC9 - The below "If Case" will check for Auto LOB/Data declaration is present in feature file
		* CICC9 - If given LOB/Data matches it will call methods in a respective class file and create the Auto Claim
		*/
		
		if(LOB.equalsIgnoreCase("CIAuto"))
		{
			ClaimCICC9.login_CICC9();
			ClaimCICC9.policySearchWithPoilcyNumber_CICC9();
			ClaimCICC9.AddReportingByNewPerson_CICC9();
			ClaimCICC9.addClaiminfoAuto_CICC9();
			ClaimCICC9.addInjury();
			ClaimCICC9.addInsuredVehicle();
			ClaimCICC9.addThridPartyVehicle();
			ClaimCICC9.saveAndAssignClaim_CICC9();
			ClaimCICC9.addExposureDetailsLiabilityDamageExposure_CICC9();
		}
		
		/**
		* CICC9 - The below "If Case" will check for Property LOB/Data declaration is present in feature file
		* CICC9 - If given LOB/Data matches it will call methods in a respective class file and create the Property Claim
		*/
		
		if(LOB.equalsIgnoreCase("CIProperty"))
		{
			ClaimCICC9.login_CICC9();
			ClaimCICC9.policySearchWithPoilcyNumber_CICC9();
			ClaimCICC9.AddReportingByNewPerson_CICC9();
			ClaimCICC9.addClaiminfoProperty_CICC9();
			ClaimCICC9.addProperty_CICC9();
			ClaimCICC9.saveAndAssignClaim_CICC9();
			ClaimCICC9.addExposureDetailsForBuildingPropertyExposure_CICC9();
		}
		
		/**
		* CICC9 - The below "If Case" will check for Liability LOB/Data declaration is present in feature file
		* CICC9 - If given LOB/Data matches it will call methods in a respective class file and create the Liability Claim
		*/
		
		if(LOB.equalsIgnoreCase("CILiability"))
		{
			ClaimCICC9.login_CICC9();
			ClaimCICC9.policySearchWithPoilcyNumber_CICC9();
			ClaimCICC9.AddReportingByNewPerson_CICC9();
			ClaimCICC9.addClaiminfoLiability_CICC9();
			ClaimCICC9.saveAndAssignClaim_CICC9();
			ClaimCICC9.addExposureDetailsLiabilityDamageExposure_CICC9();
		}
	}

	/**
	* Declaring the "When" method in the Feature file
	* Calling Methods in a "Reserves" class File to create Reserve for specified application
	* Calling Methods in a "ChecksCreation" class File to create Check for specified application
	*/

	@When("^Add Contact for the created claim ([^\"]*) for Contact$")
		 public void add_contact_for_the_created_claim_for_Contact(String ContactData) throws Throwable 
		 {
			Contact.createContact_CC8(ContactData);
		 }
	}