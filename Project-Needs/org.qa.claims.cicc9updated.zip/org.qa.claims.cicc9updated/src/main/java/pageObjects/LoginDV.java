package pageObjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import functionalLibrary.ObjectMethods;



public class LoginDV {

	
	WebDriver driver;
	
	public LoginDV (WebDriver driver) {
		this.driver = driver;
	}
		
	ObjectMethods objectMethods = new ObjectMethods();
	
	private static final Logger LOG = LogManager.getLogger(LoginDV.class);
	
	public void login(String userName, String password){
		
		setUserName(userName);
		setPassword(password);
		clickSubmitButton();	
	}
	
	public void logBack(String userName, String password){		
						
						
		logout();				
		login(userName,password);	
	}
	
	
	 public LoginDV logout()
	    {
	           
	        
	        boolean isFlagged = false;

	        while (!isFlagged)
	        {
	            try
	            {

	            	By logOutGear = By.id(":TabLinkMenuButton-btnIconEl");
	            	objectMethods.findObject(driver, logOutGear, 30);          	            
	                WebElement logOutGearEle = driver.findElement(logOutGear);
	                logOutGearEle.click();
	                
	                By logOut = By.id("TabBar:LogoutTabBarLink-textEl");
	            	objectMethods.findObject(driver, logOut, 30);          	            
	                WebElement logOutEle = driver.findElement(logOut);
	                logOutEle.click();
	                objectMethods.hardWait(2000);
	                
	                By logback = By.xpath("//a[text()='Log Back In']");
	            	objectMethods.findObject(driver, logback, 30);          	            
	                WebElement logbackEle = driver.findElement(logback);
	                logbackEle.click();
	               
	                break;
	            }
	            catch (StaleElementReferenceException e)
	            {
	                LOG.info("Into Stale");
	                continue;
	            }
	        }

	        return this;
	    }
	
    public LoginDV setUserName(String userName)
    {
           
        
        boolean isFlagged = false;

        while (!isFlagged)
        {
            try
            {

            	By userid = By.name("USER");
            	objectMethods.findObject(driver, userid, 30);          	            
                WebElement useridEle = driver.findElement(userid);
                useridEle.sendKeys(userName);
                
               
                break;
            }
            catch (StaleElementReferenceException e)
            {
                LOG.info("Into Stale");
                continue;
            }
        }

        return this;
    }
    
    
    public LoginDV setPassword(String password)
    {
           
        
        boolean isFlagged = false;

        while (!isFlagged)
        {
            try
            {

            	By passwordBy = By.name("PASSWORD");
            	objectMethods.findObject(driver, passwordBy, 30);          	            
                WebElement passwordEle = driver.findElement(passwordBy);
                passwordEle.sendKeys(password);
                
               
                break;
            }
            catch (StaleElementReferenceException e)
            {
                LOG.info("Into Stale");
                continue;
            }
        }

        return this;
    }
    
    public LoginDV clickSubmitButton()
    {
           
        
        boolean isFlagged = false;

        while (!isFlagged)
        {
            try
            {

            	By loginBy = By.name("submitButton");
            	objectMethods.findObject(driver, loginBy, 30);          	            
                WebElement loginEle = driver.findElement(loginBy);
                loginEle.click();
                
               
                break;
            }
            catch (StaleElementReferenceException e)
            {
                LOG.info("Into Stale");
                continue;
            }
        }

        return this;
    }
}
