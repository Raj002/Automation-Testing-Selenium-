package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import functionalLibrary.ObjectMethods;

	public class PickerMenuScriptless {
	WebDriver driver;
	ObjectMethods objectMethods = new ObjectMethods();
	public PickerMenuScriptless(WebDriver driver) 
	{
		this.driver = driver;
	}
	
	public PickerMenuScriptless PickerMenuWhereLabel(String labelName)
    {

		clickPickerMenuWhereLabelNthOccurence(labelName, 1);
        return this;

    }
	
	public PickerMenuScriptless clickPickerMenuWhereLabelNthOccurence(String labelName, int occurance){
		
		By pickerMenuEle = By.xpath("//Label/span[text()='" + labelName
                + "']/parent::label/following-sibling::div[1]/child::div/child::div[3]/a");
	   objectMethods.findObject(driver, pickerMenuEle , 30);          	            
       WebElement pickerMenu = driver.findElement(pickerMenuEle);
       pickerMenu.click();
	   return this;
		
	}
	public PickerMenuScriptless clickPickerMenuOption(String labelname){
		
		By pickerMenuOpt = By.xpath("//span[text()='" + labelname
                + "']/parent::a[@role='menuitem']");
	   objectMethods.findObject(driver, pickerMenuOpt , 30); 
       WebElement pickerMenuOption = driver.findElement(pickerMenuOpt);
       pickerMenuOption.click();
	   return this;
		
		
	}
}
