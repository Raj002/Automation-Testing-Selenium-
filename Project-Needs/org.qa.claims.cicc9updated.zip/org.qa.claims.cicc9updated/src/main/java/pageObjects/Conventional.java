package pageObjects;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.cucumber.listener.Reporter;

import functionalLibrary.Data;
import functionalLibrary.ObjectMethods;
import reusableLibrary.ScreenShot;

public class Conventional {

	
	WebDriver driver;
	
	Map<String, String> testData;
	Actions action;
	Conventional conventional;
	Data read;
	                      
	public Conventional (WebDriver driver) {
		this.driver = driver;
		read=new Data();

	}

ObjectMethods objectMethods = new ObjectMethods();

private static final Logger LOG = LogManager.getLogger(Conventional.class);

public void jsClick(WebElement element){
	
	
	((JavascriptExecutor)driver).executeScript("arguments[0].click();", element);
}

public Conventional selectVehicleLocation(String value)
{

    boolean isFlagged = false;

    while (!isFlagged)
    {
        try
        {
			By rangeInput = By.xpath("//input[contains(@id,'VehicleLocDuringBusHrs_RangeInput')]");
			objectMethods.findObject(driver, rangeInput, 30);
			WebElement rangeInputele = driver.findElement(rangeInput);
			rangeInputele.clear();
			rangeInputele.sendKeys(value);
			rangeInputele.sendKeys(Keys.TAB);
			break;
        }
        catch (StaleElementReferenceException e)
        {
            LOG.info("Into Stale");
            continue;
        }
    }
    return this;
    
}

public Conventional clickAddVehicle()
{

    boolean isFlagged = false;

    while (!isFlagged)
    {
        try
        {
			By buttonBy =  By.xpath("//span[contains(@id,'AddVehicleButton-btnInnerEl')]");
			objectMethods.findObject(driver, buttonBy, 30);          	            
		    WebElement buttonEle = driver.findElement(buttonBy);
		    jsClick(buttonEle);
		    break;
        }
        catch (StaleElementReferenceException e)
        {
            LOG.info("Into Stale");
            continue;
        }
    }
    return this;
    
}

public Conventional clickViewNewlySavedClaim()
{

    boolean isFlagged = false;

    while (!isFlagged)
    {
        try
        {
			By linkBy =  By.xpath("//a[contains(@id,'GoToTheClaim')]|//div[contains(@id,'GoToClaim')]");
			objectMethods.findObject(driver, linkBy, 30);          	            
		    WebElement linknEle = driver.findElement(linkBy);
		    jsClick(linknEle);
		    break;
        }
        catch (StaleElementReferenceException e)
        {
            LOG.info("Into Stale");
            continue;
        }
    }
    return this;
    
}
public Conventional addItemInCheck(String categoryval,String Amountval) throws InterruptedException
{
	
	  List<WebElement> checkItem=driver.findElements(By.xpath("//div[contains(@id,':NewPaymentDetailDV:EditablePaymentLineItemsLV-body')]//table"));
	  int i=checkItem.size()-1;
	  Actions action=new Actions(driver);
	  WebElement category=driver.findElement(By.xpath("//div[contains(@id,':NewPaymentDetailDV:EditablePaymentLineItemsLV-body')]//table["+i+"]/tbody//td[2]"));
	  
	  action.click(category).build().perform();
	  driver.switchTo().activeElement().clear();
	  action.sendKeys(categoryval).build().perform();
	  action.sendKeys(Keys.TAB).build().perform();
	  
	  Thread.sleep(1000);
	  driver.switchTo().activeElement().sendKeys(Amountval);
	  return this;
}

public Conventional clickActions()
{

    boolean isFlagged = false;

    while (!isFlagged)
    {
        try
        {
				By buttonBy =  By.xpath("//span[contains(@id,'ClaimMenuActions-btnInnerEl')]");
				objectMethods.findObject(driver, buttonBy, 30);          	            
			    WebElement buttonEle = driver.findElement(buttonBy);
			    jsClick(buttonEle);
			    break;
        }
        
        catch (StaleElementReferenceException e)
        {
            LOG.info("Into Stale");
            continue;
        }
    }
    return this;
}

	public Conventional clickCheck()
	{
		boolean isFlagged = false;
	
	    while (!isFlagged)
	    {
	        try
	        {
				By buttonBy =  By.xpath("//span[contains(@id,'ClaimMenuActions_NewTransaction_CheckSet')]");
				objectMethods.findObject(driver, buttonBy, 30);          	            
			    WebElement buttonEle = driver.findElement(buttonBy);
			    jsClick(buttonEle);
			    break;
	        }
	        catch (StaleElementReferenceException e)
	        {
	            LOG.info("Into Stale");
	            continue;
	        }
	    }
	    return this;
	}

	
public Conventional clickClaimCard()
{
	boolean isFlagged = false;

    while (!isFlagged)
    {
        try
        {
			By buttonBy =  By.xpath("//span[contains(@id,'ClaimMenuActions_NewTransaction_ClaimCard')]");
			objectMethods.findObject(driver, buttonBy, 30);          	            
		    WebElement buttonEle = driver.findElement(buttonBy);
		    jsClick(buttonEle);
		    break;
        }
        catch (StaleElementReferenceException e)
        {
            LOG.info("Into Stale");
            continue;
        }
    }
    return this;
}

public Conventional clickReserve()
{
	boolean isFlagged = false;

    while (!isFlagged)
    {
        try
        {
	By buttonBy =  By.xpath("//span[contains(@id,'ClaimMenuActions_NewTransaction_ReserveSet')]");
	objectMethods.findObject(driver, buttonBy, 30);          	            
    WebElement buttonEle = driver.findElement(buttonBy);
    jsClick(buttonEle);
    break;
        }
        catch (StaleElementReferenceException e)
        {
            LOG.info("Into Stale");
            continue;
        }
    }
    return this;
}

public void  clickPartiesInvolved()
{
	boolean isFlagged = false;

    while (!isFlagged)
    {
        try
        {
			By buttonBy =  By.xpath("//td[@id='Claim:MenuLinks:Claim_ClaimPartiesGroup']");
			objectMethods.findObject(driver, buttonBy, 30);          	            
		    WebElement buttonEle = driver.findElement(buttonBy);
		    jsClick(buttonEle);
		    break;
        }
        catch (StaleElementReferenceException e)
        {
            LOG.info("Into Stale");
            continue;
        }
    }
   
}

/*public Conventional clickContacts()
{
	boolean isFlagged = false;

    while (!isFlagged)
    {
        try
        {
	By buttonBy =  By.xpath("//div[contains(@id,'westPanel')]//table[6]/tbody/tr/td/div/span");
	objectMethods.findObject(driver, buttonBy, 30);          	            
    WebElement buttonEle = driver.findElement(buttonBy);
    jsClick(buttonEle);
    break;
        }
        catch (StaleElementReferenceException e)
        {
            LOG.info("Into Stale");
            continue;
        }
    }
    return this;
}
*/

public Conventional clickNotes()
{
	boolean isFlagged = false;

    while (!isFlagged)
    {
        try
        {
			By buttonBy =  By.xpath("//span[contains(@id,'ClaimMenuActions_NewNote-textEl')]");
			objectMethods.findObject(driver, buttonBy, 30);          	            
		    WebElement buttonEle = driver.findElement(buttonBy);
		    jsClick(buttonEle);
		    break;
        }
        catch (StaleElementReferenceException e)
        {
            LOG.info("Into Stale");
            continue;
        }
    }
    return this;
}

public Conventional clickNotesMenu()
{
	boolean isFlagged = false;

    while (!isFlagged)
    {
        try
        {
			By buttonBy =  By.xpath("//td[@id='Claim:MenuLinks:Claim_ClaimNotes']");
			objectMethods.findObject(driver, buttonBy, 30);          	            
		    WebElement buttonEle = driver.findElement(buttonBy);
		    jsClick(buttonEle);
		    break;
        }
        catch (StaleElementReferenceException e)
        {
            LOG.info("Into Stale");
            continue;
        }
    }
    return this;
}

public Conventional clickPayeeNameMenuIconAndSearch() throws InterruptedException
{
	boolean isFlagged = false;

    while (!isFlagged)
    {
        try
        {
			By buttonBy =  By.xpath("//img[contains(@id,'PayeeNameMenuIcon')]");
			objectMethods.findObject(driver, buttonBy, 30);          	            
		    WebElement buttonEle = driver.findElement(buttonBy);
		    jsClick(buttonEle);
		    Thread.sleep(4000);
		    By buttonSearchBy =  By.xpath("//span[contains(@id,'SearchMenuItem')]");
			objectMethods.findObject(driver, buttonSearchBy, 30);          	            
		    WebElement buttonSearchEle = driver.findElement(buttonSearchBy);
		    jsClick(buttonSearchEle);
		    break;
	     }
        catch (StaleElementReferenceException e)
        {
            LOG.info("Into Stale");
            continue;
        }
    }
    return this;
}

public Conventional editReserveReason(String expData, String reserveReason) throws InterruptedException
{
	List<WebElement> rows =
            driver.findElements(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
            		+ "EditableReservesLV-body']" + "/div/table/tbody/tr"));
        int row = rows.size();

        for (int i = 1; i <= row; i++)
        {

            String strAmt =
                driver
                    .findElement(
                        By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
                            + "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[3]")).getText().trim();

            if (strAmt.contentEquals(expData.trim()))
            {

                driver.findElement(
                    By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
                        + "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[9]")).click();
               Thread.sleep(4000);
                driver.switchTo().activeElement().clear();
                driver.switchTo().activeElement().sendKeys(reserveReason);
                driver.findElement(
                    By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
                        + "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[3]")).click();
                Thread.sleep(4000);
                return this;
            }
        }
        return this;
}

public Conventional editReserveComment(String expData, String reserveComment) throws InterruptedException
{

    List<WebElement> rows =
        driver.findElements(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
            + "EditableReservesLV-body']" + "/div/table/tbody/tr"));
    int row = rows.size();

    for (int i = 1; i <= row; i++)
    {

        String strAmt =
            driver
                .findElement(
                    By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
                        + "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[3]")).getText().trim();

        if (strAmt.contentEquals(expData.trim()))
        {

            driver.findElement(
                By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
                    + "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[10]")).click();
            Thread.sleep(4000);
            driver.switchTo().activeElement().clear();
            driver.switchTo().activeElement().sendKeys(reserveComment);
            driver.findElement(
                By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
                    + "EditableReservesLV-body']" + "/div/table/tbody/tr[" + i + "]/td[3]")).click();
            Thread.sleep(4000);
            return this;
        }
    }
    return this;

}

public Conventional editNewAvilableReserve(String expData, String reseveValue) throws InterruptedException
{
    List<WebElement> rows =
        driver.findElements(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
                        		+ "EditableReservesLV-body']/div/div/table"));
    int row = rows.size();
    System.out.println(row);
    System.out.println(row);
    String strAmt1 =
            driver
                .findElement(
                    By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
                    		+ "EditableReservesLV-body']/div/div/table[2]//tr/td[8]")).getText().trim();
    System.out.println(strAmt1);

    for (int i = 1; i <= row; i++)
    {
    	String strAmt =
                driver
                    .findElement(
                        By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
                        		+ "EditableReservesLV-body']/div/div/table["+ i +"]//tr/td[8]")).getText();
    	driver
        .findElement(
            By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
            		+ "EditableReservesLV-body']/div/div/table["+ i +"]//tr/td[8]")).sendKeys("500");
    	System.out.println(strAmt);

        if (strAmt.contentEquals(expData))
        {

            driver.findElement(
                By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
                        		+"EditableReservesLV-body']/div/div/table["+ i +"]//tr/td[8]")).click();
            Thread.sleep(4000);
            driver.switchTo().activeElement().clear();
            driver.switchTo().activeElement().sendKeys(reseveValue);
            driver.switchTo().activeElement().sendKeys(Keys.TAB);
/*            driver.findElement(
                By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
                        		+"EditableReservesLV-body']/div/div/table["+ i +"]//tr/td[8]")).click();*/
            Thread.sleep(4000);
            return this;
        }
    }
    return this;

}
public Conventional addNewReserve(String exposure, String costType,String costcategory,String currency, String reserveValue,String comments)
{
	boolean isFlagged = false;
	while (!isFlagged){
    try {
    	Thread.sleep(2000);
	List<WebElement> rows =
        driver.findElements(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
                        		+ "EditableReservesLV-body']/div/div/table"));
	 
    	int i =rows.size()-1;
    	
    	WebElement exposureEle=driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:EditableReservesLV-body']/div/div/table["+ i +"]//tr/td[2]"));
    	Actions action=new Actions(driver);
    	action.click(exposureEle).build().perform();
    	driver.switchTo().activeElement().clear();
    	action.sendKeys(exposure).build().perform();
    	action.sendKeys(Keys.TAB).build().perform();
    	Thread.sleep(2000);
    	
    	WebElement costTypeEle=driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
         		+"EditableReservesLV-body']/div/div/table["+ i +"]//tr/td[4]"));
    	action.click(costTypeEle).build().perform();
    	driver.switchTo().activeElement().clear();
    	action.sendKeys(costType).build().perform();
    	action.sendKeys(Keys.TAB).build().perform();
    	Thread.sleep(2000);
		
    	WebElement costcateEle=driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
         		+"EditableReservesLV-body']/div/div/table["+ i +"]//tr/td[5]"));
	 	action.click(costcateEle).build().perform();
	 	driver.switchTo().activeElement().clear();
    	action.sendKeys(costcategory).build().perform();
    	action.sendKeys(Keys.TAB).build().perform();
    	Thread.sleep(2000);
    	
    	WebElement currencyEle=driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
         		+"EditableReservesLV-body']/div/div/table["+ i +"]//tr/td[6]"));
	 	action.click(currencyEle).build().perform();
	 	driver.switchTo().activeElement().clear();
    	action.sendKeys(currency).build().perform();
    	action.sendKeys(Keys.TAB).build().perform();
    	Thread.sleep(2000);
        
    	
		WebElement reserveValEle=driver.findElement(
                By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
                        		+"EditableReservesLV-body']/div/div/table["+ i +"]//tr/td[8]"));
        driver.switchTo().activeElement().clear();
        driver.switchTo().activeElement().sendKeys(reserveValue);
        driver.switchTo().activeElement().sendKeys(Keys.TAB);
        Thread.sleep(2000); 
        
        WebElement commentsEle=driver.findElement(
                    By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
                            		+"EditableReservesLV-body']/div/div/table["+ i +"]//tr/td[12]"));
        action.click(commentsEle).build().perform();
        driver.switchTo().activeElement().sendKeys(comments);  
    }
    catch(StaleElementReferenceException e){
    	isFlagged=true;
    	continue;
    	
    }
    catch(Exception e)
    {
    	e.printStackTrace();
    }
			return this;
	}
	return this;
}


public Conventional addNewReserve_Nr(String exposure, String costType,String reserveValue,String reserveReason,String comments)
{
	boolean isFlagged = false;
	while (!isFlagged){
    try {
    	
	List<WebElement> rows =
        driver.findElements(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:EditableReservesLV-body']/div//tr"));
    	int i =rows.size()-1;
    	System.out.println(i);
    	
    	WebElement exposureEle=driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:EditableReservesLV']/div//tr["+ i +"]/td[2]"));
    	Actions action=new Actions(driver);
    	action.click(exposureEle).build().perform();
    	driver.switchTo().activeElement().clear();
    	action.sendKeys(exposure).build().perform();
    	action.sendKeys(Keys.TAB).build().perform();
    	Thread.sleep(3000);
    	
    	WebElement costTypeEle=driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:EditableReservesLV']/div//tr["+ i +"]/td[4]"));
    	action.click(costTypeEle).build().perform();
    	driver.switchTo().activeElement().clear();
    	Thread.sleep(2000);
    	action.sendKeys(costType).build().perform();
    	action.sendKeys(Keys.TAB).build().perform();
    	Thread.sleep(3000);
    	
		WebElement reserveValEle=driver.findElement(
                By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:EditableReservesLV']/div//tr["+ i +"]/td[7]"));
		action.click(reserveValEle).build().perform();
        Thread.sleep(3000);
        driver.switchTo().activeElement().sendKeys(reserveValue);
        driver.switchTo().activeElement().sendKeys(Keys.TAB);
        Thread.sleep(1000); 
        
        WebElement reserveReasonEle=driver.findElement(
                By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:EditableReservesLV']/div//tr["+ i +"]/td[9]"));
		action.click(reserveReasonEle).build().perform();
        driver.switchTo().activeElement().clear();
        Thread.sleep(2000);
        driver.switchTo().activeElement().sendKeys(reserveReason);
        driver.switchTo().activeElement().sendKeys(Keys.TAB);
        Thread.sleep(3000); 
        
        WebElement commentsEle=driver.findElement(
                    By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:EditableReservesLV']/div//tr["+ i +"]/td[10]"));
        action.click(commentsEle).build().perform();
        Thread.sleep(3000);
        action.sendKeys(comments).build().perform();
    }
    catch(StaleElementReferenceException e){
    	isFlagged=true;
    	continue;
    	
    }
    catch(Exception e)
    {
    	e.printStackTrace();
    }
			return this;
  }
	return this;
}
public Conventional addPartiesRole(String contactgroup, String role)
{
	boolean isFlagged = false;
	while (!isFlagged){
    try {
	List<WebElement> rows =
        driver.findElements(By.xpath("//div[contains(@id,'EditableClaimContactRolesLV')]/div[3]//table"));
    	int i = rows.size()-1;
    
    	
    	WebElement contactgroupEle=driver.findElement(By.xpath("//div[contains(@id,'EditableClaimContactRolesLV')]/div[3]//table["+ i +"]/tbody/tr/td[3]"));
    	Actions action=new Actions(driver);
    	action.click(contactgroupEle).build().perform();
    	driver.switchTo().activeElement().clear();
    	action.sendKeys(contactgroup).build().perform();
    	action.sendKeys(Keys.TAB).build().perform();
    	Thread.sleep(1000);
    	
    	WebElement roleEle=driver.findElement(By.xpath("//div[contains(@id,'EditableClaimContactRolesLV')]/div[3]//table["+ i +"]/tbody/tr/td[4]"));
    	action.click(roleEle).build().perform();
    	driver.switchTo().activeElement().clear();
    	action.sendKeys(role).build().perform();
    	action.sendKeys(Keys.TAB).build().perform();
    	Thread.sleep(1000);
    }
    catch(StaleElementReferenceException e){
    	isFlagged=true;
    	continue;
    	
    }
    catch(Exception e)
    {
    	e.printStackTrace();
    }
			return this;
        
    
	}
	return this;
}

public Conventional validateReserve(String exposure, String reserveValue, String costType,String costcategory, String comments)
{
	List<WebElement> rows =
	        driver.findElements(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
	                        		+ "EditableReservesLV-body']/div/div/table"));
	int i = rows.size();
	for(int j=1;j<=i;j++)
	{
		String costcateEle=driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
	     		+"EditableReservesLV-body']/div/div/table["+ j +"]//tr/td[5]")).getText();	
		String exposureEleVal=driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
		     		+"EditableReservesLV-body']/div/div/table["+ j +"]//tr/td[2]")).getText();
		if(exposureEleVal.equalsIgnoreCase(exposure)&&costcateEle.equalsIgnoreCase(costcategory))
		{
			String costTypeEle=driver.findElement(By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
		     		+"EditableReservesLV-body']/div/div/table["+ j +"]//tr/td[4]")).getText();
			
			String commentsval=driver.findElement(
		            By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
		            		+"EditableReservesLV-body']/div/div/table["+ j +"]//tr/td[10]")).getText();
			String reserveValEle=driver.findElement(
		            By.xpath("//div[@id='NewReserveSet:NewReserveSetScreen:ReservesSummaryDV:"
		                    		+"EditableReservesLV-body']/div/div/table["+ j +"]//tr/td[8]")).getText();
	
			Assert.assertEquals(exposureEleVal, exposure);
			Assert.assertEquals(costTypeEle, costType);
			Assert.assertEquals(costcateEle, costcategory);
			Assert.assertEquals(commentsval, comments);
			String reserve=reserveValEle.substring(1);
			Assert.assertEquals(reserve, reserveValue);
			break;
		}
	}
	return this;
}


public Conventional addPartiesRoleCI(String role)
{
	boolean isFlagged = false;
	while (!isFlagged){
    try {
    Thread.sleep(1000);
	List<WebElement> rows =
        driver.findElements(By.xpath("//div[contains(@id,'EditableClaimContactRolesLV')]/div[3]//table"));
    	int j = rows.size()-1;
        System.out.println("total row number"+j);
    	Actions action=new Actions(driver);
    	WebElement roleEle=driver.findElement(By.xpath("//div[contains(@id,'EditableClaimContactRolesLV')]/div[3]//table["+ j +"]/tbody/tr/td[3]"));
    	action.click(roleEle).build().perform();
    	driver.switchTo().activeElement().clear();
    	action.sendKeys(role).build().perform();
    	action.sendKeys(Keys.TAB).build().perform();
    	Thread.sleep(1000);
    }
    catch(StaleElementReferenceException e){
    	isFlagged=true;
    	continue;
    	
    }
    catch(Exception e)
    {
    	e.printStackTrace();
    }
			return this;
        
    
	}
	return this;
}


public Conventional addPartiesRoleNR(String role)
{
	boolean isFlagged = false;
	while (!isFlagged){
    try {
	List<WebElement> rows =
        driver.findElements(By.xpath("//div[contains(@id,'EditableClaimContactRolesLV-body')]/div//table"));
    	int i = rows.size()-1;
    	Actions action=new Actions(driver);
 
    	WebElement roleEle=driver.findElement(By.xpath("//div[contains(@id,'EditableClaimContactRolesLV-body')]/div//table/tbody/tr/td[3]"));
    	action.click(roleEle).build().perform();
    	driver.switchTo().activeElement().clear();
    	action.sendKeys(role).build().perform();
    	action.sendKeys(Keys.TAB).build().perform();
    	Thread.sleep(1000);
    }
    catch(StaleElementReferenceException e){
    	isFlagged=true;
    	continue;
    	
    }
    catch(Exception e)
    {
    	e.printStackTrace();
    }
			return this;
        
    
	}
	return this;
}




public void validateCheckExistCICC9(String Payto,String GrossAmt,String chkstaus)
{
	boolean flag=false;
	List<WebElement> check=driver.findElements(By.xpath("//div[contains(@id,'ChecksLV-body')]/div/div/table"));
	int size=check.size();
	for(int i=1;i<=size;i++)
	{
		String payto=driver.findElement(By.xpath("//div[contains(@id,'ChecksLV-body')]//table["+i+"]/tbody/tr/td[2]")).getText();
		if(Payto.equalsIgnoreCase(payto))
		{
			String grossamount=driver.findElement(By.xpath("//div[contains(@id,'ChecksLV-body')]//table["+i+"]/tbody/tr/td[5]")).getText();
			String status=driver.findElement(By.xpath("//div[contains(@id,'ChecksLV-body')]//table["+i+"]/tbody/tr/td[8]")).getText();
			if(grossamount.equalsIgnoreCase(GrossAmt)&&chkstaus.equalsIgnoreCase(status))
			{
				flag=true;
				break;
			}
		}
	}
	Assert.assertEquals(flag, true);
}

public void validateCheckStatus(String Payto, String Role, String GrossAmt,String chkstaus)
{
List<WebElement> check=driver.findElements(By.xpath("//div[contains(@id,'ChecksLV-body')]/div/div/table"));
int size=check.size();
for(int i=1;i<=size;i++)
{
String payto=driver.findElement(By.xpath("//div[contains(@id,'ChecksLV-body')]//table["+i+"]/tbody/tr/td[2]")).getText();
String grossamount=driver.findElement(By.xpath("//div[contains(@id,'ChecksLV-body')]//table["+i+"]/tbody/tr/td[5]")).getText();
if(Payto.equalsIgnoreCase(payto)&&grossamount.equalsIgnoreCase(GrossAmt))
{
String status=driver.findElement(By.xpath("//div[contains(@id,'ChecksLV-body')]//table["+i+"]/tbody/tr/td[8]")).getText();
Assert.assertEquals(status, chkstaus);
break;
}
}
}

public void validateNotesCICC9(String Author, String Topic, String Relatedto)
{ 
	boolean flag=false;
	List<WebElement> notes=driver.findElements(By.xpath("//div[contains(@id,'ClaimNotesLV-body')]//table"));
	int size=notes.size();
	for(int i=1;i<=size;i++)
	{
		try
		{
			String author=driver.findElement(By.xpath("//div[contains(@id,'ClaimNotesLV-body')]//table["+i+"]/tbody//tbody//tr//td/label[text()='Author']/parent::td/following-sibling::td/div")).getText();
			String topic=driver.findElement(By.xpath("//div[contains(@id,'ClaimNotesLV-body')]//table["+i+"]/tbody//tbody//tr//td/label[text()='Topic']/parent::td/following-sibling::td/div")).getText();
			String relatedto=driver.findElement(By.xpath("//div[contains(@id,'ClaimNotesLV-body')]//table["+i+"]/tbody//tbody//tr//td/label[text()='Related To']/parent::td/following-sibling::td/div")).getText();
			if(Author.equalsIgnoreCase(author)&&topic.equalsIgnoreCase(Topic)&&relatedto.equalsIgnoreCase(Relatedto))
			{
				
				Assert.assertEquals(author, Author);
				Assert.assertEquals(topic, Topic);
				Assert.assertEquals(relatedto, Relatedto);
				Reporter.addStepLog("Note is available with these values "+author+" "+topic+" "+relatedto); 
				break;
			}
			else if(i == size ) {
				Reporter.addStepLog("No Note is available with these values "+author+" "+topic+" "+relatedto);
				ScreenShot.TakeScreenShot("NoteValidation");
				throw new Exception(); 
			}
		}
		catch(Exception E){
			
		}
		
	}
	
}

public void validateContactCICC9(String Name, String Role, String Adress,String Phone) 
{
	List<WebElement> contact=driver.findElements(By.xpath("//div[contains(@id,'PeopleInvolvedDetailedLV-body')]//table"));
	int size=contact.size();
	for(int i=1;i<=size;i++){
		String name=driver.findElement(By.xpath("//div[contains(@id,'PeopleInvolvedDetailedLV-body')]//table["+i+"]/tbody/tr/td[2]")).getText();
		System.out.println(size+" "+Name);
		if(Name.equalsIgnoreCase(name))
		{
			String phone=driver.findElement(By.xpath("//div[contains(@id,'PeopleInvolvedDetailedLV-body')]//table["+i+"]/tbody/tr/td[5]")).getText();
			String Address=driver.findElement(By.xpath("//div[contains(@id,'PeopleInvolvedDetailedLV-body')]//table["+i+"]/tbody/tr/td[6]")).getText();
			String role=driver.findElement(By.xpath("//div[contains(@id,'PeopleInvolvedDetailedLV-body')]//table["+i+"]/tbody/tr/td[3]")).getText();
			Assert.assertEquals(phone, Phone);
			Assert.assertEquals(Adress, Address);
			Assert.assertEquals(role, Role);
			break;
		}
	}
	
}

public Conventional  validateReserveCC9(String coverage, String originalamount, String costType,String costcategory)
{
	List<WebElement> rows =
			
	driver.findElements(By.xpath("//div[@id='ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV']/div[3]/div/div/table"));
	
	int i = rows.size();
	for(int j=1;j<=i;j++)
	{
		String Coverage = driver.findElement(By.xpath("//div[@id='ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV']/div[3]/div/div/table["+j+"]/tbody/tr/td[4]")).getText();
		
		String originalamountapp = driver.findElement(By.xpath("//div[@id='ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV']/div[3]/div/div/table["+j+"]/tbody/tr/td[2]")).getText();
		
		int len = originalamountapp.length();
		originalamountapp=originalamountapp.substring(0,len-4);
		
			String costTypeEle = driver.findElement(By.xpath("//div[@id='ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV']/div[3]/div/div/table["+j+"]/tbody/tr/td[5]")).getText();
			
			String costcategoryEle = driver.findElement(By.xpath("//div[@id='ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV']/div[3]/div/div/table["+j+"]/tbody/tr/td[6]")).getText();
			
			if(Coverage.equalsIgnoreCase(coverage)&&costTypeEle.equalsIgnoreCase(costType)&&costcategoryEle.equalsIgnoreCase(costcategory))			
			{ 
			Assert.assertEquals(Coverage, coverage);
			System.out.println(Coverage+" "+coverage);
			
			Assert.assertEquals(originalamountapp, originalamount);
			System.out.println(originalamountapp+" "+originalamount);
			Assert.assertEquals(costTypeEle, costType);
			System.out.println(costTypeEle+" "+costType);
			Assert.assertEquals(costcategoryEle, costcategory);
			System.out.println(costcategoryEle+" "+costcategory);
			break;	
			}	
		}
			return this;		
}

/*System.out.println(Coverage+" "+coverage);
System.out.println(originalamountapp+" "+originalamount);
System.out.println(costTypeEle+" "+costType);
System.out.println(costcategoryEle+" "+costcategory);

//&&costType.equalsIgnoreCase(costTypeEle)&&costcategory.equalsIgnoreCase(costcategoryEle)
 */


public Conventional validateCheckExistCC9(String Payto,String Grossamt,String Checkstatus)
{

	List<WebElement> rows =
			
			driver.findElements(By.xpath("//div[@id='ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV']//table"));
			
			int i = rows.size();
			for(int j=1;j<=i;j++)
			{
				String payto = driver.findElement(By.xpath("//div[@id='ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV']//table["+j+"]/tbody/tr/td[2]")).getText();
				
				String grossamt = driver.findElement(By.xpath("//div[@id='ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV']//table["+j+"]/tbody/tr/td[3]")).getText();
					
				int len = grossamt.length();
				grossamt=grossamt.substring(0,len-4);
				
				String checkstatus = driver.findElement(By.xpath("//div[@id='ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV']//table["+j+"]/tbody/tr/td[5]")).getText();
					
				if(Payto.equalsIgnoreCase(payto)&& Grossamt.equalsIgnoreCase(grossamt)&&Checkstatus.equalsIgnoreCase(checkstatus))			
				{ 
				Assert.assertEquals(payto, Payto);
				System.out.println(payto+" "+Payto);
				
				Assert.assertEquals(grossamt, Grossamt);
				System.out.println(grossamt+" "+Grossamt);
					
				Assert.assertEquals(Checkstatus, checkstatus);
				System.out.println(Checkstatus+" "+checkstatus);
				
				break;	
				}	
		}
					return this;
}

public void validateNotesCC9(String Subject,String Author, String Content, String Relatedto)
{ 
	
	boolean flag=false;
	List<WebElement>notes=driver.findElements(By.xpath("//div[contains(@id,'ClaimNotesLV-body')]/div/div/table"));
	
	int size=notes.size();
	for(int i=1;i<=size;i++)
	{
	
	
		String subject=driver.findElement(By.xpath("//div[contains(@id,'ClaimNotesLV-body')]/div/div/table["+i+"]/tbody//tbody//tr//td/label[text()='Subject']/parent::td/following-sibling::td/div")).getText();
		System.out.println(Subject);
		String author=driver.findElement(By.xpath("//div[contains(@id,'ClaimNotesLV-body')]/div/div/table["+i+"]/tbody//tbody//tr//td/label[text()='Author']/parent::td/following-sibling::td/div")).getText();
		System.out.println(Author);
		String content=driver.findElement(By.xpath("//div[contains(@id,'ClaimNotesLV-body')]/div/div/table["+i+"]/tbody//tbody//tr//td/label[text()='Content Type']/parent::td/following-sibling::td/div")).getText();
		System.out.println(Content);
		String relatedto=driver.findElement(By.xpath("//div[contains(@id,'ClaimNotesLV-body')]/div/div/table["+i+"]/tbody//tbody//tr//td/label[text()='Related To']/parent::td/following-sibling::td/div")).getText();
		System.out.println(Relatedto);
		if(Subject.equalsIgnoreCase(subject)&&Content.equalsIgnoreCase(content)&&Relatedto.equalsIgnoreCase(relatedto));
		{
			flag=true;
			break;
		}
	}
	Assert.assertEquals(flag, true);
}


public Conventional validateContactCC9(String Name, String Role, String Adress,String City) 
{
	List<WebElement> rows =
	driver.findElements(By.xpath("//div[contains(@id,'PeopleInvolvedDetailedLV-body')]/div/div/table"));
	
	int i = rows.size();
	for(int j=1;j<=i;j++)
	{

		String name=driver.findElement(By.xpath("//div[contains(@id,'PeopleInvolvedDetailedLV-body')]/div/div/table["+j+"]/tbody/tr/td[2]")).getText();
		String role=driver.findElement(By.xpath("//div[contains(@id,'PeopleInvolvedDetailedLV-body')]/div/div/table["+j+"]/tbody/tr/td[4]")).getText();
		String Address=driver.findElement(By.xpath("//div[contains(@id,'PeopleInvolvedDetailedLV-body')]/div/div/table["+j+"]/tbody/tr/td[5]")).getText();
		String city=driver.findElement(By.xpath("//div[contains(@id,'PeopleInvolvedDetailedLV-body')]/div/div/table["+j+"]/tbody/tr/td[6]")).getText();
		
		if(Name.equalsIgnoreCase(name)&&Role.equalsIgnoreCase(role)&&Adress.equalsIgnoreCase(Address)&&City.equalsIgnoreCase(city))	
		{
			Assert.assertEquals(name, Name);
			System.out.println(name+" "+Name);
		
			Assert.assertEquals(role, Role);
			System.out.println(role+" "+Role);
			
			Assert.assertEquals(Adress, Address);
			System.out.println(Adress+" "+Address);
			
			Assert.assertEquals(city, City);
			System.out.println(city+" "+City);
			break; 
		} 
	}
		return this;
}


public Conventional validateReserveCC8(String coverage, String originalamount,String claimant,String costType )
{
List<WebElement> rows =
driver.findElements(By.xpath("//div[@id='ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV-body']/div/table/tbody/tr"));
int i = rows.size();
for(int j=1;j<=i;j++)
{
String Coverage = driver.findElement(By.xpath("//div[@id='ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV-body']/div/table/tbody/tr["+j+"]/td[2]")).getText(); 
String originalamountapp = driver.findElement(By.xpath("//div[@id='ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV-body']/div/table/tbody/tr["+j+"]/td[3]")).getText();
originalamountapp=originalamountapp.substring(1);
String claimantapp = driver.findElement(By.xpath("//div[@id='ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV-body']/div/table/tbody/tr["+j+"]/td[4]")).getText();
String costTypeEle = driver.findElement(By.xpath("//div[@id='ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV-body']/div/table/tbody/tr["+j+"]/td[5]")).getText();
if(Coverage.equalsIgnoreCase(coverage)&&claimantapp.equalsIgnoreCase(claimant)&&costTypeEle.equalsIgnoreCase(costType))
{ 
Assert.assertEquals(coverage, Coverage);
System.out.println(coverage+" "+Coverage);
Assert.assertEquals(originalamount, originalamountapp);
System.out.println(originalamount+" "+originalamountapp);
Assert.assertEquals(claimantapp, claimant);
System.out.println(claimantapp+" "+claimant);
Assert.assertEquals(costTypeEle, costType);
System.out.println(costTypeEle+" "+costType);
break; 
} 
}
return this;
}


public void validateCheckExistCC8(String Payto,String GrossAmt,String chkstaus)
{
	boolean flag=false;
	List<WebElement> check=driver.findElements(By.xpath("//div[@id='ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV']//table"));
	int size=check.size();
	for(int i=1;i<=size;i++)
	{
		String payto=driver.findElement(By.xpath("//div[@id='ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV']//table["+i+"]/tbody/tr/td[1]")).getText();
		if(Payto.equalsIgnoreCase(payto))
		{
			String grossamount=driver.findElement(By.xpath("//div[@id='ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV']//table["+i+"]/tbody/tr/td[4]")).getText();
			
			String money=payto.substring(1);
			Assert.assertEquals(money, Payto);
		
		String status=driver.findElement(By.xpath("//div[@id='ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV']//table["+i+"]/tbody/tr/td[8]")).getText();
		if(grossamount.equalsIgnoreCase(GrossAmt)&&chkstaus.equalsIgnoreCase(status))
		{
			flag=true;
			break;
		}
		}
	}
	Assert.assertEquals(flag,true);
}


public void validateNotesCC8(String Subject, String Topic, String Relatedto)
{ 
	boolean flag=false;
	List<WebElement> notes=driver.findElements(By.xpath("//div[contains(@id,'ClaimNotesLV-body')]//table"));
	int size=notes.size();
	for(int i=1;i<=size;i++)
	{
		String subject=driver.findElement(By.xpath("//div[contains(@id,'ClaimNotes:NotesSearchScreen:ClaimNotesLV')]/div[4]//table/tbody/tr["+i+"]/td[6]")).getText();
		String topic=driver.findElement(By.xpath("//div[contains(@id,'ClaimNotes:NotesSearchScreen:ClaimNotesLV')]/div[4]//table/tbody/tr["+i+"]/td[4]")).getText();	
		String relatedto=driver.findElement(By.xpath("//div[contains(@id,'ClaimNotes:NotesSearchScreen:ClaimNotesLV')]/div[4]//table/tbody/tr["+i+"]/td[5]")).getText();
		if(Subject.equalsIgnoreCase(subject)&&topic.equalsIgnoreCase(Topic)&&Relatedto.equalsIgnoreCase(relatedto));
		{
			flag=true;
			break;
		}
	}
	Assert.assertEquals(flag, true);
}

public Conventional validateContactCC8(String Name, String Role, String Adress,String City) 
{
	List<WebElement> contact=driver.findElements(By.xpath("//div[contains(@id,'PeopleInvolvedDetailedLV-body')]//table/tbody/tr"));
	int i = contact.size();
	for(int j=1;j<=i;j++)
	{	
			String name=driver.findElement(By.xpath("//div[contains(@id,'PeopleInvolvedDetailedLV-body')]//table/tbody/tr["+j+"]//td[2]")).getText();
			String role=driver.findElement(By.xpath("//div[contains(@id,'PeopleInvolvedDetailedLV-body')]//table/tbody/tr["+j+"]//td[3]")).getText();
			String Address=driver.findElement(By.xpath("//div[contains(@id,'PeopleInvolvedDetailedLV-body')]//table/tbody/tr["+j+"]//td[6]")).getText();
			String city=driver.findElement(By.xpath("//div[contains(@id,'PeopleInvolvedDetailedLV-body')]//table/tbody/tr["+j+"]//td[7]")).getText();			
			
			if(Name.equalsIgnoreCase(name)&&Role.equalsIgnoreCase(role)&&Adress.equalsIgnoreCase(Address)&&City.equalsIgnoreCase(city))	
			{	
			
			Assert.assertEquals(name, Name);
			System.out.println(name+" "+Name);
			
			Assert.assertEquals(role, Role);
			System.out.println(role+" "+Role);
			
			Assert.assertEquals(Address, Adress);
			System.out.println(Address+" "+Adress);
			
			Assert.assertEquals(city, City);
			System.out.println(city+" "+City);
			break;
			} 
		}
		return this;
	}
}