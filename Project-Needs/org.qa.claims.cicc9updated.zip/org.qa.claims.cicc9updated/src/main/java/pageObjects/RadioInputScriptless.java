package pageObjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import functionalLibrary.ObjectMethods;

public class RadioInputScriptless {


                WebDriver driver;
                
                public RadioInputScriptless (WebDriver driver) {
                                this.driver = driver;
                }
                
                ObjectMethods objectMethods = new ObjectMethods();
                
                private static final Logger LOG = LogManager.getLogger(RadioInputScriptless.class);
                
                
                public RadioInputScriptless clickRadioInputWhereLabelAndChoice(String labelName, String value)
                    {

                        boolean isFlagged = false;

                        while (!isFlagged)
                        {
                            try
                            {

                                By radioInputele = By.xpath("//label[text()='" + labelName
                                        + "']/parent :: td/following-sibling:: td//label[text()='" + value
                                         + "']/preceding-sibling :: input [@role='radio'][1]");
                               objectMethods.findObject(driver, radioInputele, 30);                                  
                                WebElement radioInput = driver.findElement(radioInputele);
                                radioInput.click();
                                
                               
                                break;
                            }
                            catch (StaleElementReferenceException e)
                            {
                                LOG.info("Into Stale");
                                continue;
                            }
                        }

                        return this;

                    }

                    public RadioInputScriptless clickRadioInputWhereChoice(String value)
                    {

                        boolean isFlagged = false;
                        while (!isFlagged)
                        {
                            try
                            {
                                By radioInputele = By.xpath("//label[text()='" + value + "']/preceding :: input[@role='radio'][1]");

                                objectMethods.findObject(driver, radioInputele, 30);
                                WebElement radioInput = driver.findElement(radioInputele);
                                radioInput.click();
                                break;
                            }
                            catch (StaleElementReferenceException e)
                            {
                                LOG.info("Into Stale");
                            }
                        }

                        return this;
                        }
                    
                    public RadioInputScriptless clickRadioInputWhereChoice_gs(String value)
                    {

                        boolean isFlagged = false;
                        while (!isFlagged)
                        {
                            try
                            {
                                By radioInputele = By.xpath("//label[text()='" + value + "']//parent::div//preceding-sibling::input[@type='button'][1]");

                                objectMethods.findObject(driver, radioInputele, 30);
                                WebElement radioInput = driver.findElement(radioInputele);
                                radioInput.click();
                                break;
                            }
                            catch (StaleElementReferenceException e)
                            {
                                LOG.info("Into Stale");
                            }
                        }

                        return this;

                    }
                    public RadioInputScriptless clickRadioInputWhereLabelAndChoice_gs(String labelName,String value)
                    {

                        boolean isFlagged = false;
                        while (!isFlagged)
                        {
                            try
                            {
                                By radioInputele = By.xpath("//label/span[text()='"+ labelName +"']/ancestor::div[1]/div/div/table/tbody/tr/td/div//label[text()='"+ value +"']");
                                Actions action=new Actions(driver);
                                objectMethods.findObject(driver, radioInputele, 30);
                                WebElement radioInput = driver.findElement(radioInputele);
                                action.click(radioInput).build().perform();
                                break;
                            }
                            catch (StaleElementReferenceException e)
                            {
                                LOG.info("Into Stale");
                            }
                        }

                        return this;

                    }
                    
                    
}

