/*package businessComponentsArchive;

import org.openqa.selenium.WebDriver;

import StepDefinitionNew.Hooks;
import businessComponents.ChecksCreation;
import businessComponentsArchive.Reserve;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import pageObjects.ButtonScriptless;
import pageObjects.Conventional;

public class AddReserveTest {
	WebDriver driver;
	ChecksCreation claim;
	Reserve reserve;
	Conventional con;
    ButtonScriptless button;
	@Given("^Create an Auto Claim on a policy with no COLL coverage$")
	public void create_an_Auto_Claim_on_a_policy_with_no_COLL_coverage() throws Throwable {
	  driver=Hooks.driver;
	  claim=new ChecksCreation(driver,"Testdata_ClaimCreation_CIClaim");
	  reserve=new Reserve(driver);
	  button=new ButtonScriptless(driver);
	  con=new Conventional(driver);
	  claim.searchPolicy_CI();
	  claim.selectVehicle();
	  claim.AddReportingByNewPerson();
	  claim.addLossDetails();
	  //claim.addBasicInfo();
	}

	@When("^Add reserve$")	
	public void add_reserve() throws Throwable {
		 claim.addInsuredVehicle();
		 claim.addThridPartyVehicle();
		 claim.saveAndAssingClaim();
		 claim.addExposureWithTwoSubType();
		 claim.addExposureDetailsLiabilityDamage();
	     //claim.searchClaim("29863600");
		 reserve.addReserve();
		 //con.editNewAvilableReserve("$600.00","50");
	
	}
}
*/