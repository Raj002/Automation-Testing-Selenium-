package businessComponentsArchive;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import functionalLibrary.DataStorage;
import functionalLibrary.ObjectMethods;

public class TabBar {

	WebDriver driver;

	public TabBar(WebDriver driver) {
		this.driver = driver;
	}

	ObjectMethods objectMethods = new ObjectMethods();

	private static final Logger LOG = LogManager.getLogger(TabBar.class);
	
	public void searchCreatedClaim(String key){
		openMenu();
		setClaimNumberFromKey(key);
		clickFindClaimButton();		
		
	}

	public TabBar openMenu() {

		boolean isFlagged = false;

		while (!isFlagged) {
			try {
				By menuHeader = By.id("TabBar:ClaimTab");
				WebElement menuHeaderEle = driver.findElement(menuHeader);
				objectMethods.findObject(driver, By.id("TabBar:ClaimTab-btnWrap"), 60);
				Actions actions = new Actions(driver);
				actions.moveToElement(menuHeaderEle, menuHeaderEle.getSize().width - 2, 2).click().build().perform();

				break;
			} catch (StaleElementReferenceException e) {
				LOG.info("Into Stale");
				continue;
			}

		}
		return this;
	}

	public TabBar setClaimNumberFromKey(String key) {

		boolean isFlagged = false;

		while (!isFlagged) {
			try {

				String claimNumber = DataStorage.get(key);
				outputClaimNumber(claimNumber);
				WebElement element = driver.findElement(By.cssSelector("[id$='FindClaim']"));
				
				Actions actions = new Actions(driver);
				actions.moveToElement(element);
				actions.click();
				actions.sendKeys(claimNumber);
				
				actions.build().perform();
				break;
			} catch (StaleElementReferenceException e) {
				LOG.info("Into Stale");
				continue;
			}

		}
		return this;

	}
	
	public TabBar clickDesktopTab() {

		boolean isFlagged = false;

		while (!isFlagged) {
			try {

				
				WebElement element = driver.findElement(By.cssSelector("[id$='TabBar:DesktopTab']"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", element);
			
				break;
			} catch (StaleElementReferenceException e) {
				LOG.info("Into Stale");
				continue;
			}

		}
		return this;

	}
	
	public TabBar clickSearch() {

		boolean isFlagged = false;

		while (!isFlagged) {
			try {

				
				WebElement element = driver.findElement(By.cssSelector("[id$='TabBar:SearchTab']"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", element);
			
				break;
			} catch (StaleElementReferenceException e) {
				LOG.info("Into Stale");
				continue;
			}

		}
		return this;

	}

	public void outputClaimNumber(String claimNumber) {
		return;
	}

	public TabBar clickFindClaimButton() {

		boolean isFlagged = false;

		while (!isFlagged) {
			try {

				
				WebElement element = driver.findElement(By.cssSelector("[id$=FindClaim_Button]"));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", element);
				break;
			} catch (StaleElementReferenceException e) {
				LOG.info("Into Stale");
				continue;
			}

		}
		return this;
	}
}
