/*package businessComponentsArchive;

import org.openqa.selenium.WebDriver;

import StepDefinitionNew.Hooks;
import businessComponents.ChecksCreation;
import businessComponentsArchive.GsClaimCreation_Casualty;
import businessComponentsArchive.Reserve;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class GsClaimCreationStep {
	WebDriver driver;
	
	ChecksCreation claim;

	@Given("^Application is launched$")
	public void create_an_Auto_Claim_on_a_policy_with_no_COLL_coverage() throws Throwable {
		driver=Hooks.driver;
		
		claim = new ChecksCreation(driver,"Testdata_ClaimCreation_NRClaimProperty");
		
		
	  //claim.login();
	  //claim.login();
	  claim.policySearchWithPoilcyNumber();
	  claim.addBasicInfo();
	  //claim.addClaimInfo_Property_NR();
	  
	  //claim.policySearchWithPoilcyNumber_gs();
	 // claim.addClaimInformationCasualty_gs();
	 // claim.addClaimInformationProperty_gs();
	  //claim.manageExposures_gs();
	 // claim.generalDamage();
	 // claim.manageExposuresProperty_gs();
	 // claim.PropertyDamage();
	  //claim.managePartiesInvolved_gs();
	 // claim.saveAndAssignClaim_gs();
	 // claim.reviewAndSaveClaim_gs();
	  
	}

	@When("^Creating Navigator Claim$")
	public void creating_Navigator_Claim() throws Throwable {
	  claim.addClaimInfoForSingleVechileAccident();
	  claim.addFristPartyVehicleAndFinishClaim();
	}
}*/