package businessComponentsArchive;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import reusableLibrary.*;
import functionalLibrary.Data;
import pageObjects.*;
import pageObjects.ButtonScriptless;

public class GsAuto 
{

	WebDriver driver;
	static ButtonScriptless button;
	static TextInputScriptless textInput;
	TextAreaInputScriptless textAreaInput;
	static RangeInputScriptless rangeInput;
	static RadioInputScriptless radioInput;
	LoginDV loginDv; 
	Conventional conventional;
	Data read;
	ScreenShot ts;
	 Map<String, String> testData;

	 
	public GsAuto(WebDriver driver,String dataSheet)
	{
		this.driver = driver;
		button = new ButtonScriptless(driver);
		textInput = new TextInputScriptless(driver);
		textAreaInput=new TextAreaInputScriptless(driver);
		rangeInput = new RangeInputScriptless(driver);
		radioInput = new RadioInputScriptless(driver);
		loginDv = new LoginDV (driver);	
		conventional=new Conventional(driver);
		read=new Data();
		testData=read.getdata(dataSheet);
		ts=new ScreenShot(driver);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	/*
	 * This Method will used search policy number
	 * 
	 */
	
	public void login()
	{
		driver.findElement(By.name("Login:LoginScreen:LoginDV:username")).sendKeys(testData.get("Username"));
		driver.findElement(By.name("Login:LoginScreen:LoginDV:password")).sendKeys(testData.get("Password"));
		driver.findElement(By.id("Login:LoginScreen:LoginDV:submit-btnEl")).click();
	}
	
	public void policySearchWithPoilcyNumber_gs() throws Exception
	{
		
		button.clickNewClaim();
		textInput.enterTextinputWhereLabelNthOccurence_gs("Policy #",testData.get("Policy#"),"1");
		button.clickButtonWhereAnyLetterUnderLined("Search","S");
		Thread.sleep(2000);
		textInput.enterTextinputWhereLabelNthOccurence_gs("Date of Loss",testData.get("DateofLoss"),"1");
		Thread.sleep(2000);
		button.clickButtonWhereLabel("Next >");
		Thread.sleep(2000);
		
		
	}
	
	public void basicinformation_gs() throws Exception 
	{
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Name",testData.get("InsuredName"),"1");
		Thread.sleep(2000);
		
		textInput.enterTextinputWhereLabelNthOccurence_gs("Date Received by LIU",testData.get("DateReceivedbyLIU"),"1");
		
		//driver.findElement(By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_BasicInfoScreen:PanelRow:BasicInfoDetailViewPanelDV:Notification_ReportedDate-trigger-picker")).click();
		//driver.findElement(By.id("button-1212-btnInnerEl")).click();
		
		button.clickButtonWhereLabel("Next >");
		Thread.sleep(2000);
		
		WebElement closebutton=driver.findElement(By.xpath("//div[@class='message']"));
        if(closebutton.isDisplayed())
        {
        	button.clickButtonWhereAnyLetterUnderLined("Close ","e");
            button.clickButtonWhereLabel("Next >");
                
        }
     }
			
	public void addClaimInformation_gs() throws Exception
	{
		textInput.enterTextinputWhereLabelNthOccurence_gs("Claim Description",testData.get("LossDescription"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claim Type",testData.get("ClaimType"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Cause of Loss",testData.get("LossCause"),"1");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Severity",testData.get("Severity"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Province",testData.get("LossState"),"1");
		button.clickButtonWhereAnyLetterUnderLined("Add Vehicle ","V");
		Thread.sleep(2000);	
	}
			
			
	public void vehicleDetails_gs() throws Exception
	{
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Vehicle Type",testData.get("VehicleTypeGs"),"1");
		Thread.sleep(2000);
		
		textInput.enterTextinputWhereLabelNthOccurence_gs("Make",testData.get("VMakeGs"),"1");
		textInput.enterTextinputWhereLabelNthOccurence_gs("Model",testData.get("VModelGs"),"1");
		textInput.enterTextinputWhereLabelNthOccurence_gs("Year",testData.get("VYearGs"),"1");
		Thread.sleep(2000);
		button.clickButtonWhereLabel("OK");
		button.clickButtonWhereAnyLetterUnderLined("Add Vehicle ","V");	
		Thread.sleep(2000);
	}
			
	public void thirdPartyVehicleDetails_gs() throws Exception
	{
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("3rd Party Involvement",testData.get("3rdPartyInvolvementGs"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Vehicle Type",testData.get("VehicleTypeGs"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Vehicle Type",testData.get("VehicleTypeGs"),"1");
		Thread.sleep(2000);
		
		textInput.enterTextinputWhereLabelNthOccurence_gs("Make",testData.get("VMakeGs"),"1");
		textInput.enterTextinputWhereLabelNthOccurence_gs("Model",testData.get("VModelGs"),"1");
		textInput.enterTextinputWhereLabelNthOccurence_gs("Year",testData.get("VYearGs"),"1");
		Thread.sleep(2000);
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Owner",testData.get("OwnerGs"),"1");
		button.clickButtonWhereLabel("OK");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Severity",testData.get("Severity"),"1");
		button.clickButtonWhereLabel("Next >");
	}
			
	public void manageExposures_gs() throws Exception
	{
				
		button.clickButtonWhereAnyLetterUnderLined("New Exposure","e");
		driver.findElement(By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_AssignSaveScreen:NewExposureLV_tb:AddExposure:0:item-textEl")).click();
		driver.findElement(By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_AssignSaveScreen:NewExposureLV_tb:AddExposure:0:item:0:item-textEl")).click();
		driver.findElement(By.id("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_AssignSaveScreen:NewExposureLV_tb:AddExposure:0:item:0:item:4:item-textEl")).click();
		Thread.sleep(2000);
	}
			
			
	public void vehicleDamage_gs() throws InterruptedException
	{
			
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claimant",testData.get("Claimant"),"1");
		rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Vehicle",testData.get("Vehicle"),"1");
		button.clickButtonWhereLabel("OK");
		Thread.sleep(2000);
		button.clickButtonWhereAnyLetterUnderLined("Finish ","F");

	}
}
