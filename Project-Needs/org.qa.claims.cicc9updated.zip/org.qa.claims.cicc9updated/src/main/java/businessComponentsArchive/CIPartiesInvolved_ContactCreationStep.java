package businessComponentsArchive;

import org.openqa.selenium.WebDriver;

import CC9StepDefinition.Hooks;
import businessComponentsArchive.CIPartiesInvolved_ContactCreation;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class CIPartiesInvolved_ContactCreationStep {
       WebDriver driver;
      
       
       CIPartiesInvolved_ContactCreation claim;

       @Given("^Create a CIcontact$")
       public void create_a_CIcontact() throws Throwable {
           // Write code here that turns the phrase above into concrete actions
    	   driver=Hooks.driver;
           claim = new CIPartiesInvolved_ContactCreation(driver,"Testdata_PartiesInvolved_ContactAddNR");
           claim.login();
          //claim.searchClaim("29876431");
          //claim.createContactCI();
          claim.searchClaim("055728458");
          claim.createContactNR();
       }

       @When("^Creating CIContact$")
       public void creating_CIContact() throws Throwable {
           // Write code here that turns the phrase above into concrete actions
           
       }

}