package businessComponentsArchive;

import org.openqa.selenium.WebDriver;

import CC9StepDefinition.Hooks;
import businessComponentsArchive.NoteCreation;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class NoteCreationStep {
       WebDriver driver;
      
       
       NoteCreation claim;

       @Given("^Create a Note$")
public void create_a_Note() throws Throwable {
              driver=Hooks.driver;
              claim = new NoteCreation(driver,"Testdata_Note_CIEdit");
              claim.login();
              //claim.login_NR();
              //claim.searchClaim("BOSCAS210187705");
              claim.searchClaim("201186750");
              //claim.searchClaim_NR("056230417");
              //claim.notecreation_GS();
            // claim.notecreation_CI();
             //claim.notecreation_NR();
              //claim.notecreation_GSEdit();
              claim.notecreation_CIEdit();
       }

      @When("^Note Create$")
public void note_Create() throws Throwable {
         
       }
}
