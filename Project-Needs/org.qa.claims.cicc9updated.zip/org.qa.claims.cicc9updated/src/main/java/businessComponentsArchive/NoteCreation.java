package businessComponentsArchive;

	import java.util.Map;
	import java.util.concurrent.TimeUnit;

	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;

	import functionalLibrary.Data;
	import pageObjects.ButtonScriptless;
	import pageObjects.Conventional;
import pageObjects.LinkScriptless;
import pageObjects.LoginDV;
	import pageObjects.RadioInputScriptless;
	import pageObjects.RangeInputScriptless;
	import pageObjects.TextAreaInputScriptless;
	import pageObjects.TextInputScriptless;
	import reusableLibrary.ScreenShot;

	public class NoteCreation
	{
		
		
		WebDriver driver;
		static ButtonScriptless button;
		static TextInputScriptless textInput;
		TextAreaInputScriptless textAreaInput;
		static RangeInputScriptless rangeInput;
		static RadioInputScriptless radioInput;
		static LinkScriptless linkByInput;
		LoginDV loginDv; 
		Conventional conventional;
		Data read;
		ScreenShot ts;
		 Map<String, String> testData;

		public NoteCreation(WebDriver driver,String dataSheet)
		{
			this.driver = driver;
			button = new ButtonScriptless(driver);
			textInput = new TextInputScriptless(driver);
			textAreaInput=new TextAreaInputScriptless(driver);
			rangeInput = new RangeInputScriptless(driver);
			radioInput = new RadioInputScriptless(driver);
			linkByInput = new LinkScriptless(driver);
			loginDv = new LoginDV (driver);	
			conventional=new Conventional(driver);
			read=new Data();
			testData=read.getdata(dataSheet);
			ts=new ScreenShot(driver);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}
		/*
		 * This Method will used search policy number
		 * 
		 */
		public void login()
		{
			driver.findElement(By.name("Login:LoginScreen:LoginDV:username")).sendKeys(testData.get("Username"));
			driver.findElement(By.name("Login:LoginScreen:LoginDV:password")).sendKeys(testData.get("Password"));
			driver.findElement(By.id("Login:LoginScreen:LoginDV:submit-btnEl")).click();
		}
		
		
		
		public void login_NR()
	       {
	              driver.findElement(By.name("USER")).sendKeys(testData.get("Username"));
	              driver.findElement(By.name("PASSWORD")).sendKeys(testData.get("Password"));
	              driver.findElement(By.name("submitButton")).click();;
	       }

		
		public void searchClaim(String claimnum) throws InterruptedException
		 {
		        driver.findElement(By.id("TabBar:SearchTab-btnInnerEl")).click();
		        textInput.enterTextinputWhereLabelNthOccurence_gs("Claim #", claimnum, "1");
		        button.clickButtonWhereAnyLetterUnderLined("", "S");
		        driver.findElement(By.linkText(claimnum)).click();
		        
		  }

		public void searchClaim_NR(String claimnum) throws InterruptedException
		 {
		        driver.findElement(By.id("TabBar:SearchTab-btnInnerEl")).click();
		        textInput.enterTextinputWhereLabelNthOccurence("Claim #", claimnum, "1");
		        button.clickButtonWhereAnyLetterUnderLined("", "S");
		        driver.findElement(By.linkText(claimnum)).click();
		        conventional.clickActions();
		        conventional.clickNotes();
		  }
		public void notecreation_GS() throws Exception
		{
			conventional.clickActions();
	        conventional.clickNotes();
			textInput.enterTextinputWhereLabelNthOccurence_gs("Subject",testData.get("Subject"),"1");
			rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Content Type",testData.get("ContentType"),"1");
			rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Related To",testData.get("RelatedTo"), "1");
			textInput.enterTextinputWhereLabelNthOccurence_gs("Note",testData.get("Note"), "1");
			button.clickButtonWhereAnyLetterUnderLined("Update","U");
			conventional.clickNotesMenu();
		}
	
		
		public void notecreation_CI() throws Exception
		{
			conventional.clickActions();
	        conventional.clickNotes();
			rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Topic",testData.get("Topic"),"1");
			textInput.enterTextinputWhereLabelNthOccurence_gs("Subject",testData.get("Subject"),"1");
			textInput.enterTextinputWhereLabelNthOccurence_gs("Text",testData.get("Note"), "1");
			button.clickButtonWhereAnyLetterUnderLined("Update","U");
			conventional.clickNotesMenu();
		}
	
		public void notecreation_NR() throws Exception
		{
			conventional.clickActions();
	        conventional.clickNotes();
			rangeInput.enterRangeInputWhereLabelNthOccurence("Topic",testData.get("Topic"),"1");
			textInput.enterTextinputWhereLabelNthOccurence("Subject",testData.get("Subject"),"1");
			textAreaInput.enterTextAreaInputWhereLabelNthOccurence("Text (2,500)",testData.get("Note"), "1");
			button.clickButtonWhereAnyLetterUnderLined("Update","U");
			conventional.clickNotesMenu();
		}
	
		public void notecreation_GSEdit() throws Exception
		{
			
			conventional.clickNotesMenu();
			rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Related To:",testData.get("RelatedToSearch"),"1");
			button.clickButtonWhereAnyLetterUnderLined("Search", "S");
			linkByInput.clickLinkWhereLabelNthOccurence("Edit","1");
			
			textInput.enterTextinputWhereLabelNthOccurence_gs("Subject",testData.get("Subject"),"1");
			rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Content Type",testData.get("ContentType"),"1");
			rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Related To",testData.get("RelatedTo"), "1");
			textInput.enterTextinputWhereLabelNthOccurence_gs("Note",testData.get("Note"), "1");
			button.clickButtonWhereAnyLetterUnderLined("Update","U");
			
		}
	
			
		public void notecreation_CIEdit() throws Exception
		{
			
			conventional.clickNotesMenu();
			rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Related To:",testData.get("RelatedToSearch"),"1");
			linkByInput.clickLinkWhereLabelNthOccurence("Edit","1");
			
			rangeInput.enterRangeInputWhereLabelNthOccurenceCI("Topic",testData.get("Topic"));
			textInput.enterTextinputWhereLabelNthOccurence_gs("Subject",testData.get("Subject"),"1");
			
			button.clickButtonWhereAnyLetterUnderLined("Update","U");
			
			
		}
	
		
		
		
}


