package businessComponentsArchive;

import org.openqa.selenium.WebDriver;

import CC9StepDefinition.Hooks;
import businessComponentsArchive.GsPartiesInvolved_ContactCreation;
import businessComponentsArchive.NoteCreation;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class GsPartiesInvolved_ContactCreationStep {
       WebDriver driver;
      
       
       GsPartiesInvolved_ContactCreation claim;

       @Given("^Create a contact$")
       public void create_a_contact() throws Throwable {
              driver=Hooks.driver;
              claim = new GsPartiesInvolved_ContactCreation(driver,"Testdata_PartiesInvolved_ContactAddGS");
              claim.login();
              claim.searchClaim("BOSCAS210187705");
              
              claim.createContact();
              
         }

@When("^Creating GsContact$")
public void creating_GsContact() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    
}
}