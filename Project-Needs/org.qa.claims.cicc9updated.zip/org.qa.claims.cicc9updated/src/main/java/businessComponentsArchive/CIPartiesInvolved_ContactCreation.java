package businessComponentsArchive;

	import java.util.Map;
	import java.util.concurrent.TimeUnit;

	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;

	import functionalLibrary.Data;
	import pageObjects.ButtonScriptless;
	import pageObjects.Conventional;
	import pageObjects.LoginDV;
	import pageObjects.RadioInputScriptless;
	import pageObjects.RangeInputScriptless;
	import pageObjects.TextAreaInputScriptless;
	import pageObjects.TextInputScriptless;
	import reusableLibrary.ScreenShot;

	public class CIPartiesInvolved_ContactCreation
	{
		
		
		WebDriver driver;
		static ButtonScriptless button;
		static TextInputScriptless textInput;
		TextAreaInputScriptless textAreaInput;
		static RangeInputScriptless rangeInput;
		static RadioInputScriptless radioInput;
		LoginDV loginDv; 
		Conventional conventional;
		Data read;
		ScreenShot ts;
		 Map<String, String> testData;

		public CIPartiesInvolved_ContactCreation(WebDriver driver,String dataSheet)
		{
			this.driver = driver;
			button = new ButtonScriptless(driver);
			textInput = new TextInputScriptless(driver);
			textAreaInput=new TextAreaInputScriptless(driver);
			rangeInput = new RangeInputScriptless(driver);
			radioInput = new RadioInputScriptless(driver);
			loginDv = new LoginDV (driver);	
			conventional=new Conventional(driver);
			read=new Data();
			testData=read.getdata(dataSheet);
			ts=new ScreenShot(driver);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}
		/*
		 * This Method will used search policy number
		 * 
		 */
		
		/*public void login()
		{
			driver.findElement(By.name("Login:LoginScreen:LoginDV:username")).sendKeys(testData.get("Username"));
			driver.findElement(By.name("Login:LoginScreen:LoginDV:password")).sendKeys(testData.get("Password"));
			driver.findElement(By.id("Login:LoginScreen:LoginDV:submit-btnEl")).click();
		}*/
		
		public void login()
		{
			
			driver.findElement(By.name("USER")).sendKeys(testData.get("Username"));
			driver.findElement(By.name("PASSWORD")).sendKeys(testData.get("Password"));
			driver.findElement(By.name("submitButton")).click();
			
		}
		
		public void searchClaim(String claimnum) throws InterruptedException
		 {
		        driver.findElement(By.id("TabBar:SearchTab-btnInnerEl")).click();
				
		        textInput.enterTextinputWhereLabelNthOccurence("Claim #", claimnum, "1");
		        button.clickButtonWhereAnyLetterUnderLined("", "S");
		        driver.findElement(By.linkText(claimnum)).click();
		        //conventional.clickPartiesInvolved();
		  }

		public void createContactCI() throws Exception
		{
			Thread.sleep(2000);
			conventional.clickPartiesInvolved();
			//driver.findElement(By.xpath("//td[@id='Claim:MenuLinks:Claim_ClaimPartiesGroup']")).click();
			
			
			button.clickButtonWhereAnyLetterUnderLined("New Contact","N");
			driver.findElement(By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_CreateNewContactButton:ClaimContacts_NewPerson-textEl")).click();
			
			textInput.enterTextinputWhereLabelNthOccurence_gs("First name",testData.get("FirstName"),"1");
			textInput.enterTextinputWhereLabelNthOccurence_gs("Last name",testData.get("LastName"),"1");
			textInput.enterTextinputWhereLabelNthOccurence_gs("Address 1",testData.get("Address"),"1");
			rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("State",testData.get("State"),"1");
			textInput.enterTextinputWhereLabelNthOccurence_gs("City",testData.get("City"),"1");
			//textInput.enterTextinputWhereLabelNthOccurence_gs("ZIP Code",testData.get("ZipCode"),"1");
			button.clickButtonWhereAnyLetterUnderLined("Add","A");
			
			conventional.addPartiesRoleCI(testData.get("Role"));
			button.clickButtonWhereLabelNthOccurence("OK","1");
			
		}
		
		public void createContactNR() throws Exception
		{
			Thread.sleep(2000);
			conventional.clickPartiesInvolved();
			//driver.findElement(By.xpath("//td[@id='Claim:MenuLinks:Claim_ClaimPartiesGroup']")).click();
			
			
			button.clickButtonWhereAnyLetterUnderLined("New Contact","N");
			driver.findElement(By.id("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_CreateNewContactButton:ClaimContacts_NewPerson-textEl")).click();
			Thread.sleep(2000);
			textInput.enterTextinputWhereLabelNthOccurence("First Name",testData.get("FirstName"),"1");
			textInput.enterTextinputWhereLabelNthOccurence("Last Name",testData.get("LastName"),"1");
			textInput.enterTextinputWhereLabelNthOccurence("Address 1",testData.get("Address"),"1");
			rangeInput.enterRangeInputWhereLabelNthOccurence("City",testData.get("City"),"1");
			rangeInput.enterRangeInputWhereLabelNthOccurence("State",testData.get("State"),"1");
			//textInput.enterTextinputWhereLabelNthOccurence_gs("ZIP Code",testData.get("ZipCode"),"1");
			
			button.clickButtonWhereLabelNthOccurence("Add","1");
			
			conventional.addPartiesRoleNR(testData.get("Role"));
			button.clickButtonWhereLabelNthOccurence("OK","1");
			button.clickButtonWhereLabelNthOccurence("Cleansed Address","1");
		}
		
}


