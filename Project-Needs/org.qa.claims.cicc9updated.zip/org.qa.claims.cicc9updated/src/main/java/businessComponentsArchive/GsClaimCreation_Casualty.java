package businessComponentsArchive;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.eviware.soapui.junit.Property;

import functionalLibrary.Data;
import pageObjects.ButtonScriptless;
import pageObjects.Conventional;
import pageObjects.LoginDV;
import pageObjects.PickerMenuScriptless;
import pageObjects.RadioInputScriptless;
import pageObjects.RangeInputScriptless;
import pageObjects.TextAreaInputScriptless;
import pageObjects.TextInputScriptless;
import reusableLibrary.ScreenShot;

public class GsClaimCreation_Casualty {
	WebDriver driver;
	static ButtonScriptless button;
	static TextInputScriptless textInput;
	TextAreaInputScriptless textAreaInput;
	static RangeInputScriptless rangeInput;
	static RadioInputScriptless radioInput;
	static PickerMenuScriptless pickerMenu;
	LoginDV loginDv; 
	Conventional conventional;
	Data read;
	ScreenShot ts;
	Map<String, String> testData;

	public GsClaimCreation_Casualty(WebDriver driver,String dataSheet)
	{
		this.driver = driver;
		button = new ButtonScriptless(driver);
		textInput = new TextInputScriptless(driver);
		textAreaInput=new TextAreaInputScriptless(driver);
		rangeInput = new RangeInputScriptless(driver);
		radioInput = new RadioInputScriptless(driver);
		pickerMenu = new PickerMenuScriptless(driver);
		loginDv = new LoginDV (driver);	
		conventional=new Conventional(driver);
		read=new Data();
		testData=read.getdata(dataSheet);
		ts=new ScreenShot(driver);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	/*
	 * This Method will used search policy number
	 * 
	 */
	
	public void login()
	{
		driver.findElement(By.name("Login:LoginScreen:LoginDV:username")).sendKeys(testData.get("Username"));
		driver.findElement(By.name("Login:LoginScreen:LoginDV:password")).sendKeys(testData.get("Password"));
		driver.findElement(By.id("Login:LoginScreen:LoginDV:submit-btnEl")).click();
	}
	
	public void policySearchWithPoilcyNumber_gs() throws Exception
	{
		
		   
			   button.clickNewClaim();
			   textInput.enterTextinputWhereLabelNthOccurence_gs("Policy #",testData.get("Policy#"),"1");
			   button.clickButtonWhereAnyLetterUnderLined("Search","S");
			   Thread.sleep(2000);
			   textInput.enterTextinputWhereLabelNthOccurence_gs("Date of Loss",testData.get("DateofLoss"),"1");
			 
			   button.clickButtonWhereLabel("Next >");
			   Thread.sleep(3000);
			  // driver.findElement(By.xpath("//div[@class='message']")).getText();			   	   
			}
	
			public void addClaimInformationCasualty_gs() throws Exception 
			{
				
				textInput.enterTextinputWhereLabelNthOccurence_gs("Claim Title",testData.get("ClaimTitleGs"),"1");
				textInput.enterTextinputWhereLabelNthOccurence_gs("Claim Description",testData.get("LossDescription"),"1");
				Thread.sleep(2000);
				rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Severity",testData.get("Severity"),"1");
				rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("COL1",testData.get("Col1Gs"),"1");
				Thread.sleep(2000);
				rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claim Type",testData.get("ClaimType"),"1");
				Thread.sleep(2000);
				textInput.enterTextinputWhereLabelNthOccurence_gs("Date Received by LIU",testData.get("DateReceivedbyLIU"),"1");
				Thread.sleep(2000);
				rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("State/Province",testData.get("State"),"1");
				rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claim Type",testData.get("ClaimType"),"1");
				button.clickButtonWhereLabel("Next >");
				WebElement closebutton=driver.findElement(By.xpath("//div[@class='message']"));
                if(closebutton.isDisplayed())
                {
                                button.clickButtonWhereAnyLetterUnderLined("Close ","e");
                                button.clickButtonWhereLabel("Next >");
                
                }			
			}
			
			
			public void addClaimInformationProperty_gs() throws Exception 
			{
				
				textInput.enterTextinputWhereLabelNthOccurence_gs("Claim Title",testData.get("ClaimTitleGs"),"1");
				textInput.enterTextinputWhereLabelNthOccurence_gs("Claim Description",testData.get("LossDescription"),"1");
				Thread.sleep(2000);
				rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Severity",testData.get("Severity"),"1");
				rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Peril",testData.get("Peril"),"1");
				Thread.sleep(2000);
				rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claim Type",testData.get("ClaimType"),"1");
				Thread.sleep(2000);
				textInput.enterTextinputWhereLabelNthOccurence_gs("Date Received by LIU",testData.get("DateReceivedbyLIU"),"1");
				Thread.sleep(2000);
				rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("State/Province",testData.get("State"),"1");
				rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claim Type",testData.get("ClaimType"),"1");
				
				
				button.clickButtonWhereLabel("Next >");
				WebElement closebutton=driver.findElement(By.xpath("//div[@class='message']"));
                if(closebutton.isDisplayed())
                {
                                button.clickButtonWhereAnyLetterUnderLined("Close ","e");
                                button.clickButtonWhereLabel("Next >");
                
                }			
			}
			
			
			public void manageExposures_gs() throws Exception
			{
				
				button.clickButtonWhereAnyLetterUnderLined("New Exposure","e");
				driver.findElement(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_ExposuresScreen:NewClaimExposuresLV_tb:AddExposure:0:item-textEl")).click();
				driver.findElement(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_ExposuresScreen:NewClaimExposuresLV_tb:AddExposure:0:item:0:item-textEl")).click();
				driver.findElement(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_ExposuresScreen:NewClaimExposuresLV_tb:AddExposure:0:item:0:item:1:item-textEl")).click();
				
				
			}
			
			
			public void manageExposuresProperty_gs() throws Exception
			{
				
				button.clickButtonWhereAnyLetterUnderLined("New Exposure","e");
				driver.findElement(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_ExposuresScreen:NewClaimExposuresLV_tb:AddExposure:0:item-textEl")).click();
				driver.findElement(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_ExposuresScreen:NewClaimExposuresLV_tb:AddExposure:0:item:0:item-textEl")).click();
				driver.findElement(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_ExposuresScreen:NewClaimExposuresLV_tb:AddExposure:0:item:0:item:2:item-textEl")).click();
				
				
			}
			
			public void generalDamage() throws InterruptedException
			{
			
				rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claimant",testData.get("Claimant"),"1");
				rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claimant Representative",testData.get("ClaimantRepresentative"),"1");
				rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claimant",testData.get("Claimant"),"1");
				textInput.enterTextinputWhereLabelNthOccurence_gs("Damage Description",testData.get("DamageDescription"),"1");
				button.clickButtonWhereLabel("OK");
				Thread.sleep(2000);
				button.clickButtonWhereLabel("Next >");

			}
			
			
			public void PropertyDamage() throws InterruptedException
			{
			
				pickerMenu.clickPickerMenuWhereLabelNthOccurence("Property Name",1);
				pickerMenu.clickPickerMenuOption("New Property...");
			
				textInput.enterTextinputWhereLabelNthOccurence_gs("Property Description",testData.get("PropDescription"),"1");
				button.clickButtonWhereLabel("OK");
				
				rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Claimant",testData.get("Claimant"),"1");
				rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Type",testData.get("Type"),"1");
				
				button.clickButtonWhereLabel("OK");
				
				Thread.sleep(2000);
				button.clickButtonWhereLabel("Next >");

			}
			
			
			public void managePartiesInvolved_gs()
			{
				button.clickButtonWhereLabel("Next >");
				
			}
			
			public void saveAndAssignClaim_gs()
			{
				button.clickButtonWhereLabel("Next >");
				//driver.findElement(By.id("FNOLWizard:Next-btnInnerEl")).click();
				
				
			}
			
			
			public void reviewAndSaveClaim_gs()
			
			{
				button.clickButtonWhereAnyLetterUnderLined("Finish","F");
				
			}
			

}




