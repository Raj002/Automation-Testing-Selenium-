package businessComponentsArchive;
/*package claimCenterCommonFunctionalityTests;

import org.openqa.selenium.WebDriver;


import businessComponents.ClaimCreation;
import businessComponents.GsClaimCreation_Casualty;
import businessComponents.Reserve;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class NavigatorClaim_Step {
	WebDriver driver;
	ClaimCreation claim;

	@Given("^Application is launched$")
	public void create_an_Auto_Claim_on_a_policy_with_no_COLL_coverage() throws Throwable {
		driver=Hooks.driver;
		
	 claim = new ClaimCreation(driver,"Testdata_ClaimCreation");
	  claim.login();
	  claim.policySearchWithPoilcyNumber();
	  claim.addBasicInfo();
	  claim.addClaimInfoForSingleVechileAccident();
	  claim.addFristPartyVehicleAndFinishClaim();  
	}

	@When("^Creating Navigator Claim$")
	public void creating_Navigator_Claim() throws Throwable {
	  claim.addClaimInfoForSingleVechileAccident();
	  claim.addFristPartyVehicleAndFinishClaim();
	}
}*/