package businessComponentsArchive;
/**
 * This class contains the method which is used for the claim reserve actions
 * @author n0278727
 * @ScriptedOn 05/07/2018
 * 
 */
import java.util.Map;
import org.openqa.selenium.WebDriver;
import functionalLibrary.Data;
import pageObjects.ButtonScriptless;
import pageObjects.Conventional;
import pageObjects.LoginDV;
import pageObjects.RadioInputScriptless;
import pageObjects.RangeInputScriptless;
import pageObjects.TextAreaInputScriptless;
import pageObjects.TextInputScriptless;
import reusableLibrary.ScreenShot;

public class Reserve {
	
	WebDriver driver;
	ButtonScriptless button;
	TextInputScriptless textInput;
	TextAreaInputScriptless textAreaInput;
	RangeInputScriptless rangeInput;
	RadioInputScriptless radioInput;
	LoginDV loginDv; 
	Conventional conventional;
	Data read;
	ScreenShot ts;
	Map<String, String> testData;
	
	public Reserve(WebDriver driver){
		this.driver = driver;
		button = new ButtonScriptless(driver);
		textInput = new TextInputScriptless(driver);
		textAreaInput=new TextAreaInputScriptless(driver);
		rangeInput = new RangeInputScriptless(driver);
		radioInput = new RadioInputScriptless(driver);
		loginDv = new LoginDV (driver);	
		conventional=new Conventional(driver);
		read=new Data();
		testData=read.getdata("Testdata_ClaimCreation_Reserve");
		ts=new ScreenShot(driver);
	}
	/**
	 * This method used to add new reserve line
	 * @Parm exposure, new avaialble reserve , Cost Type, Cost Cost  
	 */
	public void addReserve(){
		conventional.clickActions();
		conventional.clickReserve();
		conventional.addNewReserve("(1) 3rd Party General - ARCHBOLD & LEWIS INSURANCE", "600", "Expense", "Legal", "Test","");
		button.clickButtonWhereLabel("Save");
	}
	/**
	 * 
	 * @throws Throwable
	 */
	public void edit_Reserve() throws Throwable {
		conventional.clickActions();
		conventional.clickReserve();
		conventional.editNewAvilableReserve("Collision", "1500");
		conventional.editReserveReason("Collision", "Updated Information");
		conventional.editReserveComment("Collision", "TEST");
		button.clickButtonWhereLabel("Save");
		Thread.sleep(5000);
	}
}
