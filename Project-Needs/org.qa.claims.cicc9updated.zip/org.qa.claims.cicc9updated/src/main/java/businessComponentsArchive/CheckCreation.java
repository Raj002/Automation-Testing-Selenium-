package businessComponentsArchive;

	import java.util.Map;
	import java.util.concurrent.TimeUnit;

	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;

	import functionalLibrary.Data;
	import pageObjects.ButtonScriptless;
	import pageObjects.Conventional;
	import pageObjects.LoginDV;
	import pageObjects.RadioInputScriptless;
	import pageObjects.RangeInputScriptless;
	import pageObjects.TextAreaInputScriptless;
	import pageObjects.TextInputScriptless;
	import reusableLibrary.ScreenShot;

	public class CheckCreation
	{
		
		
		WebDriver driver;
		static ButtonScriptless button;
		static TextInputScriptless textInput;
		TextAreaInputScriptless textAreaInput;
		static RangeInputScriptless rangeInput;
		static RadioInputScriptless radioInput;
		LoginDV loginDv; 
		Conventional conventional;
		Data read;
		ScreenShot ts;
		 Map<String, String> testData;

		public CheckCreation(WebDriver driver,String dataSheet)
		{
			this.driver = driver;
			button = new ButtonScriptless(driver);
			textInput = new TextInputScriptless(driver);
			textAreaInput=new TextAreaInputScriptless(driver);
			rangeInput = new RangeInputScriptless(driver);
			radioInput = new RadioInputScriptless(driver);
			loginDv = new LoginDV (driver);	
			conventional=new Conventional(driver);
			read=new Data();
			testData=read.getdata(dataSheet);
			ts=new ScreenShot(driver);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}
		/*
		 * This Method will used search policy number
		 * 
		 */
		
		public void login()
		{
			driver.findElement(By.name("LLogin:LoginScreen:LoginDV:username")).sendKeys(testData.get("Username"));
			driver.findElement(By.name("Login:LoginScreen:LoginDV:password")).sendKeys(testData.get("Password"));
			driver.findElement(By.id("Login:LoginScreen:LoginDV:submit-btnEl")).click();
		}
		
		public void searchClaim(String claimnum) throws InterruptedException
		 {
		        driver.findElement(By.id("TabBar:SearchTab-btnInnerEl")).click();
		        textInput.enterTextinputWhereLabelNthOccurence_gs("Claim #", claimnum, "1");
		        button.clickButtonWhereAnyLetterUnderLined("", "S");
		        driver.findElement(By.linkText(claimnum)).click();
		  }

		public void checkcreation() throws Exception
		{
			rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Name",testData.get("CheckName"),"1");
			button.clickButtonWhereLabel("Next >");
			Thread.sleep(2000);
			rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Reserve Line",testData.get("ReserveLine"), "1");
			radioInput.clickRadioInputWhereLabelAndChoice("Is this the Final Payment?",testData.get("FinalPayment"));
			Thread.sleep(2000);
			textInput.enterTextinputWhereLabelNthOccurence_gs("Payment Amount",testData.get("PaymentAmount"),"1");
			rangeInput.enterRangeInputWhereLabelNthOccurenceCC9("Source Income Location",testData.get("SourceIncomeLocation"), "1");
			button.clickButtonWhereLabel("Next >");
			button.clickButtonWhereAnyLetterUnderLined("Finish","F");
		}
		
}


