package testRunners;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

import com.cucumber.listener.ExtentProperties;
import com.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import functionalLibrary.ConfigFileReader;
import functionalLibrary.DataStorage;
 
@RunWith(Cucumber.class)
@CucumberOptions(
		features = "Feature/FeatureNew/CC9Feature",
		tags={"@CheckCreation"},
		glue={"CC9StepDefinition"},
		monochrome = true,		
		plugin = {"com.cucumber.listener.ExtentCucumberFormatter:", "pretty",
				 "html:target/cucumber-report/"}	
		)

public class CommonTestRunnersCC9
{
	
	public static WebDriver driver;
	
	@BeforeClass
	static public void setup(){
		/*ExtentProperties extendtProp=ExtentProperties.INSTANCE;
		extendtProp.setReportPath(".Output/MyReport.html");*/
	}

	@AfterClass
	static public void reportProp(){
		Properties prop=DataStorage.loadProperties();
		
		String extentReportPath=ConfigFileReader.getReportCofigPath();
		Reporter.loadXMLConfig(new File(extentReportPath));
		System.out.println(extentReportPath);
		Reporter.setSystemInfo("user", System.getProperty("user.name"));
		Reporter.setSystemInfo("os","win 7");
		Reporter.setTestRunnerOutput("GuideWire Testing Report");
		Reporter.assignAuthor("Manoj Kumar");

		//driver.get("E:/Workspace/Guidewire Claim Center/output/Run_1544422892356/report.html");
	}


}


