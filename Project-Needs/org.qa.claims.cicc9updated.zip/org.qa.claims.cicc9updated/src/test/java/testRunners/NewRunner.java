package testRunners;
import java.io.File;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import com.cucumber.listener.ExtentProperties;
import com.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import functionalLibrary.ConfigFileReader;
import functionalLibrary.currentDateAndTime;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "Feature/FeatureNew/CC9Feature",
		tags={"@CheckCreation"},
		glue={"CC9StepDefinition"},	
		plugin = {"com.cucumber.listener.ExtentCucumberFormatter:",
				"pretty", "html:target/cucumber-html-report"},
		monochrome=true
		//tags = "@Sample"
		//tags = "@Testing"
		)

public class NewRunner
{
	public static String timestamp="";
	public static String folderPath="";
	
	
	@BeforeClass
	public static void setup()
	{   
		ExtentProperties extentProperties = ExtentProperties.INSTANCE;
	    timestamp=currentDateAndTime.getDateTime();
	    System.out.println(timestamp);
	    //String scenarioName=scenario.getName();
	    extentProperties.setReportPath("output/"+timestamp+"/report/extend_report.html");
	   // String reportfileName=CukesRunner.timestamp;
		String relativePath = new File(System.getProperty("user.dir")).getAbsolutePath();
		folderPath=relativePath+"output/"+timestamp+"/report/extend_report.html";
		File outputFile = new File(folderPath);
	    outputFile.mkdir();
	}
	
	@AfterClass
	public static void writeExtentReport()
	{
		/*String extentXMLPath=ConfigFileReader.getReportCofigPath();
		Reporter.loadXMLConfig(new File(extentXMLPath));*/
		
		String extentReportPath=ConfigFileReader.getReportCofigPath();
		Reporter.loadXMLConfig(new File(extentReportPath));
		System.out.println(extentReportPath);
		
        Reporter.setSystemInfo("user", System.getProperty("user.name"));
        Reporter.setSystemInfo("os", "Win 7");
        Reporter.setTestRunnerOutput("GuideWire Scriptless Expert Test Scripter");
        Reporter.assignAuthor("Suganya G");
	}
}