package testRunners;
import java.io.File;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import com.cucumber.listener.ExtentProperties;
import com.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import functionalLibrary.ConfigFileReader;
 
@RunWith(Cucumber.class)
@CucumberOptions(
		features = "Feature/FeatureNew/CC8Feature",
		tags={"@ContactCreation"},
		glue={"CC8StepDefinition"},
		monochrome = true,		
		plugin = {"com.cucumber.listener.ExtentCucumberFormatter:", "pretty",
				 "html:target/cucumber-report/"}	
		)

public class CommonTestRunnersCC8 {
	
	@BeforeClass
	static public void setup(){
		/*ExtentProperties extendtProp=ExtentProperties.INSTANCE;
		extendtProp.setReportPath(".Output/MyReport.html");*/
	}
	
	
	@AfterClass
	static public void reportProp(){
		String extentReportPath=ConfigFileReader.getReportCofigPath();
		Reporter.loadXMLConfig(new File(extentReportPath));
		System.out.println(extentReportPath);
		Reporter.setSystemInfo("user", System.getProperty("user.name"));
		Reporter.setSystemInfo("os","win 7");
		Reporter.setTestRunnerOutput("GuideWire Testing Report");
		Reporter.assignAuthor("Manoj Kumar");
		
	}
}
