package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class PartiesInvolvedContacts {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	String personOption = "//span[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_CreateNewContactButton:ClaimContacts_NewPerson-textEl' and text()='Person']";
	
	public PartiesInvolvedContacts(WebDriver driver)
	{
		this.driver = driver;
		wait = new WebDriverWait(driver, 15);
	}	
	
	public void PartiesInvolvedContactspage() throws Exception{
		Helper.clickClaimSubMenu(driver, "partis involved");
		UIMethods.clickbyxpath("//a[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_CreateNewContactButton']/span", "Click New Contact arrow button", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(personOption)));
		UIMethods.clickbyxpath(personOption, "Click Person Option", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='NewPartyInvolvedPopup:ContactDetailScreen:ttlBar' and text()='New Person']")));
	}
}
