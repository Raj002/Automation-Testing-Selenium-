package org.qa.Claims.CICC9.Auto.Pages;

import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class ClaimAdvancedSearch {
	
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	public void ClaimsSearch(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtClaimNo = xlsread.Exceldata(SheetName, "txtClaimNo", "AutoScenario08");
        String ddlsearchfordate = xlsread.Exceldata(SheetName, "ddlsearchfordate", profileID);
        
        //***************click claims links and new claims		
		UIMethods.selectbyid("ClaimSearchPopup:ClaimSearchScreen:ClaimSearchDV:ClaimSearchOptionalInputSet:DateSearch:DateSearchRangeValue", "Select Value Any in Search for Date - Loss Date", ddlsearchfordate);
		UIMethods.inputbyid("ClaimSearchPopup:ClaimSearchScreen:ClaimSearchDV:ClaimSearchRequiredInputSet:ClaimNumber", "Enter Claim Number", txtClaimNo);
		UIMethods.jscriptclickbyxpath("//*[@id='ClaimSearchPopup:ClaimSearchScreen:ClaimSearchDV:ClaimSearchAndResetInputSet:Search_link']", "Click Search Button", "Click");
		Thread.sleep(2000);
		UIMethods.jscriptclickbyxpath("//*[@id='ClaimSearchPopup:ClaimSearchScreen:ClaimSearchResultsLV:0:_Select_link']", "Click Select Button", "Click");
		Thread.sleep(5000);
	}
}