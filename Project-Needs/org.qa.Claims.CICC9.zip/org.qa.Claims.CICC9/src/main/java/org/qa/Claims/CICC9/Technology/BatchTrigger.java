package org.qa.Claims.CICC9.Technology;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

/**
 * Class for triggering Batch Jobs using  Shell Scripting in Unix Server
 * @author: 
 */

public class BatchTrigger extends FetchPropertiesFiles {

	private static final Logger LOG = Logger.getLogger(BatchTrigger.class);
	
	/**
	 * Trigger Batch Using Shell Scripting
	 * @param batchType
	 */

	public void triggerBatch(String batchType) {

		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		JSch jsch = new JSch();
		Session session;
		try {
			
			session = jsch.getSession(ftpUserName, ftpHost, 22);
			session.setPassword(ftpPassword);
			session.setConfig(config);
			session.connect();
			LOG.info("Connected");

			ChannelExec channelExec = (ChannelExec) session.openChannel("exec");
			InputStream in = channelExec.getInputStream();

			if (batchType.equals("driverBatchJob")) {
				channelExec.setCommand(batchType);
			}
			channelExec.connect();
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
			String line;
			int index = 0;

			while ((line = reader.readLine()) != null) {
				LOG.info(++index + " : " + line);
			}

			int exitStatus = channelExec.getExitStatus();
			channelExec.disconnect();
			session.disconnect();

			if (exitStatus < 0) {
				LOG.info(exitStatus);
				LOG.info("Done, but exit status not set!");
				
			} else if (exitStatus > 0) {
				LOG.info("Done, but with error!");
				
			} else {
				LOG.info("Done!");
			}

		} catch (JSchException e) {
			LOG.error("BatchTrigger : Exception occured at the JSCH"+e.getMessage());
		} catch (IOException e) {
			LOG.error("BatchTrigger : Exception I/O "+e.getMessage());

		}

	}
}