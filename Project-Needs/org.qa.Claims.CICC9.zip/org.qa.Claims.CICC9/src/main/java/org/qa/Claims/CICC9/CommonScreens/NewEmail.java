package org.qa.Claims.CICC9.CommonScreens;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class NewEmail {

	private WebDriver driver = null;
	WebDriverWait wait;
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");

	// Page Objects
	String senderName = "EmailWorksheet:CreateEmailScreen:TextInput1";
	String senderEmail = "EmailWorksheet:CreateEmailScreen:TextInput2";
	String senderEmailSubject = "EmailWorksheet:CreateEmailScreen:TextInput0";
	String senderEmailBody = "EmailWorksheet:CreateEmailScreen:TextAreaInput0";

	public NewEmail(WebDriver driver) {
		this.driver = driver;
	}

	public void NewEmailPage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtToReciepientName = xlsread.Exceldata(SheetName, "txtToReciepientName", profileID);
		String txtToReciepientEmail = xlsread.Exceldata(SheetName, "txtToReciepientEmail", profileID);
		String txtSenderName = xlsread.Exceldata(SheetName, "txtSenderName", profileID);
		String txtSenderEmail = xlsread.Exceldata(SheetName, "txtSenderEmail", profileID);
		String txtSubject = xlsread.Exceldata(SheetName, "txtSubject", profileID);
		String txtBody = xlsread.Exceldata(SheetName, "txtBody", profileID);
		String btnSendEmail = xlsread.Exceldata(SheetName, "btnSendEmail", profileID);

		UIMethods.inputbyid("EmailWorksheet:CreateEmailScreen:ToRecipientLV:0:ToName", "Input To Reciepient Name",txtToReciepientName);
		Thread.sleep(2000);
		UIMethods.inputbyid("EmailWorksheet:CreateEmailScreen:ToRecipientLV:0:ToEmail", "input To Reciepient Email",txtToReciepientEmail);

		UIMethods.clickbyid(senderName, "Click Sender Name", "Click");
		Helper.clearTextBox(driver, driver.findElement(By.id(senderName)));
		UIMethods.inputbyid(senderName, "input Sender Name", txtSenderName);

		UIMethods.clickbyid(senderEmail, "Click Sender Email", "Click");
		Helper.clearTextBox(driver, driver.findElement(By.id(senderEmail)));
		UIMethods.inputbyid(senderEmail, "input Sender Email", txtSenderEmail);

		UIMethods.clickbyid(senderEmailSubject, "Click Subject", "Click");
		Helper.clearTextBox(driver, driver.findElement(By.id(senderEmailSubject)));
		UIMethods.inputbyid(senderEmailSubject, "input Subject", txtSubject);

		UIMethods.clickbyid(senderEmailBody, "Click Body", "Click");
		UIMethods.inputbyid(senderEmailBody, "input Body", txtBody);
		Thread.sleep(2000);

		if (!(btnSendEmail.isEmpty())) {
			UIMethods.jscriptclickbyxpath("//span[text()='Send Email']", "click Send Email button", "Click");
			Thread.sleep(4000);
			
			//Added by RAJ
			if(driver.findElements(By.xpath("//span[@id='EmailWorksheet:CreateEmailScreen:_msgs_msgs']/div/text()")).size()!=0) {
				Assert.fail("An error has occurred while processing a document.  Please try the action again.  If the error continues, please contact production support.");
			}
		}
		
		
		
	}

}