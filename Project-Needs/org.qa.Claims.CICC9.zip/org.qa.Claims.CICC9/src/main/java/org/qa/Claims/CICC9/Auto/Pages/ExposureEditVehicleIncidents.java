package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class ExposureEditVehicleIncidents {

	private WebDriver driver = null;
	WebDriverWait wait;

	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");

	public ExposureEditVehicleIncidents(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 30);
	}
	
	public void exposureEditVehicleIncidents(String excelFileName, String profileID) throws Exception {		
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlExposureDriverName = xlsread.Exceldata(SheetName, "ddlExposureDriverName", profileID);
		String ddlExposureRelationToOwner = xlsread.Exceldata(SheetName, "ddlExposureRelationToOwner", profileID);
		
		UIMethods.clickbyxpath("//*[text()='Vehicle']", "click Vehicle", "Click");
		Thread.sleep(3000);
		UIMethods.jscriptclickbyxpath("//*[@id='ExposureDetail:ExposureDetailScreen:ExposureDetailDV:VehicleDamageDV:Vehicle_Incident:Vehicle_IncidentMenuIcon']", "click Vehicle Menu", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath("//*[text()='iew Incident Details...']", "click View Incident Details", "Click");
		Thread.sleep(2000);
		UIMethods.clickbyxpath("//*[text()='dit']", "click Edit", "Click");
		Thread.sleep(3000);
        UIMethods.selectbyid("EditVehicleIncidentPopup:EditVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:Driver_Picker", "input Driver Name", ddlExposureDriverName);
        Thread.sleep(3000);
        UIMethods.selectbyid("EditVehicleIncidentPopup:EditVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:RelationToInsured", "input Negotiation Type", ddlExposureRelationToOwner);
        Thread.sleep(3000);
        UIMethods.clickbyid("EditVehicleIncidentPopup:EditVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:DamDescFront_EXT", "click Front Checkbox", "Click");
        Thread.sleep(2000);
        UIMethods.clickbyid("EditVehicleIncidentPopup:EditVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:DamDescRoof_EXT", "click Roof Checkbox", "Click");
        Helper.highLightElement(driver, driver.findElement(By.xpath("//span[text()='pdate']")));
        UIMethods.clickbyxpath("//span[text()='pdate']", "click Update button", "Click");
	}
}