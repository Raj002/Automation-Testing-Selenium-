package org.qa.Claims.CICC9.CommonScreens;

import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class TransferRecovery {	
		
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
		
	public void TransferRecoveryPage(String excelFileName, String profileID) throws Exception{
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlTransferReserveLine = xlsread.Exceldata(SheetName, "ddlTransferReserveLine", profileID);
		String transRecoveryCategory = xlsread.Exceldata(SheetName, "ddlTransferReserveLineCategory", profileID);
		
		Thread.sleep(500);
		UIMethods.selectbyid("TransferRecovery:ReserveLine", "input Reserve Line", ddlTransferReserveLine);
		Thread.sleep(2000);		
		UIMethods.selectbyid("TransferRecovery:EditableRecodeLineItemsLV:0:LineCategory", "Select Line items category", transRecoveryCategory);
		Thread.sleep(2000);
        UIMethods.clickbyxpath("//*[text()='Transfer']", "click Transfer button", "Click");
        Thread.sleep(2000);
	}
	
	public void clickClaimSearch() throws Exception{        
		Thread.sleep(1000);
        UIMethods.jscriptclickbyxpath("//*[@id='TransferRecovery:Claim:SelectClaim']", "click Search Icon", "Click");
        Thread.sleep(2000);
	}
	
	
	
}