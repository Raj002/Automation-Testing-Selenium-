package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class ManagePartiesNext extends Object_Repositories {
	public  WebDriver driver = null;
	
	public ManagePartiesNext(WebDriver driver) {
		this.driver = driver;
	}

	public void ManagePartiesNextPage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String btnManagePartiesNext = xlsread.Exceldata(SheetName, "btnManagePartiesNext", profileID);

		// btnManagePartiesNext - this is in separate page
		if (!(btnManagePartiesNext.isEmpty())) {
			UIMethods.jscriptclickbyxpath(nextButton, "click Next button", "Click");
			Thread.sleep(2000);
		}
		Thread.sleep(4000);
	}

	public void ClickManagePartiesNext(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String btnManagePartiesNext = xlsread.Exceldata(SheetName, "btnManagePartiesNext", profileID);
		Thread.sleep(2000);

		// btnManagePartiesNext - this is in separate page
		if (!(btnManagePartiesNext.isEmpty())) {
			UIMethods.jscriptclickbyxpath(nextButton, "click Next button", "Click");
			Thread.sleep(3000);
		}

		try {
			UIMethods.jscriptclickbyxpath(nextButton, "click Next button", "Click");
			Thread.sleep(2000);
		} catch (Exception Ex) {
		}
		Thread.sleep(4000);
	}

	// Just click Next button
	public void ClickNextBtnOnly() throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_PartiesInvolvedScreen:ttlBar")));
		UIMethods.clickbyxpath(nextButton, "click Next button", "Click");
		
		// To Click on Documents screen Next button if appears
		if(driver.findElements(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_DocumentsScreen:ttlBar")).size()!=0) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_DocumentsScreen:ttlBar")));
			UIMethods.jscriptclickbyxpath(nextButton, "click Next button", "Click");	
		}
	}
}