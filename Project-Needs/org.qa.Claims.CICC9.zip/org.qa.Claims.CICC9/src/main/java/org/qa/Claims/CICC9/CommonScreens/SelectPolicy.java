package org.qa.Claims.CICC9.CommonScreens;

import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class SelectPolicy {
	
	public void SelectPolicypage(String excelFileName, String profileID) throws Exception{
		String SheetName = "ClaimsPolicy";
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtPolicyAccountNo = xlsread.Exceldata(SheetName, "txtPolicyAccountNo", profileID);
		UIMethods.inputbyid("ClaimPolicySelectPolicyPopup:ClaimPolicySelectPolicyScreen:PolicySearchDV:PolicySearchPolicyInputSet:PolicyNumber", "Input txtPolicyAccountNo" , txtPolicyAccountNo);
		Thread.sleep(3000);
		UIMethods.clickbyid("ClaimPolicySelectPolicyPopup:ClaimPolicySelectPolicyScreen:PolicySearchDV:Search_link", "click search", "Click");
		Thread.sleep(3000);
		UIMethods.jscriptclickbyxpath("//*[@id='ClaimPolicySelectPolicyPopup:ClaimPolicySelectPolicyScreen:PolicySearchResultLV:0:_Select_link']", "click select", "Click");
		Thread.sleep(8000);
	}
}