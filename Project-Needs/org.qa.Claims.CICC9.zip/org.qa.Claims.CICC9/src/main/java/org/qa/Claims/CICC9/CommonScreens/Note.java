package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class Note {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	public Note(WebDriver driver)
	{
		this.driver = driver;
	}	
	
	public void NewNotePage(String excelFileName, String profileID) throws Exception{		
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
        String ddlNoteTopic = xlsread.Exceldata(SheetName, "ddlNoteTopic", profileID);
		String txtNoteSubject = xlsread.Exceldata(SheetName, "txtNoteSubject", profileID);
		String ddlNoteRelatedTo = xlsread.Exceldata(SheetName, "ddlNoteRelatedTo", profileID);
		String txtNoteText = xlsread.Exceldata(SheetName, "txtNoteText", profileID);
		
        UIMethods.selectbyid("NewNoteWorksheet:NewNoteScreen:NoteDetailDV:Topic", "Input Topic", ddlNoteTopic);
        Thread.sleep(2000);
        UIMethods.inputbyid("NewNoteWorksheet:NewNoteScreen:NoteDetailDV:Subject", "input Subject", txtNoteSubject);
        
        if (ddlNoteRelatedTo.equals("EXISTING")) {
        	ddlNoteRelatedTo = CopyExposureData.exposuresdata;
        }
        Thread.sleep(2000);
        UIMethods.selectbyid("NewNoteWorksheet:NewNoteScreen:NoteDetailDV:RelatedTo", "input Related To", ddlNoteRelatedTo);
        Thread.sleep(2000);
        UIMethods.inputbyid("NewNoteWorksheet:NewNoteScreen:NoteDetailDV:Body", "input Text", txtNoteText);
        Thread.sleep(2000);
        Helper.highLightElement(driver, driver.findElement(By.xpath("//span[text()='pdate']")));
        UIMethods.jscriptclickbyxpath("//span[text()='pdate']", "click Update button", "Click");
        //UIMethods.clickbyxpath("//span[text()='pdate']", "click Update button", "Click");
        Thread.sleep(7000);
	}
}