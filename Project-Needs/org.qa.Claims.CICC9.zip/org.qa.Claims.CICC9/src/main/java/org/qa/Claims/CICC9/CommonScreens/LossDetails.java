package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class LossDetails {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	//Page Objects
	String insuredFaultRating = "//input[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Notification_Fault-inputEl']";
	String insuredWeather = "//input[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Claim_Weather-inputEl']";
	String updateButton = "//a[@id='ClaimLossDetails:ClaimLossDetailsScreen:Update']";
	String editButton = "//a[@id='ClaimLossDetails:ClaimLossDetailsScreen:Edit']";
	
	public LossDetails(WebDriver driver)
	{
		this.driver = driver;
		wait = new WebDriverWait(driver, 50);
	}	
	
	
	public void updateInsureFaultRating() throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(editButton))));
		UIMethods.jscriptclickbyxpath(editButton, "Click Edit button from Loss details screen", "Click");
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(insuredFaultRating)));
		Helper.selectDropdownValue(driver, "xpath", insuredFaultRating, "Select Insured Fault rating", "At Fault");
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(updateButton)));
		UIMethods.clickbyxpath(updateButton, "click update button", "Click");	
		Thread.sleep(3000);
	}
	
	public void LossDetailspage(String excelFileName, String profileID) throws Exception{		
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		
		String ddlInsuredFault = xlsread.Exceldata(SheetName, "ddlInsuredFault", profileID);
		String ddlInsuredWeather = xlsread.Exceldata(SheetName, "ddlInsuredWeather", profileID);
		String btnVehicleButton = xlsread.Exceldata(SheetName, "btnVehicleButton", profileID);
		String btnLossUpdateButton = xlsread.Exceldata(SheetName, "btnLossUpdateButton", profileID);
		String lnkEditMake = xlsread.Exceldata(SheetName, "lnkEditMake", profileID);			
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(insuredFaultRating)));
		Helper.selectDropdownValue(driver, "xpath", insuredFaultRating, "Select Insured Fault rating", ddlInsuredFault);
		
		// Updated by RAJ
		if(driver.findElements(By.id(insuredWeather)).size()!=0) {
			wait.until(ExpectedConditions.elementToBeClickable(By.id(insuredWeather)));
	        UIMethods.selectbyid(insuredWeather, "input insured weather", ddlInsuredWeather);
		}		
        
        if (!(btnVehicleButton.isEmpty())) {
	        UIMethods.clickbyxpath("//a[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:EditableVehicleIncidentsLV_tb:Add']/span", "click Add Vehicle button", "Click");
        }        
       
        if (!(btnLossUpdateButton.isEmpty())) {
	        UIMethods.clickbyxpath(updateButton, "click update button", "Click");
        }
        
        if (!(lnkEditMake.isEmpty())) {
        	UIMethods.clickbyxpath("//a[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:EditableVehicleIncidentsLV:0:Make']", "click Make Link", "Click");
        }                
	}
	
	public void AddInjuryButton() throws Exception{
		 UIMethods.clickbyxpath("//a[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:EditableInjuryIncidentsLV_tb:Add']/span", "click Add Injury button", "Click");
		 Thread.sleep(2000);
	}
	
	public void AddPropertiesButton() throws Exception{
		 UIMethods.clickbyxpath("//a[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Claim_Properties:EditableFixedPropertyIncidentsLV_tb:Add']/span", "click Add Property button", "Click");
	}
	
	public void lnkEditSecondVehicle() throws Exception{
		UIMethods.jscriptclickbyxpath("//a[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:EditableVehicleIncidentsLV:0:Make']", "click Make Link", "Click");
    }

	public void LossDetailsAutoSC20Page(String excelFileName, String profileID) throws Exception{
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlInsuredFault = xlsread.Exceldata(SheetName, "ddlInsuredFault", profileID);
		String ddlInsuredWeather = xlsread.Exceldata(SheetName, "ddlInsuredWeather", profileID);
		String ddlDriverName = xlsread.Exceldata(SheetName, "ddlDriverName", profileID);
		String ddlrelationToOwner = xlsread.Exceldata(SheetName, "ddlrelationToOwner", profileID);
		String btnLossUpdateButton = xlsread.Exceldata(SheetName, "btnLossUpdateButton", profileID);
		String txtInsuredLiability = xlsread.Exceldata(SheetName, "txtInsuredLiability", profileID);
		
		//Loss Details Input		
		Helper.selectDropdownValue(driver, "xpath", insuredFaultRating, "Select Insured Fault rating", ddlInsuredFault);		
		wait.until(ExpectedConditions.elementToBeClickable(By.id(insuredWeather)));
		Helper.selectDropdownValue(driver, "xpath", insuredWeather, "Select Insured weather rating", ddlInsuredWeather);
		
        UIMethods.inputbyxpath("//input[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Notification_AtFaultPercentage-inputEl']",  "input insured liability", txtInsuredLiability);
        
        //click Vehicle details
        UIMethods.clickbyxpath("//input[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:EditableVehicleIncidentsLV:0:_Checkbox']", "click vehicle checkbox", "Click");
        Thread.sleep(2000);
        UIMethods.clickbyxpath("//a[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:EditableVehicleIncidentsLV:0:Make']", "click vehicle make", "Click");
        Thread.sleep(3000);
        UIMethods.selectbyid("EditVehicleIncidentPopup:EditVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:Driver_Picker", "input driver name", ddlDriverName);
        UIMethods.selectbyid("EditVehicleIncidentPopup:EditVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:RelationToInsured", "input relation to owner", ddlrelationToOwner);
        Thread.sleep(2000);
        UIMethods.clickbyid("EditVehicleIncidentPopup:EditVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:DamDescFront_EXT", "click Front checkbox", "Click");
        Thread.sleep(2000);
        UIMethods.clickbyxpath("//*[@id='EditVehicleIncidentPopup:EditVehicleIncidentScreen:Update']/span[text()='OK']", "click OK Button", "Click");
        Thread.sleep(3000);
        //Loss Details Update
        if (btnLossUpdateButton != null) {
        UIMethods.clickbyxpath("//*[@id='ClaimLossDetails:ClaimLossDetailsScreen:Update']/span[2]", "click update button", "Click");
        Thread.sleep(2000);
        }
	}
	
}