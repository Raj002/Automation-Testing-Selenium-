package org.qa.Claims.CICC9.Technology;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

//import oracle.jdbc.OraclePreparedStatement;
//import oracle.jdbc.OracleResultSet;
//import oracle.xdb.XMLType;

/**
 * To establish database connections and fetch data from database
*/

public class ConnectionFramework extends FetchPropertiesFiles {

	private final BDDConstants constant = new BDDConstants();
	private final Properties prop = new Properties();
	private final String driver = constant.driver;
	private PreparedStatement preparedStatement;
	private Statement statement;
	public static final Logger LOG = Logger.getLogger(ConnectionFramework.class);

	/**
	 * Fetch the connection details from the properties file and establish the
	 * connection to the database
	 * @param dbEnv
	 * @return dbConnection
	 */

	public Connection returnConnection(String dbName) {

		Connection dbConnection = null;

		try {
				properties.load(FetchPropertiesFiles.class.getClassLoader()
						.getResourceAsStream("DBConnection.properties"));
			Class.forName(driver).newInstance();
			String url = properties.getProperty(dbName+"jdbcURL");
			String userName = properties.getProperty(dbName+"dbUser");
			String password = properties.getProperty(dbName+"dbPwd");
			dbConnection = DriverManager.getConnection(url, userName, password);
		}catch (IOException e) {
			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
		}catch (ClassNotFoundException e) {
			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
		} catch (SQLException e) {
			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
		} catch (IllegalAccessException e) {
			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
		} catch (InstantiationException e) {
			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
		}

		return dbConnection;
	}

	/**
	 * Read the query from .txt or .properties file and replace the constants
	 * with the required values
	 * 
	 * @param schemaName
	 * @param txtName
	 * @param replacementStrings
	 * @return
	 * @throws CustomisedExceptions
	 */

	@SuppressWarnings("resource")
	public String readQuery(String dbName,String txtName, String replacementStrings, String delimiter){

		String parameterList[];
		String strLine = null;
		String queryBuilder = "";
		String invocationMsg = txtName;

		try {
			properties.load(FetchPropertiesFiles.class.getClassLoader()
					.getResourceAsStream("DBConnection.properties"));
			
			/**
			 * If the Query is to be fetched from a .txt file
			 */
			if (txtName.contains(".txt")) {
				DataInputStream dataInputStream = null;
				File path = new File(constant.reqMsgPath + invocationMsg);
				FileInputStream prepMsg;
				prepMsg = new FileInputStream(path);
				dataInputStream = new DataInputStream(prepMsg);
				BufferedReader bufferReader = new BufferedReader(new InputStreamReader(dataInputStream));
				do {
					strLine = bufferReader.readLine();
					if (strLine != null) {
						queryBuilder = queryBuilder + strLine;
					}
				} while (strLine != null);
			}
			/**
			 * If Query is to be fetched from QuerryString.properties file
			 */
			else {
				
				prop.load(ConnectionFramework.class.getClassLoader().getResourceAsStream(constant.querySTR));
				queryBuilder = prop.getProperty(txtName);
			}
			/**
			 * Replacing the hard coded constants with the required value
			 */
			if (properties.getProperty(dbName+"SCHEMANAME") == "") {
				queryBuilder = queryBuilder.replace(constant.schemaNAME + ".", properties.getProperty(dbName+"SCHEMANAME"));
				queryBuilder = queryBuilder.replace(constant.cfgschemaNAME + ".",properties.getProperty(dbName+"CFGSCHEMANAME"));
			} else {
				queryBuilder = queryBuilder.replace(constant.schemaNAME, properties.getProperty(dbName+"SCHEMANAME"));
				queryBuilder = queryBuilder.replace(constant.cfgschemaNAME, properties.getProperty(dbName+"CFGSCHEMANAME"));
			}
			if (replacementStrings.equals("")) {

			} else {
				parameterList = replacementStrings.split(delimiter);
				for (int intI = 0; intI < parameterList.length; intI = intI + 2) {
					int intJ = intI + 1;
					queryBuilder = queryBuilder.replace(parameterList[intI], parameterList[intJ]);
				}
			}
		} catch (FileNotFoundException e) {
			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
		} catch (IOException e) {
			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
		}
		LOG.info("Query : "+queryBuilder);

		return queryBuilder;
	}

	/**
	 * Get META-DATA details from the table
	 * 
	 * @param dbEnv
	 * @param schemaName
	 * @param tableName
	 * @return
	 * 
	 */

	public String getMetadata(String dbName,String dbEnv, String schemaName, String tableName) {
		String returnValue = null;
		Connection dbConnection = null;

		try {
			dbConnection = returnConnection(dbName);

			DatabaseMetaData dbm = dbConnection.getMetaData();
			ResultSet rs1 = dbm.getColumns(null, schemaName, tableName, "%");
			while (rs1.next()) {
				returnValue = returnValue + " " + rs1.getString("COLUMN_NAME") + " \t " + rs1.getString("TYPE_NAME")
						+ " \t " + rs1.getString("COLUMN_SIZE") + " \t ";
				if (rs1.getInt("NULLABLE") == 0)
					returnValue = returnValue + "Not Nullable\n";
				else if (rs1.getInt("NULLABLE") == 1)
					returnValue = returnValue + "Nullable\n";

			}

		} catch (SQLException e) {
			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
		}

		try {
			dbConnection.close();
		} catch (SQLException e) {
			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
		}

		returnValue = returnValue.replace("null", "");
		return returnValue;
	}

	/***
	 * Getting full table information including primary keys and nullability and
	 * return as a string
	 * @param dbEnv
	 * @param schemaName
	 * @param tableName
	 * @return
	 */

	public String getMetadataDetailedInfo(String dbName,String dbEnv, String schemaName, String tableName) {
		String returnValue = null;
		Connection dbConnection = null;

		try {

			dbConnection = returnConnection(dbName);

			DatabaseMetaData dbm = dbConnection.getMetaData();
			ResultSet rs1 = dbm.getColumns(null, schemaName, tableName, "%");
			while (rs1.next()) {
				returnValue = returnValue + " " + rs1.getString("COLUMN_NAME") + " \t " + rs1.getString("TYPE_NAME")
						+ " \t " + rs1.getString("COLUMN_SIZE") + " \t ";
				if (rs1.getInt("NULLABLE") == 0)
					returnValue = returnValue + "Not Nullable\n";
				else if (rs1.getInt("NULLABLE") == 1)
					returnValue = returnValue + "Nullable\n";
			}

			ResultSet rs2 = dbm.getPrimaryKeys(null, schemaName, tableName);

			while (rs2.next()) {
				LOG.debug("Primary Key :- " + rs2.getString(4) + "\n");
			}

		} catch (SQLException e) {
			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
		}
		return returnValue;
	}

	/**
	 * Getting full table information including primary keys and nullability and
	 * return as a list
	 * @param dbEnv
	 * @param schemaName
	 * @param tableName
	 * @return
	 */

	public List<Object> getColumnDescDetailedInfoInList(String dbName,String dbEnv, String schemaName, String tableName) {
		Connection dbConnection = null;
		Map<String, List<String>> tableDetails = new HashMap<String, List<String>>();
		List<String> primarykeys = new ArrayList<String>();
		List<Object> returnList = new ArrayList<Object>();

		try {

			dbConnection = returnConnection(dbName);

			DatabaseMetaData dbm = dbConnection.getMetaData();
			ResultSet rs1 = dbm.getColumns(null, schemaName, tableName, "%");
			while (rs1.next()) {

				List<String> row = new ArrayList<String>();
				String columnName = rs1.getString("COLUMN_NAME");
				row.add(rs1.getString("TYPE_NAME"));
				row.add(rs1.getString("COLUMN_SIZE"));
				if (rs1.getInt("NULLABLE") == 0)
					row.add("Not Nullable");
				else if (rs1.getInt("NULLABLE") == 1)
					row.add("Nullable");
				tableDetails.put(columnName, row);
			}

			ResultSet rs2 = dbm.getPrimaryKeys(null, schemaName, tableName);
			while (rs2.next()) {
				primarykeys.add(rs2.getString(4));
			}
			returnList.add(tableDetails);
			returnList.add(primarykeys);

		} catch (SQLException e) {
			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
		}

		return returnList;
	}

	public List<List<String>> retMultiRowsAsList(String dbName,String txtName, String replacementStrings, int colNum) {
		Connection dbConnection = null;
		ResultSet resultSet = null;
		List<List<String>> returnMultipleRows = new ArrayList<List<String>>();
		List<String> result = new ArrayList<String>();
		TimeThread time = TimeThread.createThreadObject(1);
		int i = 1;
		int count = 1;
		try {
			String queryBuilder = readQuery(dbName,txtName, replacementStrings, ",");
			dbConnection = returnConnection(dbName);

			LOG.info("QueryBuilder : " + queryBuilder);
			do {

				statement = dbConnection.createStatement();
				resultSet = statement.executeQuery(queryBuilder);

				while (resultSet.next()) {
					result = new ArrayList<String>();
					for (i = 1; i <= colNum; i++) {
						result.add(resultSet.getString(i));
					}
					returnMultipleRows.add(result);

				}
				if (returnMultipleRows.isEmpty() && count <= 1) {
					time.start();
				}
				if (!time.isAlive())
					break;
				count++;
			} while (returnMultipleRows.isEmpty());
			time.interrupt();

		} catch (SQLException e) {
			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
		}

		finally {
			try {
				// time.destroy();
				resultSet.close();
				dbConnection.close();
			} catch (SQLException e) {
				LOG.error("ConnectionFramework : Exception : " + e.getMessage());
			}
		}
		return returnMultipleRows;
	}

	/*
	 * Fetching multiple rows and columns from database where result set can be
	 * null and returning them as a List and with an input wait time where the
	 * time for which the script will poll the database and wait for it to get
	 * updated
	 * 
	 * 
	 * @param dbEnv
	 * 
	 * @param schemaName
	 * 
	 * @param txtName
	 * 
	 * @param replacementStrings
	 * 
	 * @param colNum
	 * 
	 * @return
	 */
	public List<List<String>> retMultiRowsAsList(String dbName,String txtName, String replacementStrings, int colNum, int interval) {

		Connection dbConnection = null;
		ResultSet resultSet = null;
		List<List<String>> returnMultipleRows = new ArrayList<List<String>>();
		List<String> result = new ArrayList<String>();

		try {

			// Read query from the QueryString.Properties
			String queryBuilder = readQuery(dbName,txtName, replacementStrings, ",");
			LOG.info("  retMultiRowsAsList : queryBuilder " + queryBuilder);
			// Connect to the DB
			dbConnection = returnConnection(dbName);
			// Store the polling start time
			Instant start = Instant.now();

			do {

				statement = dbConnection.createStatement();
				resultSet = statement.executeQuery(queryBuilder);
				Thread.sleep(5000);
				// Store result value in List<List<String>>
				while (resultSet.next()) {
					result = new ArrayList<String>();
					for (int i = 1; i <= colNum; i++) {
						result.add(resultSet.getString(i));
					}
					returnMultipleRows.add(result);
				}
				// Store the polling time
				Instant end = Instant.now();
				// Time difference will be stored in Seconds
				long timeElapsed = Duration.between(start, end).getSeconds();
				// Break from the loop if Exceeds the given interval
				if (timeElapsed >= interval) {
					break;
				}

			} while (returnMultipleRows.isEmpty());

		} catch (SQLException e) {
			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
		} catch (InterruptedException e) {
			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
		} finally {

			try {

				resultSet.close();
				dbConnection.close();

			} catch (SQLException e) {
				LOG.error("ConnectionFramework : Exception : " + e.getMessage());
			}

		}
		return returnMultipleRows;
	}

	/**
	 * Fetching multiple rows and columns from database and returning them as a
	 * List where the replacement string has multiple values for one constant,
	 * separated by comma So value separator for replacement string is <,>
	 * 
	 * @param dbEnv
	 * @param schemaName
	 * @param txtName
	 * @param replacementStrings
	 * @param colNum
	 * @return
	 */
	public List<List<String>> retMultiRowsAsListLongStringReplace(String dbName,String txtName, String replacementStrings,
			int colNum) {
		Connection dbConnection = null;
		ResultSet resultSet = null;
		List<List<String>> returnMultipleRows = new ArrayList<List<String>>();
		List<String> result = new ArrayList<String>();
		int i = 1;
		try {
			String queryBuilder = readQuery(dbName,txtName, replacementStrings, "<,>");

			dbConnection = returnConnection(dbName);
			statement = dbConnection.createStatement();
			resultSet = statement.executeQuery(queryBuilder);
			while (resultSet.next()) {
				result = new ArrayList<String>();
				for (i = 1; i <= colNum; i++) {
					result.add(resultSet.getString(i));
				}
				returnMultipleRows.add(result);

			}
		} /*catch (SQLException e) {
			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
			
		}*/
		catch(Exception e)
		{
			System.out.println(e);
		}
		finally {
			try {
				resultSet.close();
				dbConnection.close();
			} /*catch (SQLException e) {
			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
			
		}*/
		catch(Exception e)
		{
			System.out.println(e);
		}

		}
		return returnMultipleRows;
	}

	/**
	 * Fetching multiple rows and columns as a list where the first row has XML
	 * Data Format Other rows should have normal data.
	 * 
	 * @param dbEnv
	 * @param schemaName
	 * @param txtName
	 * @param replacementStrings
	 * @param colNum
	 * @return
	 */

//	public List<List<String>> retMultiRowsAsListHavinXML(String dbName,String txtName, String replacementStrings, int colNum)
//			throws ClassNotFoundException {
//		Connection dbConnection = null;
//		List<List<String>> returnMultipleRows = new ArrayList<List<String>>();
//		List<String> result = new ArrayList<String>();
//		int i = 1;
//		try {
//			String queryBuilder = readQuery(dbName,txtName, replacementStrings, ",");
//
//			dbConnection = returnConnection(dbName);
//			PreparedStatement stmt = dbConnection.prepareStatement(queryBuilder);
//			ResultSet rset = stmt.executeQuery();
//			//OracleResultSet orset = (OracleResultSet) rset;
//
//			XMLType poxml1 = null;
//			while (rset.next()) {
//				result = new ArrayList<String>();
//				poxml1 = XMLType.createXML(rset.getOPAQUE(1));
//				String xmlvalue = poxml1.getStringVal();
//				result.add(xmlvalue);
//				for (i = 2; i <= colNum; i++) {
//					result.add(rset.getString(i));
//				}
//				returnMultipleRows.add(result);
//			}
//
//		} catch (SQLException e) {
//			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
//		}
//
//		finally {
//			try {
//				dbConnection.close();
//			} catch (SQLException e) {
//				LOG.error("ConnectionFramework : Exception : " + e.getMessage());
//			}
//		}
//		return returnMultipleRows;
//	}

	/**
	 * Non XML query builder process mainly used or mainly Insert, Update,Delete
	 * and Alter Queries
	 * 
	 * @param dbEnv
	 * @param schemaName
	 * @param queryName
	 * @param parameters
	 */
	public void nonXMLQuery(String dbName,String queryName, String parameters) {
		Connection dbConnection = null;
		try {
			String queryBuilder = readQuery(dbName,queryName, parameters, ",");

			dbConnection = returnConnection(dbName);
			statement = dbConnection.createStatement();
			statement.executeQuery(queryBuilder);
		} catch (SQLException e) {
			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
		}

		finally {
			try {
				dbConnection.close();
			} catch (SQLException e) {
				LOG.error("ConnectionFramework : Exception : " + e.getMessage());
			}
		}
	}

	/**
	 * XML query builder process mainly used or mainly Insert, Update,Delete and
	 * Alter Queries
	 * 
	 * @param dbEnv
	 * @param schemaName
	 * @param queryName
	 * @param parameters
	 *
	 */

	public void xmlQuery(String dbName,String queryName, String parameters) throws ClassNotFoundException {
		Connection dbConnection = null;
		try {
			String queryBuilder = readQuery(dbName,queryName, parameters, ",");

			dbConnection = returnConnection(dbName);
			preparedStatement = dbConnection.prepareStatement(queryBuilder);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			LOG.error("ConnectionFramework : Exception : " + e.getMessage());
		} finally {
			try {
				dbConnection.close();
			} catch (SQLException e) {
				LOG.error("ConnectionFramework : Exception : " + e.getMessage());
			}
		}
	}

}