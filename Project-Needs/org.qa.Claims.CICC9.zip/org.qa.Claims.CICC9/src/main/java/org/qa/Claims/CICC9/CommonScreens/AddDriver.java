package org.qa.Claims.CICC9.CommonScreens;

import org.qa.Claims.CICC9.Technology.UIMethods;

public class AddDriver {

	public void VehicleDetailspage() throws Exception {

		// Add Driver Button
		UIMethods.jscriptclickbyxpath("//a[@id='FNOLVehicleIncidentPopup:FNOLVehicleIncidentScreen:OccupantLV_tb:AddDriverButton']/span[text()='Add Driver']","click add driver button", "Click");
		Thread.sleep(3000);
	}

	public void AddPassengerpage() throws Exception {
		// Add Driver Button
		UIMethods.jscriptclickbyxpath("//a[@id='FNOLVehicleIncidentPopup:FNOLVehicleIncidentScreen:OccupantLV_tb:AddPassengerButton']/span[text()='assenger']","click add passenger button", "Click");
		Thread.sleep(3000);
	}
}