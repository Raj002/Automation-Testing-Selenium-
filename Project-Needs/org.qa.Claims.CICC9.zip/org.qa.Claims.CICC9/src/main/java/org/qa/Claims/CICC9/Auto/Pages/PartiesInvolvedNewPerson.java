package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class PartiesInvolvedNewPerson {	
	
	WebDriver driver;
	WebDriverWait wait;
	
	String firstNamefield = "//input[@id='NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:PersonNameInputSet:GlobalPersonNameInputSet:FirstName-inputEl']";
	String lastNamefield = "//input[@id='NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:PersonNameInputSet:GlobalPersonNameInputSet:LastName-inputEl']";
	String addButton = "//a[@id='NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:ContactBasicsHeaderInputSet:EditableClaimContactRolesLV_tb:Add']/span";
	String addedFirstRow = "//div[@id='NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:ContactBasicsHeaderInputSet:EditableClaimContactRolesLV-body']/div[1]/div/table/tbody/tr/td[3]/div";
	
	String roleField = "//input[@id='simplecombo-1409-inputEl']";
	
	
	public PartiesInvolvedNewPerson(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver,15);
	}
		
	public void  PartiesInvolvedNewPersonpage(String excelFileName, String profileID) throws Exception {
		String SheetName = "ClaimsPolicy";
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String firstName = xlsread.Exceldata(SheetName, "txtFirstName", profileID);
		String lastName = xlsread.Exceldata(SheetName, "txtLastName", profileID);
		String addrline1 = xlsread.Exceldata(SheetName, "txtAddrLine1", profileID);
		String addrline2 = xlsread.Exceldata(SheetName, "txtAddrLine2", profileID);
		String addrcity = xlsread.Exceldata(SheetName, "txtAddrCity", profileID);
		String addrstate = xlsread.Exceldata(SheetName, "txtAddrState", profileID);
		String zipcode = xlsread.Exceldata(SheetName, "txtZipcode", profileID);
		String otherRole = xlsread.Exceldata(SheetName, "ddlOtherRole", profileID);
		
		
		UIMethods.inputbyxpath(firstNamefield, "Enter First Name", firstName);
		UIMethods.inputbyxpath(lastNamefield, "Enter last name", lastName);
		UIMethods.inputbyxpath("//input[@id='NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:AddressLine1-inputEl']", "Enter address line1", addrline1);
		UIMethods.inputbyxpath("//input[@id='NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:AddressLine2-inputEl']", "Enter address line2", addrline2);
		UIMethods.inputbyxpath("//input[@id='NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:City-inputEl']", "Enter City", addrcity);
		UIMethods.clearAndinputbyxpath("//input[@id='NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:State-inputEl']", "Select state", addrstate);
		Thread.sleep(1000);
		UIMethods.clickbyxpath("//input[@id='NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:AddressLine2-inputEl']", "address line1", "click");
		
		UIMethods.inputbyxpath("//input[@id='NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:PostalCode-inputEl']", "Enter Zipcode", zipcode);
		UIMethods.clickbyxpath(addButton, "Click Add button", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(addedFirstRow)));		
		UIMethods.clickbyxpath(addedFirstRow, "Click role field", "Click");
		Thread.sleep(1000);
		UIMethods.clearAndinputbyxpath("//input[contains(@id,'simplecombo') or @name='Role']", "Select role", otherRole);
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath("//div[@id='NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:ContactBasicsHeaderInputSet:EditableClaimContactRolesLV-body']/div[1]/div/table/tbody/tr/td[1]/div", "Select added role", "Click");
		UIMethods.clickbyxpath("//a[@id='NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:CustomUpdateButton']/span", "Click Update Button", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimContacts:ClaimContactsScreen:ttlBar']")));
	}
}