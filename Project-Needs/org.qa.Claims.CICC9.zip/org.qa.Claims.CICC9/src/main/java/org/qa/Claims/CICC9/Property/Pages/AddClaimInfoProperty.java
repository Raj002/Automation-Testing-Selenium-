package org.qa.Claims.CICC9.Property.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class AddClaimInfoProperty {

	private WebDriver driver = null;
	WebDriverWait wait;
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");

	// Page Objects
	String descriptionField = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:Description";
	String claimLossCause = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:Claim_LossCause";
	String detailedLosCause = "//*[@id='FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:DetailedLossCause']";
	String heavyEquipmentIndicator = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:HeavyEquipmentIndicator_false";
	String howReportedField = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:Notification_HowReported";
	String zipCode = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:AddressInputSet:Address_ZIP";
	String onPromisisYesOption = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:OnPremises_true";

	public AddClaimInfoProperty(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}

	public void AddClaimInfoPage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtLossDescription = xlsread.Exceldata(SheetName, "txtLossDescription", profileID);
		String txtLossCause = xlsread.Exceldata(SheetName, "txtLossCause", profileID);
		String txtDetailedLossCause = xlsread.Exceldata(SheetName, "txtDetailedLossCause", profileID);
		String ddlHowReportedAddClaim = xlsread.Exceldata(SheetName, "ddlHowReportedAddClaim", profileID);
		String txtAddress1 = xlsread.Exceldata(SheetName, "txtAddress1AddClaim", profileID);
		String txtCity = xlsread.Exceldata(SheetName, "txtCityAddClaim", profileID);
		String txtState = xlsread.Exceldata(SheetName, "txtStateAddClaim", profileID);
		String txtZip = xlsread.Exceldata(SheetName, "txtZipAddClaim", profileID);
		String rdbOnpremises = xlsread.Exceldata(SheetName, "rdbOnpremises", profileID);
		String lnkAddressLink = xlsread.Exceldata(SheetName, "lnkAddressLink", profileID);
		String btnAddClaimNext = xlsread.Exceldata(SheetName, "btnAddClaimNext", profileID);
		String btnAddProperties = xlsread.Exceldata(SheetName, "btnAddProperties", profileID);
		
		UIMethods.inputbyid(descriptionField, "Input Description", txtLossDescription);
		Thread.sleep(2000);
		if (!(txtLossCause.isEmpty())) {
			Select dropdwn = new Select(driver.findElement(By.id(claimLossCause)));
			dropdwn.selectByVisibleText(txtLossCause);
		    Thread.sleep(4000);
		}
		Thread.sleep(4000);
	    UIMethods.selectbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:DetailedLossCause", "Input detailedlosscause", txtDetailedLossCause);
	    Thread.sleep(4000);
	    UIMethods.clickbyid(heavyEquipmentIndicator, "Click Involves Heavy Equipments No Option", "Click");
	    Thread.sleep(2000);
	    UIMethods.selectbyid(howReportedField, "Input HowReported", ddlHowReportedAddClaim);	 
	    Thread.sleep(2000);
	    UIMethods.inputbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:AddressInputSet:Address_AddressLine1", "Input Address Line1", txtAddress1);
	    Thread.sleep(1000);
	    UIMethods.inputbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:AddressInputSet:Address_City", "Input City", txtCity);
	    Thread.sleep(1000);
	    UIMethods.selectbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:AddressInputSet:Address_State", "Input State", txtState);
	    Thread.sleep(4000);
	    
	    if (!(txtZip.isEmpty())) {
	    	UIMethods.clickbyid(zipCode, "Click Zip", "Click");
	    	Helper.clearTextBox(driver, driver.findElement(By.id(zipCode)));
		    UIMethods.inputbyid(zipCode, "Input Zip", txtZip);
		    UIMethods.clickbyid(descriptionField, "Click Description", "Click");
		    Thread.sleep(3000);
	    }
	    
	    if (!(rdbOnpremises.isEmpty())) {
	    	if (rdbOnpremises.equalsIgnoreCase("false")) {
	    		UIMethods.clickbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:OnPremises_false", "Click On Premises radio - No Option", "Click");
	    	} else {
	    		UIMethods.clickbyid(onPromisisYesOption, "Click On Premises radio - Yes Option", "Click");
	    	}
	    }
	    
	    if (!(btnAddClaimNext.isEmpty())) {
		    UIMethods.clickbyxpath("//span[text()='Next >']", "click Next button", "Click");
			Thread.sleep(3000);
	    }
	    
	   if (!(lnkAddressLink.isEmpty())) {
		   UIMethods.jscriptclickbyxpath("//*[@id='FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:EditableFixedPropertyIncidentsLV:0:Address1']", "Click Address Hyperlink", "Click");
           Thread.sleep(2000);
	   }	
	   
	   if (!(btnAddProperties.isEmpty())) {
		   UIMethods.jscriptclickbyxpath("//*[@id='FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:EditableFixedPropertyIncidentsLV_tb:Add']", "Click Add Properties Button", "Click");
           Thread.sleep(2000);
	   }
	}
	
	public void AddInjuries() throws Exception {		
		UIMethods.clickbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:EditableInjuryIncidentsLV_tb:Add", "Click Add Injury Button", "Click");
		Thread.sleep(2000);
	}
	
	public void FillOutRequiredFields(String excelFileName, String profileID) throws Exception{
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");		
		String lossDescription = xlsread.Exceldata(SheetName, "txtLossDescription", profileID);
		String lossCause = xlsread.Exceldata(SheetName, "ddlLossCause", profileID);
		String detailedLossCause = xlsread.Exceldata(SheetName, "ddlDetailedLossCause", profileID);
		String howReported = xlsread.Exceldata(SheetName, "ddlHowReported", profileID);
		String lossLocation = xlsread.Exceldata(SheetName, "ddlLossLocation", profileID);
		
		UIMethods.inputbyid(descriptionField, "Input Description", lossDescription);
		Select dropdwn1 = new Select(driver.findElement(By.id(claimLossCause)));
		dropdwn1.selectByVisibleText(lossCause);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(detailedLosCause)));
		UIMethods.inputbyxpath(detailedLosCause, "Select Detailed Loss Cause", detailedLossCause);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(heavyEquipmentIndicator)));
		UIMethods.clickbyid(heavyEquipmentIndicator,"Select No for Involves Heavy Equipment", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:WeatherRelated_false")));
		UIMethods.clickbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:WeatherRelated_false", "Select No for Weather Related", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(howReportedField)));
		UIMethods.inputbyid(howReportedField, "Input HowReported", howReported);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:AddressInputSet:Address_Picker")));
		UIMethods.inputbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:AddressInputSet:Address_Picker", "Select 102 Rating Avenue", lossLocation);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(onPromisisYesOption)));
		UIMethods.clickbyid(onPromisisYesOption, "Click Yes for On Premises", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(detailedLosCause)));
		UIMethods.inputbyxpath(detailedLosCause, "Select Detailed Loss Cause", detailedLossCause);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(descriptionField)));
		UIMethods.clickbyid(descriptionField, "Click Loss Description field", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(heavyEquipmentIndicator)));
		UIMethods.clickbyid(heavyEquipmentIndicator,	"Select No for Involves Heavy Equipment", "Click");
	}

	public void ClickNextBtnOnly() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FNOLWizard:Next")));
		UIMethods.clickbyid("FNOLWizard:Next", "Click Next button", "Click");
	}
}