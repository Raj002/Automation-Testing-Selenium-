package org.qa.Claims.CICC9.Technology;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import org.apache.log4j.Logger;

/**
 * Reusable component for Web services
*/

public class UtilityMethods {

	public static Logger LOG = Logger.getLogger(UtilityMethods.class);

	/**
	 * @param fileToBeCreatedAbsoluePath
	 * @param contents
	 * @return String
	 * @MethodName writeToNewFile
	 * @MethodDescription To write String contents in a file
	 */
	public static String writeToNewFile(String fileToBeCreatedAbsoluePath, String contents) {

		BufferedWriter bufferWritter = null;
		String fileCreatedPath = null;
		try {
			fileCreatedPath = fileToBeCreatedAbsoluePath;
			bufferWritter = new BufferedWriter(new FileWriter(new File(fileToBeCreatedAbsoluePath), false));
			bufferWritter.write(contents);
			bufferWritter.close();

		} catch (Exception exception) {			
			LOG.debug("Exception in Creating File  : " + exception.getMessage());
		}
		return fileCreatedPath;

	}
	
	/**
	 * @param destinationFolder
	 * @param source
	 * @return String
	 * @MethodName renameFile
	 * @MethodDescription To rename a file
	 */
	public static String renameFile(String source, String destinationFolder) {
		String renamePath = null;
		String targetPath = null;		
		
		try {			
			targetPath = new File(source).getAbsolutePath();
			File file = new File(targetPath);
			renamePath = new File(destinationFolder).getAbsolutePath();
			File reNameFile = new File(renamePath);
			file.renameTo(reNameFile);
			
		} catch (Exception ex) {
			LOG.debug("Rename file to other dirctory" + ex.getMessage());
		}
		return renamePath;
	}

	/**
	 * @param fileToBeReadAbsolutePath
	 * @return List<String>
	 * @MethodName readFileReturnList
	 * @MethodDescription To Read a file and Store contents in List<String>
	 */
	public static List<String> readFileReturnList(String fileToBeReadAbsolutePath) {
		
		List<String> fileContentsLineByLine = new ArrayList<String>();
		FileReader fileRead = null;
		BufferedReader bufferRead = null;
		String content = null;
		
		try {
			File file = new File(fileToBeReadAbsolutePath);
			fileToBeReadAbsolutePath = file.getAbsolutePath();
			fileRead = new FileReader(fileToBeReadAbsolutePath);
			bufferRead = new BufferedReader(fileRead);
			fileContentsLineByLine = new ArrayList<String>();
			do {

				content = bufferRead.readLine();
				if (content != null) {
					fileContentsLineByLine.add(content);
				}

			} while (content != null);

		} catch (FileNotFoundException exception) {
			LOG.debug("Exception in Reading File  : " + exception.getMessage());
		} catch (IOException exception) {
			LOG.debug("Exception in Reading File  : " + exception.getMessage());
		} finally {
			try {
				bufferRead.close();
			} catch (IOException exception) {

				LOG.warn("Buffered reader is not closed : " + exception.getMessage());
			}
		}

		return fileContentsLineByLine;

	}
	
	/**
	 * @param fileToBeReadAbsolutePath
	 * @return String
	 * @MethodName readFileReturnString
	 * @MethodDescription To Read a file and Store contents in String
	 */
	public static String readFileReturnString(String fileToBeReadAbsolutePath) {
		
		String fileContents = null ,content = null;
		FileReader fileRead = null;
		BufferedReader bufferRead = null;
		
		try {
			File file = new File(fileToBeReadAbsolutePath);
			fileToBeReadAbsolutePath = file.getAbsolutePath();
			fileRead = new FileReader(fileToBeReadAbsolutePath);
			bufferRead = new BufferedReader(fileRead);
			do {

				content = bufferRead.readLine();
				if (content != null) {
					fileContents = fileContents + content + "\n";					
				}

			} while (content != null);

		} catch (FileNotFoundException exception) {
			LOG.debug("Exception in Reading File  : " + exception.getMessage());
			
		} catch (IOException exception) {
			LOG.debug("Exception in Reading File  : " + exception.getMessage());
			
		} finally {
			
			try {
				bufferRead.close();
			} catch (IOException exception) {
				LOG.warn("Buffered reader is not closed : " + exception.getMessage());
			}
		}

		return fileContents;

	}

	/**
	 * @param tagName
	 * @param xmlFilecontent
	 * @return List<String>
	 * @MethodName getXMLTagValue
	 * @MethodDescription Pass xmlContent and tagName to fetch values of the given tag
	 */
	public static List<String> getXMLTagValue(String tagName, String xmlFilecontent) {

		String paramValue = null, buffString = null;
		List<String> tagValues = new ArrayList<String>();
		List<String> xmlContentLineByLine = new ArrayList<String>();
		xmlContentLineByLine = new ArrayList<String>();
		int endTagLength = 0, count = 0;		
				
		String[] xmlContentList = xmlFilecontent.split("\n");		
		for (String xml : xmlContentList) {
			xmlContentLineByLine.add(xml);
		}

		try {

			for (int i = 0; i < xmlContentLineByLine.size(); i++) {
				
				xmlFilecontent = xmlContentLineByLine.get(i);
				if (xmlFilecontent != null && xmlFilecontent.contains(tagName)) {

					int startTagLength = xmlFilecontent.indexOf(tagName);
					buffString = xmlFilecontent.substring(startTagLength, xmlFilecontent.length());
					try{
						
						endTagLength = buffString.indexOf("</");
						paramValue = buffString.substring(0, endTagLength);					
						paramValue = paramValue.substring(paramValue.indexOf(">") + 1, paramValue.length());
					
					}catch(Exception exception){
						
						i = i + 1;
						xmlFilecontent = xmlContentLineByLine.get(i);
						startTagLength = xmlFilecontent.indexOf(">");
						endTagLength = xmlFilecontent.indexOf("</");
						paramValue = xmlFilecontent.substring(startTagLength + 1, endTagLength);
					}

					if (!tagValues.contains(paramValue)) {
						tagValues.add(paramValue);
					}
					count++;
				}
			}

			if (count == 0) {
				tagValues.add("No tag(s) Found");
			}

		} catch (Exception exception) {			
			LOG.debug("Error when parsing tagValue "+ tagName+ " of XML : " + exception.getMessage());
		} 

		return tagValues;
	}

	/**
	 * @param tagName
	 * @param xmlcontent
	 * @return List<String>
	 * @MethodName getXMLTagChunk
	 * @MethodDescription Pass xmlContent and tagName to fetch values of the given tag
	 */
	public List<String> getXMLTagChunk(String tagName, String xmlcontent) {

		List<String> tagValues = new ArrayList<String>();
		String paramValue = null, startTag = "<" + tagName + ">", endTag = "</" + tagName + ">";
		List<String> xmlContentLineByLine = new ArrayList<String>();
		xmlContentLineByLine = new ArrayList<String>();
		String[] xmlContentList = xmlcontent.split("\n");
		int count = 0;

		for (String xml : xmlContentList) {
			xmlContentLineByLine.add(xml);
		}
		count = 0;
		try {

			for (int i = 0; i < xmlContentLineByLine.size(); i++) {
				xmlcontent = xmlContentLineByLine.get(i);
				if (xmlcontent != null && xmlcontent.contains(startTag)) {

					do {
						if (!xmlcontent.contains(tagName))
							paramValue = paramValue + xmlcontent + "\n";
						i++;
						xmlcontent = xmlContentLineByLine.get(i);
					} while (!xmlcontent.contains(endTag));
					count++;
					tagValues.add(paramValue);
					paramValue = "";
				}
			}

			if (count == 0) {
				paramValue = xmlcontent;
			}

		} catch (Exception e) {
			LOG.debug("Error when parsing Chunk of XML : " + e.getMessage());
		} 

		return tagValues;
	}
	
	/**
	 * @param tagAttribute
	 * @param xmlcontent
	 * @return List<String>
	 * @MethodName getXMLTagAttributeValues
	 * @MethodDescription Pass xmlContent and tagName to fetch values of the given tagAttribute
	 */
	public static List<String> getXMLTagAttributeValues(String tagAttribute, String xmlcontent) {
		
		List<String> xmlContentLineByLine = new ArrayList<String>();
		List<String> tagValues = new ArrayList<String>();
		String param = null, buffString = null;		
		int count = 0;
		
		xmlContentLineByLine = new ArrayList<String>();		
		String[] xmlContentList = xmlcontent.split("\n");
		for (String xml : xmlContentList) {
			xmlContentLineByLine.add(xml);		
		}

		try {
			for (int i = 0; i < xmlContentLineByLine.size(); i++) {
				xmlcontent = xmlContentLineByLine.get(i);
				if (xmlcontent != null && xmlcontent.contains(tagAttribute)) {

					int startLen = xmlcontent.indexOf(tagAttribute);
					buffString = xmlcontent.substring(startLen, xmlcontent.length());
					int endTag = 0;
					startLen = buffString.indexOf("\"") + 1;
					endTag = buffString.indexOf("\"", startLen);
					param = buffString.substring(startLen, endTag);
					count++;

					if (!tagValues.contains(param)) {
					tagValues.add(param);
					}
				}
			}

			if (count == 0) {
				tagValues.add("No tag(s) Found");
			}

		} catch (Exception exception) {
			LOG.info("Error when parsing XML Attribute value : "+ exception.getMessage());
		} 

		return tagValues;
	}
	
	/**
	 * @param startTimestamp
	 * @param currentTimestamp
	 * @return List<Integer>
	 * @MethodName returnTimeDiff
	 * @MethodDescription Calculate the time difference between two timestamp
	 */
	@SuppressWarnings("deprecation")
	public static List<Integer> returnTimeDiff(Timestamp startTimestamp, Timestamp currentTimestamp) {
		int count = 1;
		List<Integer> timeDiff = new ArrayList<Integer>();
		int timeCal = (currentTimestamp.getNanos() - startTimestamp.getNanos()) / 1000000;
		if (timeCal < 0)
			timeCal = timeCal + 1000;
		else
			count = 0;

		timeDiff.add(timeCal);
		timeCal = currentTimestamp.getSeconds() - startTimestamp.getSeconds();

		if (timeCal < 0) {
			timeCal = timeCal + 60;
			count = 1;
		} else
			count = 0;

		timeDiff.add(timeCal);
		timeCal = currentTimestamp.getMinutes() - startTimestamp.getMinutes();

		timeCal = timeCal - count;
		if (timeCal < 0) {
			timeCal = timeCal + 60;
			count = 1;
		}

		else
			count = 0;

		timeDiff.add(timeCal);

		timeCal = currentTimestamp.getHours() - startTimestamp.getHours();
		timeCal = timeCal - count;
		if (timeCal < 0) {
			timeCal = timeCal + 60;
			count = 1;
		} else
			count = 0;

		timeDiff.add(timeCal);
		Collections.reverse(timeDiff);

		return timeDiff;

	}

	/**
	 * 
	 * @param format
	 * @return String
	 * @MethodName presentTimeInESTZone
	 * @MethodDescription Fetch System date and timestamp for the given timestamp in EST
	 */
	public static String presentTimeInESTZone(String format) {

		Calendar calendar = Calendar.getInstance();		
		calendar.add(Calendar.MINUTE, 35);
		Date now = calendar.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		sdf.setTimeZone(TimeZone.getTimeZone("EST"));
		String dateString = sdf.format(now);
		return dateString.toUpperCase();

	}

	/**
	 * 
	 * @param format
	 * @return String
	 * @MethodName sytemDate
	 * @MethodDescription Fetch System date and timestamp for the given timestamp
	 */
	public static String sytemDate(String format) {
		String strDate = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		Calendar cal = Calendar.getInstance();
		strDate = dateFormat.format(cal.getTime());
		return strDate;
	}

	/**
	 * 
	 * @param format
	 * @return String
	 * @MethodName sytemDate
	 * @MethodDescription Fetch System date and timestamp for the given timestamp
	 */
	public static String futureDate(String strDate, String format,String yearmonthdate, int noOfDays) {

		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		
		try {
			cal.setTime(sdf.parse(strDate));
		} catch (ParseException e) {
			LOG.error("Date can't be parsed");
		}

		if (yearmonthdate.equalsIgnoreCase("Month")) {
			cal.add(Calendar.MONTH, noOfDays);
		} else if (yearmonthdate.equalsIgnoreCase("Date")) {
			cal.add(Calendar.DATE, noOfDays);
		} else if (yearmonthdate.equalsIgnoreCase("year")) {
			cal.add(Calendar.YEAR, noOfDays);
		}

		Date date = cal.getTime();
		String dateString = sdf.format(date);

		return dateString;
		
	}	
	
	/**
	 * @param userDate
	 * @param fromFormat
	 * @param toFormat
	 * @return String
	 * @MethodName convertDateFormat
	 * @MethodDescription Convert date to any format from any format
	 */
	public static String convertDateFormat(String userDate, String fromFormat, String toFormat) {
		String dateReceivedFromUser = userDate;
		DateFormat userDateFormat = new SimpleDateFormat(fromFormat);
		DateFormat dateFormatNeeded = new SimpleDateFormat(toFormat);
		Date date = new Date();
		try {
			date = userDateFormat.parse(dateReceivedFromUser);

		} catch (ParseException e) {
			LOG.error("Date can't be parsed");
		}
		Calendar cal = new GregorianCalendar();
		cal.setTime(date);
		String convertedDate = dateFormatNeeded.format(cal.getTime());
		return convertedDate;
	}
	
	/**
	 * @param toFormat
	 * @param month
	 * @return String
	 * @MethodName getMonthLastDate
	 * @MethodDescription Get Lastdate of the month in requried format
	 */
	public static String getMonthLastDate(String toFormat,int month){
		
		String lastDate = "";
		
		Calendar calendar = Calendar.getInstance();
	    calendar.set(Calendar.MONTH, month);
	    calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DATE));
	    Date date = calendar.getTime();
	    DateFormat DATE_FORMAT = new SimpleDateFormat(toFormat);
	    System.out.println(DATE_FORMAT.format(date).toString());
	    lastDate=DATE_FORMAT.format(date).toString();
	    
	    return lastDate;

	}
	
	/**
	 * @param toFormat
	 * @param month
	 * @return String
	 * @MethodName getMonthFirstDate
	 * @MethodDescription Get Firstdate of the month in required format
	 */
	public static String getMonthFirstDate(String toFormat,int month){
		
		String lastDate = "";
		
		Calendar calendar = Calendar.getInstance();
	    calendar.set(Calendar.MONTH, month);
	    calendar.set(Calendar.DATE, calendar.getActualMinimum(Calendar.DATE));
	    Date date = calendar.getTime();
	    DateFormat DATE_FORMAT = new SimpleDateFormat(toFormat);	 
	    lastDate=DATE_FORMAT.format(date).toString();  
	    
	    return lastDate;

	}
	
	/**
	 * 
	 * @return
	 * @MethodName getMonthFirstDate
	 * @MethodDescription Get Firstdate of the month in required format
	 */
	public String sytemDateAndTimeWithAMPMIncluded() {
		String strDate = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy hh.mm.ss a");
		Calendar cal = Calendar.getInstance();
		strDate = dateFormat.format(cal.getTime());
		LOG.info("System Date and Time : " + strDate);
		strDate = strDate.toUpperCase();
		return strDate;
	}

}
