package org.qa.Claims.CICC9.Property.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ClaimStatus {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	public ClaimStatus(WebDriver driver)
	{
		this.driver = driver;
	}	
	
	public void ClaimStatusPage() throws Exception{
		//check claim open status
        //UIMethods.getSpanValueUsingID("check claim in open status", "ClaimStatus:ClaimStatus", "Open");
	}
}