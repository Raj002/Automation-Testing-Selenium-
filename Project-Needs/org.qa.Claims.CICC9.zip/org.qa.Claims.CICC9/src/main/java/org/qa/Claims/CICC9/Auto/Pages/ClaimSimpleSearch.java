package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class ClaimSimpleSearch {

	private WebDriver driver = null;
	WebDriverWait wait;

	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");

	public ClaimSimpleSearch(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver,20);
	}
	
	public void ClaimsSearch(String excelFileName, String profileID) throws Exception {
        wait = new WebDriverWait(driver,20);
        driver.switchTo().defaultContent();
        driver.switchTo().frame(0);
       
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtClaimNo = xlsread.Exceldata(SheetName, "txtClaimNo", "AutoScenario10");
        
        //***************click claims links and new claims
		UIMethods.clickbyxpath("//*[@id='Desktop:MenuLinks:Desktop_DesktopExposures']/div", "Desktop link", "Click");
		
		UIMethods.clickbyxpath("//*[@id='TabBar:SearchTab']", "Click search link", "Click");
		UIMethods.inputbyid("SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchDV:ClaimNumber", "input claimnumber", txtClaimNo);
		UIMethods.clickbyxpath("//*[@id='SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchDV:ClaimSearchAndResetInputSet:Search_link']", "click search button", "Click");
		Thread.sleep(2000);
		UIMethods.clickbyxpath("//*[@id='SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchResultsLV:0:ClaimNumber']", "click claim link", "Click");
		Thread.sleep(3000);
	}
}