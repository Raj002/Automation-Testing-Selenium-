package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.WebDriver;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class VoidRecovery {
	
	private WebDriver driver=null;
	
	public VoidRecovery(WebDriver driver)
	{
		this.driver = driver;
	}	
	
	public void voidrecoveryPage() throws Exception{
        Thread.sleep(1000);
        UIMethods.clickbyxpath("//*[@id='VoidRecovery:VoidRecoveryScreen:VoidRecovery_VoidButton']/span[2]", "click void button", "Click");
        Thread.sleep(1000);
        driver.switchTo().alert().accept();
        Thread.sleep(2000);
	}
}