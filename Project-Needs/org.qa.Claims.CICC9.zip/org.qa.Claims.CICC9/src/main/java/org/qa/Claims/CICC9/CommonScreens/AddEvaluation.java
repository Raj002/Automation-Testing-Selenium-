package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class AddEvaluation {

	private WebDriver driver = null;
	WebDriverWait wait;

	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");

	public AddEvaluation(WebDriver driver) {
		this.driver = driver;
	}
	
	public void AddEvaluationPage(String excelFileName, String profileID) throws Exception{		
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtEvaluationName = xlsread.Exceldata(SheetName, "txtEvaluationName", profileID);
		String txtEvaluationType = xlsread.Exceldata(SheetName, "txtEvaluationType", profileID);
		String txtEvaluationRelatedTo = xlsread.Exceldata(SheetName, "txtEvaluationRelatedTo", profileID);
		String txtInsuredLow = xlsread.Exceldata(SheetName, "txtInsuredLow", profileID);
		String txtInsuredHigh = xlsread.Exceldata(SheetName, "txtInsuredHigh", profileID);
		String txtInsuredTarget = xlsread.Exceldata(SheetName, "txtInsuredTarget", profileID);
		String txtEconomicTypeText = xlsread.Exceldata(SheetName, "txtEconomicTypeText", profileID);
		String txtEconomicSubmitted = xlsread.Exceldata(SheetName, "txtEconomicSubmitted", profileID);
		String txtEconomicTargeted = xlsread.Exceldata(SheetName, "txtEconomicTargeted", profileID);
		String txtEconomicLow = xlsread.Exceldata(SheetName, "txtEconomicLow", profileID);
		String txtEconomicHigh = xlsread.Exceldata(SheetName, "txtEconomicHigh", profileID);
		String txtNonEconomicTypeText = xlsread.Exceldata(SheetName, "txtNonEconomicTypeText", profileID);
		String txtNonEconomicLow = xlsread.Exceldata(SheetName, "txtNonEconomicLow", profileID);
		String txtNonEconomicHigh = xlsread.Exceldata(SheetName, "txtNonEconomicHigh", profileID);		

		//go to Evaluation page
		UIMethods.clickbyxpath("//*[@id='Claim:ClaimMenuActions_arrow']/span", "Click ClaimMenuActions", "Click");
		Thread.sleep(1000);
		//UIMethods.clickbyxpath("//div[@id='menu_item_Claim:ClaimMenuActions:ClaimNewOtherMenuItemSet:ClaimMenuActions_NewOther_Claim:ClaimMenuActions:ClaimNewOtherMenuItemSet:ClaimMenuActions_NewOther:ClaimMenuActions_NewEvaluation']/a", "Click Evaluations sub menu", "Click");
		UIMethods.jscriptclickbyxpath("//div[@id='menu_item_Claim:ClaimMenuActions:ClaimNewOtherMenuItemSet:ClaimMenuActions_NewOther_Claim:ClaimMenuActions:ClaimNewOtherMenuItemSet:ClaimMenuActions_NewOther:ClaimMenuActions_NewEvaluation']/a", "Click Evaluations sub menu", "Click");
		Thread.sleep(4000);
		
		//New Evaluation
		UIMethods.inputbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:EvaluationType", "input evaluation name", txtEvaluationName);
		Thread.sleep(2000);
		UIMethods.inputbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:SettlementCostEstimate_Name", "input txtEvaluationType", txtEvaluationType);
		 
		if (txtEvaluationRelatedTo.equals("EXISTING")) {
			 txtEvaluationRelatedTo = CopyExposureData.exposuresdata;
	    }
		
		UIMethods.inputbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:Note_RelatedTo", "input EvaluationRelatedTo", txtEvaluationRelatedTo);
		Thread.sleep(1000);
		UIMethods.inputbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:LiabilityDistribution_InsuredLiability", "input txtInsuredLow", txtInsuredLow);
		Thread.sleep(2000);
		UIMethods.inputbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:LiabilityDistribution_InsuredLiabilityTo", "input txtInsuredHigh", txtInsuredHigh);
		Thread.sleep(2000);
		UIMethods.inputbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:LiabilityDistribution_InsuredLiabilityTarget", "input txtInsuredTarget", txtInsuredTarget);
		Thread.sleep(2000);
		
		//AddEconomicDamage
		UIMethods.jscriptclickbyxpath("//*[@id='NewEvaluation:NewEvaluationScreen:NewEvaluationDV:EconomicSpecialDamagesLV_tb:Add']", "click AddEconomicDamage", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath("//*[@id='NewEvaluation:NewEvaluationScreen:NewEvaluationDV:EconomicSpecialDamagesLV:0:_Checkbox']", "click checkbox", "Click");
		UIMethods.inputbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:EconomicSpecialDamagesLV:0:typetext", "input txtEconomicTypeText", txtEconomicTypeText);
		Thread.sleep(2000);
		UIMethods.inputbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:EconomicSpecialDamagesLV:0:low_ext", "input txtEconomicSubmitted", txtEconomicSubmitted);
		Thread.sleep(2000);
		UIMethods.inputbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:EconomicSpecialDamagesLV:0:target_ext", "input txtEconomicTargeted", txtEconomicTargeted);
		UIMethods.inputbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:EconomicSpecialDamagesLV:0:high_ext", "input txtEconomicLow", txtEconomicLow);
		Thread.sleep(2000);
		UIMethods.inputbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:EconomicSpecialDamagesLV:0:likely_ext", "input txtEconomicHigh", txtEconomicHigh);
		Thread.sleep(2000);
		
		//AddNonEconomicDamage
		Helper.highLightElement(driver, driver.findElement(By.xpath("//*[@id='NewEvaluation:NewEvaluationScreen:NewEvaluationDV:NonEcoGeneralDamagesLV_tb:Add']")));
		UIMethods.jscriptclickbyxpath("//*[@id='NewEvaluation:NewEvaluationScreen:NewEvaluationDV:NonEcoGeneralDamagesLV_tb:Add']", "click AddEconomicDamage", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath("//*[@id='NewEvaluation:NewEvaluationScreen:NewEvaluationDV:NonEcoGeneralDamagesLV:0:_Checkbox']", "click checkbox", "Click");
		Thread.sleep(2000);
		UIMethods.inputbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:NonEcoGeneralDamagesLV:0:typetext", "input txtNonEconomicTypeText", txtNonEconomicTypeText);
		UIMethods.inputbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:NonEcoGeneralDamagesLV:0:low_ext", "input txtNonEconomicLow", txtNonEconomicLow);
		Thread.sleep(1000);
		UIMethods.inputbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:NonEcoGeneralDamagesLV:0:high_ext", "input txtNonEconomicHigh", txtNonEconomicHigh);
		Thread.sleep(2000);
		
		//special service instruction apply - No
		UIMethods.jscriptclickbyxpath("//*[@id='NewEvaluation:NewEvaluationScreen:NewEvaluationDV:instructions_false']", "click instructions_false", "Click");
				
		//Update Button
		Helper.highLightElement(driver, driver.findElement(By.xpath("//*[@id='NewEvaluation:NewEvaluationScreen:NewEvaluationDV_tb:Update']")));
		UIMethods.jscriptclickbyxpath("//*[@id='NewEvaluation:NewEvaluationScreen:NewEvaluationDV_tb:Update']", "click Update button", "Click");
		Thread.sleep(5000);
	}

}
