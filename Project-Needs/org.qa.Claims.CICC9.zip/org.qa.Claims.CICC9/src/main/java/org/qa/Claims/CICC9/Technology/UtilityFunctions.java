/*
 * Copyright (C) 2017, Liberty Mutual Group
 *
 * Created on Apr 5, 2017
 */

package org.qa.Claims.CICC9.Technology;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.qa.Claims.CICC9.Technology.UIMethods;

import com.google.common.base.Predicate;

/**
 * @author n0241416
 *
 */
public class UtilityFunctions {

	public static void handlePopup(WebDriver driver) {
		try {
			Alert al = driver.switchTo().alert();
			al.accept();
		} catch (NoAlertPresentException e) {

		}
	}

	public static boolean isAlertPresent(WebDriver driver) {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException ex) {
			return false;
		}
	}

	/**
	 * @param driver
	 */
	public static void isAlertPresentandContinueNextScreen(WebDriver driver) {
		int popupCount = 3;
		// TODO Auto-generated method stub
		while (UtilityFunctions.isAlertPresent(driver)&& popupCount>0) {
			handlePopup(driver);
			driver.findElement(By.name("NEXTPAGE")).click();
			popupCount--;
		}
		

	}

	public static void waitUntilSelectOptionPupulated(final Select option, WebDriver driver) {
		new FluentWait<WebDriver>(driver).withTimeout(60, TimeUnit.SECONDS).pollingEvery(10, TimeUnit.MILLISECONDS)
				.until(new Predicate<WebDriver>() {
					public boolean apply(WebDriver d) {
						return (option.getOptions().size() > 1);
					}
				});
	}

	public static void SwitchTabandClose(WebDriver driver, String base) {
		java.util.Set<String> windows = driver.getWindowHandles();
		windows.remove(base);

		if (windows.size() > 0) {
			for (String handle : windows) {
				driver.switchTo().window(handle);
				System.out.println("switched to " + driver.getTitle() + "  Window");
				String pagetitle = driver.getTitle();
				driver.close();
				System.out.println("Closed the  '" + pagetitle + "' Tab now ...");
			}
			driver.switchTo().window(base);
		}
	}

}
