package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class EditInjuiry {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	public EditInjuiry(WebDriver driver)
	{
		this.driver = driver;
	}	
	
	public void InjuiryIncidentPage(String excelFileName, String profileID) throws Exception{

		String SheetName = "ClaimsPolicy";
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		
		String txtInjuryDescription = xlsread.Exceldata(SheetName, "txtInjuryDescription", profileID);
		
		//EditInjuiry Details
        UIMethods.inputbyid("EditInjuryIncidentPopup:EditInjuryIncidentScreen:InjuryIncidentDV:InjuryIncidentInputSet:InjuryDescription", "input InjuryDescription", txtInjuryDescription);
        Thread.sleep(1000);
        UIMethods.clickbyxpath("//*[@id='EditInjuryIncidentPopup:EditInjuryIncidentScreen:Update']", "Click Ok Button", "Click");
        Thread.sleep(3000);
        
	}
}