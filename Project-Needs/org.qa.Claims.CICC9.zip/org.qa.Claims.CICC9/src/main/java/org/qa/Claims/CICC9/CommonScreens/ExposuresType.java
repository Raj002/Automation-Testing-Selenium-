package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class ExposuresType {

	private WebDriver driver = null;
	WebDriverWait wait;

	// Page Objects
	String exposureLVCheckBox = "//*[@id='ClaimExposures:ClaimExposuresScreen:ExposuresLV:0:_Checkbox']";

	public ExposuresType(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 50);
	}

	public void Exposurespage() throws Exception {
		UIMethods.clickbyxpath("//*[@id='Claim:MenuLinks:Claim_ClaimExposuresGroup']/div", "click Claim Exposures Group","Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(exposureLVCheckBox)));
		UIMethods.clickbyxpath(exposureLVCheckBox, "click ExposuresLV:0:_Checkbox", "Click");
		Thread.sleep(2000);
		Helper.highLightElement(driver, driver.findElement(By.xpath("//*[@id='ClaimExposures:ClaimExposuresScreen:ExposuresLV:0:Type']")));
		UIMethods.clickbyxpath("//*[@id='ClaimExposures:ClaimExposuresScreen:ExposuresLV:0:Type']", "click Type Link","Click");
		Thread.sleep(2000);
	}
}