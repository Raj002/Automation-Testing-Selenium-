package org.qa.Claims.CICC9.Technology;

import org.apache.log4j.Logger;

public class CustomisedExceptions extends Exception {

	private static final long serialVersionUID = 1L;
	public static Logger LOG = Logger.getLogger(CustomisedExceptions.class);
	private String message;

	public CustomisedExceptions(String message) {
		this.message = message;
		/*printStackTrace();*/

	}

	public String getMessage() {
		LOG.error("********************************************************");
		LOG.error("Exception occured due to :- " + message);
		LOG.error("********************************************************");
		return message;
	}

	public void printStackTrace() {
		LOG.error("****************Error line details*************************");
		printStackTrace(System.err);
		LOG.error("********************************************************");

	}

}
