/*
 * Copyright (C) 2018, Liberty Mutual Group
 *
 * Created on Feb 12, 2018
 */

package org.qa.Claims.CICC9.Utilities;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.FetchPropertiesFiles;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Technology.UtilityFunctions;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;


/**
 * @author n0296668
 * To click Menu items and sub menu items
 * To click actions menu items
 */
public class Helper extends Object_Repositories {
	
	private static String operatingSystemType = System.getProperty("os.name");	
	private static String subMenu;
	
	/**
	 * To click Desktop sub menu's 
	 * @param driver - reference variable of WebDriver
	 * @param subMenuName - Provide valid Desktop sub menu name (as mentioned in UI)
	 *
	 */
	public static void clickDesktopSubMenu(WebDriver driver, String subMenuName) {
		wait = new WebDriverWait(driver, 15);
		subMenu = subMenuName.toLowerCase();
		switch (subMenu) {
		case "activities":
			UIMethods.jscriptclickbyxpath(desktopActivitiesSubMenu, "Click Desktop Activities Sub Menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Activities']")));
			break;
		case "claims":
			UIMethods.jscriptclickbyxpath(desktopClaimsSubMenu, "Click Desktop Claims Sub Menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Claims']")));
			break;
		case "exposures":
			UIMethods.jscriptclickbyxpath(desktopExposuresSubMenu, "Click Desktop Exposures Sub Menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Exposures']")));
			break;
		case "subrogations":
			UIMethods.jscriptclickbyxpath(desktopSubrogationsSubMenu, "Click Desktop Subrogations Sub Menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Subrogations']")));
			break;
		case "pending assignment":
			UIMethods.jscriptclickbyxpath(desktopPendingAssignmentsSubMenu, "Click Desktop Pending assignment Sub Menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Pending Assignment']")));
			break;
		case "queues":
			UIMethods.jscriptclickbyxpath(desktopQueuesSubMenu, "Click Desktop Queues Sub Menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Queued Activities']")));
			break;
		case "calendar":
			UIMethods.jscriptclickbyxpath(desktopCalendarSubMenu, "Click Desktop Calendar Sub Menu", "Click");
			break;
		case "my calendar":
			UIMethods.jscriptclickbyxpath(desktopMyCalendarTab, "Click Desktop My calendar tab", "Click");
			break;
		case "supervisor calendar":
			UIMethods.jscriptclickbyxpath(desktopSupervisorCalendarTab, "Click Desktop supervisor calendar tab", "Click");
			break;
		case "bulk invoices":
			UIMethods.jscriptclickbyxpath(desktopBulkInvoicesSubMenu, "Click Desktop Bulk invoices Sub Menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='BulkPay:BulkPayScreen:ttlBar']")));
			break;
		case "bulk recoveries":
			UIMethods.jscriptclickbyxpath(desktopBulkRecoveriesSubMenu, "Click Desktop Bulk recoveries Sub Menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='BulkRecoveries:BulkRecoveryScreen:ttlBar']")));
			break;
		case "medical bills":
			UIMethods.jscriptclickbyxpath(desktopMedicalBillsSubMenu, "Click Desktop Medical Bills Sub Menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Medical Bills - Pending']")));
			break;
		case "regions":
			UIMethods.jscriptclickbyxpath(desktopRegionsSubMenu, "Click Desktop Regions Sub Menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimSUPRegionsPage:RegionsScreen:0']")));
			break;
		default:
			Assert.fail("Please provide valid desktop sub menu items...");
			break;
		}
	}
	
	/**
	 * To click claims sub menu's 
	 * @param driver - reference variable of WebDriver
	 * @param subMenuName - Provide valid claims sub menu name (as mentioned in UI)
	 *
	 */
	public static void clickClaimSubMenu(WebDriver driver, String subMenuName) {
		wait = new WebDriverWait(driver, 15);
		subMenu = subMenuName.toLowerCase();
		
		switch (subMenu) {
		case "summary":
			UIMethods.jscriptclickbyxpath(claimsSummarySubMenu, "Click Cliams Summary tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimSummary:ClaimSummaryScreen:ttlBar' and text()='Summary']")));
			break;		
		case "overview":
			UIMethods.jscriptclickbyxpath(claimsSummaryOverviewTab, "Click Cliams Summary Overview tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimSummary:ClaimSummaryScreen:ttlBar' and text()='Summary']")));
			break;
		case "status":
			UIMethods.jscriptclickbyxpath(claimsSummaryStatusTab, "Click Cliams Summary Overview status tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimStatus:ttlBar' and text()='Claim Status']")));
			break;
		case "health metrics":
			UIMethods.jscriptclickbyxpath(claimsSummaryHealthMetricsTab, "Click Cliams Summary Overview health metrics tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Claim Health Metrics']")));
			break;
		case "workplan":
			UIMethods.jscriptclickbyxpath(claimsWorkPlanSubMenu, "Click Cliams Workplan Sub Menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimWorkplan:ClaimWorkplanScreen:0' and text()='Workplan']")));
			break;
		case "loss details":
			UIMethods.jscriptclickbyxpath(claimsLossDetailsSubMenu, "Click Cliams Loss details Sub Menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimLossDetails:ClaimLossDetailsScreen:ttlBar']")));
			break;
		case "general":
			UIMethods.jscriptclickbyxpath(claimsLossDetailsGeneralTab, "Click Cliams Loss details general tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimLossDetails:ClaimLossDetailsScreen:ttlBar']")));
			break;
		case "associations":
			UIMethods.jscriptclickbyxpath(claimsLossDetailsAssociationsTab, "Click Cliams Loss details associations tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimAssociations:ClaimAssociationsScreen:ttlBar' and text()='Associations']")));
			break;
		case "special investigation":
			UIMethods.jscriptclickbyxpath(claimsLossDetailsSpecialInvestigationTab, "Click Cliams Loss details special investigation tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='SIDetails:SIDetailsScreen:ttlBar']")));
			break;
		case "exposures":
			UIMethods.jscriptclickbyxpath(claimsExposuresSubMenu, "Click Cliams Exposure sub menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimExposures:ClaimExposuresScreen:ttlBar' and text()='Exposures']")));
			break;
		case "reinsurance":
			UIMethods.jscriptclickbyxpath(claimsReinsuranceSubMenu, "Click Cliams Reinsurance sub menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Reinsurance Financials Summary']")));
			break;
		case "partis involved":
			UIMethods.jscriptclickbyxpath(claimsPartiesInvolvedSubMenu, "Click Cliams Parties involved sub menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimContacts:ClaimContactsScreen:ttlBar']")));
			break;
		case "contacts":
			UIMethods.jscriptclickbyxpath(claimsPartiesInvolvedContactsTab, "Click Cliams Parties involved contacts tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimContacts:ClaimContactsScreen:ttlBar']")));
			break;
		case "users":
			UIMethods.jscriptclickbyxpath(claimsPartiesInvolvedUsersTab, "Click Cliams Parties involved users tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimUsers:ClaimUsersScreen:ttlBar']")));
			break;
		case "policy":
			UIMethods.jscriptclickbyxpath(claimsPolicySubMenu, "Click Cliams Policy Sub menu", "Click");
			break;
		case "policy general":
			UIMethods.jscriptclickbyxpath(claimsPolicyGeneralTab, "Click Cliams Policy general tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Policy: General']")));
			break;
		case "policy vehicles":
			UIMethods.jscriptclickbyxpath(claimsPolicyVehiclesTab, "Click Cliams Policy vehicles tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Policy: Vehicles']")));
			break;
		case "policy endorsements":
			UIMethods.jscriptclickbyxpath(claimsPolicyEndrosementsTab, "Click Cliams Policy endrosements tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Policy: Endorsements']")));
			break;
		case "policy aggregate limits":
			UIMethods.jscriptclickbyxpath(claimsPolicyAggregateLimitsTab, "Click Cliams Policy aggregate limits tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimPolicyAggregateLimits:ClaimPolicyAggregateLimitsScreen:ttlBar']")));
			break;
		case "policy documents":
			UIMethods.jscriptclickbyxpath(claimsPolicyDocumentsTab, "Click Cliams Policy documents tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Policy Documents Page']")));
			break;
		case "financials":
			UIMethods.jscriptclickbyxpath(claimsFinancialsSubMenu, "Click Cliams Financials Sub menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimFinancialsSummary:ClaimFinancialsSummaryScreen:ttlBar']")));
			break;
		case "financials summary":
			UIMethods.jscriptclickbyxpath(claimsFinancialsSummaryTab, "Click Cliams Financials Summary tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimFinancialsSummary:ClaimFinancialsSummaryScreen:ttlBar']")));
			break;
		case "financials transactions":
			UIMethods.jscriptclickbyxpath(claimsFinancialsTransactionTab, "Click Cliams Financials transactions tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:ttlBar']")));
			break;
		case "financials checks":
			UIMethods.jscriptclickbyxpath(claimsFinancialsChecksTab, "Click Cliams Financials checks tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ttlBar']")));
			break;
		case "financial reserve log":
			UIMethods.jscriptclickbyxpath(claimsFinancialsReserveLogTab, "Click Claims Financial reserve Log Tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimFinancialReserves:ClaimFinancialsChecksScreen:ttlBar']")));
			break;
		case "notes":
			UIMethods.jscriptclickbyxpath(claimsNotesSubMenu, "Click Cliams Notes Sub Menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimNotes:NotesSearchScreen:ttlBar']")));
			break;
		case "documents":
			UIMethods.jscriptclickbyxpath(claimsDocumentsSubMenu, "Click Cliams documents Sub Menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimDocuments:Claim_DocumentsScreen:ttlBar']")));
			break;
		case "plan of actions":
			UIMethods.jscriptclickbyxpath(claimsPlanOfActionSubMenu, "Click Cliams Plan of Actions Sub Menu", "Click");
			break;
		case "evaluations":
			UIMethods.jscriptclickbyxpath(claimsPlanOfActionEvaluationsTab, "Click Cliams Plan of actions evaluation tab", "Click");
			break;
		case "negotiations":
			UIMethods.jscriptclickbyxpath(claimsPlanOfActionNegotiationsTab, "Click Cliams plan of actions negotations tab", "Click");
			break;
		case "services":
			UIMethods.jscriptclickbyxpath(claimsServicesSubMenu, "Click Cliams Service Sub Menu", "Click");
			break;
		case "litigation":
			UIMethods.jscriptclickbyxpath(claimsLitigationSubMenu, "Click Cliams Litigation Sub Menu", "Click");
			break;
		case "history":
			UIMethods.jscriptclickbyxpath(claimsHistorySubMenu, "Click Cliams History Sub Menu", "Click");
			break;
		case "fnol snapshot":
			UIMethods.jscriptclickbyxpath(claimsFNOLSnapshotSubMenu, "Click Cliams FNOL Snapshot Sub Menu", "Click");
			break;
		case "fnol loss details":
			UIMethods.jscriptclickbyxpath(claimsFNOLLossDetailsTab, "Click Cliams FNOL Loss Details tab", "Click");
			break;
		case "fnol parties involved":
			UIMethods.jscriptclickbyxpath(claimsFNOLPartiesInvolvedTab, "Click Cliams FNOL Parties Involved tab", "Click");
			break;
		case "fnol policy":
			UIMethods.jscriptclickbyxpath(claimsFNOLPolicyTab, "Click Cliams FNOL Policy tab", "Click");
			break;
		case "fnol exposures":
			UIMethods.jscriptclickbyxpath(claimsFNOLExposureTab, "Click Cliams FNOL Exposures tab", "Click");
			break;
		case "fnol notes":
			UIMethods.jscriptclickbyxpath(claimsFNOLNotesTab, "Click Cliams FNOL Notes tab", "Click");
			break;
		case "fnol documents":
			UIMethods.jscriptclickbyxpath(claimsFNOLDocumentsTab, "Click Cliams FNOL Documents tab", "Click");
			break;
		case "fnol additional fields":
			UIMethods.jscriptclickbyxpath(claimsFNOLAdditionalFieldsTab, "Click Cliams FNOL Additional fields tab", "Click");
			break;
		case "calendar":
			UIMethods.jscriptclickbyxpath(claimsCalendarSubMenu, "Click Cliams Calendar Sub Menu", "Click");
			break;
		case "my calendar":
			UIMethods.jscriptclickbyxpath(claimsCalendarMyCalendarTab, "Click Cliams Calendar my calendar tab", "Click");
			break;
		case "supervisor calendar":
			UIMethods.jscriptclickbyxpath(claimsCalendarSupervisorCalendarTab, "Click Cliams Calendar Supervisor calendar tab", "Click");
			break;
		default:
			Assert.fail("Please provide valid Claim sub menu items...");
			break;
		}		
	}
	
	public static void clickSearchSubMenu(WebDriver driver, String subMenuName) {
		wait = new WebDriverWait(driver, 15);
		subMenu = subMenuName.toLowerCase();
		switch (subMenu) {
		case "claims":
			UIMethods.jscriptclickbyxpath(searchClaimsMenu, "Click Search claims sub menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Search Claims']")));
			break;
		case "simple search":
			UIMethods.jscriptclickbyxpath(searchClaimsSimpleSearchTab, "Click Search simple search tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchDV:ClaimNumber-inputEl")));
			break;
		case "advanced search":
			UIMethods.jscriptclickbyxpath(searchClaimsAdvancedSearchTab, "Click Search advanced search tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ClaimSearch:ClaimSearchScreen:ClaimSearchDV:ClaimSearchRequiredInputSet:ClaimNumber-inputEl")));
			break;
		case "account search":
			UIMethods.jscriptclickbyxpath(searchClaimsAccountSearchTab, "Click Search Account search tab", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("AccountSearch:AccountClaimSearchScreen:AccountClaimSearchDV:Account-inputEl")));
			break;
		case "activities":
			UIMethods.jscriptclickbyxpath(searchActivitiesSubMenu, "Click Search Activities sub menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Search Activities']")));
			break;
		case "checks":
			UIMethods.jscriptclickbyxpath(searchChecksSubMenu, "Click Search checks sub menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Search Checks']")));
			break;
		case "recoveries":
			UIMethods.jscriptclickbyxpath(searchRecoveriesSubMenu, "Click Search recoveries sub menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Search Recoveries']")));
			break;
		case "bulk invoices":
			UIMethods.jscriptclickbyxpath(searchBulkInvoicesSubMenu, "Click Search bulk invoices sub menu", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Search Bulk Invoices']")));
			break;
		default:
			Assert.fail("Please provide valid Search sub menu items...");
			break;
		}
	}
	
	/**
	 * To click Main Menu items
	 * @param driver - pass your WebDriver reference variable
	 * @param menuName - Provide valid menu name (as mentioned in UI)
	 */
	public static void clickMainMenu(WebDriver driver, String menuName) {
		String mainMenuName = menuName.toLowerCase();
		switch (mainMenuName) {
		case "desktop":
			UIMethods.jscriptclickbyxpath(desktopMenu, "Click Desktop Menu", "Click");			
			break;
		case "claim":
			UIMethods.jscriptclickbyxpath(claimMenu, "Click Claims Menu", "Click");
			break;
		case "search":
			UIMethods.jscriptclickbyxpath(searchMenu, "Click Search Menu", "Click");
			break;
		case "address book":
			UIMethods.jscriptclickbyxpath(addressBookMenu, "Click Address Book Menu", "Click");
			break;
		case "dashboard":
			UIMethods.jscriptclickbyxpath(dashboardmenu, "Click Dashboard Menu", "Click");
			break;
		case "team":
			UIMethods.jscriptclickbyxpath(teamMenu, "Click Team Menu", "Click");
			break;
		case "administration":
			UIMethods.jscriptclickbyxpath(administrationMenu, "Click Administration Menu", "Click");
			break;
		default:
			Assert.fail("Please provide valid Main menu items...");
			break;
		}
	}
	
	/**
	 * This method will click on the given actions menu item
	 * @param driver - pass your WebDrver reference variable
	 * @param itemName - Provide valid actions menu items (as mentioned in UI)
	 * @throws InterruptedException 
	 */
	public static void clickActionsMenu(WebDriver driver, String itemName) throws InterruptedException {
		String menuItem = itemName.toLowerCase();
		wait = new WebDriverWait(driver, 15);
		if(driver.findElements(By.xpath(actionsMenu)).size()!=0) {
			UIMethods.clickbyxpath(actionsMenu, "Click Actions menu", "Click");
		}			
		
		switch (menuItem) {
		case "note":
			highLightElement(driver, driver.findElement(By.xpath(actionsNoteItem)));
			UIMethods.jscriptclickbyxpath(actionsNoteItem, "Click Note action item", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='wsTabBar:wsTab_0-btnInnerEl']")));
			break;
		case "email":
			highLightElement(driver, driver.findElement(By.xpath(actionsEmailItem)));
			UIMethods.jscriptclickbyxpath(actionsEmailItem, "Click Email action item", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("wsTabBar:wsTab_0-btnInnerEl")));
			break;
		case "matter":
			highLightElement(driver, driver.findElement(By.xpath(actionsMatterItem)));
			UIMethods.jscriptclickbyxpath(actionsMatterItem, "Click Matter action item", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewMatter:NewMatterScreen:ttlBar")));
			break;	
		case "evaluation":
			highLightElement(driver, driver.findElement(By.xpath(actionsEvaluationItem)));
			UIMethods.jscriptclickbyxpath(actionsEvaluationItem, "Click Evaluation action item", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewEvaluation:NewEvaluationScreen:ttlBar")));
			break;
		case "negotiation":
			highLightElement(driver, driver.findElement(By.xpath(actionsNegotiationItem)));
			UIMethods.jscriptclickbyxpath(actionsNegotiationItem, "Click Negotiation action item", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewNegotiation:NewNegotiationScreen:ttlBar")));
			break;
		case "service":
			highLightElement(driver, driver.findElement(By.xpath(actionsServiceItem)));
			UIMethods.jscriptclickbyxpath(actionsServiceItem, "Click Service action item", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewServiceRequest:ttlBar")));
			break;
		case "reserve":
			highLightElement(driver, driver.findElement(By.xpath(actionsReserveItem)));
			UIMethods.jscriptclickbyxpath(actionsReserveItem, "Click Reserve action item", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewReserveSet:NewReserveSetScreen:ttlBar")));
			break;
		case "check":
			highLightElement(driver, driver.findElement(By.xpath(actionsCheckItem)));
			UIMethods.jscriptclickbyxpath(actionsCheckItem, "Click Check action item", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NormalCreateCheckWizard:CheckWizard_CheckPayeesScreen:ttlBar")));
			break;
		case "manual check":
			highLightElement(driver, driver.findElement(By.xpath(actionsManualCheckItem)));
			UIMethods.jscriptclickbyxpath(actionsManualCheckItem, "Click Manual Check action item", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("")));
			break;
		case "recovery":
			highLightElement(driver, driver.findElement(By.xpath(actionsRecoveryItem)));
			UIMethods.jscriptclickbyxpath(actionsRecoveryItem, "Click Recovery action item", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewRecoverySet:NewRecoveryScreen:ttlBar")));
			break;
		case "correspondence":
			UIMethods.jscriptclickbyxpath(actionsCorrespondenceItem, "Click Correspondence action item", "Click");
			driver.findElement(By.xpath(actionsCorrespondenceItem)).sendKeys(Keys.ARROW_RIGHT);
			break;
		case "file review":
			UIMethods.jscriptclickbyxpath(actionsFileReviewItem, "Click File Review action item", "Click");
			driver.findElement(By.xpath(actionsFileReviewItem)).sendKeys(Keys.ARROW_RIGHT);
			break;
		case "general":
			UIMethods.jscriptclickbyxpath(actionsGeneralItem, "Click General action item", "Click");
			driver.findElement(By.xpath(actionsGeneralItem)).sendKeys(Keys.ARROW_RIGHT);
			break;
		case "interview":
			UIMethods.jscriptclickbyxpath(actionsInterviewItem, "Click Interview action item", "Click");
			driver.findElement(By.xpath(actionsInterviewItem)).sendKeys(Keys.ARROW_RIGHT);
			break;
		case "investigation":
			UIMethods.jscriptclickbyxpath(actionsInvestigationItem, "Click Investigation action item", "Click");
			driver.findElement(By.xpath(actionsInvestigationItem)).sendKeys(Keys.ARROW_RIGHT);
			break;
		case "medicare":
			UIMethods.jscriptclickbyxpath(actionsMedicareItem, "Click Medicare/Medicaid action item", "Click");
			driver.findElement(By.xpath(actionsMedicareItem)).sendKeys(Keys.ARROW_RIGHT);
			break;
		case "new mail":
			UIMethods.jscriptclickbyxpath(actionsNewMailItem, "Click New Mail action item", "Click");
			driver.findElement(By.xpath(actionsNewMailItem)).sendKeys(Keys.ARROW_RIGHT);
			break;
		case "reminder":
			UIMethods.jscriptclickbyxpath(actionsReminderItem, "Click Reminder action item", "Click");
			driver.findElement(By.xpath(actionsReminderItem)).sendKeys(Keys.ARROW_RIGHT);
			break;
		case "request":
			UIMethods.jscriptclickbyxpath(actionsRequestItem, "Click Request action item", "Click");
			driver.findElement(By.xpath(actionsRequestItem)).sendKeys(Keys.ARROW_RIGHT);
			break;
		case "warning":
			UIMethods.jscriptclickbyxpath(actionsWarningItem, "Click Warning action item", "Click");
			driver.findElement(By.xpath(actionsWarningItem)).sendKeys(Keys.ARROW_RIGHT);
			break;
		case "choose by policy coverage":
			UIMethods.jscriptclickbyxpath(actionsChooseByPolicyCoverageItem, "Click Choose by policy coverage action item", "Click");
			driver.findElement(By.xpath(actionsChooseByPolicyCoverageItem)).sendKeys(Keys.ARROW_RIGHT);
			break;
		case "choose by coverage type":
			UIMethods.jscriptclickbyxpath(actionsChooseByCoverageTypeItem, "Click Choose by coverage type action item", "Click");
			driver.findElement(By.xpath(actionsChooseByCoverageTypeItem)).sendKeys(Keys.ARROW_RIGHT);
			break;
		case "assign claim":
			highLightElement(driver, driver.findElement(By.xpath(actionsAssignClaimItem)));
			UIMethods.jscriptclickbyxpath(actionsAssignClaimItem, "Click Assign claim action item", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("AssignClaimsPopup:AssignmentPopupScreen:ttlBar")));
			break;
		case "close claim":
			highLightElement(driver, driver.findElement(By.xpath(actionsCloseClaimItem)));
			UIMethods.jscriptclickbyxpath(actionsCloseClaimItem, "Click Close claim action item", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("CloseClaimPopup:CloseClaimScreen:ttlBar")));
			break;
		case "print claim":
			highLightElement(driver, driver.findElement(By.xpath(actionsPrintClaimItem)));
			UIMethods.jscriptclickbyxpath(actionsPrintClaimItem, "Click Print claim action item", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ClaimPrintout:ClaimPrintoutScreen:ttlBar")));
			break;
		case "sync status":
			highLightElement(driver, driver.findElement(By.xpath(actionsSyncStatusItem)));
			UIMethods.jscriptclickbyxpath(actionsSyncStatusItem, "Click Sync Status action item", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ClaimSyncStatusPopup:ClaimSyncStatusScreen:ttlBar")));
			break;
		case "validate claim only":
			UIMethods.jscriptclickbyxpath(actionsValidateClaimOnlyItem, "Click Validate claim only action item", "Click");
			driver.findElement(By.xpath(actionsValidateClaimOnlyItem)).sendKeys(Keys.ARROW_RIGHT);
			break;
		case "validate claim exposure":
			UIMethods.jscriptclickbyxpath(actionsValidateClaimExposureItem, "Click Validate Claim Exposure action item", "Click");
			driver.findElement(By.xpath(actionsValidateClaimExposureItem)).sendKeys(Keys.ARROW_RIGHT);
			break;
		case "validate policy":
			UIMethods.jscriptclickbyxpath(actionsValidatePolicyItem, "Click Validate Policy action item", "Click");
			driver.findElement(By.xpath(actionsValidatePolicyItem)).sendKeys(Keys.ARROW_RIGHT);
			break;
		default:
			Assert.fail("Please provide valid Action menu items...");
			break;
		}
	}
		
	/**
	 * 
	 * @param driver - pass your WebDrver reference variable
	 * @param actionsSubMenuItemName - Provide the exact name which is mentioned in the UI (egg: B, Building, Building - Property)
	 * @throws InterruptedException 
	 */
	public static void xpathToClickActionsSubMenu(WebDriver driver, String actionsSubMenuItemName) throws InterruptedException {
		try {			
			String subMenuObject = "//div[contains(@id,'NewExposureMenuItemSet_ByCoverageType')]/a/span[text()=\""+ actionsSubMenuItemName +"\"]";			
			
			if(driver.findElements(By.xpath(subMenuObject)).size()!=0) {
				
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(subMenuObject)));
				List<WebElement> elements = driver.findElements(By.xpath(subMenuObject));
				if(elements.size()>=2) {
					UIMethods.clickbyWebElement(elements.get(1), "Click actions Sub Menu items - "+ actionsSubMenuItemName, "Click");
					//UIMethods.jscriptclickbyxpath(subMenuObject, "Click actions Sub Menu items - "+ actionsSubMenuItemName, "Click");
				} else {
					UIMethods.jscriptclickbyxpath(subMenuObject, "Click actions Sub Menu items - "+ actionsSubMenuItemName, "Click");
				}
				Thread.sleep(500);
				if(driver.findElements(By.xpath(subMenuObject+"/following-sibling::div")).size()!=0) {
					driver.findElement(By.xpath(subMenuObject)).sendKeys(Keys.ARROW_RIGHT);
					Thread.sleep(500);
				}				
			} else {
				Assert.fail("Given Actions sub menu isn't available, Please check it.." + actionsSubMenuItemName);
			}			
		} catch(ElementNotFoundException | ElementNotVisibleException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @param driver - pass your WebDrver reference variable
	 * @param actionsSubMenuItemName - Provide the exact name which is mentioned in the UI (egg: B, Building, Building - Property)
	 * Sometimes coverage type and coverage sub types are same in that case we have to use this function
	 * @throws InterruptedException 
	 */
	public static void xpathToClickActionsSubMenuSame(WebDriver driver, String actionsSubMenuItemName) throws InterruptedException {
		try {			
			String subMenuObject = "(//div[contains(@id,'NewExposureMenuItemSet_ByCoverageType')]/a/span[text()=\""+ actionsSubMenuItemName +"\"])[2]";
			
			List<WebElement> elements = driver.findElements(By.xpath(subMenuObject));
			if(elements.size()>=2) {
				elements.get(1).click();
			}
			
			if(driver.findElements(By.xpath(subMenuObject)).size()!=0) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(subMenuObject)));
				UIMethods.jscriptclickbyxpath(subMenuObject, "Click actions Sub Menu items - "+ actionsSubMenuItemName, "Click");	
				if(driver.findElements(By.xpath(subMenuObject+"/following-sibling::div")).size()!=0) {
					driver.findElement(By.xpath(subMenuObject)).sendKeys(Keys.ARROW_RIGHT);
					Thread.sleep(500);
				}				
			} else {
				Assert.fail("Given Actions sub menu isn't available, Please check it.." + actionsSubMenuItemName);
			}			
		} catch(ElementNotFoundException | ElementNotVisibleException e) {
			e.printStackTrace();
		}
	}
	
	public static void clickTableColumnRow(String columnNumber,String position,String objectName, String description,String testData) throws InterruptedException {
		
		UIMethods.jscriptclickbyxpath("(//div[contains(@id,'gridview-')]/div/table[1]/tbody/tr/td["+columnNumber+"])["+position+"]", description, "Click");
		Thread.sleep(500);
		UIMethods.clearAndinputbyxpath("//input[@name='"+objectName+"']", description, testData);
	}
	
	public static void clickCheckBox(String object, String description) throws Exception {
		UIMethods.jscriptclickbyxpath(object, description, "Click");
		Thread.sleep(500);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_SPACE);
		robot.keyRelease(KeyEvent.VK_SPACE);		
	}	
	
	public static String getDropdownXpath(String fieldName) {		
		String actualXpath = "//input[contains(@id,'simplecombo') and @name='"+ fieldName +"']";
		return actualXpath;
	}
	
	/**
	 * This method will enter date on the respective fields based on the Operating System version
	 * @param driver - pass your WebDrver reference variable
	 * @param object - Date field object (id)
	 * @param description - Provide field name that you are going to enter value
	 * @param testData - pass the test data
	 */
	public static void enterDate(WebDriver driver, String object, String description,String testData) throws InterruptedException {
		
		// Based on the execution mode this method will enter loss date
		if (FetchPropertiesFiles.executionMode.equalsIgnoreCase("Sauce Lab")) {
			// To clear text box field
			((JavascriptExecutor) driver).executeScript("arguments[0].value ='';",driver.findElement(By.id(object)));
			Thread.sleep(1000);
			UIMethods.inputbyid(object, description, testData);
		} else {
			// Comparing Operating System Environment
			if (operatingSystemType.equalsIgnoreCase("Windows 10")) {
				// To clear text box field
				((JavascriptExecutor) driver).executeScript("arguments[0].value ='';",driver.findElement(By.id(object)));
				Thread.sleep(1000);
				UIMethods.inputbyid(object, description, testData);
			} else {
				WebElement element = driver.findElement(By.id(object));
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
				Thread.sleep(1000);
				testData = testData.replace("/", "");
				element.sendKeys(Keys.HOME, Keys.chord(Keys.SHIFT, Keys.END), testData);
				
				String[] actual = description.split(" ", 2);				
				Report.pass("Enter loss date", testData, description, actual[1] + " is Entered");
				Thread.sleep(1000);
			}
		}
	}
	
	/**
	 * This method will enter time on the respective fields based on the Operating System version
	 * @param driver - pass your WebDrver reference variable
	 * @param object - Date field object (id)
	 * @param description - Provide field name that you are going to enter value
	 * @param testData - pass the test data
	 */
	public static void enterTime(WebDriver driver, String object, String description, String testData)
			throws InterruptedException {
		
		if (FetchPropertiesFiles.executionMode.equalsIgnoreCase("Sauce Lab")) {
			// To clear text box field
			((JavascriptExecutor) driver).executeScript("arguments[0].value ='';", driver.findElement(By.id(object)));
			Thread.sleep(1000);
			UIMethods.inputbyid(object, description, testData);
		} else {
			if (operatingSystemType.equalsIgnoreCase("Windows 10")) {
				// To clear text box field
				((JavascriptExecutor) driver).executeScript("arguments[0].value ='';", driver.findElement(By.id(object)));
				Thread.sleep(1000);
				UIMethods.inputbyid(object, description, testData);
			} else {
				WebElement element = driver.findElement(By.id(object));
				//((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
				UIMethods.clickbyid(object, description, testData);
				Thread.sleep(1000);
				testData = testData.replace(":", "").replace(" ", "");
				element.sendKeys(Keys.HOME, Keys.chord(Keys.SHIFT, Keys.END), testData);

				String[] actual = description.split(" ", 2);
				Report.pass("Enter loss date", testData, description, actual[1] + " is Entered");
				Thread.sleep(1000);
			}
		}
	}
	
	/**
	 *	This method will clear and enter the value based on the given test data for the drop down field 
	 * @param driver - pass your WebDrver reference variable
	 * @param object - Object of drop down field (can be id, xpath or cssSelector)
	 * @param description - Provide field name that you are going to enter value
	 * @param testData - pass the test data
	 * @throws InterruptedException 
	 */
	public static void selectDropdownValue(WebDriver driver, String locatorType, String object, String description, String testData) throws InterruptedException {
		wait = new WebDriverWait(driver, 25);
		String locator = locatorType.toLowerCase();
		switch (locator) {
		case "id":
			wait.until(ExpectedConditions.elementToBeClickable(By.id(object)));
			UIMethods.clearAndInputbyid(object, description, testData);
			driver.findElement(By.id(object)).click();
			Thread.sleep(1000);
			break;
		case "xpath":
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(object)));
			UIMethods.clearAndinputbyxpath(object, description, testData);
			driver.findElement(By.xpath(object)).click();
			Thread.sleep(1000);
			break;
		case "cssselector":
			wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(object)));
			UIMethods.clearAndinputbyCssSelector(object, description, testData);
			driver.findElement(By.cssSelector(object)).click();
			Thread.sleep(1000);
			break;
		default:
			Assert.fail("Please provide valid locator type...");
			break;
		}
	}
		
	public static WebElement getUIXpath(WebDriver driver,String fieldName) {
		WebElement xpathUIField = null;
		try {
			xpathUIField = driver.findElement(By.xpath("//span[text()='"+ fieldName +"']"));
		} catch(ElementNotFoundException e) {
			e.printStackTrace();
		}		
		return xpathUIField;
	}
	
	/**
	 * This method will help you to take the screenshots only the visible screen
	 * @param driver - pass your WebDrver reference variable
	 * @param screenshotName - Name of the screenshot
	 */
	public static String getScreenshot(WebDriver driver, String screenShotPath, String screenshotName) throws IOException{
		String dateName = new SimpleDateFormat("MM_dd_yyyy_hhmmss").format(new Date());
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		
		String destination = System.getProperty("user.dir") + "/CICC9_Screenshots/" +screenShotPath+ "/" + screenshotName + dateName
				+ ".png";
		File finalDestination = new File(destination);
		FileUtils.copyFile(source, finalDestination);
		return destination;
	}
	
	/**
	 * This method will help you to take the screenshots on the entire page
	 * @param driver - pass your WebDrver reference variable
	 * @param screenshotName - Name of the screenshot
	 */
	public static void getFullPageScreenShot(WebDriver driver, String screenshotName) throws IOException {
		String dateName = new SimpleDateFormat("MM_dd_yyyy_hhmmss").format(new Date());
		Screenshot screenshot = new AShot().takeScreenshot(driver);
		//Screenshot screenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
		//Screenshot screenshot = new AShot().shootingStrategy(new ViewportPastingStrategy(1000)).takeScreenshot(driver);
		String destination = System.getProperty("user.dir") + "/CICC9_Screenshots/" + screenshotName + dateName + ".png";
		ImageIO.write(screenshot.getImage(), "PNG", new File(destination));
	}
	
	/**
	 * This method will help you to get the entered text box value
	 * @param driver - pass your WebDrver reference variable
	 * @param object - Object of drop down field (can be id, xpath or cssSelector)
	 * @param locatorType - provide valid locator type such as (xpath, id, cssselector)
	 */
	public static String getAttributeValue(WebDriver driver, String locatorType, String object) {
		String actualValue = null;
		
		switch (locatorType.toLowerCase()) {
		case "id":
			actualValue = driver.findElement(By.id(object)).getAttribute("value");
			break;
		case "xpath":
			actualValue = driver.findElement(By.xpath(object)).getAttribute("value");
			break;
		case "cssselector":
			actualValue = driver.findElement(By.cssSelector(object)).getAttribute("value");
			break;
		default:
			Assert.fail("Please provide valid locatory type/Object");
			break;
		}		
		
		return actualValue;
	}
	
	/**
	 * This method clears the text box using JavaScriptExecutor class
	 */
	public static void clearTextBox(WebDriver driver, WebElement element) throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].value ='';", element);
		Thread.sleep(1000);
	}

	/**
	 * Checks if the alert is in the DOM, regardless of being displayed or not
	 */
	public static boolean isAlertPresent(WebDriver driver) {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException Ex) {
			return false;
		}
	}
	
	public void checkPageIsReady(WebDriver driver) {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		if (js.executeScript("return document.readyState").toString().equals("complete")) {
			System.out.println("Page Is loaded.");
			return;
		}

		for (int i = 0; i < 25; i++) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
			}
			// To check page ready state.
			if (js.executeScript("return document.readyState").toString().equals("complete")) {
				break;
			}
		}
	}
	
	public static void waitForLoad(WebDriver driver) {
        ExpectedCondition<Boolean> pageLoadCondition = new
                ExpectedCondition<Boolean>() {
                    public Boolean apply(WebDriver driver) {
                        return ((JavascriptExecutor)driver).executeScript("return document.readyState").equals("complete");
                    }
                };
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(pageLoadCondition);
    }
	
	/**
	 * This method can be used to highlight the given element
	 * @param driver - pass your WebDrver reference variable
	 * @param element - The element which you are going to highlight
	 * @throws InterruptedException 
	 *
	 */
	public static void highLightElement(WebDriver driver,WebElement element) throws InterruptedException
	{
		for (int i = 0; i < 2; i++) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element,
					"color: yellow; border: 2px solid yellow;");
			Thread.sleep(1000);
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "");
		}
	}
	
	public static void validateAndAcceptAlert(WebDriver driver) throws InterruptedException {
		Thread.sleep(3000);
		// Handle OK button in Pop-up
		if (UtilityFunctions.isAlertPresent(driver) == true) {
			try {
				Alert alert = driver.switchTo().alert();
				System.out.println("Found and clicked Alert window with text message as " + alert.getText());
				alert.accept();
				Thread.sleep(3000);
			} catch (Exception Ex) {
				Ex.printStackTrace();
			}
		} else {
			System.out.println("No Alert present");
		}
	}

	/**
	 * This will generate date time stamp based on the given count
	 * 
	 * @param count
	 *            - 0 means today, 1 means tomorrow, -1 means yesterday in similar
	 *            way we will give the count
	 */
	public static String getDateTime(int count) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, count);
		Date date = calendar.getTime();
		Format formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a");
		String tomorrowDate = formatter.format(date);
		return tomorrowDate;
	}

	public static String getDate(int count) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, count);
		Date date = calendar.getTime();
		Format formatter = new SimpleDateFormat("MM/dd/yyyy");
		String actualDate = formatter.format(date);
		return actualDate;
		
	}

	/**
	 * Generate random int numbers from the given limit
	 * @param min - lower bound value
	 * @param max - upper bound value 
	 */
	public static int generateRandomNum(int min, int max) {
		Random random = new Random();
		return random.nextInt((max - min) + 1) + min;
	}
	
	/**
	 * This will generate date time stamp based on the given count
	 * 
	 * @param count
	 *            - 0 means today, 1 means tomorrow, -1 means yesterday in similar
	 *            way we will give the count
	 */
	public static String getDateTimeStamp(int count) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, count);
		Date date = calendar.getTime();
		Format formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
		String tomorrowDate = formatter.format(date);
		return tomorrowDate;
	}

	public static void validateErrorMessage(WebDriver driver) throws ParseException {
		// Added by RAJ
		if(driver.findElements(By.xpath("//span[@id='FNOLWizard:FNOLWizard_FindPolicyScreen:_msgs_msgs']/div")).size()!=0) {
			String errorMessage = driver.findElement(By.xpath("//span[@id='FNOLWizard:FNOLWizard_FindPolicyScreen:_msgs_msgs']/div")).getText();			
			Report.fail("Validate Search Result", "Validation", "Search Result", "Service Down : " + errorMessage);
			Report.totalStatus();
			Report.reportPreparation();
			Report.reportCompletion();
			Assert.fail("Service Down : " + errorMessage);
		}
	}
	
	public void clickButtonWhereLabelNthOccurence(WebDriver driver, String labelName, String occurnence) {

		boolean isFlagged = false;

		while (!isFlagged) {
			try {

				By buttonBy = By.xpath("(//*[normalize-space(text())='" + labelName + "' and contains(@class,'btn')])["
						+ occurnence + "]");
				WebElement buttonEle = driver.findElement(buttonBy);
				((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + buttonEle.getLocation().y + ")");
				// ((JavascriptExecutor)driver).executeScript("window.scrollTo(0,"+buttonEle.getLocation().x+")");
				buttonEle.click();

				break;
			} catch (StaleElementReferenceException e) {
				continue;
			}
		}

	}

}
