package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class TotalLossSalvage {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	//Page Objects
	String updateButton = "//span[text()='pdate']";	
	
	public TotalLossSalvage(WebDriver driver)
	{
		this.driver = driver;
	}	
	
	public void LossSalvagepage(String excelFileName, String profileID) throws Exception {
		String SheetName = "ClaimsPolicy";
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		
		String ddlAssignmentType = xlsread.Exceldata(SheetName, "ddlAssignmentType", profileID);
		String txtAdjusterNotes = xlsread.Exceldata(SheetName, "txtAdjusterNotes", profileID);
		String ddlSalvageStatus = xlsread.Exceldata(SheetName, "ddlSalvageStatus", profileID);
		
        UIMethods.clickbyxpath("//*[@id='ExposureDetail:ExposureDetailScreen:ExposureDetailDV:VehicleDamage_VehicleSalvageCardTab']", "click Total Loss Salvage Tab", "Click");
        Thread.sleep(1000);
        UIMethods.clickbyid("ExposureDetail:ExposureDetailScreen:Edit", "click Edit Button", "Click");
        Thread.sleep(2000);
        
        UIMethods.clickbyid("ExposureDetail:ExposureDetailScreen:ExposureDetailDV:VehicleSalvageDV:VehicleSalvage_ConfirmedTotalLoss_true", "click Confirm Total Loss Radio", "Click");
        Thread.sleep(2000);
        
        UIMethods.selectbyid("ExposureDetail:ExposureDetailScreen:ExposureDetailDV:VehicleSalvageDV:assignmenttype", "input Assignment Type", ddlAssignmentType);
        UIMethods.clickbyid("ExposureDetail:ExposureDetailScreen:ExposureDetailDV:VehicleSalvageDV:vendorpickupsalvage_false", "click Vendor Salvage Radio", "Click");
        Thread.sleep(2000);
        
        UIMethods.inputbyid("ExposureDetail:ExposureDetailScreen:ExposureDetailDV:VehicleSalvageDV:adjusternotes", "input Adjuster Notes", txtAdjusterNotes);
        UIMethods.clickbyid("ExposureDetail:ExposureDetailScreen:ExposureDetailDV:VehicleSalvageDV:bidapprovalrequired_false", "click Bid Approval", "Click");
        UIMethods.selectbyid("ExposureDetail:ExposureDetailScreen:ExposureDetailDV:VehicleSalvageDV:salvagestatus", "input Salvage Status", ddlSalvageStatus);
        
        // Update Button
        UIMethods.jscriptclickbyxpath(updateButton, "click Update button", "Click");
        Thread.sleep(3000);
        
        // Update Button
        UIMethods.jscriptclickbyxpath(updateButton, "click Update button", "Click");
        Thread.sleep(3000);
        
	}
}