package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class Services extends Object_Repositories {

	private WebDriver driver = null;
	WebDriverWait wait;

	public Services(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 10);
	}

	public void clickNextButton() throws Exception {
		if (driver.findElements(By.xpath("//span[contains(@id,'FNOLWizard_ServicesScreen:ttlBar')]")).size() != 0) {
			for (int intLoop = 1; intLoop <= 7; intLoop++) {
				UIMethods.clickbyxpath(nextButton, "Click Next Button", "Click");				
				try {
					driver.findElement(By.xpath("//span[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_ServicesScreen:ttlBar']")).isDisplayed();
				} catch (Exception Ex) {
					break;
				}
			}
		}
	}
}