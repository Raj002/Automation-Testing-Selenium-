package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class NewExposurePopup {

	private WebDriver driver = null;
	WebDriverWait wait;

	public NewExposurePopup(WebDriver driver) {
		this.driver = driver;
	}
	
	public void NewExposurePopuppage(String excelFileName, String profileID) throws Exception {
		String SheetName = "ClaimsPolicy";
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlClaimant = xlsread.Exceldata(SheetName, "ddlClaimant", profileID);
		String ddlClaimantType = xlsread.Exceldata(SheetName, "ddlClaimantType", profileID);
		
		UIMethods.selectbyid("NewClaimWizard_NewExposurePopup:NewClaimWizard_ExposurePageScreen:NewClaimExposureDV:NewClaimVehicleDamageDV:Claimant_Picker", "input Claimant_Picker", ddlClaimant);
        UIMethods.selectbyid("NewClaimWizard_NewExposurePopup:NewClaimWizard_ExposurePageScreen:NewClaimExposureDV:NewClaimVehicleDamageDV:Claimant_Type", "input Claimant_Type", ddlClaimantType);
        UIMethods.clickbyxpath("//a[@id='NewClaimWizard_NewExposurePopup:NewClaimWizard_ExposurePageScreen:Update__dup_1']/span[text()='OK']", "click ok button", "Click");
	
	}
}