package org.qa.Claims.CICC9.Property.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.FetchPropertiesFiles;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class PropertyIncident {

	private WebDriver driver = null;
	WebDriverWait wait;

	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");

	//Page Objects
	String targetCloseDate = "EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixPropIncidentAssessDV:TargetCloseDate";
	String demageDescription = "EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixedPropertyIncidentDV:Description";
	String habitableField = "EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixedPropertyIncidentDV:PropertyHabitable_false";
	String okButton  = "EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:Update__dup_1";
	
	public PropertyIncident(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}

	public void PropertyIncidentPage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtPropertyDescription = xlsread.Exceldata(SheetName, "txtPropertyDescription", profileID);
		String txtDamageDescription = xlsread.Exceldata(SheetName, "txtDamageDescription", profileID);
		String ddlSeverity = xlsread.Exceldata(SheetName, "ddlSeverity", profileID);

		UIMethods.inputbyid("EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixedPropertyIncidentDV:PropertyDescription","Input Property Description", txtPropertyDescription);
		wait.until(ExpectedConditions.elementToBeClickable(By.id(demageDescription)));
		UIMethods.inputbyid(demageDescription,"Input Damage Description", txtDamageDescription);
		wait.until(ExpectedConditions.elementToBeClickable(By.id(habitableField)));
		UIMethods.clickbyid(habitableField,"Is property Habitable rdb", "Click");
		UIMethods.selectbyid("EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixedPropertyIncidentDV:fixedPropertySeverity","Input Severity", ddlSeverity);
		wait.until(ExpectedConditions.elementToBeClickable(By.id(okButton)));
		UIMethods.clickbyid("EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:Update__dup_1","Click Ok Button", "Click");
		Thread.sleep(2000);
	}

	public void PropertyIncidentWithoutHBE(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtPropertyDescription = xlsread.Exceldata(SheetName, "txtPropertyDescription", profileID);
		String txtDamageDescription = xlsread.Exceldata(SheetName, "txtDamageDescription", profileID);
		String ddlSeverity = xlsread.Exceldata(SheetName, "ddlSeverity", profileID);

		UIMethods.inputbyid("EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixedPropertyIncidentDV:PropertyDescription","Input Property Description", txtPropertyDescription);
		UIMethods.inputbyid("EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixedPropertyIncidentDV:Description","Input Damage Description", txtDamageDescription);
		UIMethods.selectbyid("EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixedPropertyIncidentDV:fixedPropertySeverity","Input Severity", ddlSeverity);
		UIMethods.clickbyid("EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:Update__dup_1","Click Ok Button", "Click");
		Thread.sleep(2000);
	}

	public void EditPropertyIncidentPage() throws Exception {
		UIMethods.clickbyid("EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:Edit", "Click Edit Button","Click");
		Thread.sleep(2000);
	}

	public void ClickAssessmentTab() throws Exception {
		Helper.highLightElement(driver, driver.findElement(By.id("EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:FixPropIncidentDetailDV:Incident_AssessmentTab")));
		UIMethods.clickbyid("EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:FixPropIncidentDetailDV:Incident_AssessmentTab","Click Assessment Tab", "Click");
		Thread.sleep(2000);
	}

	public void PropertyIncidentAssessmentPage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");

		String btnAddAssessment = xlsread.Exceldata(SheetName, "btnAddAssessment", profileID);
		String txtTargetCloseDate = xlsread.Exceldata(SheetName, "txtTargetCloseDate", profileID);
		String btnUpdateAssessment = xlsread.Exceldata(SheetName, "btnUpdateAssessment", profileID);

		if (!(btnAddAssessment.isEmpty())) {
			UIMethods.clickbyid("EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixPropIncidentAssessDV:FixPropAssessSourceLV_tb:Add","Click Add Assessment Button", "Click");
		}

		// txtTargetCloseDate
		if (!(txtTargetCloseDate.isEmpty())) {
			String strExecutionType = (FetchPropertiesFiles.executionMode).toString();
			Helper.clearTextBox(driver, driver.findElement(By.id(targetCloseDate)));
			Helper.highLightElement(driver, driver.findElement(By.id(targetCloseDate)));
			if (strExecutionType.equalsIgnoreCase("Saucelab")) {
				UIMethods.inputbyid(targetCloseDate,"Input Target Close Date", txtTargetCloseDate);
			} else {
				UIMethods.inputbyid(targetCloseDate,"Input Target Close Date", txtTargetCloseDate);
			}
		}

		if (!(btnUpdateAssessment.isEmpty())) {
			Helper.highLightElement(driver, driver.findElement(By.id("EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:Update")));
			UIMethods.clickbyid("EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:Update", "Click Update Assessment Button", "Click");
			
			if(driver.findElements(By.xpath("//span[@id='EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:_msgs_msgs']/div")).size()!=0) {
				String actualErrorMessage = driver.findElement(By.xpath("//span[@id='EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:_msgs_msgs']/div")).getText();
				System.out.println("Error message for time : " + actualErrorMessage);
				if(actualErrorMessage.contains("Target Close Date : Field must be a valid date in the format")) {
					Helper.clearTextBox(driver, driver.findElement(By.id(targetCloseDate)));
					UIMethods.inputbyid(targetCloseDate, "Input Target Close Date",txtTargetCloseDate);
					Helper.highLightElement(driver, driver.findElement(By.id("FNOLWizard:Next")));
					UIMethods.clickbyid("EditFixedPropertyIncidentPopup:EditFixedPropertyIncidentScreen:Update", "Click Update Assessment Button", "Click");
				}
			}
		}
		Thread.sleep(2000);
	}
}