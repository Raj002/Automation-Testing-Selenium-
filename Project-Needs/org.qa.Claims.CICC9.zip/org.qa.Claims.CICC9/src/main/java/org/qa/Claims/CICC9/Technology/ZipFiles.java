package org.qa.Claims.CICC9.Technology;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.apache.log4j.Logger;

/**
 * To Zip multiple files into a single Zip file
 * 
*/

public class ZipFiles {
	public static final Logger LOG = Logger.getLogger(ZipFiles.class);
	List<String> fileList;
	private static String OUTPUT_ZIP_FILE = null;
	private static String SOURCE_FOLDER = null;

	public ZipFiles() {
		fileList = new ArrayList<String>();
	}

	/**
	 * Zip a folder into a Zip file
	 * 
	 * @param outputZIP_file
	 * @param srcFolder
	 */
	public void createZipFolder(String outputZIP_file, String srcFolder) {
		OUTPUT_ZIP_FILE = outputZIP_file;
		SOURCE_FOLDER = srcFolder;

		ZipFiles zipFiles = new ZipFiles();
		zipFiles.generateFileList(new File(SOURCE_FOLDER));
		zipFiles.zipIt(OUTPUT_ZIP_FILE);
	}

	/**
	 * Read files inside a folder and compress it
	 * 
	 * @param zipFile
	 * 
	 */
	public void zipIt(String zipFile) {

		byte[] buffer = new byte[1024];

		try {

			FileOutputStream fos = new FileOutputStream(zipFile);
			ZipOutputStream zos = new ZipOutputStream(fos);

			LOG.info("Output to Zip : " + zipFile);

			for (String file : this.fileList) {

				LOG.info("File Added : " + file);
				ZipEntry ze = new ZipEntry(file);
				zos.putNextEntry(ze);

				FileInputStream in = new FileInputStream(SOURCE_FOLDER + File.separator + file);

				int len;
				while ((len = in.read(buffer)) > 0) {
					zos.write(buffer, 0, len);
				}

				in.close();
			}

			zos.closeEntry();
			// remember close it
			zos.close();

			LOG.info("Done");
		} catch (IOException ex) {
			LOG.error("ZipFiles : Exception : " + ex.getMessage());
		}
	}

	/**
	 * Traverse a directory and get all files, and add the file into fileList
	 * 
	 * @param node
	 * 
	 */

	public void generateFileList(File node) {

		// add file only
		if (node.isFile()) {
			fileList.add(generateZipEntry(node.getAbsoluteFile().toString()));

		}

		if (node.isDirectory()) {
			String[] subNote = node.list();
			for (String filename : subNote) {
				generateFileList(new File(node, filename));
			}
		}

	}

	/**
	 * Format the file path for zip
	 * @param file
	 * @return Formatted file path
	 */
	private String generateZipEntry(String file) {

		return file.substring(file.lastIndexOf("\\") + 1, file.length());

	}

}
