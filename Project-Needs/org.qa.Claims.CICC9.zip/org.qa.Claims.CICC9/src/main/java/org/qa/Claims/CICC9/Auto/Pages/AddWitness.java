package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class AddWitness {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	public AddWitness(WebDriver driver)
	{
		this.driver = driver;
	}	
	
	public void AddWitnesspage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlWitnessContact = xlsread.Exceldata(SheetName, "ddlWitnessContact", profileID);
		String ddlWitnessStmtInd = xlsread.Exceldata(SheetName, "ddlWitnessStmtInd", profileID);
		String ddlWitnessPosition = xlsread.Exceldata(SheetName, "ddlWitnessPosition", profileID);
		
		Thread.sleep(5000);
		WebElement addwitnessbutton = driver.findElement(By.xpath("//a[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:AtTheSceneDV:WitnessLV:EditableWitnessesLV_tb:Add']/span[text()='Add']"));
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("arguments[0].click();", addwitnessbutton);
		Thread.sleep(2000);
		//UIMethods.clickbyxpath("//a[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:AtTheSceneDV:WitnessLV:EditableWitnessesLV_tb:Add']/span[text()='Add']", "click Add Witness button", "Click");
		Thread.sleep(2000);
        UIMethods.selectbyid("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:AtTheSceneDV:WitnessLV:EditableWitnessesLV:0:Contact", "input witness contact", ddlWitnessContact);
        UIMethods.selectbyid("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:AtTheSceneDV:WitnessLV:EditableWitnessesLV:0:EditableWitnesses_WitnessStatementInd", "input WitnessStatementInd", ddlWitnessStmtInd);
        UIMethods.selectbyid("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:AtTheSceneDV:WitnessLV:EditableWitnessesLV:0:EditableWitnesses_WitnessPosition", "input WitnessPosition", ddlWitnessPosition);
	}
}