package org.qa.Claims.CICC9.CommonScreens;

public class Payment 
{
	
}
