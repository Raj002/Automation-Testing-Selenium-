package org.qa.Claims.CICC9.Utilities;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Technology.UtilityFunctions;

public class signOutAction extends Object_Repositories{

	private WebDriver driver = null;

	String logOutCCLink = "//a[@id=':TabLinkMenuButton']/span";
	String logOutABLick = "TabBar:AMABSiteMinderTabBarLink";

	public signOutAction(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}

	public void ClaimsLogout() throws Exception {
		Thread.sleep(3000);
		try {
			driver.findElement(By.xpath(logOutCCLink)).isDisplayed();
			UIMethods.jscriptclickbyxpath(logOutCCLink, "Click Settings Icon", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='TabBar:LogoutTabBarLink-textEl']")));
			//UIMethods.clickbyxpath(logOutCCLink, "click logout button", "Click");
			UIMethods.jscriptclickbyxpath("//span[@id='TabBar:LogoutTabBarLink-textEl']", "Click Log Out option", "Click");
			if (UtilityFunctions.isAlertPresent(driver)) {
				Alert alert = driver.switchTo().alert();
				System.out.println("Found and clicked Alert window with text message as " + alert.getText());
				alert.accept();
				Thread.sleep(3000);
			}
		} catch (Exception ex) {
			driver.findElement(By.id(logOutABLick)).isDisplayed();
			UIMethods.clickbyid(logOutABLick, "click logout button", "Click");
			if (UtilityFunctions.isAlertPresent(driver)) {
				Alert alert = driver.switchTo().alert();
				System.out.println("Found and clicked Alert window with text message as " + alert.getText());
				alert.accept();
				Thread.sleep(3000);
			}
		}
	}

	public void ClaimsLogoutWithHandlePopup() throws Exception {
		Thread.sleep(3000);
		try {
			driver.findElement(By.id(logOutCCLink)).isDisplayed();
			UIMethods.clickbyxpath(logOutCCLink, "click logout button", "Click");
			UIMethods.clickbyxpath("//span[@id='TabBar:LogoutTabBarLink-textEl']", "Click log out option", "Click");
		} catch (Exception ex) {
			driver.findElement(By.id(logOutABLick)).isDisplayed();
			UIMethods.clickbyxpath(logOutCCLink, "click logout button", "Click");
			UIMethods.clickbyxpath("//span[@id='TabBar:LogoutTabBarLink-textEl']", "Click log out option", "Click");
		}
		Thread.sleep(1000);

		// Handle Pop-up
		try {
			Alert alert = driver.switchTo().alert();
			System.out.println("Found and clicked Alert window with text message as " + alert.getText());
			alert.accept();
			Thread.sleep(3000);
		} catch (Exception Ex) {
		}
	}

}
