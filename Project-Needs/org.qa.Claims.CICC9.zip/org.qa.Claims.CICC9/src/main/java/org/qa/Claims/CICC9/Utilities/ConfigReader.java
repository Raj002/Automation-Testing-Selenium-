package org.qa.Claims.CICC9.Utilities;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

public class ConfigReader {
	static Properties properties;
	static BufferedReader reader;

	public static Map<String, String> getConfig() {

		properties = new Properties();
		Map<String, String> map = new HashMap<String, String>();
		try {
			properties.load(ConfigReader.class.getResourceAsStream("/src/test/resources/Config.Properties"));

		} catch (IOException e) {
			System.err.println("Couldn't load properties correctly..." + e.getMessage());
			e.printStackTrace();
		}

		for (Entry<Object, Object> entry : properties.entrySet()) {
			map.put((String) entry.getKey(), (String) entry.getValue());
		}

		return map;
	}
	
	public static String getConfig(String key) {
		properties = new Properties();
		Map<String, String> map = new HashMap<String, String>();
		try {
			properties.load(ConfigReader.class.getResourceAsStream("/src/test/resources/Config.Properties"));
		} catch( IOException e) {
			System.err.println("Couldn't load properties correctly..." + e.getMessage());
		}
		
		for(Entry<Object, Object> entry: properties.entrySet()) {
			map.put((String)entry.getKey(), (String)entry.getValue());
			if(map.containsKey(key) == true) {
				return map.get(key);
			}			
		}
		return null;
	}
	
	public static void main(String[] args) {
		System.out.println(ConfigReader.getConfig("TESTING_TYPE"));
	}
	
}
