package org.qa.Claims.CICC9.CommonScreens;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class NewUserContact {
	
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
		
	public void NewPersonContactDetailpage(String excelFileName, String profileID) throws Exception {	
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		Thread.sleep(3000);
		String txtNewUserfirstname = xlsread.Exceldata(SheetName, "txtNewUserfirstname", profileID);
		String txtNewUserlastname = xlsread.Exceldata(SheetName, "txtNewUserlastname", profileID);
		String txtNewuserEmpNum = xlsread.Exceldata(SheetName, "txtNewuserEmpNum", profileID);
		UIMethods.inputbyid("NewContact:ABContactDetailScreen:ContactBasicsDV:FirstName", "Input FirstName", txtNewUserfirstname);
        UIMethods.inputbyid("NewContact:ABContactDetailScreen:ContactBasicsDV:LastName", "Input LastName", txtNewUserlastname);
        Thread.sleep(2000);
        if (!(txtNewuserEmpNum.isEmpty())) {
	        SimpleDateFormat formatter = new SimpleDateFormat("MMddyyhhmmssms");
			Calendar currentDate = Calendar.getInstance();
			String empNum = formatter.format(currentDate.getTime());
	        UIMethods.inputbyid("NewContact:ABContactDetailScreen:ContactBasicsDV:ABUserContactBasicsInputSet:EmployeeNumber", "Input Employee number", empNum);
        }
        
        UIMethods.clickbyid("NewContact:ABContactDetailScreen:ContactBasicsDV_tb:Update", "Click Update Button", "Click");
        Thread.sleep(3000);
      }
    
}