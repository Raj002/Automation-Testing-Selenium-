package org.qa.Claims.CICC9.Property.Pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Technology.UtilityFunctions;
import org.qa.Claims.CICC9.Utilities.Helper;

public class PolicySelection {

	private WebDriver driver = null;
	WebDriverWait wait;

	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");

	public PolicySelection(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}

	public void PolicySelectionPage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtPolicySelection = xlsread.Exceldata(SheetName, "txtPolicySelection", profileID);
		
		Helper.validateAndAcceptAlert(driver);
		
		//Updated by RAJ
		UIMethods.jscriptclickbyxpath("//a[@id='Claim:MenuLinks:Claim_ClaimPolicyGroup']/div", "Click Policy Link from left panel", "Click");
		//UIMethods.clickbyid("Claim:MenuLinks:Claim_ClaimPolicyGroup", "Click Policy Left Tab", "Click");
		Thread.sleep(5000);
		Helper.validateAndAcceptAlert(driver);
		
		UIMethods.jscriptclickbyxpath("//a[@id='ClaimPolicyGeneral:ClaimPolicyGeneralScreen:ClaimPolicyGeneral_SelectPolicyButton']/span[2]", "Click Select Policy button", "Click");
		//UIMethods.clickbyid("ClaimPolicyGeneral:ClaimPolicyGeneralScreen:ClaimPolicyGeneral_SelectPolicyButton","Click Select Policy Button", "Click");
		Thread.sleep(1000);

		//Updated by RAJ
		Helper.validateAndAcceptAlert(driver);
		
		UIMethods.inputbyid("ClaimPolicySelectPolicyPopup:ClaimPolicySelectPolicyScreen:PolicySearchDV:PolicySearchPolicyInputSet:PolicyNumber","Enter policy Account Number", txtPolicySelection);
		wait.until(ExpectedConditions.elementToBeClickable(By.id("ClaimPolicySelectPolicyPopup:ClaimPolicySelectPolicyScreen:PolicySearchDV:Search_link")));
		Thread.sleep(3000);
		UIMethods.clickbyid("ClaimPolicySelectPolicyPopup:ClaimPolicySelectPolicyScreen:PolicySearchDV:Search_link","Click Search Button", "Click");
		Thread.sleep(5000);
		UIMethods.clickbyid("ClaimPolicySelectPolicyPopup:ClaimPolicySelectPolicyScreen:PolicySearchResultLV:0:_Select_link","Click Select Button", "Click");
		Thread.sleep(5000);
	}
	
	
}