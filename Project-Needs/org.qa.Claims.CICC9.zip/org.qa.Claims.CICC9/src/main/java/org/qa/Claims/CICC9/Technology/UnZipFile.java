package org.qa.Claims.CICC9.Technology;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.log4j.Logger;

/**
 * To Zip multiple files into a single Zip file
 */
public class UnZipFile {
	
	public static final Logger LOG = Logger.getLogger(UnZipFile.class);
	List<String> fileList;
	@SuppressWarnings("unused")
	private static  String INPUT_ZIP_FILE = null;
	private static  String OUTPUT_FOLDER = null;

	/**
	 * Class to decompress and unzip files from a Zip file
	 * @param zipFile            
	 * @param output
	 *            
	 */
	public void unZipIt(String zipFile, String outputFolder) {
		INPUT_ZIP_FILE = zipFile;
		OUTPUT_FOLDER  = outputFolder;
		
		byte[] buffer = new byte[1024];
		try {
			// create output directory is not exists
			File folder = new File(OUTPUT_FOLDER);
			if (!folder.exists()) {
				folder.mkdir();
			}
			// get the zip file content
			ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile));
			// get the zipped file list entry
			ZipEntry ze = zis.getNextEntry();
			while (ze != null) {
				String fileName = ze.getName();
				File newFile = new File(outputFolder + File.separator + fileName);
				LOG.info("file unzip : " + newFile.getAbsoluteFile());
				new File(newFile.getParent()).mkdirs();
				FileOutputStream fos = new FileOutputStream(newFile);
				int len;
				while ((len = zis.read(buffer)) > 0) {
					fos.write(buffer, 0, len);
				}

				fos.close();
				ze = zis.getNextEntry();
			}
			zis.closeEntry();
			zis.close();
			LOG.info("Done");
		} catch (IOException ex) {
			LOG.error("ConnectionFramework : Exception : " + ex.getMessage());
		}
	}
}