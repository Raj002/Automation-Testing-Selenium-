package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class EditLossDetailsPage {

	private WebDriver driver = null;
	WebDriverWait wait;

	// Page Objects
	String editLossDetails = "//*[@id='ClaimLossDetails:ClaimLossDetailsScreen:Edit']/span[text()='dit']";
	String propertyAddressLink = "//*[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:EditableFixedPropertyIncidentsLV:0:Address1']";

	public EditLossDetailsPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}

	public void editLossDetailsPage() throws Exception {
		Thread.sleep(4000);
		Helper.highLightElement(driver, driver.findElement(By.xpath(editLossDetails)));
		UIMethods.clickbyxpath(editLossDetails, "click edit loss details", "Click");
	}

	public void PropertyAddressLink() throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(propertyAddressLink)));
		Thread.sleep(2000);
		Helper.highLightElement(driver, driver.findElement(By.xpath(propertyAddressLink)));
		UIMethods.clickbyxpath(propertyAddressLink, "click Property Address Link", "Click");
		Thread.sleep(3000);
	}
}