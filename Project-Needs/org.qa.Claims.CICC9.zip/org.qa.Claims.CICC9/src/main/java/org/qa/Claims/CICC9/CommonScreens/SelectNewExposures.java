package org.qa.Claims.CICC9.CommonScreens;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Auto.Pages.Exposure_General;
import org.qa.Claims.CICC9.Auto.Pages.Exposure_PIP;
import org.qa.Claims.CICC9.Property.Pages.Exposure_Bodily_Injury;
import org.qa.Claims.CICC9.Property.Pages.Exposure_Loss_Of_Use;
import org.qa.Claims.CICC9.Property.Pages.Exposure_Med_Pay;
import org.qa.Claims.CICC9.Property.Pages.Exposure_Personal_Property;
import org.qa.Claims.CICC9.Property.Pages.Exposure_Property;
import org.qa.Claims.CICC9.Property.Pages.Exposure_Vehicle;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;
import org.testng.Assert;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

public class SelectNewExposures extends Object_Repositories{
	
	WebDriver driver;	
	
	// Object reference for page objects
	Exposure_Bodily_Injury bodilyInjury;
	Exposure_Loss_Of_Use lossOfUse;
	Exposure_Med_Pay medPay;
	Exposure_Personal_Property personalProperty;
	Exposure_Property property;
	Exposure_Vehicle vehicle;
	Exposure_PIP pip;
	Exposure_General general;
	SetReserves setReserve;
	PayeeInformation payeeInfo;
	PaymentInformation paymentInfo;
	CopyExposureData copyExposureName;
	SetCheckInstructions checkPage;
	
	// Page Objects
	String coverageType1 = "//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType']";
	String coverageType2 = "//*[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_AssignSaveScreen:NewExposureLV_tb:AddExposure:NewExposureMenuItemSet_ByCoverageType']";
	String coverageType3 = "//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverage']";
	String P_OptionType = "//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:7:item']";
	String B_OptionType = "//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:1:item']";
	String L_OptionType = "//*[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_AssignSaveScreen:NewExposureLV_tb:AddExposure:NewExposureMenuItemSet_ByCoverageType:5:item']";
	String L_OptionType1 = "//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:5:item']";
	String P_OptionType1 = "//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:10:item']";
	String P_OptionType2 = "//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:12:item']";
	String LiabilityInjuryOption = "//*[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_AssignSaveScreen:NewExposureLV_tb:AddExposure:NewExposureMenuItemSet_ByCoverageType:5:item:1:item']";
	String LiabilityOption = "//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:5:item:0:item']";
	String LiabilityBodilyInjury = "//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:5:item:1:item']";
	String policyLevelCoverageOption = "//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverage:0:item']";
	String newExposureClaimantType = "NewClaimWizard_NewExposurePopup:NewClaimWizard_ExposurePageScreen:NewClaimExposureDV:Claimant_Type";
	String buildingOption = "//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:1:item:1:item']";
	String actionsMenu = "//*[text()='ctions']";
	
	public SelectNewExposures (WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 15);
		bodilyInjury = new Exposure_Bodily_Injury(driver);
		lossOfUse = new Exposure_Loss_Of_Use(driver);
		medPay = new Exposure_Med_Pay(driver);
		personalProperty = new Exposure_Personal_Property(driver);
		property = new Exposure_Property(driver);
		vehicle = new Exposure_Vehicle(driver);
		pip = new Exposure_PIP(driver);
		general = new Exposure_General(driver);
		setReserve = new SetReserves(driver);
		payeeInfo = new PayeeInformation(driver);
		paymentInfo = new PaymentInformation(driver);
		copyExposureName = new CopyExposureData(driver);
		checkPage = new SetCheckInstructions(driver);
	}
	
	public void ExposuresPiPMedical() throws Exception{		
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(P_OptionType, "Click P Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:7:item:0:item']", "Click PIP - Add'l PIP - Medical Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:7:item:0:item:0:item']", "Click PIP - Add'l PIP - Medical Option", "Click");
		Thread.sleep(3000);
	}
	
	
	public void ExposuresLiabilityBodilyInjuryVehicle() throws Exception{
		UIMethods.clickbyxpath("//*[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_AssignSaveScreen:NewExposureLV_tb:AddExposure']", "click New Exposure", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType2, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(L_OptionType, "Click L Option", "Click");
		
		//Updated By RAJ
		UIMethods.jscriptclickbyxpath(LiabilityOption, "Click Liability Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_AssignSaveScreen:NewExposureLV_tb:AddExposure:NewExposureMenuItemSet_ByCoverageType:5:item:0:item:5:item']", "Click Liability - Vehicle", "Click");
		Thread.sleep(3000);
	}
	
	public void ExposuresPropertyCollision() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(P_OptionType, "Click P Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:7:item:2:item']", "Click Property Collision Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:7:item:2:item:0:item']", "Click Property Collision Vehicle", "Click");
		Thread.sleep(3000);
	}
	
	public void ExposuresPropertyDamageCollision() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(P_OptionType, "Click P Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:7:item:12:item']", "Click Property Damage Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:7:item:12:item:0:item']", "Click Property Damage - Collision Vehicle", "Click");
		Thread.sleep(3000);
	}
	
	public void ExposuresPropertyDamageCollisionVehicle() throws Exception{		
		Helper.clickActionsMenu(driver, "choose by coverage type");	
		
		Helper.xpathToClickActionsSubMenu(driver, "P");
		Helper.xpathToClickActionsSubMenu(driver, "Property Damage - Collision");
		Helper.xpathToClickActionsSubMenu(driver, "Property Damage - Collision - Vehicle");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id("NewExposure:NewExposureScreen:ttlBar")));
	}
	
	public void ExposuresPropertyDamageComprehensiveVehicle() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType3, "Click Chose by Coverage", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(policyLevelCoverageOption, "Click Policy Level Coverage Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverage:0:item:2:item']", "Click Property Damage - Comprehensive Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverage:0:item:2:item:0:item']", "Click Property Damage - Comprehensive - Vehicle", "Click");
		Thread.sleep(3000);
	}
	
	public void ExposuresBuildingProperty() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(B_OptionType, "Click B Option", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(buildingOption, "Click Building Option", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:1:item:1:item:0:item']", "Click Building-Property Option", "Click");
		Thread.sleep(3000);
	}
	
	public void ExposuresGreenUpdgrates() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:6:item']", "Click G Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:6:item:0:item']", "Click Green Upgrade Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:6:item:0:item:1:item']", "Click Green Upgrade-Personal Property Option", "Click");
		Thread.sleep(3000);
	}
	
	public void ExposuresCoverageBuildingProperty() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(B_OptionType, "Click B Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:1:item:0:item']", "Click Building Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:1:item:0:item:0:item']", "Click Building-Property Option", "Click");
		Thread.sleep(3000);
	}
	
	public void ExposuresLocationLevelBuildingProperty() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType3, "Click Policy Coverage", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(policyLevelCoverageOption, "Click 1st Option Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverage:0:item:0:item']", "Click Location Level coverage Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverage:0:item:0:item:0:item']", "Click Building-Property Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverage:0:item:0:item:0:item:0:item']", "Click Building-Property Option", "Click");
		Thread.sleep(3000);
	}
	
	public void ExposuresLiabilityProperty() throws Exception {
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(L_OptionType1, "Click L Option", "Click");
		UIMethods.jscriptclickbyxpath(LiabilityOption, "Click Liability Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:5:item:0:item:4:item']", "Click Liability - Property Option", "Click");
		Thread.sleep(3000);
	}
	
	public void ExposuresCollisionVehicle() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(P_OptionType, "Click P Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:7:item:11:item']", "Click Property Damage Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:7:item:11:item:0:item']", "Click Collision Vehicle Option", "Click");
		Thread.sleep(3000);
	}
	
	public void ExposuresBodilyInjury() throws Exception {
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(L_OptionType1, "Click L Option", "Click");
		UIMethods.jscriptclickbyxpath(LiabilityOption, "Click Liability Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:5:item:0:item:0:item']", "Click Liability Bodily - Injury Option", "Click");
		Thread.sleep(3000);
	}
	
	public void ExposuresLiabilityBodilyInjury() throws Exception{
		UIMethods.clickbyxpath("//*[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_AssignSaveScreen:NewExposureLV_tb:AddExposure']", "click New Exposure", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType2, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(L_OptionType, "Click L Option", "Click");
		UIMethods.jscriptclickbyxpath(LiabilityInjuryOption, "Click Liability - Bodily Injury", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_AssignSaveScreen:NewExposureLV_tb:AddExposure:NewExposureMenuItemSet_ByCoverageType:5:item:1:item:0:item']", "Click Liability Bodily Injury - Bodily Injury", "Click");
		Thread.sleep(3000);
	}
	
	public void GLExposuresLiabilityBodilyInjury() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(P_OptionType, "Click L Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:7:item:1:item']", "Click Liability Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:7:item:1:item:0:item']", "Click Liability Bodily - Injury Option", "Click");
		Thread.sleep(3000);
	}
	
	public void ExposuresBodilyInjuryNew() throws Exception {
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(L_OptionType1, "Click L Option", "Click");
		UIMethods.jscriptclickbyxpath(LiabilityBodilyInjury, "Click Liability - Bodily Injury", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:5:item:1:item:0:item']", "Click Liability Bodily Injury - Bodily Injury", "Click");
		Thread.sleep(3000);
	}
	
	public void ExposuresBodilyInjuryVehicleNew() throws Exception {
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(L_OptionType1, "Click L Option", "Click");		
		UIMethods.jscriptclickbyxpath(LiabilityBodilyInjury, "Click Liability - Bodily Injury", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:5:item:1:item:5:item']", "Click Liability Bodily Injury - Bodily Injury - Vehicle", "Click");
		Thread.sleep(3000);
	}
	
	public void ExposuresPropertyDamage() throws Exception {
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(P_OptionType1, "Click P Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:10:item:4:item']", "Click Property Damage Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:10:item:4:item:0:item']", "Click Personal Property Option", "Click");
		Thread.sleep(3000);
	}
	
	public void ExposuresPersonalProperty() throws Exception {
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(P_OptionType1, "Click P Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:10:item:2:item']", "Click Personal Property Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:10:item:2:item:0:item']", "Click Personal Property of Others Option", "Click");
		Thread.sleep(3000);
	}
	
	public void GLExposureBodilyExposurePage() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(B_OptionType, "Click B Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:1:item:2:item']", "Click Bodily Injuiry Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:1:item:2:item:0:item']", "Click Bodily Injuiry - Bodily Injuiry", "Click");
		Thread.sleep(3000);
	}
	
	public void GLExposureDrugistPropertyPage() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:3:item']", "Click D Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:3:item:2:item']", "Click Drugist", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:3:item:2:item:3:item']", "Click Drugist Property", "Click");
		Thread.sleep(3000);
	}
	
	public void GLExposureEmploymentPracticesPage() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:4:item']", "Click E Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:4:item:1:item']", "Click Employment Practices Liab Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:4:item:1:item:1:item']", "Click Employment Practices Liab - General", "Click");
		Thread.sleep(3000);
	}	
	
	public void GLExposurePersonalInjuiryPage() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(P_OptionType2, "Click P Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:12:item:1:item']", "Click Personal Injuiry Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:12:item:1:item:1:item']", "Click Personal Injuiry General Vehicle", "Click");
		Thread.sleep(3000);
	}
	
	public void GLExposurePersonalLiabilityPage() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:13:item']", "Click P Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:13:item:1:item']", "Click Personal Lia Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:13:item:1:item:1:item']", "Click Personal Lia - General Vehicle", "Click");
		Thread.sleep(3000);
	}
	
	public void GLExposurePollutionLiabilityPage() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(P_OptionType2, "Click P Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:12:item:2:item']", "Click Pollution Lia Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:12:item:2:item:1:item']", "Click Pollution Lia - General", "Click");
		Thread.sleep(3000);
	}

	public void GLExposurePropertyDamagePage() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(P_OptionType2, "Click P Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:12:item:10:item']", "Click Property Damage", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:12:item:10:item:2:item']", "Click Property Damage - Vehicle", "Click");
		Thread.sleep(3000);
	}
	
	public void GLExposureUmbrellaPage() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(B_OptionType, "Click Umbrella Option", "Click");
		UIMethods.jscriptclickbyxpath(buildingOption, "Click Umbrella - General Option", "Click");
		Thread.sleep(3000);
	}
	
	public void GLPremisesBodilyExposureSelection() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType3, "Click Choose by Policy Coverage", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(policyLevelCoverageOption, "Click Policy Level Coverage Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverage:0:item:3:item']", "Click Premises & Operational Liab Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverage:0:item:3:item:0:item']", "Click Premises & Operational Liab - Bodily Injuiry", "Click");
		Thread.sleep(3000);
	}
	
	public void SelectNewExposuresPage() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(B_OptionType, "Click B Option", "Click");
		UIMethods.jscriptclickbyxpath(buildingOption, "Click Building", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:1:item:1:item:0:item']", "Click Building Property", "Click");
		Thread.sleep(3000);
	}
	
	
	public void PersonalLiaPropertyExposuresPage() throws Exception{
		UIMethods.jscriptclickbyxpath(actionsMenu, "click Actions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(coverageType1, "Click Coverage Type", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(P_OptionType1, "Click P Option", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:10:item:0:item']", "Click Personal Liab", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverageType:10:item:0:item:2:item']", "Click Personal Liab Property", "Click");
		Thread.sleep(3000);
	}
	
	public void FillOutClaimantSection(String excelFileName, String profileID) {		
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");		
		String newExposureClaimant = xlsread.Exceldata(SheetName, "ddlNewExposureClaimant", profileID);
		String newExposureClaimantType = xlsread.Exceldata(SheetName, "ddlNewExposureClaimantType", profileID);

		UIMethods.inputbyid("NewClaimWizard_NewExposurePopup:NewClaimWizard_ExposurePageScreen:NewClaimExposureDV:Claimant_Picker", "Select value from Claimant drop-down", newExposureClaimant);
		UIMethods.inputbyid(newExposureClaimantType, "Select value from Type drop-down", newExposureClaimantType);
		UIMethods.inputbyid(newExposureClaimantType, "Select value from Type drop-down", newExposureClaimantType);
	}
	
	public void SelectNewIncidentOption(String excelFileName, String profileID) throws Exception {
		UIMethods.clickbyxpath("//*[@id='menu_NewClaimWizard_NewExposurePopup:NewClaimWizard_ExposurePageScreen:NewClaimExposureDV:BIDamageInputSet:Injury_Incident:Injury_IncidentMenuIcon']", "Click down arrow", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath("//*[@id='NewClaimWizard_NewExposurePopup:NewClaimWizard_ExposurePageScreen:NewClaimExposureDV:BIDamageInputSet:Injury_Incident:BodilyInjuryDamageDV_NewIncidentMenuItem']", "Click New Incident option", "Click");
	}
	
	public void ClickOKButtonOnly() {
		UIMethods.clickbyid("NewClaimWizard_NewExposurePopup:NewClaimWizard_ExposurePageScreen:Update", "Click OK button", "Click");
	}
	
	public void create_Exposure_During_OR_Post_FNOL(String excelFileName, String profileID, String startRow, String endRow) throws Exception {		
		
		xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String modeOfExposure = xlsread.Exceldata(SheetName, "ExposureMode", profileID);

		if (modeOfExposure.equalsIgnoreCase("during") || modeOfExposure.equalsIgnoreCase("post")) {
			select_Exposure_Creation_Type(excelFileName, profileID);

			// This loop will create exposure multiple times based on the test data given in
			// the test data sheet
			for (int i = Integer.valueOf(startRow); i <= Integer.valueOf(endRow); i++) {
				String TCNO = String.valueOf(i);
				xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
				String policyNumber = xlsread.Exceldata(SheetName, "txtPolAccNo", TCNO);
				int rowCount = xlsread.GetExcelRowcount(SheetName);
				
				if (rowCount <= Integer.valueOf(endRow)) {
					System.out.println("Row count is lesser than end row");
					break;
				}
				
				// When the Profile ID appears and the policy number becomes empty then it will
				// create the exposure based on the Exposure types
				if (policyNumber.isEmpty() == true) {
					select_Exposure_Creation_Type(excelFileName, TCNO);
				} else {
					// When the Policy Number field contains value then it will break the loop and
					// it will goto next scenario
					break;
				}
			}
		} else {
			Report.pass("Mode of Exposure isn't given to create Exposure During FNOL. Since it will do a Claim creation", "Create Claim", "Create Claim", "Create Claim");
		}

	}
	
	public void select_Exposure_Creation_Type(String excelFileName, String profileID) throws Exception {		
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");	
		String modeOfExposure = xlsread.Exceldata(SheetName, "ExposureMode", profileID);
		String exposureOption = xlsread.Exceldata(SheetName, "NewExposureOption", profileID);
		String exposureType = xlsread.Exceldata(SheetName, "ExposureType", profileID);
		
		String expectedCoverageTypeOption = xlsread.Exceldata(SheetName, "CoverageTypeOptions", profileID);
		String expectedCoverageType = xlsread.Exceldata(SheetName, "CoverageType", profileID);
		String expectedCoverageSubType = xlsread.Exceldata(SheetName, "Coverage Subtype", profileID);
		
		String paymentOption = xlsread.Exceldata(SheetName, "paymentOption", profileID);
				
		if(modeOfExposure.equalsIgnoreCase("during")) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Save and Assign Claim')]")));
		}
		
		if(modeOfExposure.equalsIgnoreCase("during") || modeOfExposure.equalsIgnoreCase("post")) {			
			if(modeOfExposure.equalsIgnoreCase("during")) {
				UIMethods.jscriptclickbyxpath("//a[contains(@id,'NewExposureLV_tb:AddExposure')]/span", "Click New Exposure Button", "Click");
			}
			
			// Validate Creation of Exposure type (Choose by Policy Coverage OR Choose by Coverage Type)
			if (exposureOption.equalsIgnoreCase("Choose by Policy Coverage")) {
				if (modeOfExposure.equalsIgnoreCase("during") || modeOfExposure.equalsIgnoreCase("post")) {

					// This method will create exposure by clicking on New Exposure button during FNOL
					Helper.clickActionsMenu(driver, exposureOption);
					create_Exposure_By_Policy_Type(excelFileName, profileID);
				}
				select_Exposure_Type(exposureType, excelFileName, profileID);

			} else {

				// By default Choose by Coverage Type will be executed if you haven't mention Choose by Policy Coverage OR Choose by Coverage Type
				Helper.clickActionsMenu(driver, exposureOption);
				
				if(modeOfExposure.equalsIgnoreCase("during")) {
					if(expectedCoverageType.equalsIgnoreCase("Default Liability - Third Party") || expectedCoverageType.equalsIgnoreCase("Excess") || expectedCoverageType.equalsIgnoreCase("Umbrella")) {
						Helper.xpathToClickActionsSubMenu(driver, expectedCoverageType);
						Helper.xpathToClickActionsSubMenu(driver, expectedCoverageSubType);					
					} else {
						Helper.xpathToClickActionsSubMenu(driver, expectedCoverageTypeOption);
						Helper.xpathToClickActionsSubMenu(driver, expectedCoverageType);
						Helper.xpathToClickActionsSubMenu(driver, expectedCoverageSubType);
					}
				} else {
					Helper.xpathToClickActionsSubMenu(driver, expectedCoverageTypeOption);
					Helper.xpathToClickActionsSubMenu(driver, expectedCoverageType);
					Helper.xpathToClickActionsSubMenu(driver, expectedCoverageSubType);
				}

				select_Exposure_Type(exposureType, excelFileName, profileID);

				/*// To make Reserve and its's Payment in Exposure level
				if (paymentOption.equalsIgnoreCase("yes")) {

					copyExposureName.getExposureName(excelFileName, profileID);
					Helper.clickActionsMenu(driver, "reserve");
					setReserve.setReserve(excelFileName, profileID);
					Helper.clickActionsMenu(driver, "check");
					payeeInfo.enterPayeeDetails(profileID);
					paymentInfo.PaymentInformationAddItemPage(excelFileName, profileID);
					checkPage.clickOnFinishAndAcceptAlert();
				}*/
			}

		} else {
			//Report.pass("Mode of Exposure isn't given to create Exposure During FNOL. Since it will do a Claim creation", "Create Claim", "Create Claim", "Create Claim");
		}
	}
	
	
	public void create_Exposure_By_Policy_Type(String excelFileName, String profileID) throws InterruptedException {
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");	
		String expectedCoverageType = xlsread.Exceldata(SheetName, "CoverageType", profileID);
		String expectedCoverageSubType = xlsread.Exceldata(SheetName, "Coverage Subtype", profileID);
		String modeOfExposure = xlsread.Exceldata(SheetName, "ExposureMode", profileID);
		String policyCoverageOptionArrowIcon = null;
		
		if(modeOfExposure.equalsIgnoreCase("post")) {			
			for(int i=0;i<=4;i++) {
				policyCoverageOptionArrowIcon = "//div[contains(@id,'MenuItemSet_ByCoverage:"+i+":item-arrowE')]";
				if(driver.findElements(By.xpath(policyCoverageOptionArrowIcon)).size()!=0) {
					String type = "//div[contains(@id,'MenuItemSet_ByCoverage:"+i+":item-arrowE')]/preceding-sibling::span";
					String policyType = driver.findElement(By.xpath(type)).getText();
					String propertyName = xlsread.Exceldata(SheetName, "propertyName", profileID);
					
					if(policyType.contains(propertyName)) {
						String policyCoverageMenu = "//div[contains(@id,'MenuItemSet_ByCoverage:"+i+":item-arrowE')]/parent::a";
						driver.findElement(By.xpath(policyCoverageMenu)).sendKeys(Keys.ARROW_RIGHT);
						Thread.sleep(500);
						
						String locationLevelCoverage = driver.findElement(By.xpath("//div[contains(@id,'AddExposure_EXT:0:item:0:item-arrowEl')]/preceding-sibling::span")).getText();
						if(locationLevelCoverage.contains("Location Level Coverages")){
							// Click on Arrow icon
							String secondSubMenuIcon = "//div[contains(@id,'AddExposure_EXT:"+i+":item:0:item-arrowEl')]/parent::a";
							driver.findElement(By.xpath(secondSubMenuIcon)).sendKeys(Keys.ARROW_RIGHT);	
						}
						xpath_To_Click_Post_ChooseByPolicy_Exposure_SubMenuitems(expectedCoverageType);
						xpath_To_Click_Post_ChooseByPolicy_Exposure_SubMenuitems(expectedCoverageSubType);						
						break;						
					} else if(policyType.contains("Policy Level Coverage")) {
						Helper.xpathToClickActionsSubMenu(driver, "Policy Level Coverage");					
						xpath_To_Click_Post_ChooseByPolicy_Exposure_SubMenuitems("Policy Level Coverage");
						xpath_To_Click_Post_ChooseByPolicy_Exposure_SubMenuitems(expectedCoverageType);
						xpath_To_Click_Post_ChooseByPolicy_Exposure_SubMenuitems(expectedCoverageSubType);
					}
					
				} else {
					Assert.fail("Choose by Policy Type option isn't available for the given policy type. Please check it...");
				}
			}
			
			
		} else if(modeOfExposure.equalsIgnoreCase("during")) {
			for(int i=0;i<=4;i++) {
				policyCoverageOptionArrowIcon = "//div[contains(@id,'AddExposure_EXT:"+i+":item-arrowEl')]";			
				if(driver.findElements(By.xpath(policyCoverageOptionArrowIcon)).size()!=0) {
					
					String type = "//div[contains(@id,'AddExposure_EXT:"+i+":item-arrowEl')]/preceding-sibling::span";
					String policyType = driver.findElement(By.xpath(type)).getText();
					String propertyName = xlsread.Exceldata(SheetName, "propertyName", profileID);
					
					if(policyType.contains(propertyName)) {
						String policyCoverageMenu = "//div[contains(@id,'AddExposure_EXT:"+i+":item-arrowEl')]/parent::a";
						driver.findElement(By.xpath(policyCoverageMenu)).sendKeys(Keys.ARROW_RIGHT);
						Thread.sleep(500);
						
						String locationLevelCoverage = driver.findElement(By.xpath("//div[contains(@id,'AddExposure_EXT:0:item:0:item-arrowEl')]/preceding-sibling::span")).getText();
						if(locationLevelCoverage.contains("Location Level Coverages")){
							// Click on Arrow icon
							String secondSubMenuIcon = "//div[contains(@id,'AddExposure_EXT:"+i+":item:0:item-arrowEl')]/parent::a";
							driver.findElement(By.xpath(secondSubMenuIcon)).sendKeys(Keys.ARROW_RIGHT);	
						}
						xpath_To_Click_During_ChooseByPolicy_Exposure_SubMenuitems(expectedCoverageType);
						xpath_To_Click_During_ChooseByPolicy_Exposure_SubMenuitems(expectedCoverageSubType);						
						break;
						
					} else if(policyType.contains("Policy Level Coverage")) {
						xpath_To_Click_During_ChooseByPolicy_Exposure_SubMenuitems("Policy Level Coverage");
						xpath_To_Click_During_ChooseByPolicy_Exposure_SubMenuitems(expectedCoverageType);
						xpath_To_Click_During_ChooseByPolicy_Exposure_SubMenuitems(expectedCoverageSubType);
					}
												
				} else {
					Assert.fail("Choose by Policy Type option isn't available for the given policy type. Please check it...");
				}
			}
		}		
	}
	

	public void select_Exposure_Type(String exposureType, String excelFileName, String profileID) throws Exception {
		
		if (exposureType.equalsIgnoreCase("Bodily Injury")) {
			bodilyInjury.validateAndEnterBodilyInjuryExposure(excelFileName, profileID);

		} else if (exposureType.equalsIgnoreCase("Loss of Use")) {
			lossOfUse.validateAndEnterLossOfUseExposure(excelFileName, profileID);

		} else if (exposureType.equalsIgnoreCase("Med Pay")) {
			medPay.validateAndEnterMedPayExposure(excelFileName, profileID);

		} else if (exposureType.equalsIgnoreCase("Personal Property")) {
			personalProperty.validateAndEnterPropertyExposure(excelFileName, profileID);

		} else if (exposureType.equalsIgnoreCase("Property")) {
			property.validateAndEnterPropertyExposure(excelFileName, profileID);

		} else if (exposureType.equalsIgnoreCase("Vehicle") | exposureType.equalsIgnoreCase("Towing & Labor")) {
			vehicle.validateAndEnterVehicleExposure(excelFileName, profileID);

		} else if(exposureType.equalsIgnoreCase("pip")) {
			pip.validateAndEnterPIPExposure(excelFileName, profileID);

		} else if(exposureType.equalsIgnoreCase("general")) {
			general.validateAndEnterGeneralExposure(excelFileName, profileID);
			
		} else {
			Assert.fail("Please provide valid exposure type...");
		}				
	}
	
	
	// Select During FNOL Choose by policy Exposure type
	public void xpath_To_Click_During_ChooseByPolicy_Exposure_SubMenuitems(String exposureName) throws InterruptedException {
		
		try {
			String subMenuItems = "//div[contains(@id,'FNOLWizard:')]/a/span[text()='"+exposureName+"']";
			if(driver.findElements(By.xpath(subMenuItems)).size()!=0) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(subMenuItems)));
				UIMethods.jscriptclickbyxpath(subMenuItems, "Click Policy Coverage Sub Type - " + exposureName, "Click");
				if(driver.findElements(By.xpath(subMenuItems+"/following-sibling::div")).size()!=0) {
					driver.findElement(By.xpath(subMenuItems)).sendKeys(Keys.ARROW_RIGHT);
					Thread.sleep(500);
				}
			} else {
				Assert.fail("Given Actions sub menu isn't available, Please check it.." + exposureName);
			}
			
		} catch(ElementNotFoundException | ElementNotVisibleException e) {
			e.printStackTrace();
		}		
	}
	
	public void xpath_To_Click_Post_ChooseByPolicy_Exposure_SubMenuitems(String exposureName) throws InterruptedException {
		try {
			String subMenuItems = "//div[contains(@id,'NewExposureMenuItemSet_ByCoverage')]/a/span[text()='"+exposureName+"']";
			if(driver.findElements(By.xpath(subMenuItems)).size()!=0) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(subMenuItems)));
				UIMethods.jscriptclickbyxpath(subMenuItems, "Click Policy Coverage Sub Type - " + exposureName, "Click");
				if(driver.findElements(By.xpath(subMenuItems+"/following-sibling::div")).size()!=0) {
					driver.findElement(By.xpath(subMenuItems)).sendKeys(Keys.ARROW_RIGHT);
					Thread.sleep(500);
				}
			} else {
				Assert.fail("Given Actions sub menu isn't available, Please check it.." + exposureName);
			}
			
		}catch(ElementNotFoundException | ElementNotVisibleException e) {
			e.getMessage();
		}
	}

}
