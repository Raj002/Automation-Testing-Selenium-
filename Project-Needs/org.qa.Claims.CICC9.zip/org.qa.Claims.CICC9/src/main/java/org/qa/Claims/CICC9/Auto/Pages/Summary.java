package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class Summary {

	private WebDriver driver = null;
	WebDriverWait wait;

	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	//Page Objects
	String claimStatusLink = "ClaimSummaryGroup:MenuLinks:ClaimSummaryGroup_ClaimStatus";
	String lossDetails = "//a[@id='Claim:MenuLinks:Claim_ClaimLossDetailsGroup']/div";
	String summary = "//a[@id='Claim:MenuLinks:Claim_ClaimSummaryGroup']/div";
	
	public Summary(WebDriver driver) {
		this.driver = driver;
	}

	public void Summarypage() throws Exception {
		Thread.sleep(2000);
		Helper.highLightElement(driver, driver.findElement(By.xpath(lossDetails)));
		Helper.clickClaimSubMenu(driver, "loss details");
	}

	public void ClickSummary() throws Exception {
		Thread.sleep(2000);
		Helper.highLightElement(driver, driver.findElement(By.xpath(summary)));
		Helper.clickClaimSubMenu(driver, "summary");
	}

	public void VerifyLossDate(String excelFileName, String profileID) throws Exception{		
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String lblLossDate = xlsread.Exceldata(SheetName, "lblLossDate", profileID);
			
		String actualLossDate = driver.findElement(By.id("ClaimSummary:ClaimSummaryScreen:ClaimSummaryDV:LossDate")).getText();
		if (actualLossDate.equalsIgnoreCase(lblLossDate)) {
			Report.pass("Verify Text", "Financial transacion", lblLossDate + " should available in Loss Date", actualLossDate + " is exist in Loss Date");
		} else {
			Report.fail("Verify Text", "Financial transacion", lblLossDate + " should available in Loss Date", actualLossDate + " is not same as in Loss Date");
		}	
	}
		
	public void VerifyClaimStatus(String excelFileName, String profileID) throws Exception{
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String lblClaimStatus = xlsread.Exceldata(SheetName, "lblClaimStatus", profileID);
		
		Helper.highLightElement(driver, driver.findElement(By.id(claimStatusLink)));
		UIMethods.clickbyid(claimStatusLink, "click Claim Status", "Click");
		Thread.sleep(2000);
			
		String actualClaimStatus = driver.findElement(By.id("ClaimStatus:ClaimStatus")).getText();
		if (actualClaimStatus.equalsIgnoreCase(lblClaimStatus)) {
			Report.pass("Verify Text", "Financial transacion", lblClaimStatus + " should available in Claim Status", actualClaimStatus + " is exist in Claim Status");
		} else {
			Report.fail("Verify Text", "Financial transacion", lblClaimStatus + " should available in Claim Status", actualClaimStatus + " is not same as in Claim Status");
		}	
	}
}