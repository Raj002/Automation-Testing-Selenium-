package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class AddSource {

	private WebDriver driver = null;
	WebDriverWait wait;
	String projectdir = System.getProperty("user.dir");
	String SheetName = "ClaimsPolicy";

	// Page Objects
	String descriptionField = "NewFixPropAssessSourcePopup:EditAssessmentSourceScreen:FixPropAssessSourceDetailsDV:General_Name";
	String inputSource = "NewFixPropAssessSourcePopup:EditAssessmentSourceScreen:FixPropAssessSourceDetailsDV:Source";
	String okButton = "NewFixPropAssessSourcePopup:EditAssessmentSourceScreen:Update";
	String assessorLink = "NewFixPropAssessSourcePopup:EditAssessmentSourceScreen:FixPropAssessSourceDetailsDV:InternalAssessor_AssigneeInput:InternalAssessor_AssigneeInput_PickerButton";
	

	public AddSource(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}

	public void AddSourcepage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtSourceName = xlsread.Exceldata(SheetName, "txtSourceName", profileID);
		String ddlGeneralSource = xlsread.Exceldata(SheetName, "ddlGeneralSource", profileID);
		String ddlSourceIncidentType = xlsread.Exceldata(SheetName, "ddlSourceIncidentType", profileID);
		String ddlDeckAdjuster = xlsread.Exceldata(SheetName, "ddlDeckAdjuster", profileID);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(descriptionField)));
		UIMethods.inputbyid(descriptionField, "Input Description", txtSourceName);

		UIMethods.selectbyid(inputSource, "Input Source", ddlGeneralSource);
        UIMethods.selectbyid("NewFixPropAssessSourcePopup:EditAssessmentSourceScreen:FixPropAssessSourceDetailsDV:IncidentType", "Input Incident Type", ddlSourceIncidentType);        
        UIMethods.selectbyid("NewFixPropAssessSourcePopup:EditAssessmentSourceScreen:FixPropAssessSourceDetailsDV:deskadjuster", "Input Deck Adjuster", ddlDeckAdjuster);        
        UIMethods.clickbyid(okButton, "Click OK Button", "Click");
        Thread.sleep(3000);        
     }
	
	public void AddSourceWithAssessor(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtSourceName = xlsread.Exceldata(SheetName, "txtSourceName", profileID);
		String ddlGeneralSource = xlsread.Exceldata(SheetName, "ddlGeneralSource", profileID);
		String txtSearchUserName = xlsread.Exceldata(SheetName, "txtSearchUserName", profileID);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(descriptionField)));
		UIMethods.inputbyid(descriptionField, "Input Description", txtSourceName);
		UIMethods.selectbyid(inputSource, "Input Source", ddlGeneralSource);
		Thread.sleep(2000);
		Helper.highLightElement(driver, driver.findElement(By.id(assessorLink)));
        UIMethods.clickbyid(assessorLink, "Click Assessor Icon", "Click");
        Thread.sleep(2000);
        
        UIMethods.inputbyid("AssigneePickerPopup:AssigneePickerScreen:AssignmentSearchDV:Username", "Input Username", txtSearchUserName);
        Thread.sleep(2000);
        UIMethods.clickbyid("AssigneePickerPopup:AssigneePickerScreen:AssignmentSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search_link", "Click Search Button", "Click");
        Thread.sleep(2000);
        UIMethods.clickbyid("AssigneePickerPopup:AssigneePickerScreen:AssignmentUserLV:0:_Select_link", "Click Search Button", "Click");
        Thread.sleep(2000);
        UIMethods.clickbyid(okButton, "Click OK Button", "Click");
        Thread.sleep(3000);        
     }	
}