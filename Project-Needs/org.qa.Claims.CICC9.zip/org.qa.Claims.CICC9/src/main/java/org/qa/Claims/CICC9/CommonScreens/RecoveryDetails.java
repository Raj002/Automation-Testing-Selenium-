package org.qa.Claims.CICC9.CommonScreens;

import org.qa.Claims.CICC9.Technology.UIMethods;

public class RecoveryDetails {
	
	public void recoverydetailsvoid() throws Exception{
        Thread.sleep(1000);
        UIMethods.clickbyxpath("//*[@id='ClaimFinancialsTransactionsDetail:ClaimFinancialsTransactionsDetailScreen:TransactionDetailToolbarButtonSet:TransactionDetailToolbarButtons_VoidButton']/span[2]", "click void button", "Click");
        Thread.sleep(2000);
	}
	
	public void recoverydetailsrecode() throws Exception{
        Thread.sleep(1000);
        UIMethods.clickbyxpath("//*[@id='ClaimFinancialsTransactionsDetail:ClaimFinancialsTransactionsDetailScreen:TransactionDetailToolbarButtonSet:TransactionDetailToolbarButtons_RecodeButton']", "click recode button", "Click");
        Thread.sleep(2000);
	}
	
	public void recoveryDetailsTransfer() throws Exception{
        Thread.sleep(1000);
        UIMethods.clickbyxpath("//*[@id='ClaimFinancialsTransactionsDetail:ClaimFinancialsTransactionsDetailScreen:TransactionDetailToolbarButtonSet:TransactionDetailToolbarButtons_TransferButton']", "Click Transfer Button", "Click");
        Thread.sleep(2000);
	}
}