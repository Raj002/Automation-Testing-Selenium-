package org.qa.Claims.CICC9.CommonScreens;

import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class Subrogation {
		
	public void Subrogationpage(String excelFileName, String profileID) throws Exception{
		String SheetName = "ClaimsPolicy";
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		
		String ddlResponsibleParty = xlsread.Exceldata(SheetName, "ddlResponsibleParty", profileID);
		String txtResponsibleLiability = xlsread.Exceldata(SheetName, "txtResponsibleLiability", profileID);
		String ddlStatuteType = xlsread.Exceldata(SheetName, "ddlStatuteType", profileID);
		String ddlStatuteState = xlsread.Exceldata(SheetName, "ddlStatuteState", profileID);
		String ddlExternalSubrogator = xlsread.Exceldata(SheetName, "ddlExternalSubrogator", profileID);
		
		UIMethods.clickbyid("Claim:MenuLinks:Claim_ClaimSubrogationGroup", "Click Subrogation Left Menu", "Click");
		Thread.sleep(1000);
		
		UIMethods.clickbyid("SubrogationGeneral:ClaimSubroSummaryScreen:Edit", "Click Edit button", "Click");
		Thread.sleep(2000);
		
		UIMethods.clickbyid("SubrogationGeneral:ClaimSubroSummaryScreen:SubrogationMainDV:AdversePartyInfo:EditableAdverseGeneralLV_tb:Add", "Click Add Responsibilities Party button", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyid("SubrogationGeneral:ClaimSubroSummaryScreen:SubrogationMainDV:AdversePartyInfo:EditableAdverseGeneralLV:0:_Checkbox", "Click Responsibility Checkbox", "Click");
		UIMethods.selectbyid("SubrogationGeneral:ClaimSubroSummaryScreen:SubrogationMainDV:AdversePartyInfo:EditableAdverseGeneralLV:0:AdverseParty", "Input Party", ddlResponsibleParty);
		UIMethods.inputbyid("SubrogationGeneral:ClaimSubroSummaryScreen:SubrogationMainDV:AdversePartyInfo:EditableAdverseGeneralLV:0:LiabilityPercentage", "Input Liability", txtResponsibleLiability);
		
		
		UIMethods.clickbyid("SubrogationGeneral:ClaimSubroSummaryScreen:SubrogationMainDV:StatuteLimitations:EditableStatuteLV_tb:Add", "Click Add Statute of Limitations", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyid("SubrogationGeneral:ClaimSubroSummaryScreen:SubrogationMainDV:StatuteLimitations:EditableStatuteLV:0:_Checkbox", "Click Statute Checkbox", "Click");
		UIMethods.selectbyid("SubrogationGeneral:ClaimSubroSummaryScreen:SubrogationMainDV:StatuteLimitations:EditableStatuteLV:0:StatuteLimitType", "Input Type", ddlStatuteType);
		UIMethods.selectbyid("SubrogationGeneral:ClaimSubroSummaryScreen:SubrogationMainDV:StatuteLimitations:EditableStatuteLV:0:JurisdictionState", "Input State", ddlStatuteState);
		
		UIMethods.clickbyid("SubrogationGeneral:ClaimSubroSummaryScreen:SubrogationMainDV:SubroExternalOwner_true", "Click Externally Owned?", "Click");
		Thread.sleep(2000);
		UIMethods.selectbyid("SubrogationGeneral:ClaimSubroSummaryScreen:SubrogationMainDV:Subrogator", "Input Subrogator", ddlExternalSubrogator);
		
        UIMethods.clickbyxpath("//span[text()='pdate']", "click Update button", "Click");
        Thread.sleep(3000);
	}		
}