package org.qa.Claims.CICC9.Property.Pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.CommonScreens.NewExposureEntry;
import org.qa.Claims.CICC9.CommonScreens.NewPersonContactDetail;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class Exposure_Personal_Property extends Object_Repositories {
	public WebDriver driver;

	// Page objects
	String severityDropdown = "//input[contains(@id,'GeneralDamage_Severity-inputEl')]";
	String propertyDescription = "//*[@id='NewClaimWizard_NewExposurePopup:NewClaimWizard_ExposurePageScreen:NewClaimExposureDV:NewClaimThirdPartyPropertyDamageDV:PropertyDescription-inputEl']";
	String damageDescription = "//textarea[contains(@id,'Description-inputEl')]";

	public Exposure_Personal_Property(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}

	public void validateAndEnterPropertyExposure(String excelFileName, String profileID) throws Exception {
		NewPersonContactDetail newperson = new NewPersonContactDetail(driver);
		NewPropertyIncident newProperty = new NewPropertyIncident(driver);

		xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String expectedCoverageType = xlsread.Exceldata(SheetName, "CoverageType", profileID);
		String expectedCoverageSubType = xlsread.Exceldata(SheetName, "Coverage Subtype", profileID);
		String txtclaimantType = xlsread.Exceldata(SheetName, "txtClaimantType", profileID);
		String claimantNameOption = xlsread.Exceldata(SheetName, "claimantNameOption", profileID);
		String claimantNameVendorOption = xlsread.Exceldata(SheetName, "newVendorOptions", profileID);
		String claimantNameLegalOption = xlsread.Exceldata(SheetName, "newVendorOptions", profileID);
		String severityOption = xlsread.Exceldata(SheetName, "ddlSeverity", profileID);
		String propertyDesc = xlsread.Exceldata(SheetName, "peopertyDescription", profileID);
		String damageDesc = xlsread.Exceldata(SheetName, "damageDescription", profileID);
		String modeOfExposure = xlsread.Exceldata(SheetName, "ExposureMode", profileID);
		String lobType = xlsread.Exceldata(SheetName, "LOBType", profileID);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newExposureTitle)));

		if (driver.findElements(By.xpath(primaryCoverage)).size() != 0) {
			String actualPrimaryCoverage = driver.findElement(By.xpath(primaryCoverage)).getText();
			Assert.assertEquals(actualPrimaryCoverage, expectedCoverageType);
		}

		if (driver.findElements(By.xpath(coverageSubType)).size() != 0) {
			String actualCoverageSubType = driver.findElement(By.xpath(coverageSubType)).getText();
			
			// This will remove the extra white spaces between the sentences
			if (actualCoverageSubType.contains("'") | expectedCoverageSubType.contains("'")) {
				String actual = actualCoverageSubType.replace(" ", "");
				String expected = expectedCoverageSubType.replace(" ", "");
				Assert.assertTrue(actual.contains(expected));
			} else {
				Assert.assertEquals(actualCoverageSubType, expectedCoverageSubType);
			}
		}

		UIMethods.jscriptclickbyxpath(riskUnit, "Select Coverage / Risk unit", "Click");
		Thread.sleep(1000);
		if (driver.findElements(By.xpath(firstDropdownOption)).size() != 0) {
			driver.findElement(By.xpath(firstDropdownOption)).click();
		}

		if (lobType.equalsIgnoreCase("property")) {
			for (int i = 0; i <= 4; i++) {
				try {
					Assert.assertTrue(Helper.getUIXpath(driver, "Coverage / Risk Unit").isDisplayed());
					// Address Number is now changed to Location Number
					Assert.assertTrue(Helper.getUIXpath(driver, "Location Number").isDisplayed());
					Assert.assertTrue(Helper.getUIXpath(driver, "Building Number").isDisplayed());
				} catch (StaleElementReferenceException e) {
					e.getMessage();
				}
			}
		}
				
		// Validate UI frm this screen
		Thread.sleep(1000);		
		Assert.assertTrue(Helper.getUIXpath(driver, "Potential Large Loss?").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "CERC Exposure").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Reservation of Rights").isDisplayed());
		
		if(lobType.equalsIgnoreCase("property")) {
			Assert.assertTrue(Helper.getUIXpath(driver, "Coverage on Excess Basis").isDisplayed());
		}
		
		Assert.assertTrue(Helper.getUIXpath(driver, "Claimant").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Type").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Contact Prohibited?").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Primary Phone").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Address").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Severity").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Property Description").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Damage Description").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Loss Estimate").isDisplayed());

		// Validate Line items table
		Assert.assertTrue(Helper.getUIXpath(driver, "Qty").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Item").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Category").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Orig Cost (total)$").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Purchase Date").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Age in Years").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Depr. %").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Repl. Value. (total)$").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "ACV (total)$").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Holdback $").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Limit Amount$").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Tax%").isDisplayed());

		if (driver.findElement(By.xpath(lossParty)) != null) {
			String actualLossParty = driver.findElement(By.xpath(lossParty)).getText();
			if (actualLossParty.contains("Insured's loss")) {

				String insuredName = driver.findElement(By.xpath(getInsuredName)).getText();
				String actualInsuredName = insuredName.substring(5).trim();

				Helper.selectDropdownValue(driver, "xpath", claimantNameField, "Select Claimant", actualInsuredName);
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(claimantTypeField)));
				
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(severityDropdown)));
				UIMethods.clearAndinputbyxpath(severityDropdown, "Select Severity Option", severityOption);
				Thread.sleep(2000);
				UIMethods.inputbyxpath(damageDescription, "Enter Damage Description", damageDesc);
				
				/*// Add Line item details
				if(driver.findElements(By.xpath("//div[contains(@id,'gridview-')]/div/table[1]/tbody/tr/td[1]")).size()!=0) {
					Helper.clickTableColumnRow("3", "LineItemName", "Click/Select Line item name", "Line Item1");
					Helper.clickCheckBox(commonCheckBox, "Click Line item chek box");
					Helper.clickTableColumnRow("4", "LineItemCategory", "Click/Select Line item category", "Other");
					driver.findElement(By.xpath(damageDescription)).click();
				}	*/			
				
			} else if (actualLossParty.contains("Third-party")) {
				UIMethods.clickbyxpath(claimantArrowIcon, "Click Claimant arrow icon", "Click");
				Thread.sleep(1000);
				switch (claimantNameOption.toLowerCase()) {

				case "new person":
					UIMethods.clickbyWebElement(Helper.getUIXpath(driver, "New Person"), "Select New Person option","Click");
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewContactPopup:ContactDetailScreen:ttlBar")));
					newperson.NewPersonContactDetailpage(excelFileName, profileID);
					break;
				case "new vendor":
					UIMethods.clickbyWebElement(Helper.getUIXpath(driver, "New Vendor"), "Select New Vendor option","Click");
					Helper.getUIXpath(driver, "New Vendor").sendKeys(Keys.ARROW_RIGHT);
					NewExposureEntry.enterVendorDetails(claimantNameVendorOption, excelFileName, profileID);
					break;
				case "new company":
					UIMethods.clickbyWebElement(Helper.getUIXpath(driver, "New Company"), "Select New Company option","Click");
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewContactPopup:ContactDetailScreen:ttlBar")));
					newperson.NewPersonContactDetailpage(excelFileName, profileID);
					break;
				case "new legal":
					UIMethods.clickbyWebElement(Helper.getUIXpath(driver, "New Legal"), "Select New Legal option","Click");
					Helper.getUIXpath(driver, "New Legal").sendKeys(Keys.ARROW_RIGHT);
					NewExposureEntry.enterNewLegalDetails(claimantNameLegalOption, excelFileName, profileID);
					break;
				case "search":
					UIMethods.clickbyWebElement(Helper.getUIXpath(driver, "Search"), "Select Search option", "Click");
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("AddressBookPickerPopup:AddressBookSearchScreen:ttlBar")));

					// TO-DO Need to work application issue Search address book screen

					break;
				case "view contact details":
					UIMethods.clickbyWebElement(Helper.getUIXpath(driver, "View Contact Details"),"Select View Contact Details option", "Click");
					if (driver.findElements(By.xpath("//a[contains(@id,'ClaimContactDetailPopup:_')]")).size() != 0) {
						UIMethods.jscriptclickbyxpath("//a[contains(@id,'ClaimContactDetailPopup:_')]","Click Return to exposure link", "Click");
					}
					break;
				default:
					Assert.fail("Please provide the valid name to select claimant name options");
					break;
				}

				// Select Claimant Type
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(claimantTypeField)));
				Helper.selectDropdownValue(driver, "xpath", claimantTypeField, "Select Claimant Type", txtclaimantType);
				
				if(driver.findElements(By.xpath(severityDropdown)).size()!=0) {
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(severityDropdown)));
					UIMethods.clearAndinputbyxpath(severityDropdown, "Select Severity Option", severityOption);
					Thread.sleep(2000);
					UIMethods.inputbyxpath(damageDescription, "Enter Damage Description", damageDesc);
				}
				
				// To Enter Property name details
				if(driver.findElements(By.xpath(propertyNameArrowIcon)).size()!=0) {
					//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(@id,'ClaimContactDetailPopup:_')]")));
					UIMethods.jscriptclickbyxpath(propertyNameArrowIcon, "Click Property Name Arrow Icon", "Click");
					UIMethods.clickbyWebElement(Helper.getUIXpath(driver, "New Incident..."), "Select New Incident option","Click");
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Return to New Exposure')]")));
					Thread.sleep(2000);				
					newProperty.PropertyIncidentPage(excelFileName, profileID);
				}
				
			} else {
				Report.fail("Loss Party isn't available in Exposure screen", "Loss Party", "Loss Party","Loss Party not available");
				Assert.fail("Loss Party is not available..");
			}
		} else {
			Report.fail("Loss Party isn't available in Exposure screen", "Loss Party", "Loss Party","Loss Party not available");
			Assert.fail("Loss Party is not available..");
		}

		// Click on OK Button from New Exposure Screen
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newExposureTitle)));
		driver.findElement(By.xpath(newExposureTitle)).click();
		Thread.sleep(500);

		Helper.getScreenshot(driver, "Personal_Property_Exposure",  modeOfExposure+"_TC_" +profileID+ "_");
		
		// Click OK Button During FNOL
		if (driver.findElements(By.xpath(okButton)).size() != 0) {
			UIMethods.jscriptclickbyxpath(okButton, "Click OK Button", "Click");
		}

		// Click Update Button Post FNOL
		if (driver.findElements(By.xpath(updateButton)).size() != 0) {
			UIMethods.jscriptclickbyxpath(updateButton, "Click Update Button", "Click");
		}

		// Writing Exposure created status into the Excel sheet in Status Column for
		// both during and post FNOL
		if (driver.findElements(By.xpath(saveAndAssignClaimLabel)).size() != 0 | driver.findElements(By.xpath(exposureScreenLabel)).size() != 0) {
			if (modeOfExposure.equalsIgnoreCase("during")) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(saveAndAssignClaimLabel)));
				if(driver.findElements(By.xpath(saveAndAssignClaimLabel)).size()!=0) {
					xlsread.WriteIntoExistingExcel(SheetName, "personalPropertyStatus", "Pass", profileID, true);
					xlsread.WriteIntoExistingExcel(SheetName, "statusForAllExposures", "Pass", profileID, true);
				} else {
					xlsread.WriteIntoExistingExcel(SheetName, "personalPropertyStatus", "Fail", profileID, false);
					xlsread.WriteIntoExistingExcel(SheetName, "statusForAllExposures", "Fail", profileID, false);
				}
			} 
			
			if (modeOfExposure.equalsIgnoreCase("post")) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(exposureScreenLabel)));
				if(driver.findElements(By.xpath(exposureScreenLabel)).size()!=0) {
					xlsread.WriteIntoExistingExcel(SheetName, "personalPropertyStatus", "Pass", profileID, true);
					xlsread.WriteIntoExistingExcel(SheetName, "statusForAllExposures", "Pass", profileID, true);
				} else {
					xlsread.WriteIntoExistingExcel(SheetName, "personalPropertyStatus", "Fail", profileID, false);
					xlsread.WriteIntoExistingExcel(SheetName, "statusForAllExposures", "Fail", profileID, false);
				}
			}
			
			
		}
	}
}
