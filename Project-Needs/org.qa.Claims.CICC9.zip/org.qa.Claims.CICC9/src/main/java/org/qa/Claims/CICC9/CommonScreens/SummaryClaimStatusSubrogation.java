package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class SummaryClaimStatusSubrogation {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	public SummaryClaimStatusSubrogation(WebDriver driver)
	{
		this.driver = driver;
	}	
	
	public void SummarySubrogationpage(String excelFileName, String profileID) throws Exception{
		String SheetName = "ClaimsPolicy";
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");		
		String ddlSubrogationStatus = xlsread.Exceldata(SheetName, "ddlSubrogationStatus", profileID);
		
		UIMethods.clickbyid("Claim:MenuLinks:Claim_ClaimSummaryGroup", "Click Summary Left Menu", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyid("ClaimSummaryGroup:MenuLinks:ClaimSummaryGroup_ClaimStatus", "Click Claim Status Link", "Click");
		Thread.sleep(2000);
		UIMethods.clickbyid("ClaimStatus:Edit", "Click Edit Claim Status button", "Click");
		UIMethods.selectbyid("ClaimStatus:SubrogationStatus", "Input Subrogation Status", ddlSubrogationStatus);
		Thread.sleep(2000);
		UIMethods.clickbyid("ClaimStatus:3:ClaimIndicatorInputSet:CoverageInQuestion_false", "Click Coverage Question", "Click");
		Thread.sleep(500);
        UIMethods.clickbyxpath("//span[text()='pdate']", "click Update button", "Click");
        Thread.sleep(3000);
	}
		
}