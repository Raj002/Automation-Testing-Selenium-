package org.qa.Claims.CICC9.CommonScreens;


import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.FetchPropertiesFiles;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;
import org.testng.Assert;

public class SearchCreatePolicy extends Object_Repositories{

	public WebDriver driver = null;
	
	String strTime = "12:00 AM";
	String txtPolicyAccountNumber;
	String txtPolicyType;
	String txtSearchType;
	String txtLossDate;
	
	// Find Ploicy Page Objects
	String createUVPolicyRadioButton = "#FNOLWizard:FNOLWizard_FindPolicyScreen:ScreenMode_false-inputEl";
	String policyAccountNumber = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:policyNumber-inputEl";
	String policyType = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:PolicyType-inputEl";
	String lossDateField = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:date-inputEl";
	String searchButton = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:Search";
	String resetButton = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:Reset";		
	String typeOfClaimProperty = "//input[@id='FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:ClaimMode_option1-inputEl']";
	
	
	String inputTime = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:Claim_lossTime";
	String policyState = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:PolicyState";
	String agencyCodeTextBox = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:ProducerCode";
	String uwCompany = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:UW_CompRangeInput";
	String policyLevelCoverageTextBox = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:EditableGeneralLiabilityPolicyCoveragesLV:0:CoverageType";
	String lossDateTextBox = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:Claim_LossDate";
	String agencyValidateCode = "//table[@id='FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:5']/tbody/tr[11]/td[5]/a/span[2]";
	
	// Create Unverified Policy Page objects
	String sourceSystem = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:SourceSystem-inputEl";
	String UNpolicySymbol = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:policySymbol-inputEl";
	String UNpolicyAccountNumber = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:policyAccountNumber-inputEl";
	String UNPolicyType = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:Type-inputEl";
	String UNLossDate = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:Claim_LossDate-inputEl";
	String UNEffectiveDate = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:EffectiveDate-inputEl";
	String UNExpirationDate = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:ExpirationDate-inputEl";
	String UNOriginalEffectiveDate = "FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:OrigEffectiveDate-inputEl";
	
	
	public SearchCreatePolicy(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 40);
	}

	public void search_Policy_During_Post_FNOL(String excelFileName, String profileID) throws InterruptedException, IOException {
		xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		txtPolicyAccountNumber = xlsread.Exceldata(SheetName, "txtPolAccNo", profileID);
		txtPolicyType = xlsread.Exceldata(SheetName, "txtPolType", profileID);
		txtLossDate = xlsread.Exceldata(SheetName, "txtLossDate", profileID);
		String txtLOBType = xlsread.Exceldata(SheetName, "LOBType", profileID);
		
		UIMethods.inputbyid(policyAccountNumber,"Enter Policy Number", txtPolicyAccountNumber);
		Helper.selectDropdownValue(driver, "id", policyType, "Select Policy type", txtPolicyType);		
		Helper.enterDate(driver, lossDateField,"Enter loss date", txtLossDate);
		UIMethods.clickbyid(searchButton,"Click search button", "Click");	
		
		Helper.waitForLoad(driver);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:PolicyResultLV-body']/div/div/table/tbody")));
		
		if(txtPolicyType.equalsIgnoreCase("Boiler & Machinery") || txtPolicyType.equalsIgnoreCase("Inland Marine - CL") || txtPolicyType.equalsIgnoreCase("Crime") || txtPolicyType.equalsIgnoreCase("Burglary & Theft") || txtPolicyType.equalsIgnoreCase("Commercial Property")) {
			
			if(txtLOBType.equalsIgnoreCase("property")) {
				clickTypeOfClaimRadioButton(0, txtLOBType);
				Thread.sleep(1000);
			} else if(txtLOBType.equalsIgnoreCase("Property - Quick Claim Property")) {
				clickTypeOfClaimRadioButton(1, txtLOBType);
				Thread.sleep(1000);
			}
			
		} else if(txtPolicyType.equalsIgnoreCase("Business Owners Policy") || txtPolicyType.equalsIgnoreCase("Commercial Package Policy") || txtPolicyType.equalsIgnoreCase("Commercial Auto") || txtPolicyType.equalsIgnoreCase("Commercial Farm")) {
			
			if(txtLOBType.equalsIgnoreCase("general liability")) {
				clickTypeOfClaimRadioButton(0, txtLOBType);
				Thread.sleep(1000);
			} else if(txtLOBType.equalsIgnoreCase("property")) {
				clickTypeOfClaimRadioButton(1, txtLOBType);
				Thread.sleep(1000);
			} else if(txtLOBType.equalsIgnoreCase("Property - Quick Claim Property")) {
				clickTypeOfClaimRadioButton(2, txtLOBType);
				Thread.sleep(1000);
			}
			
		} else if(txtPolicyType.equalsIgnoreCase("Commercial Business Package") || txtPolicyType.equalsIgnoreCase("Garage Coverage Form")) {
			
			if(txtLOBType.equalsIgnoreCase("Auto")) {
				clickTypeOfClaimRadioButton(0, txtLOBType);
				Thread.sleep(1000);
			} else if(txtLOBType.equalsIgnoreCase("Auto - Quick Claim Auto")) {
				clickTypeOfClaimRadioButton(1, txtLOBType);
				Thread.sleep(1000);
			} else if(txtLOBType.equalsIgnoreCase("Auto - First and Final")) {
				clickTypeOfClaimRadioButton(2, txtLOBType);
				Thread.sleep(1000);
			} else if(txtLOBType.equalsIgnoreCase("general liability")) {
				clickTypeOfClaimRadioButton(3, txtLOBType);
				Thread.sleep(1000);
			} else if(txtLOBType.equalsIgnoreCase("property")) {
				clickTypeOfClaimRadioButton(4, txtLOBType);
				Thread.sleep(1000);
			} else if(txtLOBType.equalsIgnoreCase("Property - Quick Claim Property")) {
				clickTypeOfClaimRadioButton(5, txtLOBType);
				Thread.sleep(1000);
			}			
		}
		
		if(driver.findElements(By.xpath("//div[@class='message']")).size()!=0) {
			String actualErrorMessage  = driver.findElement(By.xpath("//div[@class='message']")).getText();
			if(actualErrorMessage.contains("Errors detected in Policy Search XML. An issue was encountered in the search functionality")) {
				UIMethods.jscriptclickbyxpath("//a[@id='FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:PolicyResultLV:0:selectButton']", "Click on first search result", "Click");
				Thread.sleep(1000);
			}
		}
		
		Helper.waitForLoad(driver);
		Thread.sleep(3000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(nextButton)));
		UIMethods.jscriptclickbyxpath(nextButton, "Click Next Button", "Click");
				
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='FNOLWizard:Prev']")));
	}
	
	/**
	 * Search or Create policy using policy number, policy type and it's loss date
	 * @param excelFileName - valid file name to get data from excel sheet
	 * @param profileID - based on the given profileID (row id in Excel) it will get data from the excel sheet 
	 *
	 */
	public void SearchCreatePolicypage(String excelFileName, String profileID) throws Exception {		
		xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		txtPolicyAccountNumber = xlsread.Exceldata(SheetName, "txtPolAccNo", profileID);
		txtPolicyType = xlsread.Exceldata(SheetName, "txtPolType", profileID);
		txtLossDate = xlsread.Exceldata(SheetName, "txtLossDate", profileID);
		String exposureType = xlsread.Exceldata(SheetName, "ExposureType", profileID);
		
		UIMethods.inputbyid(policyAccountNumber,"Enter Policy Number", txtPolicyAccountNumber);
		Helper.selectDropdownValue(driver, "id", policyType, "Select Policy type", txtPolicyType);		
		Helper.enterDate(driver, lossDateField,"Enter loss date", txtLossDate);
		UIMethods.clickbyid(searchButton,"Click search button", "Click");
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:PolicyResultLV-body']/div/div/table/tbody")));
				
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(nextButton)));
		UIMethods.jscriptclickbyxpath(nextButton, "Click Next Button", "Click");
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='FNOLWizard:Prev']")));
	}

	public void SearchCreatePolicyGLpage(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		txtPolicyAccountNumber = xlsread.Exceldata(SheetName, "txtPolAccNo", profileID);
		txtPolicyType = xlsread.Exceldata(SheetName, "txtPolType", profileID);
		txtLossDate = xlsread.Exceldata(SheetName, "txtLossDate", profileID);
		
		UIMethods.inputbyid(policyAccountNumber,"Input Policy Accont Number", txtPolicyAccountNumber);
		Helper.selectDropdownValue(driver, "id", policyType, "Select Policy type", txtPolicyType);		
		Helper.enterDate(driver, lossDateField,"Enter loss date", txtLossDate);
		UIMethods.clickbyid(searchButton,"Click search button", "Click");	
		
		Thread.sleep(3000);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(nextButton)));
		UIMethods.jscriptclickbyxpath(nextButton, "Click Next Button", "Click");
	}

	public void SearchCreateUnverifiedAutoPolicyPage(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtAgencyCode = xlsread.Exceldata(SheetName, "txtAgencyCode", profileID);
		String ddlPolicyState = xlsread.Exceldata(SheetName, "ddlPolicyState", profileID);
		String ddlUWCompany = xlsread.Exceldata(SheetName, "ddlUWCompany", profileID);
		
		wait.until(ExpectedConditions.elementToBeClickable(By.id(policyState)));
		Thread.sleep(3000);
		UIMethods.selectbyid(policyState,"Input Policy State", ddlPolicyState);
		Thread.sleep(3000);
		/*Helper.clearTextBox(driver, driver.findElement(By.id(inputTime)));
		UIMethods.inputbyid(inputTime, "Input Time","12:00 AM");*/
		Helper.enterTime(driver, inputTime, "Enter Time", strTime);
		wait.until(ExpectedConditions.elementToBeClickable(By.id(agencyCodeTextBox)));
		Helper.clearTextBox(driver, driver.findElement(By.id(agencyCodeTextBox)));
		
		if (!(txtAgencyCode.isEmpty())) {
			String strExecutionType = (FetchPropertiesFiles.executionMode).toString();
			if (strExecutionType.equalsIgnoreCase("Saucelab")) {
				UIMethods.inputbyid(agencyCodeTextBox,"input Agency Code", txtAgencyCode);
			} else {
				UIMethods.inputbyid(agencyCodeTextBox,"input Agency Code", txtAgencyCode);
			}
		}		
		Thread.sleep(8000);
		
		//Validate Agency Code - Added by RAJ
		Helper.highLightElement(driver, driver.findElement(By.xpath(agencyValidateCode)));
		UIMethods.jscriptclickbyxpath(agencyValidateCode, "Click Validate Agency Code", "Click");
		Thread.sleep(8000);
		UIMethods.selectbyid(uwCompany,"Input UW Company", ddlUWCompany);

		for (int intLoop = 1; intLoop <= 7; intLoop++) {
			
			Helper.enterTime(driver, inputTime, "Enter Time", strTime);
			Thread.sleep(2000);
			UIMethods.clickbyxpath("//*[text()='Next >']", "Click Next", "Click");
			Thread.sleep(5000);
			if (driver.findElements(By.xpath("//*[text()='Close']")).size() > 0) {
				UIMethods.jscriptclickbyxpath("//*[text()='Close']", "Click Close Option", "Click");
				Thread.sleep(3000);
			}
			try {
				driver.findElement(By.xpath("//*[text()='Step 1 of 5: Search or Create Policy']")).isDisplayed();
			} catch (Exception Ex) {
				break;
			}
			Thread.sleep(3000);
		}
	}

	public void SearchPolicyAUFFpage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		txtPolicyAccountNumber = xlsread.Exceldata(SheetName, "txtPolAccNo", profileID);
		txtPolicyType = xlsread.Exceldata(SheetName, "txtPolType", profileID);
		txtSearchType = xlsread.Exceldata(SheetName, "txtSearchType", profileID);
		txtLossDate = xlsread.Exceldata(SheetName, "txtLossDate", profileID);
		
		UIMethods.inputbyid(policyAccountNumber,"Enter Policy Number", txtPolicyAccountNumber);
		Helper.selectDropdownValue(driver, "id", policyType, "Select Policy Type", txtPolicyType);
		Helper.enterDate(driver, lossDateField,"Enter loss date", txtLossDate);	
		UIMethods.clickbyid(searchButton,"Click search button", "Click");			
		
		UIMethods.jscriptclickbyxpath("//input[@id='FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:ClaimMode_option1-inputEl']","Select first Auto and Final", "Click");
			
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(nextButton)));
		UIMethods.jscriptclickbyxpath(nextButton, "Click Next Button", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:ttlBar")));
	}

	public void SearchCreateUnverifiedPolicypage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlSourceSystem = xlsread.Exceldata(SheetName, "ddlSourceSystem", profileID);
		String txtPolicySymbol = xlsread.Exceldata(SheetName, "txtPolicySymbol", profileID);
		txtPolicyAccountNumber = xlsread.Exceldata(SheetName, "txtPolicyAccountNo", profileID);
		String txtPolicyType = xlsread.Exceldata(SheetName, "txtPolicyType", profileID);
		txtLossDate = xlsread.Exceldata(SheetName, "txtLossDate", profileID);
		String txtEffectiveDate = xlsread.Exceldata(SheetName, "txtEffectiveDate", profileID);
		String txtExpirationDate = xlsread.Exceldata(SheetName, "txtExpirationDate", profileID);
		String txtOriginalEffectiveDate = xlsread.Exceldata(SheetName, "txtOriginalEffectiveDate", profileID);

		UIMethods.clickbyid(createUVPolicyRadioButton, "Click Create Unverified Policy Radio", "Click");
		wait.until(ExpectedConditions.elementToBeClickable(By.id(sourceSystem)));
		Helper.selectDropdownValue(driver, "id", sourceSystem, "Select Source system", ddlSourceSystem);
		wait.until(ExpectedConditions.elementToBeClickable(By.id(UNpolicySymbol)));
		UIMethods.inputbyid(UNpolicySymbol, "Enter Policy Symbol", txtPolicySymbol);
		UIMethods.inputbyid(UNpolicyAccountNumber, "Enter Policy Account Number", txtPolicyAccountNumber);
		Helper.selectDropdownValue(driver, "cssselector", UNPolicyType, "Select Unverified Policy type", txtPolicyType);
		
		if (Helper.isAlertPresent(driver) == true) {
			try {
				Alert alert = driver.switchTo().alert();
				alert.accept();
				Thread.sleep(2000);
				Alert alert1 = driver.switchTo().alert();
				alert1.accept();
				Thread.sleep(2000);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		
		Helper.enterDate(driver, UNLossDate,"Enter loss date", txtLossDate);
		wait.until(ExpectedConditions.elementToBeClickable(By.id(UNEffectiveDate)));
		Helper.enterDate(driver, UNEffectiveDate,"Enter effective date", txtEffectiveDate);
		wait.until(ExpectedConditions.elementToBeClickable(By.id(UNExpirationDate)));
		Helper.enterDate(driver, UNExpirationDate,"Enter expiration date", txtExpirationDate);
		wait.until(ExpectedConditions.elementToBeClickable(By.id(UNOriginalEffectiveDate)));		
		Helper.enterDate(driver, UNOriginalEffectiveDate,"Enter OriginalEffective date", txtOriginalEffectiveDate);		
	}

	public void namesearchpage() throws Exception {
		UIMethods.jscriptclickbyxpath("//a[@id='FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:Insured_Name:Insured_NameMenuIcon']/img","Click Insured Name ICon", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:Insured_Name:MenuItem_Search-itemEl']/span[text()='Search']")));
		UIMethods.jscriptclickbyxpath("//a[@id='FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:Insured_Name:MenuItem_Search-itemEl']/span[text()='Search']", "Click Search option", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("AddressBookPickerPopup:AddressBookSearchScreen:ttlBar")));
	}

	public void newpersonpage() throws Exception {
		UIMethods.jscriptclickbyxpath("//*[@id='FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:Insured_Name:Insured_NameMenuIcon']/img","Click Name ICon", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:Insured_Name:ClaimNewContactPickerMenuItemSet:NewContactPickerMenuItemSet_NewPerson","Click New person Option", "Click");
		Thread.sleep(2000);
	}

	public void addcoverage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlPoliyCoverageType = xlsread.Exceldata(SheetName, "ddlPoliyCoverageType", profileID);
		String ddlPoliyStatus = xlsread.Exceldata(SheetName, "ddlPoliyStatus", profileID);
		
		Helper.enterTime(driver, inputTime, "Enter Time", strTime);
		Thread.sleep(2000);
		UIMethods.jscriptclickbyxpath("//*[@id='FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:EditableAutoPolicyCoveragesLV_tb:Add']","Click Add button", "Click");
		Thread.sleep(1000);
		UIMethods.selectbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:EditableAutoPolicyCoveragesLV:0:CoverageType","Click coverage type", ddlPoliyCoverageType);
		Thread.sleep(1000);
		UIMethods.inputbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:EditableAutoPolicyCoveragesLV:0:Status","Click policy status", ddlPoliyStatus);
		Thread.sleep(1000);
	}

	public void SearchCreatePolicyGLPage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		txtPolicyAccountNumber = xlsread.Exceldata(SheetName, "txtPolAccNo", profileID);
		String poltype = xlsread.Exceldata(SheetName, "txtPolType", profileID);
		String lossdt = xlsread.Exceldata(SheetName, "txtLossDate", profileID);

		Thread.sleep(1000);
		UIMethods.inputbyid(policyAccountNumber, "Input Policy Account Number", txtPolicyAccountNumber);
		UIMethods.inputbyid(policyType, "Input Policy Type", poltype);
		Thread.sleep(3000);
		Helper.enterDate(driver, lossDateField,"Input loss date", lossdt);
		Thread.sleep(2000);
		/*String strExecutionType = (FetchPropertiesFiles.executionMode).toString();
		if (strExecutionType.equalsIgnoreCase("Saucelab")) {
			UIMethods.inputbyid(lossDateField, "input loss date", lossdt);
		} else {
			UIMethods.inputbyid(lossDateField, "input loss date", lossdt);
		}
		*/
		UIMethods.clickbyid(searchButton, "Click search button", "Click");
		Thread.sleep(6000);
		
		// Added by RAJ
		Helper.validateErrorMessage(driver);
		
		UIMethods.jscriptclickbyxpath("//*[@id='FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:ClaimMode_General Liability']","Select General Liability", "Click");
		Thread.sleep(2000);
		Helper.enterTime(driver, inputTime, "Enter Time", strTime);
		Thread.sleep(2000);
		Helper.highLightElement(driver, driver.findElement(By.id("FNOLWizard:Next")));
		UIMethods.clickbyid("FNOLWizard:Next", "Click Next Button", "Click");
	}

	public void SearchCreatePolicyQuickClaimPage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		txtPolicyAccountNumber = xlsread.Exceldata(SheetName, "txtPolAccNo", profileID);
		txtPolicyType = xlsread.Exceldata(SheetName, "txtPolType", profileID);
		txtLossDate = xlsread.Exceldata(SheetName, "txtLossDate", profileID);		
		
		UIMethods.inputbyid(policyAccountNumber,"Enter Policy Number", txtPolicyAccountNumber);
		Helper.selectDropdownValue(driver, "id", policyType, "Select Policy type", txtPolicyType);		
		Helper.enterDate(driver, lossDateField,"Enter loss date", txtLossDate);
		UIMethods.clickbyid(searchButton,"Click search button", "Click");
		
		Thread.sleep(3000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:ClaimMode_option1-inputEl']")));
		UIMethods.clickbyxpath("//input[@id='FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:ClaimMode_option1-inputEl']","Select Quick Claim Property", "Click");
		Helper.waitForLoad(driver);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(nextButton)));
		UIMethods.jscriptclickbyxpath(nextButton, "Click Next Button", "Click");		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Step 2 of 2: Quick Claim Property']")));
	}

	public void SearchCreatePolicyPageFarmProperty(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		txtPolicyAccountNumber = xlsread.Exceldata(SheetName, "txtPolAccNo", profileID);
		String poltype = xlsread.Exceldata(SheetName, "txtPolType", profileID);
		String lossDate = xlsread.Exceldata(SheetName, "txtLossDate", profileID);

		UIMethods.inputbyid(policyAccountNumber, "Input Policy Account Number", txtPolicyAccountNumber);
		UIMethods.inputbyid(policyType, "Input Policy Type", poltype);
		wait.until(ExpectedConditions.elementToBeClickable(By.id(lossDateField)));
		Helper.enterDate(driver, lossDateField,"Input loss date", lossDate);

		/*String strExecutionType = (FetchPropertiesFiles.executionMode).toString();
		if (strExecutionType.equalsIgnoreCase("Saucelab")) {
			UIMethods.inputbyid(lossDateField, "Input loss date", lossDate);
		} else {
			UIMethods.inputbyid(lossDateField, "Input loss date", lossDate);
		}*/
		Helper.highLightElement(driver, driver.findElement(By.id(searchButton)));
		UIMethods.clickbyid(searchButton, "Click search button", "Click");
		Thread.sleep(5000);
		
		// Added by RAJ
		Helper.validateErrorMessage(driver);
		
		UIMethods.clickbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:ClaimMode_Property","Click Property loss type", "Click");
		Thread.sleep(3000);
		
		Helper.enterTime(driver, inputTime, "Enter Time", strTime);		
		UIMethods.clickbyid("FNOLWizard:Next", "Click Next Button", "Click");
	}

	public void SelectCreateUnverifiedPolicyRadioButton() throws Exception {
		UIMethods.clickbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:ScreenMode_false","Click Create Unverified Policy radio button", "Click");
	}

	public void FillOutSourceSystemSection(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String sourceSystem = xlsread.Exceldata(SheetName, "ddlSourceSystem", profileID);
		String policySymbol = xlsread.Exceldata(SheetName, "txtPolicySymbol", profileID);
		txtPolicyAccountNumber = xlsread.Exceldata(SheetName, "txtPolAccNo", profileID);
		String polType = xlsread.Exceldata(SheetName, "txtPolType", profileID);
		String lossDate = xlsread.Exceldata(SheetName, "txtLossDate", profileID);

		UIMethods.selectbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:SourceSystem","Select value from Source System", sourceSystem);

		// Updated by RAJ		
		UIMethods.inputbyid(UNpolicySymbol,"Input Policy Symbol", policySymbol);
		
		UIMethods.inputbyid(policyAccountNumber,"Input Policy Account Number", txtPolicyAccountNumber);

		Thread.sleep(2000);
		WebElement elem = driver.findElement(By.id("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:Type"));
		Select sel = new Select(elem);
		sel.selectByVisibleText(polType);
		try {
			Alert alert = driver.switchTo().alert();
			alert.accept();
			Thread.sleep(2000);
			Alert alert1 = driver.switchTo().alert();
			alert1.accept();
			Thread.sleep(2000);
		} catch (NoAlertPresentException ex) {
			ex.printStackTrace();
		}

		UIMethods.clickbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:ClaimLossType_General Liability","Select GL Type of Claim", "Click");

		UIMethods.clickbyid(lossDateTextBox, "Click loss date field", "Click");
		Helper.enterDate(driver, lossDateField,"Input loss date", lossDate);
		/*String strExecutionType = (FetchPropertiesFiles.executionMode).toString();
		if (strExecutionType.equalsIgnoreCase("Saucelab")) {
			UIMethods.inputbyid(lossDateTextBox, "Input loss date", lossDate);
		} else {
			UIMethods.inputbyid(lossDateTextBox, "Input loss date", lossDate);
		}*/
	}

	public void FillOutBasicInformationSection(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String effDate = xlsread.Exceldata(SheetName, "txtEffDate", profileID);
		String expDate = xlsread.Exceldata(SheetName, "txtExpDate", profileID);
		String origEffDate = xlsread.Exceldata(SheetName, "txtOrigEffDate", profileID);

		UIMethods.clickbyid(UNEffectiveDate, "Click effective date field", "Click");
		Helper.enterDate(driver, UNEffectiveDate,"Input effective date", effDate);
		/*String strExecutionType = (FetchPropertiesFiles.executionMode).toString();
		if (strExecutionType.equalsIgnoreCase("Saucelab")) {
			UIMethods.inputbyid(effectiveDate, "Input effective date", effDate);
		} else {
			UIMethods.inputbyid(effectiveDate, "Input effective date", effDate);
		}*/

		UIMethods.clickbyid(UNExpirationDate, "Click expiration date field", "Click");
		Helper.enterDate(driver, UNExpirationDate,"Input expiration date", expDate);
		/*if (strExecutionType.equalsIgnoreCase("Saucelab")) {
			UIMethods.inputbyid(expirationDate, "Input expiration date", expDate);
		} else {
			UIMethods.inputbyid(expirationDate, "Input expiration date", expDate);
		}*/

		UIMethods.clickbyid(UNOriginalEffectiveDate, "Click Original effective date field", "Click");
		Helper.enterDate(driver, UNOriginalEffectiveDate,"Input Original effective date", origEffDate);
		/*if (strExecutionType.equalsIgnoreCase("Saucelab")) {
			UIMethods.inputbyid(originalEffectiveDate, "Input Original effective date", origEffDate);
		} else {
			UIMethods.inputbyid(originalEffectiveDate, "Input Original effective date", origEffDate);
		}*/
	}

	public void SearchForInsuredContact() throws Exception {
		UIMethods.clickbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:Other_OtherFinancialInterests","Click Other Financial Interests text box", "Click");		
		UIMethods.clickbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:Insured_Name:Insured_NameMenuIcon","Select down arrow", "Click");		
		UIMethods.clickbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:Insured_Name:MenuItem_Search","Select Search option", "Click");
	}

	public void SelectPolicyState(String excelFileName, String profileID) {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String polState = xlsread.Exceldata(SheetName, "ddlPolState", profileID);
		UIMethods.inputbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:PolicyState","Select Policy State", polState);
	}

	public void FillOutAgentSection(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String agencyCode = xlsread.Exceldata(SheetName, "txtAgencyCode", profileID);

		UIMethods.clickbyid(agencyCodeTextBox,"Click Agency Code field", "Click");
		Helper.clearTextBox(driver, driver.findElement(By.id(agencyCodeTextBox)));
		UIMethods.inputbyid(agencyCodeTextBox,"Input Agency Code", agencyCode);
		UIMethods.clickbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:NewClaimPolicyGeneralDV:ValidateAgencyCode","Click Validate Agency Code button", "Click");
	}

	public void FillOutUWSection(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String UWCompany = xlsread.Exceldata(SheetName, "ddlUWCompany", profileID);
		UIMethods.inputbyid(uwCompany,"Input Agency Code", UWCompany);
	}

	public void AddPolicyLevelCoverages(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String policyLevelCoverage = xlsread.Exceldata(SheetName, "ddlPolicyLevelCoverage", profileID);
		UIMethods.clickbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:NewClaimPolicyGeneralPanelSet:EditableGeneralLiabilityPolicyCoveragesLV_tb:Add","Click Add button", "Click");
		UIMethods.inputbyid(policyLevelCoverageTextBox,"Select a policy level coverage to add", policyLevelCoverage);
		UIMethods.inputbyid(policyLevelCoverageTextBox,"Tab to the next field", "\t");
	}

	public void SearchByPolAccountNumberAndNameAndLossDateAdvanced(String excelFileName, String profileID)
			throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		txtPolicyAccountNumber = xlsread.Exceldata(SheetName, "txtPolAccNo", profileID);
		String txtStep1Name = xlsread.Exceldata(SheetName, "txtStep1Name", profileID);
		String polType = xlsread.Exceldata(SheetName, "txtPolType", profileID);
		String lossDate = xlsread.Exceldata(SheetName, "txtLossDate", profileID);
		String searchType = xlsread.Exceldata(SheetName, "ddlSearchType", profileID);

		UIMethods.inputbyid(policyAccountNumber,"Input Policy Account Number", txtPolicyAccountNumber);
		UIMethods.inputbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:org", "Input Name",txtStep1Name);
		UIMethods.inputbyid(policyType,"Input Policy Type", polType);
		UIMethods.clickbyid(lossDateField,"Input loss date", "Click");
		Helper.enterDate(driver, lossDateField,"Input loss date", lossDate);
		
		/*String strExecutionType = (FetchPropertiesFiles.executionMode).toString();
		if (strExecutionType.equalsIgnoreCase("Saucelab")) {
			UIMethods.inputbyid(lossDateField,"Input loss date", lossDate);
		} else {
			UIMethods.inputbyid(lossDateField,"Input loss date", lossDate);
		}*/
		UIMethods.inputbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:searchType","Select Advanced search type", searchType);
		UIMethods.clickbyid(searchButton,"Click search button", "Click");
		
		// Added by RAJ
		Helper.validateErrorMessage(driver);
	}

	public void SearchByPolAccountNumberAndNameAndLossDate(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		txtPolicyAccountNumber = xlsread.Exceldata(SheetName, "txtPolAccNo", profileID);
		String polType = xlsread.Exceldata(SheetName, "txtPolType", profileID);
		String lossDate = xlsread.Exceldata(SheetName, "txtLossDate", profileID);
		String step1Name = xlsread.Exceldata(SheetName, "txtStep1Name", profileID);

		UIMethods.inputbyid(policyAccountNumber,"Input Policy Account Number", txtPolicyAccountNumber);
		UIMethods.inputbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:org", "Enter name",step1Name);
		UIMethods.inputbyid(policyType,"Input Policy Type", polType);

		Helper.enterDate(driver, lossDateField,"Input loss date", lossDate);
		/*String strExecutionType = (FetchPropertiesFiles.executionMode).toString();
		if (strExecutionType.equalsIgnoreCase("Saucelab")) {
			UIMethods.inputbyid(lossDateField,"Input loss date", lossDate);
		} else {
			UIMethods.inputbyid(lossDateField,"Input loss date", lossDate);
		}*/
		UIMethods.clickbyid(searchButton,"Click search button", "Click");
		
		// Added by RAJ
		Helper.validateErrorMessage(driver);
	}

	public void SearchByPolAccountNumberAndLossDate(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		txtPolicyAccountNumber = xlsread.Exceldata(SheetName, "txtPolAccNo", profileID);
		String polType = xlsread.Exceldata(SheetName, "txtPolType", profileID);
		String lossDate = xlsread.Exceldata(SheetName, "txtLossDate", profileID);
		String state = xlsread.Exceldata(SheetName, "ddlState", profileID);

		UIMethods.inputbyid(policyAccountNumber,"Input Policy Account Number", txtPolicyAccountNumber);
		UIMethods.inputbyid(policyType,"Input Policy Type", polType);
		
		Helper.enterDate(driver, lossDateField,"Input loss date", lossDate);
		/*String strExecutionType = (FetchPropertiesFiles.executionMode).toString();
		if (strExecutionType.equalsIgnoreCase("Saucelab")) {
			UIMethods.inputbyid(lossDateField,"Input loss date", lossDate);
		} else {
			UIMethods.inputbyid(lossDateField,"Input loss date", lossDate);
		}*/
		UIMethods.inputbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:FNOLWizard_PolicySearchInputSet:AddressInputSet:Address_State","Select State value", state);
		UIMethods.clickbyid(searchButton,"Click search button", "Click");
		
		// Added by RAJ
		Helper.validateErrorMessage(driver);
	}

	public void SearchByNameAndLossDate(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String step1Name = xlsread.Exceldata(SheetName, "txtStep1Name", profileID);
		String polType = xlsread.Exceldata(SheetName, "txtPolType", profileID);
		String lossDate = xlsread.Exceldata(SheetName, "txtLossDate", profileID);

		UIMethods.inputbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:org", "Enter name",step1Name);
		UIMethods.inputbyid(policyType,"Input Policy Type", polType);
		
		Helper.enterDate(driver, lossDateField,"Input loss date", lossDate);
		/*String strExecutionType = (FetchPropertiesFiles.executionMode).toString();
		if (strExecutionType.equalsIgnoreCase("Saucelab")) {
			UIMethods.inputbyid(lossDateField,"Input loss date", lossDate);
		} else {
			UIMethods.inputbyid(lossDateField,"Input loss date", lossDate);
		}*/
		UIMethods.clickbyid(searchButton,"Click search button", "Click");
		
		// Added by RAJ
		Helper.validateErrorMessage(driver);
	}

	public void SearchByLossDateAndSSN(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String polType = xlsread.Exceldata(SheetName, "txtPolType", profileID);
		String lossDate = xlsread.Exceldata(SheetName, "txtLossDate", profileID);
		String ssn = xlsread.Exceldata(SheetName, "txtSSN", profileID);

		UIMethods.inputbyid(policyType,"Input Policy Type", polType);
		
		Helper.enterDate(driver, lossDateField,"Input loss date", lossDate);
		/*String strExecutionType = (FetchPropertiesFiles.executionMode).toString();
		if (strExecutionType.equalsIgnoreCase("Saucelab")) {
			UIMethods.inputbyid(lossDateField,"Input loss date", lossDate);
		} else {
			UIMethods.inputbyid(lossDateField,"Input loss date", lossDate);
		}*/
		UIMethods.inputbyid("FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:FNOLWizard_PolicySearchInputSet:ssn","Input loss date", ssn);
		UIMethods.clickbyid(searchButton,"Click search button", "Click");
		
		// Added by RAJ
		Helper.validateErrorMessage(driver);
	}

	public void SelectNextButton() {
		UIMethods.clickbyid("FNOLWizard:Next", "Click Next button", "Click");
	}	
	
	public void clickTypeOfClaimRadioButton(int position, String typeOfClaim) {
		String radioButton = "//input[@id='FNOLWizard:FNOLWizard_FindPolicyScreen:FNOLWizardFindPolicyPanelSet:ClaimMode_option"+position+"-inputEl']";
		UIMethods.jscriptclickbyxpath(radioButton, "Select " + typeOfClaim + " Option", "Click");
	}
}