package org.qa.Claims.CICC9.Property.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class NewClaimSaved extends Object_Repositories{
	
	private WebDriver driver=null;
	public static String intClaimNumber;
	
	String gotoClaimLink = "//div[@id='NewClaimSaved:NewClaimSavedScreen:NewClaimSavedDV:GoToClaim']";
	String claimNumebr = "NewClaimSaved:NewClaimSavedScreen:NewClaimSavedDV:Header";
	
	public NewClaimSaved(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 60);
	}

	public void NewClaimSavedPage(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
				
		//Writing Claim number in excel sheet		
		String successMessage = driver.findElement(By.id(claimNumebr)).getText();
		String actualClaimNumber = successMessage.substring(5, 15).trim();
		xlsread.WriteIntoExistingExcel(SheetName, "claimNumber", actualClaimNumber, profileID, true);		
		Helper.highLightElement(driver, driver.findElement(By.xpath(gotoClaimLink)));
		
		if(driver.findElements(By.xpath(gotoClaimLink)).size()!=0) {
			xlsread.WriteIntoExistingExcel(SheetName, "claimStatus", "Pass", profileID, true);
		} else {
			xlsread.WriteIntoExistingExcel(SheetName, "claimStatus", "Fail", profileID, true);
		}
			
		// Click on Got to claim link to navigate Exposure screen
		Report.pass("Claim Number", "Claim Number", actualClaimNumber, actualClaimNumber);
		UIMethods.clickbyxpath(gotoClaimLink, "Click link to view claim details", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimSummary:ClaimSummaryScreen:ttlBar' and text()='Summary']")));
		Thread.sleep(8000);
		Helper.getScreenshot(driver, "Summary_Screen", "TC_" +profileID+ "_");
	}
	
	public void FetchClaimNumber() throws Exception{
		Thread.sleep(2000);
		intClaimNumber = (driver.findElement(By.xpath("//*[@id='NewClaimSaved:NewClaimSavedScreen:NewClaimSavedDV:Header']")).getText().split(" "))[1];
	}	
}