package org.qa.Claims.CICC9.CommonScreens;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Property.Pages.NewPropertyIncident;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

public class NewExposureEntry extends Object_Repositories{
	
	ExcelXlsFileRead xlsread;
	private static WebDriver driver=null;
	static NewPersonContactDetail newperson;
		
	//Page Objects
	static String newExposureTitle = "//span[text()='New Exposure']";
	
	String updateButton = "//a[@id='NewContactPopup:ContactDetailScreen:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:CustomUpdateButton']/span";
	String coverageRiskUnit = "NewExposure:NewExposureScreen:NewExposureDV:NewClaimVehicleDamageDV:Coverage-inputEl";
	String inputClaimantField = "NewExposure:NewExposureScreen:NewExposureDV:NewClaimVehicleDamageDV:Claimant_Picker-inputEl";
	String claimantTypeField = "NewExposure:NewExposureScreen:NewExposureDV:NewClaimVehicleDamageDV:Claimant_Type-inputEl";
	//String coverageUnit = "NewExposure:NewExposureScreen:NewExposureDV:NewClaimVehicleDamageDV:Coverage";
	//String inputClaimant = "NewExposure:NewExposureScreen:NewExposureDV:NewClaimVehicleDamageDV:Claimant_Picker";
	String exposureCoverage = "NewExposure:NewExposureScreen:NewExposureDV:NewClaimPropertyDamageDV:Exposure_Coverage";
	//String claimantTypeField = "NewExposure:NewExposureScreen:NewExposureDV:NewClaimVehicleDamageDV:Claimant_Type";
	
	public NewExposureEntry(WebDriver driver)
	{
		this.driver = driver;
		wait = new WebDriverWait(driver, 30);
		newperson  = new NewPersonContactDetail(driver);
	}	
	
	public void GLNewExposureBodilyInjuiryPage(String excelFileName, String profileID) throws Exception {		
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		
		String ddlCoverageUnit = xlsread.Exceldata(SheetName, "ddlCoverageUnit", profileID);
		String ddlClaimant = xlsread.Exceldata(SheetName, "ddlClaimant", profileID);
		String ddlClaimantType = xlsread.Exceldata(SheetName, "ddlClaimantType", profileID);
		String btnGLBiExpUpdate = xlsread.Exceldata(SheetName, "btnGLBiExpUpdate", profileID);
		String btnNewIncident = xlsread.Exceldata(SheetName, "btnNewIncident", profileID);
		
		//New Exposure Bodily Injuiry
		Thread.sleep(2000);
		UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:NewBodilyInjurySummaryDV:Coverage", "Input Coverage Unit", ddlCoverageUnit);
		Thread.sleep(2000);
		UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:NewBodilyInjurySummaryDV:Claimant_Picker", "input Claimant", ddlClaimant);
        UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:NewBodilyInjurySummaryDV:Claimant_Type", "input Claimant Type", ddlClaimantType);
        Thread.sleep(4000);

		// New Incident Overview - to Add New Incident
		if (!(btnNewIncident.isEmpty())) {
			UIMethods.jscriptclickbyxpath("//*[@id='NewExposure:NewExposureScreen:NewExposureDV:NewBodilyInjurySummaryDV:BIDamageInputSet:Injury_Incident:Injury_IncidentMenuIcon']","Click arrow Button", "Click");
			Thread.sleep(1000);
			UIMethods.jscriptclickbyxpath("//*[@id='NewExposure:NewExposureScreen:NewExposureDV:NewBodilyInjurySummaryDV:BIDamageInputSet:Injury_Incident:BodilyInjuryDamageDV_NewIncidentMenuItem']","Click New Incident", "Click");
			Thread.sleep(2000);
		}
		Thread.sleep(2000);

		// Update Button in Bodily Injuiry Exposure Screen
		if (!(btnGLBiExpUpdate.isEmpty())) {
			for (int intLoop = 1; intLoop <= 7; intLoop++) {
				UIMethods.clickbyxpath("//span[text()='pdate']", "click Update button", "Click");
				Thread.sleep(4000);
				if (driver.findElements(By.id("NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:NewClaimDuplicatesWorksheet_CloseButton")).size() > 0) {
					UIMethods.jscriptclickbyxpath("//*[@id='NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:NewClaimDuplicatesWorksheet_CloseButton']","Click Close Option", "Click");
					Thread.sleep(3000);
				}
				try {
					driver.findElement(By.xpath("//span[text()='New Exposure - Bodily Injury']/parent::div")).isDisplayed();
				} catch (Exception Ex) {
					break;
				}
				Thread.sleep(3000);
			}
		}
	}
	
	public void ExposureMedicalPIP(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");		
		String ddlCoverageUnit = xlsread.Exceldata(SheetName, "ddlCoverageUnit", profileID);
		String ddlClaimant = xlsread.Exceldata(SheetName, "ddlClaimant", profileID);
		String ddlClaimantType = xlsread.Exceldata(SheetName, "ddlClaimantType", profileID);
		String btnPIPUpdate = xlsread.Exceldata(SheetName, "btnPIPUpdate", profileID);
		String btnNewIncident = xlsread.Exceldata(SheetName, "btnNewIncident", profileID);
		
		Thread.sleep(2000);
		UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:NewPIPSummaryDV:Title_Coverage", "Input Coverage Unit", ddlCoverageUnit);
		Thread.sleep(2000);
		UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:NewPIPSummaryDV:PIPDamages_Claimant", "input Claimant", ddlClaimant);
		Thread.sleep(2000);
        UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:NewPIPSummaryDV:Exposure_ClaimantType", "input Claimant Type", ddlClaimantType);
        Thread.sleep(4000);
        
        // New Incident Overview  - to Add New Incident
		if (!(btnNewIncident.isEmpty())) {
 			UIMethods.jscriptclickbyxpath("//*[@id='NewExposure:NewExposureScreen:NewExposureDV:NewPIPSummaryDV:BIDamageInputSet:Injury_Incident:Injury_IncidentMenuIcon']", "Click arrow Button", "Click");
 			Thread.sleep(1000);
 			UIMethods.jscriptclickbyxpath("//*[@id='NewExposure:NewExposureScreen:NewExposureDV:NewPIPSummaryDV:BIDamageInputSet:Injury_Incident:BodilyInjuryDamageDV_NewIncidentMenuItem']", "Click New Incident", "Click");
 	        Thread.sleep(2000);	
 		}    		
   		
    	// Update Button
		if (!(btnPIPUpdate.isEmpty())) {
        	UIMethods.clickbyxpath("//span[text()='pdate']", "click Update button", "Click");
        	Thread.sleep(3000);
		}        
	}
	
	public void GLNewExposureBodilyInjuiryVehiclePage(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");		
		String ddlCoverageUnit = xlsread.Exceldata(SheetName, "ddlCoverageUnit", profileID);
		String ddlClaimant = xlsread.Exceldata(SheetName, "ddlClaimant", profileID);
		String ddlClaimantType = xlsread.Exceldata(SheetName, "ddlClaimantType", profileID);
		String btnGLBiExpUpdate = xlsread.Exceldata(SheetName, "btnGLBiExpUpdate", profileID);
		String btnNewIncident = xlsread.Exceldata(SheetName, "btnNewIncident", profileID);
		
		//New Exposure Bodily Injury
		Thread.sleep(2000);
		UIMethods.selectbyid(coverageRiskUnit, "Input Coverage Unit", ddlCoverageUnit);
		Thread.sleep(2000);
		UIMethods.selectbyid(inputClaimantField, "input Claimant", ddlClaimant);
        UIMethods.selectbyid(claimantTypeField, "input Claimant Type", ddlClaimantType);
        Thread.sleep(4000);

		// New Incident Overview - to Add New Incident
		if (!(btnNewIncident.isEmpty())) {
			UIMethods.jscriptclickbyxpath("//*[@id='NewExposure:NewExposureScreen:NewExposureDV:NewClaimVehicleDamageDV:Vehicle_Incident:Vehicle_IncidentMenuIcon']","Click arrow Button", "Click");
			Thread.sleep(1000);
			UIMethods.jscriptclickbyxpath("//*[@id='NewExposure:NewExposureScreen:NewExposureDV:NewClaimVehicleDamageDV:Vehicle_Incident:NewClaimVehicleDamageDV_NewIncidentMenuItem']","Click New Incident", "Click");
			Thread.sleep(2000);
		}
		Thread.sleep(2000);

		// Update Button in Bodily Injury Exposure Screen
		if (!(btnGLBiExpUpdate.isEmpty())) {
			for (int intLoop = 1; intLoop <= 7; intLoop++) {
				UIMethods.clickbyxpath("//span[text()='pdate']", "click Update button", "Click");
				Thread.sleep(4000);
				if (driver.findElements(By.id("NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:NewClaimDuplicatesWorksheet_CloseButton")).size() > 0) {
					UIMethods.jscriptclickbyxpath("//*[@id='NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:NewClaimDuplicatesWorksheet_CloseButton']","Click Close Option", "Click");
					Thread.sleep(3000);
				}
				try {
					driver.findElement(By.xpath("//span[text()='New Exposure - Vehicle']/parent::div")).isDisplayed();
				} catch (Exception Ex) {
					break;
				}
				Thread.sleep(3000);
			}
		}
	}

	public void GLNewExposureGeneralPage(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");		
		String ddlCoverageUnit = xlsread.Exceldata(SheetName, "ddlCoverageUnit", profileID);
		String ddlClaimant = xlsread.Exceldata(SheetName, "ddlClaimant", profileID);
		String ddlClaimantType = xlsread.Exceldata(SheetName, "ddlClaimantType", profileID);
		String txtDamageDescription = xlsread.Exceldata(SheetName, "txtDamageDescription", profileID);
		
		Thread.sleep(2000);
		UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:Exposure_Coverage", "Input Coverage Unit", ddlCoverageUnit);
		Thread.sleep(2000);
		UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:Claimant_Picker", "input Claimant", ddlClaimant);
        UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:Claimant_Type", "input Claimant Type", ddlClaimantType);
        Thread.sleep(2000);
        UIMethods.inputbyid("NewExposure:NewExposureScreen:NewExposureDV:Description", "input Damage Description", txtDamageDescription);
        
        //Update Button in Exposure Screen
        Helper.highLightElement(driver, driver.findElement(By.xpath("//span[text()='pdate']")));
        UIMethods.jscriptclickbyxpath("//span[text()='pdate']", "click Update button", "Click");
        Thread.sleep(2000);
        
	}
	
	public void ClickUpdateButton() throws Exception {		
		//Update Button in Exposure Screen
        UIMethods.clickbyxpath("//span[text()='pdate']", "click Update button", "Click");
        Thread.sleep(2000);
	}	
	
	public void GLNewExposureDrugistPage(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");		
		String ddlCoverageUnit = xlsread.Exceldata(SheetName, "ddlCoverageUnit", profileID);
		String ddlClaimant = xlsread.Exceldata(SheetName, "ddlClaimant", profileID);
		String ddlClaimantType = xlsread.Exceldata(SheetName, "ddlClaimantType", profileID);
		String txtDamageDescription = xlsread.Exceldata(SheetName, "txtDamageDescription", profileID);
		
		Thread.sleep(3000);
		UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimPropertyDamageDV:Claimant_Picker", "input Claimant", ddlClaimant);
		Thread.sleep(2000);
        UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimPropertyDamageDV:Claimant_Type", "input Claimant Type", ddlClaimantType);
        Thread.sleep(2000);
        
        //Update Button in Exposure Screen
        UIMethods.jscriptclickbyxpath("//span[text()='pdate']", "click Update button", "Click");
        Thread.sleep(4000);        
	}

	public void NewExposurePropertyPage(String excelFileName, String profileID) throws Exception{
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String claimantName = xlsread.Exceldata(SheetName, "ddlClaimantName", profileID);
		String claimantType = xlsread.Exceldata(SheetName, "ddlClaimantType", profileID);
		String coverageRiskUnit = xlsread.Exceldata(SheetName, "ddlCoverageRiskUnit", profileID);
		String txtPropertyNameIncident = xlsread.Exceldata(SheetName, "txtPropertyNameIncident", profileID);
		
		Thread.sleep(3000);
		UIMethods.selectbyid(exposureCoverage, "input Exposure_Coverage", coverageRiskUnit);
		Thread.sleep(3000);
		UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimPropertyDamageDV:Claimant_Picker", "input Claimant_Picker", claimantName);
		Thread.sleep(3000);
        UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimPropertyDamageDV:Claimant_Type", "input Claimant_Type", claimantType);
        Thread.sleep(3000);
        UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimPropertyDamageDV:NewClaimIncidentInputSet:Property_Incident", "input Property Name", txtPropertyNameIncident);
        Thread.sleep(2000);
        Helper.highLightElement(driver, driver.findElement(By.xpath("//a[@id='NewExposure:NewExposureScreen:Update']/span[text()='pdate']")));
        UIMethods.jscriptclickbyxpath("//a[@id='NewExposure:NewExposureScreen:Update']/span[text()='pdate']", "click update button", "Click");
        Thread.sleep(15000);
        Helper.waitForLoad(driver);
	}
	
	public void NewExposurePropertyIncidentPage(String excelFileName, String profileID) throws Exception{
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String claimantName = xlsread.Exceldata(SheetName, "ddlClaimantName", profileID);
		String claimantType = xlsread.Exceldata(SheetName, "ddlClaimantType", profileID);
		String coverageRiskUnit = xlsread.Exceldata(SheetName, "ddlCoverageRiskUnit", profileID);
		Thread.sleep(3000);
		if(!coverageRiskUnit.isEmpty()) {
			UIMethods.selectbyid(exposureCoverage, "input Exposure_Coverage", coverageRiskUnit);
			Thread.sleep(3000);
		}		
		UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimPropertyDamageDV:Claimant_Picker", "input Claimant_Picker", claimantName);
		Thread.sleep(3000);
        UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimPropertyDamageDV:Claimant_Type", "input Claimant_Type", claimantType);
        Thread.sleep(2000);
        Helper.highLightElement(driver, driver.findElement(By.id("NewExposure:NewExposureScreen:NewExposureDV:NewClaimPropertyDamageDV:NewClaimIncidentInputSet:Property_Incident:Property_IncidentMenuIcon")));
        UIMethods.clickbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimPropertyDamageDV:NewClaimIncidentInputSet:Property_Incident:Property_IncidentMenuIcon", "click New Incident Icon", "Click");
        Thread.sleep(2000);
        UIMethods.clickbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimPropertyDamageDV:NewClaimIncidentInputSet:Property_Incident:NewClaimPropertyDamageDV_NewIncidentMenuItem", "click New Incident Option", "Click");
        Thread.sleep(2000);
	}
	
	public void NewExposurePersonalPropertyPage(String excelFileName, String profileID) throws Exception{
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String claimantName = xlsread.Exceldata(SheetName, "ddlClaimantName", profileID);
		String claimantType = xlsread.Exceldata(SheetName, "ddlClaimantType", profileID);
		String coverageRiskUnit = xlsread.Exceldata(SheetName, "ddlCoverageRiskUnit", profileID);
		String ddlDamageSeverity = xlsread.Exceldata(SheetName, "ddlDamageSeverity", profileID);
		String txtDamageProperty = xlsread.Exceldata(SheetName, "txtDamageProperty", profileID);
		String txtDamageDescription = xlsread.Exceldata(SheetName, "txtDamageDescription", profileID);
		String txtLineItemName = xlsread.Exceldata(SheetName, "txtLineItemName", profileID);
		String ddlLineItemCategory = xlsread.Exceldata(SheetName, "ddlLineItemCategory", profileID);
		
		Thread.sleep(3000);
		UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimThirdPartyPropertyDamageDV:Exposure_Coverage", "input Exposure_Coverage", coverageRiskUnit);
		UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimThirdPartyPropertyDamageDV:Claimant_Picker", "input Claimant_Picker", claimantName);
        UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimThirdPartyPropertyDamageDV:Claimant_Type", "input Claimant_Type", claimantType);
        Thread.sleep(2000);
        UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimThirdPartyPropertyDamageDV:GeneralDamage_Severity", "input Severity", ddlDamageSeverity);
        UIMethods.inputbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimThirdPartyPropertyDamageDV:PropertyDescription", "input Property Description", txtDamageProperty);
        UIMethods.inputbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimThirdPartyPropertyDamageDV:Description", "Input Damage Description", txtDamageDescription);
        UIMethods.inputbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimThirdPartyPropertyDamageDV:FixPropIncidentBusinessPersonalPropInputSet:FixPropertyContentsLineItemsLV:0:LineItemName", "Input Line Item Name", txtLineItemName);
        UIMethods.selectbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimThirdPartyPropertyDamageDV:FixPropIncidentBusinessPersonalPropInputSet:FixPropertyContentsLineItemsLV:0:LineItemCategory", "Input Line Item Category", ddlLineItemCategory);
        Thread.sleep(2000);
        UIMethods.jscriptclickbyxpath("//span[text()='pdate']", "Click Update button", "Click");
        Thread.sleep(7000);
	}

	public void NewExposureVehicle(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String claimantName = xlsread.Exceldata(SheetName, "ddlClaimant", profileID);
		String claimantType = xlsread.Exceldata(SheetName, "ddlClaimantType", profileID);
		String ddlCoverageUnit = xlsread.Exceldata(SheetName, "ddlCoverageUnit", profileID);
		Thread.sleep(2000);
		UIMethods.selectbyid(coverageRiskUnit, "Coverage Unit", ddlCoverageUnit);
		Helper.waitForLoad(driver);
		Thread.sleep(2000);
		UIMethods.selectbyid(inputClaimantField, "input Claimant", claimantName);
		Helper.waitForLoad(driver);
		Thread.sleep(4000);
        UIMethods.selectbyid(claimantTypeField, "input Claimant Type", claimantType);
        Helper.waitForLoad(driver);
        Thread.sleep(2000);
        Helper.highLightElement(driver, driver.findElement(By.xpath("//span[text()='pdate']")));
        UIMethods.jscriptclickbyxpath("//span[text()='pdate']", "click Update button", "Click");
        Thread.sleep(5000);
        
        // Validating error message if exists on the screen
        if(driver.findElements(By.id("NewExposure:NewExposureScreen:_msgs_msgs")).size()!=0) {
        	Assert.fail(driver.findElement(By.id("NewExposure:NewExposureScreen:_msgs_msgs")).getText());
        }        
	}
	
	public void NewExposureVehicleIncident(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String claimantName = xlsread.Exceldata(SheetName, "ddlClaimant", profileID);
		String claimantType = xlsread.Exceldata(SheetName, "ddlClaimantType", profileID);
		String ddlCoverageUnit = xlsread.Exceldata(SheetName, "ddlCoverageUnit", profileID);
		
		Thread.sleep(3000);
		UIMethods.selectbyid(coverageRiskUnit, "Coverage Unit", ddlCoverageUnit);
		Helper.waitForLoad(driver);
		Thread.sleep(3000);
		wait.until(ExpectedConditions.elementToBeClickable(By.id(inputClaimantField)));		
		UIMethods.selectbyid(inputClaimantField, "Select Claimant", claimantName);
		Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(By.id(claimantTypeField)));
        UIMethods.selectbyid(claimantTypeField, "Select Claimant Type", claimantType);
        Thread.sleep(2000);
        UIMethods.clickbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimVehicleDamageDV:Vehicle_Incident:Vehicle_IncidentMenuIcon", "click New Incident Icon", "Click");
        UIMethods.clickbyid("NewExposure:NewExposureScreen:NewExposureDV:NewClaimVehicleDamageDV:Vehicle_Incident:NewClaimVehicleDamageDV_NewIncidentMenuItem", "click New Incident Option", "Click");
        Thread.sleep(2000);
	}
	
	public void NewExposureVehiclePage(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String coverageRiskUnit = xlsread.Exceldata(SheetName, "ddlCoverageRiskUnit", profileID);
		String claimantName = xlsread.Exceldata(SheetName, "ddlClaimant", profileID);
		String claimantType = xlsread.Exceldata(SheetName, "ddlClaimantType", profileID);
		
		Helper.selectDropdownValue(driver, "id", coverageRiskUnit, "Select Coverage Risk Unit", "2002 KIA SEDONA KNDUP131426256245"); //coverageRiskUnit
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("")));
		Helper.selectDropdownValue(driver, "id", inputClaimantField, "Select Claimant Name", "FFA Driver11"); //claimantName
		wait.until(ExpectedConditions.elementToBeClickable(By.id(claimantType)));
		Helper.selectDropdownValue(driver, "id", claimantTypeField, "Select claimant type", "Employee"); //claimantType		
	}
	
	/*public void validateNewExposureUI(String excelFileName, String profileID) throws Exception {
		NewPersonContactDetail  newperson  = new NewPersonContactDetail(driver);
		NewPropertyIncident newProperty = new NewPropertyIncident(driver);
		InjuiryIncident injuryIncident = new InjuiryIncident(driver);
		
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");	
		String modeOfExposure = xlsread.Exceldata(SheetName, "ExposureMode", profileID);
		String expectedCoverageType = xlsread.Exceldata(SheetName, "CoverageType", profileID);
		String expectedCoverageSubType = xlsread.Exceldata(SheetName, "Coverage Subtype", profileID);
		String txtclaimantType = xlsread.Exceldata(SheetName, "txtClaimantType", profileID);
		String claimantNameOption = xlsread.Exceldata(SheetName, "claimantNameOption", profileID);
		String claimantNameVendorOption = xlsread.Exceldata(SheetName, "newVendorOptions", profileID);
		String claimantNameLegalOption = xlsread.Exceldata(SheetName, "newVendorOptions", profileID);
		String exposureType = xlsread.Exceldata(SheetName, "Exposure", profileID);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newExposureTitle)));
		
		if(modeOfExposure.equalsIgnoreCase("during")) {
			String lossParty = "//div[contains(@id,'LossParty-inputEl')]";			
			String primaryCoverage = "//div[contains(@id,'PrimaryCoverage-inputEl')]";			
			String coverageSubType = "//div[contains(@id,'CoverageSubType-inputEl')]";
			String riskUnit = "//div[contains(@id,'Coverage-trigger-picker')]";
			
			
			String claimantNameField = "//input[contains(@id,'Claimant_Picker-inputEl')]";		
			String claimantTypeField = "//input[contains(@id,'Claimant_Type-inputEl')]";
			String claimantArrowIcon = "(//a[contains(@id,'MenuIcon')]/img)[1]";
			String propertyNameArrowIcon = "(//a[contains(@id,'MenuIcon')]/img)[2]";
			String injuryNameArrowIcon = "(//a[contains(@id,'MenuIcon')]/img)[3]";
			
			if(driver.findElements(By.xpath(primaryCoverage)).size()!=0) {
				String actualPrimaryCoverage = driver.findElement(By.xpath(primaryCoverage)).getText();
				Assert.assertEquals(actualPrimaryCoverage, expectedCoverageType);
			}
			
			if(driver.findElements(By.xpath(coverageSubType)).size()!=0) {
				String actualCoverageSubType = driver.findElement(By.xpath(coverageSubType)).getText();
				Assert.assertEquals(actualCoverageSubType, expectedCoverageSubType);
			}
			
			UIMethods.jscriptclickbyxpath(riskUnit, "Select Coverage / Risk unit", "Click");
			Thread.sleep(1000);
			if(driver.findElements(By.xpath(firstDropdownOption)).size()!=0) {
				driver.findElement(By.xpath(firstDropdownOption)).click();
			}
						
			wait.until(ExpectedConditions.visibilityOf(Helper.getUIXpath(driver,"Coverage / Risk Unit")));			
			Assert.assertTrue(Helper.getUIXpath(driver,"Coverage / Risk Unit").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver,"Address Number").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver,"Building Number").isDisplayed());
			
			if(exposureType.equalsIgnoreCase("Loss of Use")) {
				Assert.assertTrue(Helper.getUIXpath(driver,"Item Number").isDisplayed());
				Assert.assertTrue(Helper.getUIXpath(driver,"Coverage on Excess Basis").isDisplayed());
			}
			
			Assert.assertTrue(Helper.getUIXpath(driver,"Potential Large Loss?").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver,"CERC Exposure").isDisplayed());
			
			if(exposureType.equalsIgnoreCase("Property")) {
				Assert.assertTrue(Helper.getUIXpath(driver,"Reservation of Rights").isDisplayed());
				Assert.assertTrue(Helper.getUIXpath(driver,"Coverage on Excess Basis").isDisplayed());
			}
			
			Assert.assertTrue(Helper.getUIXpath(driver,"Claimant").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver,"Type").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver,"Contact Prohibited?").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver,"Primary Phone").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver,"Address").isDisplayed());
			
			if(exposureType.equalsIgnoreCase("Property")) {
				Assert.assertTrue(Helper.getUIXpath(driver,"Property Name").isDisplayed());
				Assert.assertTrue(Helper.getUIXpath(driver,"Other Coverage Info").isDisplayed());
			}		
			
			if(exposureType.equalsIgnoreCase("Bodily Injury")) {
				Assert.assertTrue(Helper.getUIXpath(driver,"Alternate Contact").isDisplayed());
				Assert.assertTrue(driver.findElement(By.xpath("//label[text()='Injury Incident Overview']")).isDisplayed());
				Assert.assertTrue(Helper.getUIXpath(driver,"Injury").isDisplayed());
				Assert.assertTrue(Helper.getUIXpath(driver,"Injured Person").isDisplayed());
				Assert.assertTrue(Helper.getUIXpath(driver,"Severity").isDisplayed());
				Assert.assertTrue(Helper.getUIXpath(driver,"Description").isDisplayed());
				Assert.assertTrue(driver.findElement(By.xpath("//label[text()='Coding']")).isDisplayed());
				Assert.assertTrue(Helper.getUIXpath(driver,"Jurisdiction").isDisplayed());
				Assert.assertTrue(driver.findElement(By.xpath("//label[text()='Other Carrier Involvement']")).isDisplayed());
				Assert.assertTrue(Helper.getUIXpath(driver,"Other Coverage Info").isDisplayed());					
			}
			
			// Validating details table
			Assert.assertTrue(Helper.getUIXpath(driver,"Insurer").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver,"Claim #").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver,"Policy #").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver,"Contact").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver,"Phone").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver,"Notes").isDisplayed());
			
			if(driver.findElement(By.xpath(lossParty))!=null) {
				String actualLossParty = driver.findElement(By.xpath(lossParty)).getText();
				if(actualLossParty.contains("Insured's loss")) {
					
					String insuredName = driver.findElement(By.xpath("//span[contains(@id,'FNOLWizard:ClaimInfoBar:Insured')]/span[2]")).getText();
					String actualInsuredName = insuredName.substring(5).trim();
					
					Helper.selectDropdownValue(driver, "xpath", claimantNameField, "Select Claimant", actualInsuredName);
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(claimantTypeField)));
					Helper.selectDropdownValue(driver, "xpath", claimantTypeField, "Select Claimant Type", txtclaimantType);
					
					if(exposureType.equalsIgnoreCase("Property")) {
						UIMethods.jscriptclickbyxpath(propertyNameArrowIcon, "Click Property Name Arrow Icon", "Click");
						UIMethods.clickbyWebElement(Helper.getUIXpath(driver,"New Incident..."), "Select New Incident option", "Click");
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Return to New Exposure')]")));
						newProperty.PropertyIncidentPage(excelFileName, profileID);	
					}					
					
				} else if (actualLossParty.contains("Third-party")) {
					UIMethods.clickbyxpath(claimantArrowIcon, "Click Claimant arrow icon", "Click");
					switch (claimantNameOption.toLowerCase()) {
					
					case "new person":						
						UIMethods.clickbyWebElement(Helper.getUIXpath(driver,"New Person"), "Select New Person option", "Click");
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewContactPopup:ContactDetailScreen:ttlBar")));	
						newperson.NewPersonContactDetailpage(excelFileName, profileID);
						break;
					case "new vendor":
						UIMethods.clickbyWebElement(Helper.getUIXpath(driver,"New Vendor"), "Select New Vendor option", "Click");
						Helper.getUIXpath(driver,"New Vendor").sendKeys(Keys.ARROW_RIGHT);
						enterVendorDetails(claimantNameVendorOption, excelFileName, profileID);
						break;
					case "new company":
						UIMethods.clickbyWebElement(Helper.getUIXpath(driver,"New Company"), "Select New Company option", "Click");
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewContactPopup:ContactDetailScreen:ttlBar")));	
						newperson.NewPersonContactDetailpage(excelFileName, profileID);
						break;
					case "new legal":
						UIMethods.clickbyWebElement(Helper.getUIXpath(driver,"New Legal"), "Select New Legal option", "Click");
						Helper.getUIXpath(driver,"New Legal").sendKeys(Keys.ARROW_RIGHT);
						enterNewLegalDetails(claimantNameLegalOption, excelFileName, profileID);						
						break;
					case "search":
						UIMethods.clickbyWebElement(Helper.getUIXpath(driver,"Search"), "Select Search option", "Click");
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("AddressBookPickerPopup:AddressBookSearchScreen:ttlBar")));	
						
						// TO-DO Need to work application issue Search address book screen
						
						break;
					case "view contact details":
						UIMethods.clickbyWebElement(Helper.getUIXpath(driver,"View Contact Details"), "Select View Contact Details option", "Click");
						if(driver.findElements(By.xpath("//a[contains(@id,'ClaimContactDetailPopup:_')]")).size()!=0) {
							UIMethods.jscriptclickbyxpath("//a[contains(@id,'ClaimContactDetailPopup:_')]", "Click Return to exposure link", "Click");
						}
						break;
					default:
						Assert.fail("Please provide the valid name to select claimant name options");
						break;
					}
					
					// Select Claimant Type
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(claimantTypeField)));
					Helper.selectDropdownValue(driver, "xpath", claimantTypeField, "Select Claimant Type", txtclaimantType);
					
					if(exposureType.equalsIgnoreCase("Property")) {
						// To Enter Property name details
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(@id,'ClaimContactDetailPopup:_')]")));
						newProperty.PropertyIncidentPage(excelFileName, profileID);
					}
					
					if(exposureType.equalsIgnoreCase("Bodily Injury")) {
						UIMethods.jscriptclickbyxpath(injuryNameArrowIcon, "Click Injury incident overview Name Arrow Icon", "Click");
						UIMethods.clickbyWebElement(Helper.getUIXpath(driver,"New Incident..."), "Select New Incident option", "Click");
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Return to New Exposure')]")));
						injuryIncident.AddInjuiryIncidentPage(excelFileName, profileID);
					}
					
					
					
					
				} else {
					Report.warn("Loss Party isn't available in Exposure screen", "Loss Party", "Loss Party", "Loss Party not available");
				}
			}		
			
			// Click on OK Button from New Exposure Screen
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newExposureTitle)));
			UIMethods.jscriptclickbyxpath("//span[text()='OK']", "Click OK Button", "Click");		
			
		} else if(modeOfExposure.equalsIgnoreCase("post")) {
			Report.pass("Exposure will be create after claim creation", "Post FNOL", "Post FNOL", "Post FNOL");
		}		
	}*/
	
	/**
	 *	Based on the Claimant Name - > Vendor option will enter the details  
	 * @param vendorOption - vendor option (Same as UI)
	 */
	public static void enterVendorDetails(String vendorOption, String excelFileName, String profileID) throws Exception {			
		switch (vendorOption.toLowerCase()) {
		case "autobody repair shop":
			UIMethods.clickbyWebElement(Helper.getUIXpath(driver,"Autobody Repair Shop"), "Select Vendor - Autobody Repair Shop option", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewContactPopup:ContactDetailScreen:ttlBar")));			
			newperson.NewPersonContactDetailpage(excelFileName, profileID);
			/*UIMethods.clearAndInputbyid(contactName, "Enter Autobody Repair shop contact name", "Kevin");
			UIMethods.clearAndInputbyid(organizationName, "Enter Autobody Repair shop organization name", "shifterz");
			UIMethods.jscriptclickbyxpath(updateButton, "Click on Update button", "Click");*/
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newExposureTitle)));
			break;
		case "auto towing agency":
			UIMethods.clickbyWebElement(Helper.getUIXpath(driver,"Auto Towing Agency"), "Select Vendor - Auto Towing Agency option", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewContactPopup:ContactDetailScreen:ttlBar")));
			newperson.NewPersonContactDetailpage(excelFileName, profileID);
			/*UIMethods.clearAndInputbyid(contactName, "Enter Auto Towing Agency contact name", "adams");
			UIMethods.clearAndInputbyid(organizationName, "Enter Auto Towing Agency organization name", "adams autoshop");
			UIMethods.jscriptclickbyxpath(updateButton, "Click on Update button", "Click");*/
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newExposureTitle)));
			break;
		case "doctor":
			UIMethods.clickbyWebElement(Helper.getUIXpath(driver,"Doctor"), "Select Vendor - Doctor option", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewContactPopup:ContactDetailScreen:ttlBar")));
			newperson.NewPersonContactDetailpage(excelFileName, profileID);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newExposureTitle)));
			break;
		case "medical care organization":
			UIMethods.clickbyWebElement(Helper.getUIXpath(driver,"Medical Care Organization"), "Select Vendor - Medical Care Organization option", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewContactPopup:ContactDetailScreen:ttlBar")));
			newperson.NewPersonContactDetailpage(excelFileName, profileID);
			/*UIMethods.clearAndInputbyid(contactName, "Enter Medical Care Organization contact name", "adams");
			UIMethods.clearAndInputbyid(organizationName, "Enter Medical Care Organization name", "adams autoshop");
			UIMethods.jscriptclickbyxpath(updateButton, "Click on Update button", "Click");*/
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newExposureTitle)));
			break;
		case "vendor (company)":
			UIMethods.clickbyWebElement(Helper.getUIXpath(driver,"Vendor (Company)"), "Select Vendor - Vendor (Company) option", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewContactPopup:ContactDetailScreen:ttlBar")));
			newperson.NewPersonContactDetailpage(excelFileName, profileID);
			/*UIMethods.clearAndInputbyid(contactName, "Enter Vendor (Company) contact name", "allen");
			UIMethods.clearAndInputbyid(organizationName, "Enter Vendor (Company) Organization name", "allen autoshop");
			UIMethods.jscriptclickbyxpath(updateButton, "Click on Update button", "Click");*/
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newExposureTitle)));
			break;
		default:
			Assert.fail("Please provide the valid name to select vendor options");
			break;
		}
	}
	
	/**
	 *	Based on the Claimant Name - > New Legal option will enter the details  
	 * @param legalOption - Legal option (Same as UI)
	 */
	public static void enterNewLegalDetails(String legalOption, String excelFileName, String profileID) throws Exception {
		switch (legalOption.toLowerCase()) {
		case "adjudicator":
			UIMethods.clickbyWebElement(Helper.getUIXpath(driver,"Adjudicator"), "Select Legal - Adjudicator option", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewContactPopup:ContactDetailScreen:ttlBar")));
			newperson.NewPersonContactDetailpage(excelFileName, profileID);		
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newExposureTitle)));
			break;
		case "attorney":
			UIMethods.clickbyWebElement(Helper.getUIXpath(driver,"Attorney"), "Select Legal - Attorney option", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewContactPopup:ContactDetailScreen:ttlBar")));
			newperson.NewPersonContactDetailpage(excelFileName, profileID);	
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newExposureTitle)));
			break;
		case "law firm":
			UIMethods.clickbyWebElement(Helper.getUIXpath(driver,"Law Firm"), "Select Legal - Law Firm option", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewContactPopup:ContactDetailScreen:ttlBar")));
			newperson.NewPersonContactDetailpage(excelFileName, profileID);	
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newExposureTitle)));
			break;
		case "legal venue":
			UIMethods.clickbyWebElement(Helper.getUIXpath(driver,"Legal Venue"), "Select Legal - Legal Venue option", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewContactPopup:ContactDetailScreen:ttlBar")));
			newperson.NewPersonContactDetailpage(excelFileName, profileID);	
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newExposureTitle)));
			break;
		default:
			Assert.fail("Please provide the valid name to select New Legal options");
			break;
		}		
	}
		
}