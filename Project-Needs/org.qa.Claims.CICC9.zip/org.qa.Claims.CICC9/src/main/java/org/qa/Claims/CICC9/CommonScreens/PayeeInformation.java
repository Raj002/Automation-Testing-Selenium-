package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;
import org.testng.Assert;

public class PayeeInformation extends Object_Repositories {

	private WebDriver driver = null;

	// Page Objects
	String primaryPayeeName = "//div[contains(@id,'PrimaryPayee_Name-trigger-picker')]";
	String primaryPayeeTextBox = "//input[contains(@id,'PrimaryPayee_Name-inputE')]";
	
	String nextButton = "//a[@id='NormalCreateCheckWizard:Next']";

	public PayeeInformation(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 15);
	}

	public void enterPayeeDetails(String profileID) throws Exception {

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Enter payee information')]")));
		driver.findElement(By.xpath("//span[contains(text(),'Enter payee information')]")).click();
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(primaryPayeeName)));
		
		String actualExposureName = driver.findElement(By.xpath("//span[@id='Claim:ClaimInfoBar:Insured-btnInnerEl']/span[2]")).getText();
		String expectedPayeeName = actualExposureName.trim();
		UIMethods.clearAndinputbyxpath(primaryPayeeTextBox, "Select Primary Payee Name", expectedPayeeName);
		
		Thread.sleep(2000);
		String actualPayeeName = Helper.getAttributeValue(driver, "xpath", primaryPayeeTextBox);
		Assert.assertEquals(actualPayeeName, expectedPayeeName);
		
		/*UIMethods.clickbyxpath(primaryPayeeName, "Select Pripmary Payee Name", "Click");
		Thread.sleep(1000);
		if (driver.findElements(By.xpath(firstDropdownOption)).size() != 0) {
			driver.findElement(By.xpath(firstDropdownOption)).click();
		} else {
			Assert.fail("Primary Payee isn't displayed");
		}*/

		UIMethods.jscriptclickbyxpath(nextButton, "Click Next button", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Enter payment information')]")));
	}
}