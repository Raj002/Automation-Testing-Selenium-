package org.qa.Claims.CICC9.Auto.Pages;

import org.qa.Claims.CICC9.Technology.UIMethods;

public class ReserveDetails {
			
	public void ReserveDetailspage() throws Exception{
		UIMethods.clickbyxpath("//*[@id='ClaimFinancialsTransactionsDetail:ClaimFinancialsTransactionsDetailScreen:TransactionDetailToolbarButtonSet:TransactionDetailToolbarButtons_CreateCheckButton']/span[2]", "click CreateCheck Button", "Click");
		Thread.sleep(2000);
	}
}