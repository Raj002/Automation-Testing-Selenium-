package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.qa.Claims.CICC9.Property.Pages.NewClaimSaved;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class BulkRecoveries {
	
	private WebDriver driver;
	
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	//Page Objects
	String issuedDate = "NewBulkRecoveryDetail:BulkRecoveryDetailDV:IssueDate";
	String receivedDate = "NewBulkRecoveryDetail:BulkRecoveryDetailDV:ReceiveDate";	
	
	public BulkRecoveries(WebDriver driver) {
		this.driver = driver;
	}

	public void BulkRecoveryPage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String btnCreateNewRecovery = xlsread.Exceldata(SheetName, "btnCreateNewRecovery", profileID);
		String mnuPayerSearch = xlsread.Exceldata(SheetName, "mnuPayerSearch", profileID);
		String txtCheckNumber = xlsread.Exceldata(SheetName, "txtCheckNumber", profileID);
		String txtIssueDate = xlsread.Exceldata(SheetName, "txtIssueDate", profileID);
		String txtCheckAmount = xlsread.Exceldata(SheetName, "txtCheckAmount", profileID);
		String txtReceiveDate = xlsread.Exceldata(SheetName, "txtReceiveDate", profileID);
		String btnAddLineItems = xlsread.Exceldata(SheetName, "btnAddLineItems", profileID);
		String txtRecoveryClaimNumber = xlsread.Exceldata(SheetName, "txtRecoveryClaimNumber", profileID);
		String ddlRecoveryReserveLine = xlsread.Exceldata(SheetName, "ddlRecoveryReserveLine", profileID);
		String txtRecoveryAmount = xlsread.Exceldata(SheetName, "txtRecoveryAmount", profileID);
		String ddlRecoveryCategory = xlsread.Exceldata(SheetName, "ddlRecoveryCategory", profileID);
		String ddlRecoveryCode = xlsread.Exceldata(SheetName, "ddlRecoveryCode", profileID);
		String btnRecoveryUpdate = xlsread.Exceldata(SheetName, "btnRecoveryUpdate", profileID);
		String recoverySearchType = xlsread.Exceldata(SheetName, "bulkRecoverySearchType", profileID);
		
		
		if (!(btnCreateNewRecovery.isEmpty())) {
			UIMethods.clickbyid("Desktop:MenuLinks:Desktop_BulkRecoveries", "Click Bulk Recoveries Option", "Click");
			Helper.highLightElement(driver, driver.findElement(By.xpath("//*[@id='BulkRecoveries:BulkRecoveryScreen:CreateNewButton']/span[2]")));
			UIMethods.clickbyxpath("//*[@id='BulkRecoveries:BulkRecoveryScreen:CreateNewButton']/span[2]", "click Create New button", "Click");
		}
		
		if (!(mnuPayerSearch.isEmpty())) {
			UIMethods.jscriptclickbyxpath("//*[@id='NewBulkRecoveryDetail:BulkRecoveryDetailDV:Payee:PayeeMenuIcon']", "click Payer menu icon", "Click");
			Thread.sleep(1000);
			UIMethods.jscriptclickbyxpath("//*[@id='NewBulkRecoveryDetail:BulkRecoveryDetailDV:Payee:MenuItem_Search']", "click Search option", "Click");
			UIMethods.selectbyid("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:ContactSubtype", "Select Search type", recoverySearchType);
			Thread.sleep(3000);
			UIMethods.inputbyid("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:Keyword", "Enter Name", "john");
			Thread.sleep(2000);
			if(driver.findElement(By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:Keyword")).getAttribute("value").contains("john")) {
				UIMethods.clickbyid("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search", "Click Search button", "Click");
				Thread.sleep(3000);
			}		
			Helper.highLightElement(driver, driver.findElement(By.id("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:_Select")));
			UIMethods.clickbyid("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:_Select", "Click Select button", "Click");
			Thread.sleep(4000);
		}
		
		UIMethods.inputbyid("NewBulkRecoveryDetail:BulkRecoveryDetailDV:CheckNumber", "input Check Number",txtCheckNumber);

		if (!(txtIssueDate.isEmpty())) {
			UIMethods.clickbyid(issuedDate, "Click IssueDate", "Click");
			Helper.clearTextBox(driver, driver.findElement(By.id(issuedDate)));
			UIMethods.inputbyid(issuedDate, "input IssueDate", txtIssueDate);
		}

		UIMethods.inputbyid("NewBulkRecoveryDetail:BulkRecoveryDetailDV:InvoiceAmount", "input Check Amount",txtCheckAmount);

		if (!(txtReceiveDate.isEmpty())) {
			Thread.sleep(2000);
			UIMethods.clickbyid(receivedDate, "Click ReceiveDate", "Click");
			Helper.clearTextBox(driver, driver.findElement(By.id(receivedDate)));
			UIMethods.inputbyid(receivedDate, "input ReceiveDate", txtReceiveDate);
		}

		if (!(btnAddLineItems.isEmpty())) {
			UIMethods.clickbyid("NewBulkRecoveryDetail:BulkRecoveryItemsPanel:BulkRecoveryItemsLV_tb:Add", "Click Line Items Add button", "Click");
			Thread.sleep(2000);
		}
		
		if (txtRecoveryClaimNumber.equalsIgnoreCase("CURRENTCLAIM")) {
			txtRecoveryClaimNumber = NewClaimSaved.intClaimNumber;
		}
		
		if (!(txtRecoveryClaimNumber.isEmpty())) {
			UIMethods.inputbyid("NewBulkRecoveryDetail:BulkRecoveryItemsPanel:BulkRecoveryItemsLV:0:claimNumber", "input Claim Number", txtRecoveryClaimNumber);
			UIMethods.clickbyid("NewBulkRecoveryDetail:BulkRecoveryDetailDV:InvoiceAmount", "Click Check Amount", "Click");
		}
		
		if(driver.findElements(By.id("NewBulkRecoveryDetail:BulkRecoveryItemsPanel:BulkRecoveryItemsLV:0:BulkInvoiceItemsLV_ReserveLine")).size()!=0) {
			Thread.sleep(2000);
			UIMethods.selectbyid("NewBulkRecoveryDetail:BulkRecoveryItemsPanel:BulkRecoveryItemsLV:0:BulkInvoiceItemsLV_ReserveLine", "input Reserve Line", ddlRecoveryReserveLine);
		}
		
		if(driver.findElements(By.id("NewBulkRecoveryDetail:BulkRecoveryItemsPanel:BulkRecoveryItemsLV:0:Amount")).size()!=0) {
			Thread.sleep(3000);
			UIMethods.inputbyid("NewBulkRecoveryDetail:BulkRecoveryItemsPanel:BulkRecoveryItemsLV:0:Amount", "input Amount", txtRecoveryAmount);
		}
		
		if(driver.findElements(By.id("NewBulkRecoveryDetail:BulkRecoveryItemsPanel:BulkRecoveryItemsLV:0:Category")).size()!=0) {
			Thread.sleep(1000);
			UIMethods.selectbyid("NewBulkRecoveryDetail:BulkRecoveryItemsPanel:BulkRecoveryItemsLV:0:Category", "input Recovery Category", ddlRecoveryCategory);
			Thread.sleep(3000);
		}
		
		if(driver.findElements(By.id("NewBulkRecoveryDetail:BulkRecoveryItemsPanel:BulkRecoveryItemsLV:0:RecoveryCode")).size()!=0) {
			Thread.sleep(1000);
			UIMethods.selectbyid("NewBulkRecoveryDetail:BulkRecoveryItemsPanel:BulkRecoveryItemsLV:0:RecoveryCode", "input RecoveryCode", ddlRecoveryCode);
			Thread.sleep(3000);
		}
		Thread.sleep(3000);
		
		//Added by RAJ as per Test Case from ALM (Test Plan -> Subject -> Claim Center -> Automation -> Core Regression - Configurations -> Property -> Prop_E2E_Core_Scenario 14
		RemoveUnwantedLineItems();		
		
		// Update Button
		if (!(btnRecoveryUpdate.isEmpty())) {
			Helper.highLightElement(driver, driver.findElement(By.xpath("(//div[@id='NewBulkRecoveryDetail:0']/div/a/span[2])[1]")));
	        UIMethods.jscriptclickbyxpath("(//div[@id='NewBulkRecoveryDetail:0']/div/a/span[2])[1]", "click Update button", "Click");
	        Thread.sleep(3000);
		}
	}

	public void RemoveUnwantedLineItems() throws Exception {
		UIMethods.clickbyid("NewBulkRecoveryDetail:BulkRecoveryItemsPanel:BulkRecoveryItemsLV:1:_Checkbox","Click line Item Checkbox", "Click");
		for (int intLoop = 1; intLoop <= 9; intLoop++) {
			UIMethods.clickbyid("NewBulkRecoveryDetail:BulkRecoveryItemsPanel:BulkRecoveryItemsLV:" + intLoop + ":_Checkbox","Click line Item " + (intLoop + 1) + " Checkbox to remove", "Click");
			Thread.sleep(500);
		}
		
		Helper.highLightElement(driver, driver.findElement(By.id("NewBulkRecoveryDetail:BulkRecoveryItemsPanel:BulkRecoveryItemsLV_tb:Remove")));
		UIMethods.clickbyid("NewBulkRecoveryDetail:BulkRecoveryItemsPanel:BulkRecoveryItemsLV_tb:Remove","Click Remove button", "Click");
		Thread.sleep(7000);
	}
}
