package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class VehicleDetailsInput {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	String SheetName = "ClaimsPolicy";
	
	//Page Objects
	String vehicleYearTextBox = "FNOLVehicleIncidentPopup:FNOLVehicleIncidentScreen:Vehicle_Year";
	String vehicleMakeTextBox = "FNOLVehicleIncidentPopup:FNOLVehicleIncidentScreen:Vehicle_Make";
	String vehicleModelTextBox = "FNOLVehicleIncidentPopup:FNOLVehicleIncidentScreen:Vehicle_Model";
	String vehicleVIN = "FNOLVehicleIncidentPopup:FNOLVehicleIncidentScreen:Vehicle_VIN";
	String frontCheckBox = "FNOLVehicleIncidentPopup:FNOLVehicleIncidentScreen:DamDescFront_EXT";
	String okButton = "//a[@id='FNOLVehicleIncidentPopup:FNOLVehicleIncidentScreen:Update']/span[text()='OK']";
	String vehicleSelection = "NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:Vehicle_Picker";
	String lossParty = "NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:LossParty";
	String VINButton = "//*[@id='NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:Vehicle_Vin_Validation_EXT']/span[2]";
	
	
	public VehicleDetailsInput(WebDriver driver)
	{
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}	
	
	public void VehicleDetailsInputpage(String excelFileName, String profileID) throws Exception {
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String vehicleYear = xlsread.Exceldata(SheetName, "txtVehicleYear", profileID);
		String vehicleMake = xlsread.Exceldata(SheetName, "txtVehicleMake", profileID);
		String vehicleModel = xlsread.Exceldata(SheetName, "txtVehicleModel", profileID);
		String vehicleVin = xlsread.Exceldata(SheetName, "txtVehicleVin", profileID);
		String btnVehicleDetailsOK = xlsread.Exceldata(SheetName, "btnVehicleDetailsOK", profileID);
		String btnVehicleDetailsNext = xlsread.Exceldata(SheetName, "btnVehicleDetailsNext", profileID);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(vehicleYearTextBox)));
		UIMethods.inputbyid(vehicleYearTextBox, "input vehicle year", vehicleYear);
		UIMethods.inputbyid(vehicleMakeTextBox, "input vehicle make", vehicleMake);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(vehicleModelTextBox)));
		UIMethods.inputbyid(vehicleModelTextBox, "input vehicle model", vehicleModel);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(vehicleVIN)));
		UIMethods.inputbyid(vehicleVIN, "input vehicle vin", vehicleVin);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(frontCheckBox)));
		UIMethods.clickbyid(frontCheckBox, "click Front checkbox", "Click");
		Thread.sleep(3000);

		if (!(btnVehicleDetailsOK.isEmpty())) {
			Helper.highLightElement(driver, driver.findElement(By.xpath(okButton)));
			UIMethods.jscriptclickbyxpath(okButton, "click ok button", "Click");
			Thread.sleep(2000);
		}

		if (!(btnVehicleDetailsNext.isEmpty())) {
			Helper.highLightElement(driver, driver.findElement(By.xpath("//span[text()='Next >']")));
			UIMethods.jscriptclickbyxpath("//span[text()='Next >']", "click Next button", "Click");
			Thread.sleep(3000);
		}
	}
	
	public void VehicleDetailsInputpage1(String excelFileName, String profileID) throws Exception {
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlvehicleselecttype = xlsread.Exceldata(SheetName, "ddlvehicleselecttype", profileID);
		String ddlLossParty = xlsread.Exceldata(SheetName, "ddlLossParty", profileID);
		String vehicleYear = xlsread.Exceldata(SheetName, "txtVehicleYear", profileID);
		String vehicleMake = xlsread.Exceldata(SheetName, "txtVehicleMake", profileID);
		String vehicleModel = xlsread.Exceldata(SheetName, "txtVehicleModel", profileID);
		String vehicleVin = xlsread.Exceldata(SheetName, "txtVehicleVin", profileID);
		
		Thread.sleep(2000);
		UIMethods.selectbyid(vehicleSelection, "input select vehicle", ddlvehicleselecttype);
		UIMethods.selectbyid(lossParty, "input select vehicle", ddlLossParty);
		UIMethods.inputbyid(vehicleYearTextBox, "input vehicle year", vehicleYear);
		UIMethods.inputbyid(vehicleMakeTextBox, "input vehicle make", vehicleMake);
		UIMethods.inputbyid(vehicleModelTextBox, "input vehicle model", vehicleModel);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(vehicleVIN)));
		UIMethods.inputbyid(vehicleVIN, "input vehicle vin", vehicleVin);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(VINButton)));
		UIMethods.jscriptclickbyxpath(VINButton, "click validate Vin button", "Click");
		Thread.sleep(2000);
	}
	
	public void NewVehicleIncidentPage(String excelFileName, String profileID) throws Exception {
		 String projectdir = System.getProperty("user.dir");
		 ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		 String ddlvehicleselecttype = xlsread.Exceldata(SheetName, "ddlvehicleselecttype", profileID);
		 String ddlLossParty = xlsread.Exceldata(SheetName, "ddlLossParty", profileID);
		 String vehicleYear = xlsread.Exceldata(SheetName, "txtVehicleYear", profileID);
		 String vehicleMake = xlsread.Exceldata(SheetName, "txtVehicleMake", profileID);
		 String vehicleModel = xlsread.Exceldata(SheetName, "txtVehicleModel", profileID);
		 String vehicleVin = xlsread.Exceldata(SheetName, "txtVehicleVin", profileID);
		 
		 Thread.sleep(2000);  
		 UIMethods.selectbyid(vehicleSelection, "input select vehicle", ddlvehicleselecttype);
		 UIMethods.selectbyid(lossParty, "input select vehicle", ddlLossParty);
		 Thread.sleep(2000);
		 UIMethods.inputbyid("NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:Vehicle_Year", "input vehicle year", vehicleYear);
         UIMethods.inputbyid("NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:Vehicle_Make", "input vehicle make", vehicleMake);
         UIMethods.inputbyid("NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:Vehicle_Model", "input vehicle model", vehicleModel);
         Thread.sleep(2000);
         UIMethods.inputbyid("NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:Vehicle_VIN", "input vehicle vin", vehicleVin);
         UIMethods.clickbyxpath(VINButton, "click validate Vin button", "Click");
         Thread.sleep(2000);
	}
	
	public void ServiceNeededSection() throws Exception {
		UIMethods.clickbyid("FNOLVehicleIncidentPopup:FNOLVehicleIncidentScreen:VehicleIncidentPanelSet:VehicleIncidentRentalDV:RentalInputGroup:_checkbox", "click Rental checkbox", "Click");
        Thread.sleep(500);
        UIMethods.clickbyid("FNOLVehicleIncidentPopup:FNOLVehicleIncidentScreen:VehicleIncidentPanelSet:VehicleIncidentRentalDV:RentalInputGroup:RentalCarAuth_EXT_false", "click No in Rental Car Authorized", "Click");
        Thread.sleep(2000);
        UIMethods.clickbyid("FNOLVehicleIncidentPopup:FNOLVehicleIncidentScreen:VehicleIncidentPanelSet:VehicleIncidentTowingDV:TowingInputGroup:_checkbox", "click Towing Checkbox", "Click");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(frontCheckBox)));
        UIMethods.clickbyid(frontCheckBox, "click Front Checkbox", "Click");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(okButton)));
        UIMethods.jscriptclickbyxpath(okButton, "click ok button", "Click");
        Thread.sleep(2000);
	}
	
	public void addCitation(String excelFileName, String profileID) throws Exception {
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtCitationNumber = xlsread.Exceldata(SheetName, "txtCitationNumber", profileID);
		Thread.sleep(2000);
		UIMethods.jscriptclickbyxpath("//*[@id='FNOLVehicleIncidentPopup:FNOLVehicleIncidentScreen:OtherDetailsDV:DriverCitationsLV_tb:Add']", "click add citiation button", "Click");
		Thread.sleep(2000);
		UIMethods.inputbyid("FNOLVehicleIncidentPopup:FNOLVehicleIncidentScreen:OtherDetailsDV:DriverCitationsLV:0:CitationsArray_CitationNumber", "input CitationNumber", txtCitationNumber);
	}
}