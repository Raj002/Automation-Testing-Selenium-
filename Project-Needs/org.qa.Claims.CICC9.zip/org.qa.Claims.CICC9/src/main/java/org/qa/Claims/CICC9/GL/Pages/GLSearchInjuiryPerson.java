package org.qa.Claims.CICC9.GL.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class GLSearchInjuiryPerson {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	public GLSearchInjuiryPerson(WebDriver driver)
	{
		this.driver = driver;
	}	
	
	public void GLSearchInjuiryPersonPage() throws Exception{
		Thread.sleep(1000);
		//Search Injuiry Person
        UIMethods.jscriptclickbyxpath("//*[@id='NewInjuryIncidentPopup:NewInjuryIncidentScreen:InjuryIncidentDV:Injured_Picker:Injured_PickerMenuIcon']/img", "Click Arrow Button", "Click");
        Thread.sleep(1000);
        UIMethods.jscriptclickbyxpath("//*[@id='NewInjuryIncidentPopup:NewInjuryIncidentScreen:InjuryIncidentDV:Injured_Picker:MenuItem_Search']", "Click Search option", "Click");
        Thread.sleep(3000);
	}
}
