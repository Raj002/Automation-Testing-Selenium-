package org.qa.Claims.CICC9.Property.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class SummaryClaimStatus {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	public SummaryClaimStatus(WebDriver driver)
	{
		this.driver = driver;
	}	
	
	public void SummaryClaimStatusPage() throws Exception{
        //check loss date value
		//UIMethods.getSpanValueUsingID("check loss date", "ClaimSummary:ClaimSummaryScreen:ClaimSummaryDV:LossDate", "12/03/2012 12:00 AM");

        //***************click claims links
		UIMethods.clickbyid("ClaimSummaryGroup:MenuLinks:ClaimSummaryGroup_ClaimStatus", "Click Claim Status", "Click");
		Thread.sleep(2000);
	}
}