package org.qa.Claims.CICC9.Auto.Pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.CommonScreens.InjuiryIncident;
import org.qa.Claims.CICC9.CommonScreens.NewExposureEntry;
import org.qa.Claims.CICC9.CommonScreens.NewPersonContactDetail;
import org.qa.Claims.CICC9.Property.Pages.NewPropertyIncident;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class Exposure_PIP extends Object_Repositories {
	public WebDriver driver;

	// Page Objects
	String locationDropdown = "//input[contains(@id,'Address_Picker-inputEl')]";
	String locationCity = "//input[contains(@id,'City-inputEl')]";
	String locationState = "//input[@id='NewClaimWizard_NewExposurePopup:NewClaimWizard_ExposurePageScreen:NewClaimExposureDV:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:State-inputEl']";
	String locationZipCode = "//input[contains(@id,'PostalCode-inputEl')]";
	String addressLine1 = "//input[contains(@id,'AddressLine1-inputEl')]";
	String severityField = "//input[contains(@id,'Damage_Severity-inputEl')]";
	
	String claimantTypeField = "//input[contains(@id,'ClaimantType-inputE')]";
	String claimantNameField = "//input[contains(@id,'Claimant-inputE')]";

	public Exposure_PIP(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}

	public void validateAndEnterPIPExposure(String excelFileName, String profileID) throws Exception {
		InjuiryIncident injuryIncident = new InjuiryIncident(driver);

		xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String expectedCoverageType = xlsread.Exceldata(SheetName, "CoverageType", profileID);
		String expectedCoverageSubType = xlsread.Exceldata(SheetName, "Coverage Subtype", profileID);
		String modeOfExposure = xlsread.Exceldata(SheetName, "ExposureMode", profileID);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newExposureTitle)));

		if (driver.findElements(By.xpath(primaryCoverage)).size() != 0) {
			String actualPrimaryCoverage = driver.findElement(By.xpath(primaryCoverage)).getText();
			Assert.assertEquals(actualPrimaryCoverage, expectedCoverageType);
		}

		if (driver.findElements(By.xpath(coverageSubType)).size() != 0) {
			String actualCoverageSubType = driver.findElement(By.xpath(coverageSubType)).getText();
			
			// This will remove the extra white spaces between the sentences
			if (actualCoverageSubType.contains("'") | expectedCoverageSubType.contains("'")) {
				String actual = actualCoverageSubType.replace(" ", "");
				String expected = expectedCoverageSubType.replace(" ", "");
				Assert.assertTrue(actual.contains(expected));
			} else {
				Assert.assertEquals(actualCoverageSubType, expectedCoverageSubType);
			}
		}

		UIMethods.jscriptclickbyxpath(riskUnit, "Select Coverage / Risk unit", "Click");
		Thread.sleep(1000);
		if (driver.findElements(By.xpath(firstDropdownOption)).size() != 0) {
			driver.findElement(By.xpath(firstDropdownOption)).click();
		}
		
		for(int i=0;i<=4;i++) {
			try {
				Assert.assertTrue(Helper.getUIXpath(driver, "Coverage / Risk Unit").isDisplayed());
				Assert.assertTrue(Helper.getUIXpath(driver, "Potential Large Loss?").isDisplayed());														     
			} catch(StaleElementReferenceException e) {
				e.getMessage();
			}
		}
		
		if(modeOfExposure.equalsIgnoreCase("during")) {
			Assert.assertTrue(Helper.getUIXpath(driver, "Contact Permitted").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver, "Primary Phone").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver, "Eligible for SSDI?").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver, "Carrier Name").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver, "Address").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver, "Primary Contact").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver, "Primary Phone").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver, "Weekly Compensation Rate").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver, "Additional Information").isDisplayed());
		}
		
		// Validate UI from PIP
		Thread.sleep(1000);
		Assert.assertTrue(Helper.getUIXpath(driver, "CERC Exposure").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Injury").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Injured Person").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Severity").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Description").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Claimant").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Type").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Other Coverage Info").isDisplayed());
		
		// Post
		if(modeOfExposure.equalsIgnoreCase("post")) {
			//Assert.assertTrue(Helper.getUIXpath(driver, "Pay Direction Code").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver, "Reservation of Rights").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver, "Contact Prohibited?").isDisplayed());
			/*Assert.assertTrue(Helper.getUIXpath(driver, "Benefits Begin Date").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver, "Benefits End Date").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver, "Max Benefit Amount").isDisplayed());
			Assert.assertTrue(Helper.getUIXpath(driver, "Additional Information").isDisplayed());*/
			Assert.assertTrue(Helper.getUIXpath(driver, "Structured Settlement?").isDisplayed());
		}
		

		// Validating details table
		Assert.assertTrue(Helper.getUIXpath(driver, "Insurer").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Claim #").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Policy #").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Contact").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Phone").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Notes").isDisplayed());

		if (driver.findElement(By.xpath(lossParty)) != null) {
			String actualLossParty = driver.findElement(By.xpath(lossParty)).getText();
			if (actualLossParty.contains("Insured's loss")) {

				String insuredName = driver.findElement(By.xpath(getInsuredName)).getText();
				String actualInsuredName = insuredName.substring(5).trim();
				Thread.sleep(2000);
				Helper.selectDropdownValue(driver, "xpath", this.claimantNameField, "Select Claimant", actualInsuredName);
				Thread.sleep(3000);
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(this.claimantTypeField)));
				
				if(modeOfExposure.equalsIgnoreCase("post")) {
					if(driver.findElements(By.xpath("//input[contains(@id,'CompBenefits_Description-input')]")).size()!=0) {
						driver.findElement(By.xpath("//input[contains(@id,'CompBenefits_Description-input')]")).click();
						Thread.sleep(1000);	
					}		
					if(driver.findElements(By.xpath("//input[contains(@id,'Claimant_OtherCoverage_false-inputE')]")).size()!=0) {
						driver.findElement(By.xpath("//input[contains(@id,'Claimant_OtherCoverage_false-inputE')]")).click();
					}
					// To Enter Incident Overview Vehicle details
					UIMethods.jscriptclickbyxpath(propertyNameArrowIcon, "Click Injury incident Arrow Icon", "Click");					
				} else {		
					Thread.sleep(1000);	
					// To Enter Incident Overview Vehicle details
					UIMethods.jscriptclickbyxpath("(//a[contains(@id,'MenuIcon')]/img)[1]", "Click Injury incident Arrow Icon", "Click");					
				}
				Thread.sleep(1000);	
				UIMethods.clickbyWebElement(Helper.getUIXpath(driver, "New Incident..."), "Select New Incident option","Click");
				injuryIncident.AddInjuiryIncidentPage(excelFileName, profileID);

			} 

		// Click on OK Button from New Exposure Screen
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newExposureTitle)));

		Helper.getScreenshot(driver, "PIP_Exposure",  modeOfExposure+"_TC_" +profileID+ "_");
		
		// Click OK Button During FNOL
		if (driver.findElements(By.xpath(okButton)).size() != 0) {
			UIMethods.jscriptclickbyxpath(okButton, "Click OK Button", "Click");
		}

		// Click Update Button Post FNOL
		if (driver.findElements(By.xpath(updateButton)).size() != 0) {
			UIMethods.jscriptclickbyxpath(updateButton, "Click Update Button", "Click");
		}
		
		// Writing Exposure created status into the Excel sheet in Status Column for
		// both during and post FNOL
		if (driver.findElements(By.xpath(saveAndAssignClaimLabel)).size() != 0 | driver.findElements(By.xpath(exposureScreenLabel)).size() != 0) {
			if (modeOfExposure.equalsIgnoreCase("during")) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(saveAndAssignClaimLabel)));
				if(driver.findElements(By.xpath(saveAndAssignClaimLabel)).size()!=0) {
					xlsread.WriteIntoExistingExcel(SheetName, "PIPStatus", "Pass", profileID, true);
					xlsread.WriteIntoExistingExcel(SheetName, "statusForAllExposures", "Pass", profileID, true);
				} else {
					xlsread.WriteIntoExistingExcel(SheetName, "PIPStatus", "Fail", profileID, false);
					xlsread.WriteIntoExistingExcel(SheetName, "statusForAllExposures", "Fail", profileID, false);
				}
			} else if (modeOfExposure.equalsIgnoreCase("post")) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(exposureScreenLabel)));
				if(driver.findElements(By.xpath(exposureScreenLabel)).size()!=0) {
					xlsread.WriteIntoExistingExcel(SheetName, "PIPStatus", "Pass", profileID, true);
					xlsread.WriteIntoExistingExcel(SheetName, "statusForAllExposures", "Pass", profileID, true);
				} else {
					xlsread.WriteIntoExistingExcel(SheetName, "PIPStatus", "Fail", profileID, false);
					xlsread.WriteIntoExistingExcel(SheetName, "statusForAllExposures", "Fail", profileID, false);
				}
			}		
			
		}
	} else {
		Report.fail("Loss Party isn't available in Exposure screen", "Loss Party", "Loss Party","Loss Party not available");
		Assert.fail("Loss Party is not available..");
	} }
}
