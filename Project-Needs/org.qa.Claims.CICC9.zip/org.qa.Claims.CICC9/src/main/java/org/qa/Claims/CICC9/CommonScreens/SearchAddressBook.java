package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class SearchAddressBook {
	
	WebDriver driver;
	WebDriverWait wait;
	String txtSearchType;
	String txtFirstName;
	String txtLastName;	
	
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	//Page Objects
	String searchAddressBookType = "//input[@id='AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:ContactSubtype-inputEl']";
	String firstName = "AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:FirstName-inputEl";
	String lastName = "AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:Keyword-inputEl";
	String searchButton = "//a[@id='AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search']";
	String resetButton = "//a[@id='AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Reset']";
	
	
	String nameField = "AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:Keyword";
	String firstNameField = "AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:FirstName";
	String searchType = "AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:ContactSubtype";
	
	public SearchAddressBook(WebDriver driver){
		this.driver = driver;
		wait = new WebDriverWait(driver, 15);
	}
		
	public void SearchCreatePolicyPage(String excelFileName, String profileID) throws Exception{		
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");	
		txtFirstName = xlsread.Exceldata(SheetName, "txtSearchFirstName", profileID);
		txtLastName = xlsread.Exceldata(SheetName, "txtSearchLastName", profileID);
		txtSearchType = xlsread.Exceldata(SheetName, "ddlSearchType", profileID);
		
		Helper.selectDropdownValue(driver, "id", searchAddressBookType, "Select search type", txtSearchType);			
		//UIMethods.clearAndinputbyxpath(searchAddressBookType, "Select search type", txtSearchType);
		UIMethods.inputbyid(firstName, "Enter First Name" , txtFirstName);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(searchButton)));
		UIMethods.clickbyxpath(searchButton, "Click Search button", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("")));
		
		// Need to update the object properties for select button from the search results
		UIMethods.jscriptclickbyxpath("//*[@id='AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:_Select_link']", "Click Select Button", "Click");
		Thread.sleep(5000);
	}
	
	public void SearchForClaimantContact(String excelFileName, String profileID) throws Exception{
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");		
		txtLastName = xlsread.Exceldata(SheetName, "txtLastName", profileID);
		
		UIMethods.inputbyxpath(resetButton, "Click Reset button", "Click");
		wait.until(ExpectedConditions.elementToBeClickable(By.id(lastName)));
		UIMethods.inputbyid(lastName, "Enter Last name", txtLastName);		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(searchButton)));
		UIMethods.clickbyxpath(searchButton, "Click Search button", "Click");
		
		// Need to update the object properties for select button from the search results
		UIMethods.clickbyid("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:_Select", "Click Select button", "Click");
	}

	public void SearchbyPersonType(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");		
		txtSearchType = xlsread.Exceldata(SheetName, "ddlType", profileID);
		txtFirstName = xlsread.Exceldata(SheetName, "txtFirstName", profileID);
		txtLastName = xlsread.Exceldata(SheetName, "txtLastName", profileID);

		Helper.selectDropdownValue(driver, "id", searchAddressBookType, "Select search type", txtSearchType);	
		//UIMethods.clearAndinputbyxpath(searchAddressBookType, "Select search type", txtSearchType);
		wait.until(ExpectedConditions.elementToBeClickable(By.id(firstName)));
		UIMethods.inputbyid(firstName, "Enter First Name" , txtFirstName);
		wait.until(ExpectedConditions.elementToBeClickable(By.id(lastName)));
		UIMethods.inputbyid(lastName, "Enter Last Name" , txtLastName);		
		UIMethods.clickbyxpath(searchButton, "Click Search button", "Click");
		
		// Need to update the object properties for select button from the search results
		UIMethods.clickbyid("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:_Select", "Click Select button", "Click");		
	}

}