package org.qa.Claims.CICC9.Property.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class QuickClaimProperty {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	String newPersonOption = "//div[@id='FNOLWizard:NewClaimWizard_QuickClaimScreen:QuickClaimDV:ReportedBy_Name:ClaimNewPersonOnlyPickerMenuItemSet:ClaimNewPersonOnlyPickerMenuItemSet_NewPersonMenuItem']/a/span[text()='New Person']";
	
	public QuickClaimProperty(WebDriver driver)
	{
		this.driver = driver;
		wait = new WebDriverWait(driver, 15);
	}	
	
	public void QuickClaimPropertypage() throws Exception{
		UIMethods.clickbyid("FNOLWizard:NewClaimWizard_QuickClaimScreen:QuickClaimDV:ReportedBy_Name:ReportedBy_NameMenuIcon", "Click Name arrow icon", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newPersonOption)));
		UIMethods.jscriptclickbyxpath(newPersonOption, "Select new Person Option", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewContactPopup:ContactDetailScreen:ttlBar")));
	}	
}