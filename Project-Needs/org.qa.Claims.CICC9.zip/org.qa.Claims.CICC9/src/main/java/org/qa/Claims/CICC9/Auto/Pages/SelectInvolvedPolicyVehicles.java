package org.qa.Claims.CICC9.Auto.Pages;

import org.qa.Claims.CICC9.Technology.UIMethods;

public class SelectInvolvedPolicyVehicles {
	
	public void SelectInvolvedPolicyVehiclespage() throws Exception{
		Thread.sleep(2000);
        UIMethods.clickbyid("FNOLWizard:FNOLWizard_PickPolicyRiskUnitsScreen:PolicySummaryVehicleLV:0:VehicleSelected", "select anyone checkbox", "Click");
        Thread.sleep(1000);
        UIMethods.clickbyid("FNOLWizard:Next", "Click Next Button", "Click");	
        Thread.sleep(2000);
	}
}