package org.qa.Claims.CICC9.Auto.Pages;

import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.testng.Assert;

public class Exposures {

	private WebDriver driver = null;
	WebDriverWait wait;

	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");

	// Page Objects
	//String claimExposureGroup = "//*[@id='Claim:MenuLinks:Claim_ClaimExposuresGroup']/div";
	String exposureLVCheckBox = "//img[contains(@class,'x-grid-checkcolumn')]";
	String createReserveButton = "//a[@id='ClaimExposures:ClaimExposuresScreen:ClaimExposures_CreateReserve']/span";
	

	public Exposures(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 15);
	}
	
	public void Exposurespage() throws Exception {
		
		Helper.clickClaimSubMenu(driver, "Exposures");	
		Helper.clickCheckBox(exposureLVCheckBox, "Click First Exposure check box to create reserve");
		
		if(!driver.findElement(By.id("ClaimExposures:ClaimExposuresScreen:ClaimExposures_CreateReserve")).getAttribute("class").contains("disabled")) {
			 UIMethods.clickbyxpath(createReserveButton, "click Create Reserve button", "Click");
		} else {
        	Assert.fail("Create reserve button is disabled. Failed to click Exposure check box...");
        } 		
          
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='NewReserveSet:NewReserveSetScreen:ttlBar' and text()='Set Reserves' ]")));
	}
	
	public void ExposureAssignPage() throws Exception{
		Helper.clickClaimSubMenu(driver, "Exposures");		
		UIMethods.clickbyxpath(exposureLVCheckBox, "Click First Exposure to Assign exposure ", "Click"); 
        UIMethods.clickbyxpath("//a[@id='ClaimExposures:ClaimExposuresScreen:ClaimExposures_Assign']/span", "click Assign Button", "Click");
        Thread.sleep(2000);
	}
	
	public void ExposureDetailsPage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlInsuredType = xlsread.Exceldata(SheetName, "ddlInsuredType", profileID);
		
		UIMethods.clickbyid("ExposureDetail:ExposureDetailScreen:Edit", "click Edit", "Click");
		Thread.sleep(2000);
        UIMethods.selectbyid("ExposureDetail:ExposureDetailScreen:ExposureDetailDV:ExposureDetailDV:Claimant_Type", "input Claimant Type", ddlInsuredType);
        UIMethods.clickbyxpath("//span[text()='pdate']", "click Update Button", "Click");
        Thread.sleep(2000);
	}
	
	public void VerifyLossParty(String excelFileName, String profileID) throws Exception{
		Thread.sleep(1000);		
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String lblLossParty = xlsread.Exceldata(SheetName, "lblLossParty", profileID);
			
		String actualLossParty = driver.findElement(By.id("ExposureDetail:ExposureDetailScreen:ExposureDetailDV:ExposureDetailDV:LossParty")).getText();
		if (actualLossParty.equalsIgnoreCase(lblLossParty)) {
			Report.pass("Verify Text", "Financial transacion", lblLossParty + " should available in Loss Party", actualLossParty + " is exist in Loss Party");
		} else {
			Report.fail("Verify Text", "Financial transacion", lblLossParty + " should available in Loss Party", actualLossParty + " is not same as in Loss Party");
		}	
	}
}
