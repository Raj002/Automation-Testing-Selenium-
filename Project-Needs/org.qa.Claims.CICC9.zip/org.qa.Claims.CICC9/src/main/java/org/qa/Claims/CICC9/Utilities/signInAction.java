package org.qa.Claims.CICC9.Utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class signInAction extends Object_Repositories{

	private WebDriver driver = null;
	Properties prop;

	String userName = "Login:LoginScreen:LoginDV:username-inputEl";
	String password = "Login:LoginScreen:LoginDV:password-inputEl";
	String submitButton = "Login:LoginScreen:LoginDV:submit";

	public signInAction(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 30);
		prop = new Properties();
		FileInputStream fis;
		try {
			fis = new FileInputStream(".//src/test/resources/Config.Properties");
			prop.load(fis);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void ClaimsLogin() throws Exception {
		// Verify Page
		UIMethods.PageVerification(driver.findElement(By.id(userName)), "Login");		
		wait.until(ExpectedConditions.elementToBeClickable(By.id(userName)));
		UIMethods.inputbyid(userName, "Enter User Name", prop.getProperty("USER_NAME"));
		wait.until(ExpectedConditions.elementToBeClickable(By.id(password)));
		UIMethods.inputbyid(password, "Enter Password", prop.getProperty("PASSWORD"));
		UIMethods.clickbyid(submitButton, "Click Login button", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("container-1011-innerCt")));
	}

	public void ClaimsContactCenterLogin() throws Exception {
		driver.get("https://stage-amcontactcenter.lmig.com/ab/ContactCenter.do");
		Thread.sleep(2000);
		UIMethods.clearAndinputbyxpath(userName, "Enter User Name", prop.getProperty("USER_NAME"));
		UIMethods.clearAndinputbyxpath(password, "Enter Password", prop.getProperty("PASSWORD"));
		UIMethods.clickbyname(submitButton, "Click Login button", "Click");
		Thread.sleep(3000);
	}

	public void ClaimsLoginTest1Automation() throws Exception {
		UIMethods.clearAndinputbyxpath(userName, "Enter User Name", "n9985790");
		UIMethods.clearAndinputbyxpath(password, "Enter Password", "uatest26");
		UIMethods.clickbyname(submitButton, "Click Login button", "Click");
		Thread.sleep(2000);
	}

	public void ClaimsLogBackIn() throws Exception {
		Thread.sleep(2000);
		UIMethods.jscriptclickbyxpath("//a[text()='Log Back In']", "Click Log Back-In Link", "Click");
		Thread.sleep(4000);
		UIMethods.clearAndinputbyxpath(userName, "Enter User Name", prop.getProperty("USER_NAME"));
		UIMethods.clearAndinputbyxpath(password, "Enter Password", prop.getProperty("PASSWORD"));
		UIMethods.clickbyname(submitButton, "Click Login button", "Click");
		Thread.sleep(2000);
	}

}
