package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class NewPropertyLiabilityIncident {

	private WebDriver driver = null;
	WebDriverWait wait;

	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");

	// Page Objects
	String propertyDescription = "NewFixedPropertyIncidentPopup:NewFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixedPropertyIncidentDV:PropertyDescription";
	String demageDescription = "NewFixedPropertyIncidentPopup:NewFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixedPropertyIncidentDV:Description";
	String propertySeverity = "NewFixedPropertyIncidentPopup:NewFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixedPropertyIncidentDV:fixedPropertySeverity";
	String propertyName = "NewFixedPropertyIncidentPopup:NewFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixedPropertyIncidentDV:AddressInputSet:Address_Picker";
	String addressLine1 = "NewFixedPropertyIncidentPopup:NewFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixedPropertyIncidentDV:AddressInputSet:Address_AddressLine1";
	String locationNumber = "NewFixedPropertyIncidentPopup:NewFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixedPropertyIncidentDV:AddressInputSet:Address_LocationNumber";
	String buildingNumber = "NewFixedPropertyIncidentPopup:NewFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixedPropertyIncidentDV:AddressInputSet:Address_BuildingNumber";
	String propertyCity = "NewFixedPropertyIncidentPopup:NewFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixedPropertyIncidentDV:AddressInputSet:Address_City";
	String okButton = "//a[@id='NewFixedPropertyIncidentPopup:NewFixedPropertyIncidentScreen:Update']/span[text()='OK']";

	public NewPropertyLiabilityIncident(WebDriver driver) {
		this.driver = driver;
	}

	public void NewPropertyLiabilityIncidentPage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtPropertyDescription = xlsread.Exceldata(SheetName, "txtPropertyDescription", profileID);
		String txtDamageDescription = xlsread.Exceldata(SheetName, "txtDamageDescription", profileID);
		String ddlPropertySeverity = xlsread.Exceldata(SheetName, "ddlPropertySeverity", profileID);
		String ddlPropertyName = xlsread.Exceldata(SheetName, "ddlPropertyName", profileID);
		String txtPropertyAddress1 = xlsread.Exceldata(SheetName, "txtPropertyAddress1", profileID);
		String txtLocationNumber = xlsread.Exceldata(SheetName, "txtLocationNumber", profileID);
		String txtBuildingNumber = xlsread.Exceldata(SheetName, "txtBuildingNumber", profileID);
		String txtPropertyCity = xlsread.Exceldata(SheetName, "txtPropertyCity", profileID);
		String btnPropLiabIncidentDetailsOK = xlsread.Exceldata(SheetName, "btnPropLiabIncidentDetailsOK", profileID);
		// Add Property Liability Incident Details
		Thread.sleep(2000);
		UIMethods.inputbyid(propertyDescription, "input PropertyDescription", txtPropertyDescription);
		UIMethods.inputbyid(demageDescription, "input DamageDescription", txtDamageDescription);
		Thread.sleep(2000);
		UIMethods.selectbyid(propertySeverity, "input PropertySeverity", ddlPropertySeverity);
		Thread.sleep(2000);

		if (!(ddlPropertyName.isEmpty())) {
			String strExpected = "New";
			if (ddlPropertyName.contains(strExpected)) {
				UIMethods.selectbyid(propertyName, "input PropertyName", "New...");
			} else {
				UIMethods.selectbyid(propertyName, "input PropertyName", ddlPropertyName);
			}
			Thread.sleep(3000);
		}

		UIMethods.inputbyid(addressLine1, "input PropertyAddress1", txtPropertyAddress1);
		Thread.sleep(3000);
		UIMethods.inputbyid(locationNumber, "input Location Number", txtLocationNumber);
		UIMethods.inputbyid(buildingNumber, "input Building Number", txtBuildingNumber);
		UIMethods.inputbyid(propertyCity, "input PropertyCity", txtPropertyCity);
		Thread.sleep(2000);
		if (!(btnPropLiabIncidentDetailsOK.isEmpty())) {
			UIMethods.jscriptclickbyxpath(okButton, "click ok button", "Click");
			Thread.sleep(2000);
		}
	}

	public void NewPropertyIncidentPage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtPropertyDescription = xlsread.Exceldata(SheetName, "txtPropertyDescription", profileID);
		String txtDamageDescription = xlsread.Exceldata(SheetName, "txtDamageDescription", profileID);
		String ddlPropertySeverity = xlsread.Exceldata(SheetName, "ddlPropertySeverity", profileID);
		String rdoHabitable = xlsread.Exceldata(SheetName, "rdoHabitable", profileID);
		String ddlPropertyName = xlsread.Exceldata(SheetName, "ddlPropertyName", profileID);
		String txtPropertyAddress1 = xlsread.Exceldata(SheetName, "txtPropertyAddress1", profileID);
		String txtLocationNumber = xlsread.Exceldata(SheetName, "txtLocationNumber", profileID);
		String txtBuildingNumber = xlsread.Exceldata(SheetName, "txtBuildingNumber", profileID);
		String txtPropertyCity = xlsread.Exceldata(SheetName, "txtPropertyCity", profileID);
		String btnPropLiabIncidentDetailsOK = xlsread.Exceldata(SheetName, "btnPropLiabIncidentDetailsOK", profileID);

		// Add Property Liability Incident Details
		UIMethods.inputbyid(propertyDescription, "input PropertyDescription", txtPropertyDescription);
		UIMethods.inputbyid(demageDescription, "input DamageDescription", txtDamageDescription);
		Thread.sleep(2000);
		UIMethods.selectbyid(propertySeverity, "input PropertySeverity", ddlPropertySeverity);
		if (!(rdoHabitable.isEmpty())) {
			if (rdoHabitable.equalsIgnoreCase("false")) {
				UIMethods.clickbyid("NewFixedPropertyIncidentPopup:NewFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixedPropertyIncidentDV:PropertyHabitable_false","Click Habitable No Option", "click");
			} else {
				UIMethods.clickbyid("NewFixedPropertyIncidentPopup:NewFixedPropertyIncidentScreen:FixPropIncidentDetailDV:FixedPropertyIncidentDV:PropertyHabitable_true","Click Habitable Yes Option", "click");
			}
		}
		if (!(ddlPropertyName.isEmpty())) {
			String strExpected = "New";
			if (ddlPropertyName.contains(strExpected)) {
				UIMethods.selectbyid(propertyName, "input PropertyName", "New...");
			} else {
				UIMethods.selectbyid(propertyName, "input PropertyName", ddlPropertyName);
			}
			Thread.sleep(3000);
		}
		UIMethods.inputbyid(addressLine1, "input PropertyAddress1", txtPropertyAddress1);
		Thread.sleep(2000);
		UIMethods.inputbyid(locationNumber, "input Location Number", txtLocationNumber);
		Thread.sleep(2000);
		UIMethods.inputbyid(buildingNumber, "input Building Number", txtBuildingNumber);
		Thread.sleep(2000);
		UIMethods.inputbyid(propertyCity, "input PropertyCity", txtPropertyCity);
		Thread.sleep(2000);
		if (!(btnPropLiabIncidentDetailsOK.isEmpty())) {
			Helper.highLightElement(driver, driver.findElement(By.xpath(okButton)));
			UIMethods.jscriptclickbyxpath(okButton, "click ok button", "Click");
			Thread.sleep(2000);
		}
	}
}