package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class AddOfficials {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	public AddOfficials(WebDriver driver)
	{
		this.driver = driver;
	}	
	
	public void AddOfficialspage(String excelFileName, String profileID) throws Exception {	
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlOfficialType = xlsread.Exceldata(SheetName, "ddlOfficialType", profileID);
		String txtOfficialName = xlsread.Exceldata(SheetName, "txtOfficialName", profileID);
			
		Thread.sleep(5000);
		WebElement addofficialsbutton = driver.findElement(By.xpath("//a[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:AtTheSceneDV:Claim_Officials:EditableOfficialsLV_tb:Add']/span[text()='Add']"));
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("arguments[0].click();", addofficialsbutton);
		Thread.sleep(2000);
        UIMethods.selectbyid("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:AtTheSceneDV:Claim_Officials:EditableOfficialsLV:0:OfficialType", "input officials type", ddlOfficialType);
        UIMethods.inputbyid("FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:AtTheSceneDV:Claim_Officials:EditableOfficialsLV:0:Name", "input officials name", txtOfficialName);
        UIMethods.clickbyxpath("//a[@id='FNOLWizard:Next']/span[text()='Next >']", "click Next button", "Click");
        Thread.sleep(3000);
	}
}