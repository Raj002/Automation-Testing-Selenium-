package org.qa.Claims.CICC9.Technology;

import java.io.IOException;

import org.apache.log4j.Logger;

import com.itextpdf.text.io.RandomAccessSourceFactory;
import com.itextpdf.text.pdf.PRTokeniser;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.RandomAccessFileOrArray;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;


/**
 * Reusable component for Web services
 */

public class PDFFunctions {
	
	
	private static final Logger LOG = Logger.getLogger(PDFFunctions.class);
	
	
	/**
	 * @param src
	 * @param pageNum
	 * @return String
	 * @MethodName parsePdf
	 * @MethodDescription Method to parse a PDF file and return the contents in the form of a String
	 */
	public String parsePdf(String src,int pageNum) {
		String pdfRead="";
		PdfReader reader;
		try {
			reader = new PdfReader(src);
			byte[] streamBytes = reader.getPageContent(pageNum);
			PRTokeniser tokenizer = new PRTokeniser(
					new RandomAccessFileOrArray(
							new RandomAccessSourceFactory()
									.createSource(streamBytes)));
			while (tokenizer.nextToken()) {
				
				if (tokenizer.getTokenType() == PRTokeniser.TokenType.STRING) {
					if(tokenizer.getStringValue().toString().contains("\n"))
						pdfRead=pdfRead+tokenizer.getStringValue()+"\n";
					else
						pdfRead=pdfRead+tokenizer.getStringValue();						
					
				}
	
			}

			reader.close();
		} catch (IOException e) {
			LOG.debug("Catch Exception: " + e.getMessage(),e);	
		}
		return pdfRead;
	}
	
	/**
	 * 
	 * @param sourceFilePath
	 * @param pageNum
	 * @return String
	 * @MethodName readPDFInBulk
	 * @MethodDescription Read PDF File whole contents instead of line by line
	 */
	public static String readPDFInBulk(String sourceFilePath,int pageNum){

		String pdfRead="";
		PdfReader reader;	
		try {
			reader = new PdfReader(sourceFilePath);
			String temp = PdfTextExtractor.getTextFromPage(reader, pageNum);			
			reader.close();
			pdfRead=temp;
		} catch (IOException e) {			
			LOG.debug("Catch Exception: " + e.getMessage(),e);	
		}
		
		return pdfRead;
	
	}

	/**
	 * 
	 * @param sourceFilePath
	 * @return int
	 * @MethodName readPDFInBulk
	 * @MethodDescription Get the pages count from the PDF
	 */
	public int getPdfPageNumber(String sourceFilePath){
		PdfReader reader;
		int pageCount=0;
		try {
			reader = new PdfReader(sourceFilePath);
			pageCount = reader.getNumberOfPages();			
			reader.close();
		} catch (IOException e) {
			
			LOG.debug("Catch Exception: " + e.getMessage(),e);	
		}
		return pageCount;		
	}

	
 }
	
	
