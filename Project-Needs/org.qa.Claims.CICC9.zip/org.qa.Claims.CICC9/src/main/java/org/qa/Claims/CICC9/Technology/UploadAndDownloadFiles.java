package org.qa.Claims.CICC9.Technology;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Vector;
import org.apache.log4j.Logger;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

/**
 * Class to download file from FTP server to local
 * 
*/

public class UploadAndDownloadFiles extends FetchPropertiesFiles {

	public static String sftpHost, sftpUser, sftpPassword, sftpDir, sftpPort = "22";
	public static final Logger LOG = Logger.getLogger(UploadAndDownloadFiles.class);
	public static Properties properties = new Properties();

	/**
	 * Get the environment details from the properties files
	 * @param environment
	 */
	public static void getEnvDetails() {

		sftpUser = FetchPropertiesFiles.ftpUserName;
		sftpPassword = FetchPropertiesFiles.ftpPassword;
		sftpHost = FetchPropertiesFiles.ftpHost;
	}

	/**
	 * Get the number of files present in the given directory in FTP Server
	 * 
	 * @param environment
	 * @param fileName
	 * @param destinationDirectory
	 * @return
	 */
	public static int getFileCountInServer(String fileName, String destinationDirectory) {

		int fileListCount = 0;
		JSch jsch = new JSch();
		Session session = null;
		try {
			getEnvDetails();
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			session = jsch.getSession(sftpUser, sftpHost, 22);
			session.setPassword(sftpPassword);
			session.setConfig(config);
			session.connect();
			Channel channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftpChannel = (ChannelSftp) channel;
			LOG.info("Directory:" + sftpChannel.pwd());
			sftpChannel.cd(destinationDirectory);
			LOG.info("Directory after cd:" + sftpChannel.pwd());
			Vector<?> filelist = sftpChannel.ls(destinationDirectory);
			fileListCount = filelist.size();
			sftpChannel.exit();
			session.disconnect();
		} catch (JSchException e) {
			LOG.error("Get the file count : " + e.getMessage());
		} catch (SftpException e) {
			LOG.error("Get the file count : " + e.getMessage());
		}

		return fileListCount;
	}

	/**
	 * Upload files created in the local to the server directory
	 * 
	 * @param environment
	 * @param fileName
	 * @param sourceDirectory
	 * @param destinationDirectory
	 */
	public static void uploadFileToFTPServer(String fileName, String sourceDirectory, String destinationDirectory) {

		JSch jsch = new JSch();
		Session session = null;

		try {

			getEnvDetails();
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			session = jsch.getSession(sftpUser, sftpHost, 22);
			session.setPassword(sftpPassword);
			session.setConfig(config);
			session.connect();
			Channel channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftpChannel = (ChannelSftp) channel;
			LOG.info("Directory:" + sftpChannel.pwd());
			sftpChannel.cd(destinationDirectory);
			LOG.info("Directory after cd:" + sftpChannel.pwd());

			String filePath = sourceDirectory + fileName;
			File file = new File(filePath);
			sftpChannel.put(new FileInputStream(file), file.getName());
			sftpChannel.exit();

		} catch (JSchException e) {
			LOG.error("JSchException : " + e.getMessage());
		} catch (SftpException e) {
			LOG.error("SftpException : " + e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			session.disconnect();
		}
	}

	/**
	 * Download files from the server directory to Local folder
	 * 
	 * @param environment
	 * @param fileName
	 * @param sourceDirectory
	 * @param destinationDirectory
	 */
	public static boolean downloadFileFromFTPServer(String fileName, String sourceDirectory,
			String destinationDirectory) {

		JSch jsch = new JSch();
		Session session = null;
		try {
			getEnvDetails();
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			session = jsch.getSession(sftpUser, sftpHost, 22);
			session.setPassword(sftpPassword);
			session.setConfig(config);
			session.connect();
			Channel channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftpChannel = (ChannelSftp) channel;
			LOG.info("Directory:" + sftpChannel.pwd());
			sftpChannel.cd(sourceDirectory);
			LOG.info("Directory after cd:" + sftpChannel.pwd());
			LOG.info(destinationDirectory);
			sftpChannel.get(fileName, destinationDirectory);
			sftpChannel.exit();
			return true;
		} catch (JSchException e) {
			LOG.error("JSchException : " + e.getMessage());
			return false;
		} catch (SftpException e) {
			LOG.error("SftpException : " + e.getMessage());
			return false;
		} finally {
			session.disconnect();
		}
	}

}
