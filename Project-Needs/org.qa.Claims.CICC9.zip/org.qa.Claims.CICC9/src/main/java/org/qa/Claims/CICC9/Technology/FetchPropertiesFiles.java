package org.qa.Claims.CICC9.Technology;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import org.apache.log4j.Logger;

public class FetchPropertiesFiles {

	public static Logger LOG = Logger.getLogger(FetchPropertiesFiles.class);
	public static BDDConstants constants= new BDDConstants();
	public static Properties properties = new Properties();
	public static String environment, databaseEnv, soapURL, restURL,agent_id, browserName, sauceLabURL, testingType,
			retailSchemaName,retailCfgSchemaName,jdbcURL,dbUserName,dbPassword,ftpHost,ftpUserName,ftpPassword  ,serviceTestingEsbIP,serviceTestingCoreIP;
	static boolean flag= false;

	public static String portalUrl="",chromeWebdriverPath="",ieWebdriverPath,autoItpath,executionMode, modeOfExposure;
	public static void getProperties(){
		try {
			properties.load(FetchPropertiesFiles.class.getClassLoader()
					.getResourceAsStream("Config.Properties"));  //  example :"Object.Properties" property file name
			portalUrl=properties.getProperty("APPLICATION_URL");
			//uncomment the below line for switching browsers
			//chromeWebdriverPath=properties.getProperty("ChromeDriver");
			ieWebdriverPath=properties.getProperty("IE_DRIVER_PATH");
			autoItpath = properties.getProperty("autoItpath");
			executionMode = properties.getProperty("EXECUTION_MODE");
			browserName = properties.getProperty("BROWSER_NAME");
			sauceLabURL = properties.getProperty("SAUCE_LAB_URL");
			testingType = properties.getProperty("TESTING_TYPE");
			modeOfExposure = properties.getProperty("MODE_OF_EXPOSURE");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	public static String getEnvConnection(){
		
		//Reading Environment properties files to Fetch the Environment details
		try {
			properties.load(FetchPropertiesFiles.class.getClassLoader()
					.getResourceAsStream(constants.envProperties));
		} catch (IOException e) {			
			LOG.info("Properties files might be missing in the directory:  "
					+ e.getMessage());;
		}
		environment = properties.getProperty(constants.environment);

		return environment;
	}

	public static HashMap<String, String> getEnvironmentSettings() {

		// Reading Environment properties files to Fetch the Environment details
		HashMap<String, String> envSetting = new HashMap<String, String>();
		try {
			properties.load(FetchPropertiesFiles.class.getClassLoader().getResourceAsStream(constants.envProperties));
		} catch (IOException e) {
			LOG.info("Properties files might be missing in the directory:  " + e.getMessage());
		}
		envSetting.put("Endpoint", properties.getProperty("Endpoint"));
		envSetting.put("LoginType", properties.getProperty("LoginType"));

		return envSetting;
	}

	public static String getEnvConnection(String env){	
		
		environment = env;
		return environment;
	}
	
	
	/**
	 * Get the Environment SYS\SYS2\INT\INT2 from the properties files
	 * 
	 */
	public boolean getServiceConnnection() {
		try {	
			
			if (environment.equals(constants.TEST)) {
				
				LOG.info(constants.EXESTARTS);
				LOG.info(constants.BORDER);
				LOG.info(constants.ENVSTRING  +environment);
				
						
				//Reading DBConnection properties files to Fetch the Database Details 				
				databaseEnv = environment;
				properties.load(FetchPropertiesFiles.class.getClassLoader()
						.getResourceAsStream(constants.dbProperties));

				retailSchemaName = properties.getProperty(constants.testschemaName);
				retailCfgSchemaName = properties.getProperty(constants.testCfgschemaName);
				jdbcURL= properties.getProperty(constants.testJdbcURL);
				dbUserName= properties.getProperty(constants.testUserName);
				dbPassword=properties.getProperty(constants.testPassword);
				
				LOG.info(constants.SCHEMASTRING +retailSchemaName);
				LOG.info(constants.SCHEMACFGSTRING +retailCfgSchemaName);
				LOG.info(constants.JDBCSTRING +jdbcURL);
				
				//Reading Server properties files to Fetch the server details
				properties.load(FetchPropertiesFiles.class.getClassLoader()
						.getResourceAsStream(
								constants.serverConnectionProperties));
				soapURL = properties.getProperty(constants.syssoapUrl);
				restURL = properties.getProperty(constants.sysrestUrl);
				ftpHost = properties.getProperty(constants.ftpSYSHostName);
				ftpUserName = properties.getProperty(constants.ftpSYSUserName);
				ftpPassword = properties.getProperty(constants.ftpSYSPassWord);			
				serviceTestingEsbIP = properties.getProperty(constants.sysesbIP);
				serviceTestingCoreIP = properties.getProperty(constants.syscoreIP);
				LOG.info(constants.SOAPSTRING +soapURL);
				LOG.info(constants.RESTSTRING +restURL);
				LOG.info(constants.FTPHOSTNAMESTRING +ftpHost);
				
				LOG.info(constants.BORDER);
				
			} else if (environment.equals(constants.DEV)) {
				
				LOG.info(constants.EXESTARTS);
				LOG.info(constants.BORDER);
				LOG.info(constants.ENVSTRING  +environment);
				
						
				//Reading DBConnection properties files to Fetch the Database Details 				
				databaseEnv = environment;
				properties.load(FetchPropertiesFiles.class.getClassLoader()
						.getResourceAsStream(constants.dbProperties));

				retailSchemaName = properties.getProperty(constants.devschemaName);
				retailCfgSchemaName = properties.getProperty(constants.devCfgschemaName);
				jdbcURL= properties.getProperty(constants.devJdbcURL);
				dbUserName= properties.getProperty(constants.devUserName);
				dbPassword=properties.getProperty(constants.devPassword);
				
				LOG.info(constants.SCHEMASTRING +retailSchemaName);
				LOG.info(constants.SCHEMACFGSTRING +retailCfgSchemaName);
				LOG.info(constants.JDBCSTRING +jdbcURL);
				
				//Reading Server properties files to Fetch the server details
				properties.load(FetchPropertiesFiles.class.getClassLoader()
						.getResourceAsStream(
								constants.serverConnectionProperties));
				soapURL = properties.getProperty(constants.sys2soapUrl);
				restURL = properties.getProperty(constants.sys2restUrl);
				ftpHost=properties.getProperty(constants.ftpSYS2HostName);
				ftpUserName=properties.getProperty(constants.ftpSYS2UserName);
				ftpPassword=properties.getProperty(constants.ftpSYS2PassWord);			
				serviceTestingEsbIP = properties.getProperty(constants.sys2esbIP);
				serviceTestingCoreIP = properties.getProperty(constants.sys2coreIP);
				LOG.info(constants.SOAPSTRING +soapURL);
				LOG.info(constants.RESTSTRING +restURL);
				LOG.info(constants.FTPHOSTNAMESTRING +ftpHost);
				
				LOG.info(constants.BORDER);
				
			} else if (environment.equals(constants.STAGE)) {
				
				LOG.info(constants.EXESTARTS);
				LOG.info(constants.BORDER);
				LOG.info(constants.ENVSTRING  +environment);
				
						
				//Reading DBConnection properties files to Fetch the Database Details 				
				databaseEnv = environment;
				properties.load(FetchPropertiesFiles.class.getClassLoader()
						.getResourceAsStream(constants.dbProperties));

				retailSchemaName = properties.getProperty(constants.stageschemaName);
				retailCfgSchemaName = properties.getProperty(constants.stageCfgschemaName);
				jdbcURL= properties.getProperty(constants.stageJdbcURL);
				dbUserName= properties.getProperty(constants.stageUserName);
				dbPassword=properties.getProperty(constants.stagePassword);
				
				LOG.info(constants.SCHEMASTRING +retailSchemaName);
				LOG.info(constants.SCHEMACFGSTRING +retailCfgSchemaName);
				LOG.info(constants.JDBCSTRING +jdbcURL);
				
				//Reading Server properties files to Fetch the server details
				properties.load(FetchPropertiesFiles.class.getClassLoader()
						.getResourceAsStream(
								constants.serverConnectionProperties));
				soapURL = properties.getProperty(constants.intsoapUrl);
				restURL = properties.getProperty(constants.intrestUrl);
				ftpHost=properties.getProperty(constants.ftpINTHostName);
				ftpUserName=properties.getProperty(constants.ftpINTUserName);
				ftpPassword=properties.getProperty(constants.ftpINTPassWord);			
				serviceTestingEsbIP = properties.getProperty(constants.intesbIP);
				serviceTestingCoreIP = properties.getProperty(constants.intcoreIP);
				LOG.info(constants.SOAPSTRING +soapURL);
				LOG.info(constants.RESTSTRING +restURL);
				LOG.info(constants.FTPHOSTNAMESTRING +ftpHost);
				
				LOG.info(constants.BORDER);
				
			} 
			flag=true;	
			
		} catch (IOException e) {
			LOG.info("Properties files might be missing in the directory:  "
					+ e.getMessage());
		}
		
		
	return flag;	
	
	}
	}