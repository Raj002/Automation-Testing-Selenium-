package org.qa.Claims.CICC9.CommonScreens;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;
import org.testng.Assert;

public class PaymentInformation extends Object_Repositories {

	private WebDriver driver = null;

	// Page Objects
	// String reserveLine =
	// "NormalCreateCheckWizard:CheckWizard_CheckPaymentsScreen:NewCheckPaymentPanelSet:NewPaymentDetailDV:Transaction_ReserveLine";
	String exposureTextBox = "NormalCreateCheckWizard:CheckWizard_CheckPaymentsScreen:NewCheckPaymentPanelSet:NewPaymentDetailDV:Transaction_Exposure";
	String costCategoryTextBox = "NormalCreateCheckWizard:CheckWizard_CheckPaymentsScreen:NewCheckPaymentPanelSet:NewPaymentDetailDV:Transaction_CostCategory";
	// String paymentType =
	// "NormalCreateCheckWizard:CheckWizard_CheckPaymentsScreen:NewCheckPaymentPanelSet:NewPaymentDetailDV:Payment_PaymentType";
	String matterTextBox = "NormalCreateCheckWizard:CheckWizard_CheckPaymentsScreen:NewCheckPaymentPanelSet:NewPaymentDetailDV:Matter";
	// String lineCategory =
	// "NormalCreateCheckWizard:CheckWizard_CheckPaymentsScreen:NewCheckPaymentPanelSet:NewPaymentDetailDV:EditablePaymentLineItemsLV:0:LineCategory";
	// String paymentAmount =
	// "NormalCreateCheckWizard:CheckWizard_CheckPaymentsScreen:NewCheckPaymentPanelSet:NewPaymentDetailDV:EditablePaymentLineItemsLV:0:Amount";
	// String paymentLineCheckBox =
	// "NormalCreateCheckWizard:CheckWizard_CheckPaymentsScreen:NewCheckPaymentPanelSet:NewPaymentDetailDV:EditablePaymentLineItemsLV:0:_Checkbox";
	String paymentNextButton = "//a[@id='NormalCreateCheckWizard:Next']";
	String closeButton = "//a[@id='CheckDuplicatesWorksheet:NewCheckDuplicatesScreen:CheckDuplicatesWorksheet_CloseButton']";

	String reserveLine = "//input[contains(@id,'ReserveLineInputSet:ReserveLine-inputE')]";
	String exposure = "//input[contains(@id,'ReserveLineInputSet:Exposure-inputE')]";
	String matter = "//input[contains(@id,'ReserveLineInputSet:Matter-inputE')]";
	String costType = "//input[contains(@id,'ReserveLineInputSet:CostType-inputE')]";
	String costCategory = "//input[contains(@id,'ReserveLineInputSet:CostCategory-inputE')]";
	String servicePeriodStart = "//input[contains(@id,'ServicePeriod_Start-inputE')]";
	String servicePeriodEnds = "//input[contains(@id,'ServicePeriod_End-inputE')]";
	String comment = "//textarea[contains(@id,'Transaction_Comments-inputE')]";
	String paymentLineCheckBox = "(//div[contains(@id,'gridview-')])[2]/div/table/tbody/tr/td[1]/div/img";

	String paymentLineItemCategory = "(//div[contains(@id,'gridview-')])[2]/div/table[1]/tbody/tr[1]/td[2]/div";
	String paymentLineItemDetails = "(//div[contains(@id,'gridview-')])[2]/div/table[1]/tbody/tr[1]/td[3]/div";
	String paymentLineItemAmount = "(//div[contains(@id,'gridview-')])[2]/div/table[1]/tbody/tr[1]/td[3]/div";
	String paymentLineItemAmount1 = "(//div[contains(@id,'gridview-')])[2]/div/table[1]/tbody/tr[1]/td[4]/div";

	String paymentAmount = "//input[contains(@id,'textfield') and @name='Amount']";
	String paymentType = "//input[contains(@id,'Payment_PaymentType-inputE')]";

	// Matter Page Objects
	String matterName = "//input[@id='NewMatter:NewMatterScreen:NewMatterDV:Matter_Name-inputEl']";
	String matterPlaintiff = "//input[@id='NewMatter:NewMatterScreen:NewMatterDV:Plaintiff-inputEl']";
	String matterDefendant = "//input[@id='NewMatter:NewMatterScreen:NewMatterDV:Defendant-inputEl']";
	String matterLitigatedFalse = "//input[@id='NewMatter:NewMatterScreen:NewMatterDV:Litigated_false-inputEl']";
	String matterAssignedTo = "//input[@id='NewMatter:NewMatterScreen:NewMatterDV:AssignedTo-inputEl']";
	String relatedExposureAddButton = "//a[@id='NewMatter:NewMatterScreen:NewMatterDV:Add']";
	String relatedExposureCheckBox = "//div[contains(@id,'gridview-')]/div/table/tbody/tr/td[1]";
	String relatedExposureRelatedTo = "//div[contains(@id,'gridview-')]/div/table/tbody/tr/td[2]";

	public PaymentInformation(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}

	public void PaymentInformationPage(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");

		String ddlReserveLine = xlsread.Exceldata(SheetName, "ddlReserveLine", profileID);
		String ddlExposure = xlsread.Exceldata(SheetName, "ddlPaymentExposure", profileID);
		String ddlCostCategory = xlsread.Exceldata(SheetName, "ddlCostCategory", profileID);
		String ddlPaymentType = xlsread.Exceldata(SheetName, "ddlPaymentType", profileID);
		String ddlMatter = xlsread.Exceldata(SheetName, "ddlMatter", profileID);
		String ddlLineCategory = xlsread.Exceldata(SheetName, "ddlLineCategory", profileID);
		String txtPaymentAmount = xlsread.Exceldata(SheetName, "txtPaymentAmount", profileID);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("")));

		UIMethods.selectbyid(reserveLine, "input ReserveLine", ddlReserveLine);
		Thread.sleep(5000);

		// ddlExposure
		try {
			if (ddlExposure.equals("EXISTING")) {
				ddlExposure = CopyExposureData.exposuresdata;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		if (driver.findElements(By.id(exposureTextBox)).size() != 0) {
			UIMethods.selectbyid(exposureTextBox, "input ddlExposure", ddlExposure);
			Thread.sleep(2000);
		}

		if (driver.findElements(By.id(costCategoryTextBox)).size() != 0) {
			// ddlCostCategory
			UIMethods.selectbyid(costCategoryTextBox, "input ddlCostCategory", ddlCostCategory);
			Thread.sleep(2000);
		}

		if (driver.findElements(By.id(paymentType)).size() != 0) {
			// Payment Type
			UIMethods.selectbyid(paymentType, "input Payment_PaymentType", ddlPaymentType);
			Thread.sleep(2000);
		}

		if (driver.findElements(By.id(matterTextBox)).size() != 0) {
			// Input Matter
			UIMethods.selectbyid(matterTextBox, "input Matter", ddlMatter);
			Thread.sleep(2000);
		}
		Thread.sleep(2000);
		if (driver.findElements(By.id(paymentLineItemCategory)).size() != 0) {
			// Input Line Category
			UIMethods.selectbyid(paymentLineItemCategory, "input LineCategory", ddlLineCategory);
			Thread.sleep(4000);
		}

		if (driver.findElements(By.id(paymentAmount)).size() != 0) {
			// Payment Amount
			UIMethods.inputbyid(paymentAmount, "input payment amount", txtPaymentAmount);
			Thread.sleep(2000);
		}

		if (driver.findElements(By.id(paymentLineCheckBox)).size() != 0) {
			// PaymentLine Checkbox
			UIMethods.clickbyid(paymentLineCheckBox, "click _Checkbox", "Click");
			Thread.sleep(5000);
		}

		// btnPaymentNext
		for (int i = 1; i <= 7; i++) {
			UIMethods.jscriptclickbyxpath(paymentNextButton, "Click Next", "Click");
			Thread.sleep(6000);
			if (driver.findElements(By.xpath(closeButton)).size() > 0) {
				UIMethods.jscriptclickbyxpath(closeButton, "click close button", "Click");
				Thread.sleep(5000);
			}
			try {
				driver.findElement(By.xpath("//span[text()='Step 2 of 3: Enter payment information']/parent::div"))
						.isDisplayed();
			} catch (Exception Ex) {
				break;
			}
		}
		Thread.sleep(4000);
	}

	public void PaymentInformationAddItemPage(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");

		String ddlReserveLine = xlsread.Exceldata(SheetName, "reserveLine", profileID);
		String ddlLineCategory = xlsread.Exceldata(SheetName, "lineItemCategory", profileID);
		String txtPaymentAmount = xlsread.Exceldata(SheetName, "txtPaymentAmount", profileID);
		String MName = xlsread.Exceldata(SheetName, "matterName", profileID);
		String assignedto = xlsread.Exceldata(SheetName, "assignedTO", profileID);
		String expoName = xlsread.Exceldata(SheetName, "exposureName", profileID);
		String paymenttype = xlsread.Exceldata(SheetName, "paymentType", profileID);
		String txtLineItemDetails = xlsread.Exceldata(SheetName, "lineItemDetails", profileID);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Enter payment information')]")));
		Helper.selectDropdownValue(driver, "xpath", reserveLine, "Select reserve Line", ddlReserveLine);
		// UIMethods.inputbyid(reserveLine, "Select Reserve Line", ddlReserveLine);
		/*
		 * Thread.sleep(5000); if (ddlExposure.equals("EXISTING")) { ddlReserveLine =
		 * CopyExposureData.exposuresdata; } UIMethods.inputbyid(exposureTextBox,
		 * "input ddlExposure", ddlExposure);
		 */
		driver.findElement(By.xpath(comment)).click();
		Thread.sleep(2000);
		if (driver.findElements(By.xpath(matter)).size() != 0) {
			Helper.clickActionsMenu(driver, "matter");

			// Enter matter details
			wait.until(ExpectedConditions.visibilityOfElementLocated(
					By.xpath("//span[@id='NewMatter:NewMatterScreen:ttlBar' and text()='New Matter']")));
			UIMethods.inputbyxpath(matterName, "Enter Matter Name", MName);

			String insuredObject = "//span[@id='Claim:ClaimInfoBar:Insured-btnInnerEl']/span[2]";
			String actualinsuredName = driver.findElement(By.xpath(insuredObject)).getText().trim();
			Helper.selectDropdownValue(driver, "xpath", matterPlaintiff, "Select Matter Plaintiff", actualinsuredName);
			Thread.sleep(1000);
			Helper.selectDropdownValue(driver, "xpath", matterDefendant, "Select Matter Defendant", actualinsuredName);

			UIMethods.clickbyxpath(matterLitigatedFalse, "Click Matter Litigation false option", "Click");
			Helper.selectDropdownValue(driver, "xpath", matterAssignedTo, "Select matter assigned to", assignedto);
			UIMethods.jscriptclickbyxpath(relatedExposureAddButton, "Click Add button to add related exposure","Click");
			Thread.sleep(1000);
			Helper.clickCheckBox(relatedExposureCheckBox, "Click related exposure check box");
			UIMethods.jscriptclickbyxpath(relatedExposureRelatedTo, "Click Related to", "Click");
			UIMethods.clearAndinputbyxpath(Helper.getDropdownXpath("exposure"), "Select Related To", expoName);

			driver.findElement(By.xpath(matterName)).click();
			UIMethods.jscriptclickbyxpath(updateButton, "Click Matter Update button", "Click");
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//a[@id='MatterDetailPage:MatterDetailPage_UpLink']")));

			if (driver.findElements(By.xpath("//a[@id='MatterDetailPage:MatterDetailPage_UpLink']")).size() != 0) {
				xlsread.WriteIntoExistingExcel(SheetName, "matterStatus", "Pass", profileID, true);
			} else {
				xlsread.WriteIntoExistingExcel(SheetName, "matterStatus", "Fail", profileID, false);
			}

			UIMethods.jscriptclickbyxpath(saveIcon, "Click Unsaved icon", "Click");
			Thread.sleep(1000);
			UIMethods.jscriptclickbyxpath("//a[contains(@id,'TabBar:UnsavedWorkTabBarLink') and text()='Step 2 of 3: Enter payment information']","Navigate to Payment Information screen", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='NormalCreateCheckWizard:CheckWizard_CheckPaymentsScreen:ttlBar']")));

			Helper.selectDropdownValue(driver, "xpath", matter, "Select Matter", MName);
		}

		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(paymentType)));
		Helper.selectDropdownValue(driver, "xpath", paymentType, "Select Payment type", paymenttype);

		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(servicePeriodStart)));
		UIMethods.clearAndinputbyxpath(servicePeriodStart, "Enter Service Start Date", Helper.getDate(0));

		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(servicePeriodEnds)));
		UIMethods.clearAndinputbyxpath(servicePeriodEnds, "Enter Service Ends Date", Helper.getDate(0));

		UIMethods.inputbyxpath(comment, "Enter comments", "To test");
		Helper.clickCheckBox(paymentLineCheckBox, "Click Line Item check box");

		UIMethods.jscriptclickbyxpath(paymentLineItemCategory, "Click Line item category", "Click");
		UIMethods.clearAndinputbyxpath(Helper.getDropdownXpath("LineCategory"), "Select Line Item Category", ddlLineCategory);

		if (driver.findElements(By.xpath("//span[text()='Detail']")).size() != 0) {
			UIMethods.jscriptclickbyxpath(paymentLineItemDetails, "Click Line items details text box", "Click");
			Thread.sleep(500);
			UIMethods.clearAndinputbyxpath(Helper.getDropdownXpath("Detail"), "Enter Line Items Details", txtLineItemDetails);

			UIMethods.jscriptclickbyxpath(paymentLineItemAmount1, "Click Line Items Amount text box", "Click");
			UIMethods.clearAndinputbyxpath(paymentAmount, "Enter Line Items Payment Amount", txtPaymentAmount);
		} else {
			UIMethods.jscriptclickbyxpath(paymentLineItemAmount, "Click Line Items Amount text box", "Click");
			Thread.sleep(1000);
			UIMethods.clearAndinputbyxpath(paymentAmount, "Enter Line Items Payment Amount", txtPaymentAmount);
		}

		// Click Next button
		for (int intLoop = 1; intLoop <= 7; intLoop++) {
			UIMethods.jscriptclickbyxpath(paymentNextButton, "Click Next Button", "Click");
			/*Thread.sleep(1000);
			By errorMessage = By.id("NormalCreateCheckWizard:CheckWizard_CheckPaymentsScreen:_msgs");
			if(driver.findElement(errorMessage).isDisplayed() == true) {
				Assert.fail("Failed to update : " + driver.findElement(errorMessage).getText());
				break;
			}*/
			Thread.sleep(2000);			
			if (driver.findElements(By.xpath(closeButton)).size() > 0) {
				UIMethods.jscriptclickbyxpath(closeButton, "Click warning close button", "Click");
				Thread.sleep(5000);
			}
			try {
				driver.findElement(By.xpath("//span[text()='Step 2 of 3: Enter payment information']/parent::div"))
						.isDisplayed();
			} catch (Exception Ex) {
				break;
			}
		}
	}
}