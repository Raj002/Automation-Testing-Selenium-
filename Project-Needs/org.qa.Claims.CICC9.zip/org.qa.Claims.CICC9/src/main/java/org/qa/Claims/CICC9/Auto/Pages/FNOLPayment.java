package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class FNOLPayment {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	String chkAmount = "FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:FNOLWizardCheckDV:CheckAmount";
	String deductibeApplies = "FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:FNOLWizardCheckDV:DeductibleApplies_false";
	String lossTime = "FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:Claim_lossTime";
	String closeButton = "NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:NewClaimDuplicatesWorksheet_CloseButton";
	String finishButton = "FNOLWizard:Finish";
	
	public FNOLPayment(WebDriver driver)
	{
		this.driver = driver;
		wait = new WebDriverWait(driver, 30);
	}	
	
	public void FNOLPaymentpage(String excelFileName, String profileID) throws Exception {
        //Read data from excel
        String SheetName = "ClaimsPolicy";
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String payeePicker = xlsread.Exceldata(SheetName, "txtPayeePicker", profileID);
		String checkAmount = xlsread.Exceldata(SheetName, "txtCheckAmount", profileID);
		String claimContactRoles = xlsread.Exceldata(SheetName, "txtClaimContactRoles", profileID);
		String firstName1 = xlsread.Exceldata(SheetName, "txtFirstName1", profileID);
		String lastName1 = xlsread.Exceldata(SheetName, "txtLastName1", profileID);
		
        //Payment
		Thread.sleep(2000);
        UIMethods.selectbyid("FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:FNOLWizardCheckDV:Payee_Picker", "Input Payee_Picker", payeePicker);
        Thread.sleep(3000);
        //UIMethods.clickbyid(chkAmount, "Click CheckAmount", "Click");
        UIMethods.jscriptclickbyxpath(chkAmount, "Clikc check amount", "Click");
        UIMethods.inputbyid(chkAmount, "Input CheckAmount", checkAmount);
        
        UIMethods.clickbyid("FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:Description", "Click Description", "Click");
        Thread.sleep(3000);
        UIMethods.clickbyid(deductibeApplies, "Click DeductibleApplies_false", "Click");
        Thread.sleep(3000);
        UIMethods.clickbyid("FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:Description", "Click Description", "Click");
        Thread.sleep(2000);
        Helper.clearTextBox(driver, driver.findElement(By.id(lossTime)));
        driver.findElement(By.id(lossTime)).sendKeys("12:00 AM");
        Thread.sleep(2000);
        UIMethods.clickbyid(finishButton, "Click Finish", "Click");
        Thread.sleep(5000);
        UIMethods.clickbyid(closeButton, "Click CloseButton", "Click");
        Thread.sleep(5000);
        Helper.clearTextBox(driver, driver.findElement(By.id(lossTime)));
        driver.findElement(By.id(lossTime)).sendKeys("12:00 AM");
        Thread.sleep(2000);
        UIMethods.clickbyid(finishButton, "Click Finish", "Click");
        Thread.sleep(5000);
        Helper.clearTextBox(driver, driver.findElement(By.id(lossTime)));
        driver.findElement(By.id(lossTime)).sendKeys("12:00 AM");
        Thread.sleep(3000);
        UIMethods.jscriptclickbyxpath("//*[@id='WebMessageWorksheet:WebMessageWorkSheetScreen:WebMessageWorksheet_ClearButton']", "Click ClearButton", "Click");
        Thread.sleep(5000);
        driver.findElement(By.id(lossTime)).sendKeys("12:00 AM");
        Thread.sleep(2000);
        UIMethods.clickbyid(finishButton, "Click Finish", "Click");
        Thread.sleep(5000);
		if (driver.findElements(By.xpath("//span[@id='FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:_msgs_msgs']/div")).size() != 0) {
			Helper.clearTextBox(driver, driver.findElement(By.id(lossTime)));
			driver.findElement(By.id(lossTime)).sendKeys("12:00 AM");
			UIMethods.clickbyid(finishButton, "Click Finish", "Click");
			Thread.sleep(5000);
		}        
       }
}