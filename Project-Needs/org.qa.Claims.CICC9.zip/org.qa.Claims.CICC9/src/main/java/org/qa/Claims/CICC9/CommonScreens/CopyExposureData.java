package org.qa.Claims.CICC9.CommonScreens;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;
import org.testng.Assert;

public class CopyExposureData extends Object_Repositories{

	private WebDriver driver = null; 
	public static String exposuresdata = null;

	// Page Objects
	String exposureNumberLink = "//a[@id='ClaimExposures:ClaimExposuresScreen:ExposuresLV:0:Order']";
	String upToExposuresLink = "//a[@id='ExposureDetail:ExposureDetail_UpLink' and text()='Up to Exposures']";	
	String createReserveButton = "//a[@id='ExposureDetail:ExposureDetailScreen:ExposureDetailScreen_CreateReserveButton']";
	
	
	public CopyExposureData(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 15);
	}

	public void getExposureName(String excelFileName, String profileID) throws Exception {
		
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");		
		String expectedCoverageName = xlsread.Exceldata(SheetName, "coverageName", profileID);
		String expectedCoverageType = xlsread.Exceldata(SheetName, "coverageType", profileID);
		
		Helper.clickClaimSubMenu(driver, "exposures");
		
		//UIMethods.jscriptclickbyxpath("//span[text()='#']", "Click Sort icon to get created exposure name", "Click");
		
		// Getting Table row length
		List<WebElement> list = driver.findElements(By.xpath(mainTable));
		int rowLength = list.size();
		String actualCoverageName = null;
		
		for(int i=1;i<=rowLength;i++) {
			
			actualCoverageName = driver.findElement(By.xpath("//div[contains(@id,'gridview-')]/div/table["+i+"]/tbody/tr[1]/td[4]/div")).getText();
			String actualCoverageType = driver.findElement(By.xpath("//div[contains(@id,'gridview-')]/div/table["+i+"]/tbody/tr[1]/td[3]/div/a")).getText();
			
			if(actualCoverageName.trim().equals(expectedCoverageName.trim()) && actualCoverageType.trim().equals(expectedCoverageType.trim())) {
				
				String exposureNumberLink = "//div[contains(@id,'gridview-')]/div/table["+i+"]/tbody/tr[1]/td[2]/div/a[contains(@id,'ClaimExposures:ClaimExposuresScreen:ExposuresLV')]";				
				//wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(exposureNumberLink)));
				UIMethods.jscriptclickbyxpath(exposureNumberLink, "Click Exposure Numebr Link", "Click");
				
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(upToExposuresLink)));
				// Copy Exposure Name from Exposure screen
				String actualExposureName = driver.findElement(By.xpath("//span[@id='ExposureDetail:ExposureDetailScreen:ttlBar']")).getText();
				exposuresdata = actualExposureName.trim();
				xlsread.WriteIntoExistingExcel(SheetName, "exposureName", exposuresdata, profileID, true);
				
				if(driver.findElements(By.xpath(createReserveButton)).size()!=0) {
					UIMethods.clickbyxpath(createReserveButton, "Click Create Reserve Button from Exposure page", "Click");
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='NewReserveSet:NewReserveSetScreen:ttlBar' and text()='Set Reserves']")));					
				}
				break;
			} 	
		}	
		
		if(driver.findElements(By.xpath("//span[@id='ClaimExposures:ClaimExposuresScreen:ttlBar']")).size()!=0) {
			Helper.getScreenshot(driver, "Payment_Exposure_Failed", "TC_" + profileID + "_");
			Assert.fail("Given Coverage Option isn't available in Exposure screen. Please refer the screenshot from PAYMENT_EXPOSURE folder.");	
			Report.fail("Given Coverage Option "+expectedCoverageName+" isn't available in Exposure screen", expectedCoverageName, expectedCoverageName, actualCoverageName);;
		}
		
		/*wait.until(ExpectedConditions.elementToBeClickable(By.xpath(upToExposuresLink)));
		UIMethods.jscriptclickbyxpath(upToExposuresLink, "Click Up to Exposure Link", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimExposures:ClaimExposuresScreen:ttlBar']")));*/
		
	}
}