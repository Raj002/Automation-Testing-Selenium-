package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class FinancialChecks {

	private WebDriver driver = null;
	WebDriverWait wait;

	public FinancialChecks(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 10);
	}

	public void FinancialCheckspage() throws Exception {
		Thread.sleep(3000);
		UIMethods.clickbyid("ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV:ScheduledSendDateHeader_link","Click date field to sort", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV:0:Status")));
		String finalmsgActual = driver.findElement(By.id("ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ChecksLV:0:Status")).getText();
		String finalmsgExpected = "Awaiting submission";
		Thread.sleep(2000);
		if (finalmsgExpected.equalsIgnoreCase(finalmsgActual)) {
			Thread.sleep(2000);
			Report.pass("Verify Text", "Financial Summary",finalmsgExpected + " should available in Financial Summary page",finalmsgActual + " is exist in Financial Summary page");
		} else {
			Report.fail("Verify Text", "Financial Summary",finalmsgExpected + " should available in Financial Summary page",finalmsgActual + " is not same as in Financial Summary page");
		}
	}
}