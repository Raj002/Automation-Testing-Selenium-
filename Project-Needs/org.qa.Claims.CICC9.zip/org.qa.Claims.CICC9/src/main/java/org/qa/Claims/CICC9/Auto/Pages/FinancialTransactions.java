package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class FinancialTransactions {
	
	private WebDriver driver=null;
	WebDriverWait wait;

	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	//Page Objects
	String claimNumber = "ClaimSearchPopup:ClaimSearchScreen:ClaimSearchDV:ClaimSearchRequiredInputSet:ClaimNumber";
	
	public FinancialTransactions(WebDriver driver)
	{
		this.driver = driver;
	}	
	
	public void FinancialTransactionspage() throws Exception{
		UIMethods.jscriptclickbyxpath("//*[text()='Financials']", "click financial transactions", "Click");
		Thread.sleep(2000);
		UIMethods.clickbyid("ClaimFinancialsGroup:MenuLinks:ClaimFinancialsGroup_ClaimFinancialsTransactions", "click Transactions", "Click");
		Thread.sleep(2000);
		UIMethods.clickbyxpath("//*[@id='ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV:1:Amount']/span", "click amount", "Click");
		Thread.sleep(2000);
	}
	
	public void PropertyFinancialTransactionspage() throws Exception{
		UIMethods.jscriptclickbyxpath("//*[@id='ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV:CreateDateHeader_link']/span", "click financial transactions", "Click");
		Thread.sleep(3000);
		UIMethods.clickbyxpath("//*[@id='ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV:0:Amount']/span", "click amount", "Click");
		Thread.sleep(2000);
	}
	
	public void PropertyFinancialTransactionsAmtpage() throws Exception{
		Thread.sleep(2000);
		UIMethods.clickbyxpath("//*[@id='ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV:0:Amount']/span", "click amount", "Click");
		Thread.sleep(2000);
	}
	
	public void PropertyFinancialTransactionsrecodedAmtpage() throws Exception{
		Thread.sleep(2000);
		UIMethods.clickbyxpath("//*[@id='ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV:2:Amount']/span", "click amount", "Click");
		Thread.sleep(2000);
	}
	
	public void PropertyFinancialTransactionsVoidedstatus() throws Exception{
		UIMethods.jscriptclickbyxpath("//*[@id='ClaimFinancialsGroup:MenuLinks:ClaimFinancialsGroup_ClaimFinancialsTransactions']", "click transactions", "Click");
		Thread.sleep(1000);
		String voidmsgActual = driver.findElement(By.id("ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV:1:Status")).getText();
		String voidmsgExpected = "Voided";
		Thread.sleep(2000);
		if (voidmsgExpected.equalsIgnoreCase(voidmsgActual)) {
			Thread.sleep(2000);
			Report.pass("Verify Text", "Financial transacion", voidmsgExpected + " should available in Financial transacion page", voidmsgActual + " is exist in Financial transacion page");
		} else {
			Report.fail("Verify Text", "Financial transacion", voidmsgExpected + " should available in Financial transacion page", voidmsgActual + " is not same as in Financial transacion page");
		}			
	}
	
	public void FinancialSearchClaims(String excelFileName, String profileID) throws Exception{		
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtSearchClaimNumber = xlsread.Exceldata(SheetName, "txtSearchClaimNumber", profileID);
		String ddlSearchForDateSince = xlsread.Exceldata(SheetName, "ddlSearchForDateSince", profileID);

		UIMethods.clickbyid(claimNumber, "Click Claim Number", "Click");
		Helper.clearTextBox(driver, driver.findElement(By.id(claimNumber)));
		UIMethods.inputbyid(claimNumber, "Input Claim Number", txtSearchClaimNumber);
		Thread.sleep(500);
		UIMethods.selectbyid("ClaimSearchPopup:ClaimSearchScreen:ClaimSearchDV:ClaimSearchOptionalInputSet:DateSearch:DateSearchRangeValue", "Input Search for Date Since", ddlSearchForDateSince);
		
		UIMethods.clickbyid("ClaimSearchPopup:ClaimSearchScreen:ClaimSearchDV:ClaimSearchAndResetInputSet:Search_link", "Click Search button", "Click");
		Thread.sleep(2000);
		Helper.highLightElement(driver, driver.findElement(By.id("ClaimSearchPopup:ClaimSearchScreen:ClaimSearchResultsLV:0:_Select_link")));
		UIMethods.clickbyid("ClaimSearchPopup:ClaimSearchScreen:ClaimSearchResultsLV:0:_Select_link", "Click Select button", "Click");
		Thread.sleep(2000);
	}
	
	public void VerifyTransactionStatus() throws Exception{
		Thread.sleep(1000);
		String actualLossDate = driver.findElement(By.id("ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:TransactionsLV:1:Status")).getText();
		if (actualLossDate.equalsIgnoreCase("Transferred")) {
			Report.pass("Verify Text", "Financial transacion", "Transferred should available in Loss Date", actualLossDate + " is exist in Loss Date");
		} else {
			Report.fail("Verify Text", "Financial transacion", "Transferred should available in Loss Date", actualLossDate + " is not same as in Loss Date");
		}	
	}
}