package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class LossCause {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	public LossCause(WebDriver driver)
	{
		this.driver = driver;
	}	
	
	public void LossCausepage(String excelFileName, String profileID) throws Exception{
        //Read data from excel
        String SheetName = "ClaimsPolicy";
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtDescription = xlsread.Exceldata(SheetName, "txtDescription", profileID);
		String txtLossCause = xlsread.Exceldata(SheetName, "txtLossCause", profileID);
		String txtDetailedLossCause = xlsread.Exceldata(SheetName, "txtDetailedLossCause", profileID);
		String txtPickerEnhanced = xlsread.Exceldata(SheetName, "txtPickerEnhanced", profileID);
        //Loss Cause
		Thread.sleep(3000);
        UIMethods.inputbyid("FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:Description", "Input Description", txtDescription);
        UIMethods.selectbyid("FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:losscause", "Input losscause", txtLossCause);
        UIMethods.selectbyid("FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:detailedlosscause", "Input detailedlosscause", txtDetailedLossCause);
        UIMethods.selectbyid("FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:RepairShop_Picker_Enhanced", "Input RepairShop_Picker_Enhanced", txtPickerEnhanced);
        Thread.sleep(3000);
        UIMethods.clearAndInputbyid("FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:Claim_lossTime", "Input Time", "12:00 AM");
        Thread.sleep(3000);
        }
}