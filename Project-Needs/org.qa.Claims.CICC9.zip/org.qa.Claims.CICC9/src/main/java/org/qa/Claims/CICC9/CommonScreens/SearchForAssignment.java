package org.qa.Claims.CICC9.CommonScreens;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class SearchForAssignment {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	public SearchForAssignment(WebDriver driver) {
		
		this.driver = driver;
	}

	public void SearchForUser(String excelFileName, String profileID) throws Exception {
		
		String SheetName = "ClaimsPolicy";
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		
		String searchForUserLastName = xlsread.Exceldata(SheetName, "txtSearchForUserLastName", profileID);
		
		wait = new WebDriverWait(driver,20);
		UIMethods.inputbyid("AssigneePickerPopup:AssigneePickerScreen:AssignmentSearchDV:LastName", "Input Last Name", searchForUserLastName);
		UIMethods.clickbyid("AssigneePickerPopup:AssigneePickerScreen:AssignmentSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search", "Click Search button", "Click");
		wait = new WebDriverWait(driver,20);
		UIMethods.clickbyid("AssigneePickerPopup:AssigneePickerScreen:AssignmentUserLV:0:_Select", "Click Assign button", "Click");		
	}
}
