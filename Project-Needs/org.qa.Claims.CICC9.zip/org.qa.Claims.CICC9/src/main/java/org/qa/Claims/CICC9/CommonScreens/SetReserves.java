package org.qa.Claims.CICC9.CommonScreens;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

public class SetReserves extends Object_Repositories{

	private WebDriver driver = null;
	String txtExposure;
	String txtCostType;
	String txtCostCategory;
	String txtNewAvailableReserve;
	
	String addButton = "//a[@id='NewReserveSet:NewReserveSetScreen:Add']";
	String saveButton = "//*[text()='Save']";
	String removeButton = "//a[@id='NewReserveSet:NewReserveSetScreen:Remove']";
	String financialTitle = "//span[@id='ClaimFinancialsTransactions:ClaimFinancialsTransactionsScreen:ttlBar']";
	String nextIcon = "(//a[contains(@id,'gbutton') and @data-qtip='Next Page'])[1]";
	
	
	public SetReserves(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 15);
	}
	
	public void setReserve(String excelFileName, String profileID) throws Exception {	
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");		
		txtExposure = xlsread.Exceldata(SheetName, "ddlExposure", profileID);
		txtCostType = xlsread.Exceldata(SheetName, "CostType", profileID);
		txtCostCategory = xlsread.Exceldata(SheetName, "CostCategory", profileID);
		txtNewAvailableReserve = xlsread.Exceldata(SheetName, "newAvailableReserves", profileID); 		
		String expectedExposureName = xlsread.Exceldata(SheetName, "exposureName", profileID);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='NewReserveSet:NewReserveSetScreen:ttlBar' and text()='Set Reserves']")));
		
		// Check if next page (or) icon is getting displayed or not
		if(driver.findElement(By.xpath(nextIcon)).isDisplayed() == true) {
			
			// Get count of total pages in reserve screen
			String count = driver.findElement(By.xpath("(//div[contains(@id,'tbtext')])[2]")).getText();
			int totalCount = Integer.valueOf(count.substring(3));
			int a = 0;
			
			for(int j=1;j<=totalCount;j++) {
				
				// Add new row if the page exceeds one
				if(j>=2) {					
					UIMethods.jscriptclickbyxpath(addButton, "Click add button", "Click");
					Thread.sleep(1000);					
				}
				
				for(int i=1;i<=getRowLength();i++) {
					String actualExposureName = driver.findElement(By.xpath("//div[contains(@id,'gridview-')]/div/table["+i+"]/tbody/tr[1]/td[2]/div")).getText();
					String actualCostType = driver.findElement(By.xpath("//div[contains(@id,'gridview-')]/div/table["+i+"]/tbody/tr[1]/td[4]/div")).getText();
					String actualCostCategory = driver.findElement(By.xpath("//div[contains(@id,'gridview-')]/div/table["+i+"]/tbody/tr[1]/td[5]/div")).getText();
					
					if(actualExposureName.trim().equals(expectedExposureName) && actualCostType.trim().equals(txtCostType) && actualCostCategory.trim().equals(txtCostCategory)) {				
						
						// Update New Available Reserves
						UIMethods.jscriptclickbyxpath("//div[contains(@id,'gridview-')]/div/table["+ i +"]/tbody/tr/td[8]", "Click New Available Reserves text box", "Click");				
						UIMethods.clearAndinputbyxpath("//input[contains(@id,'textfield') and @name='NewAmount']", "Enter New Available Reserves", txtNewAvailableReserve);
						
						String actualDropdownValue = driver.findElement(By.xpath("//input[contains(@id,'textfield') and @name='NewAmount']")).getAttribute("value");
						if(!actualDropdownValue.contains(txtNewAvailableReserve)) {
							Assert.fail("Failed to select/Enter New Available Reserves");
						}						
						
						// Remove Extra row rows from the list (table)
						driver.findElement(By.xpath("//div[contains(@id,'gridview-')]/div/table[1]/tbody/tr/td[5]")).click();
						Thread.sleep(1000);				
						Helper.clickCheckBox("//div[contains(@id,'gridview-')]/div/table["+ getRowLength() +"]/tbody/tr/td[1]", "Click Check box to Remove");			
						String checkBoxStatus = driver.findElement(By.xpath("//div[contains(@id,'gridview-')]/div/table["+ getRowLength() +"]/tbody/tr/td[1]//img")).getAttribute("class");				
						if(!checkBoxStatus.contains("checked")) {
							Assert.fail("Failed to click Last row check box from Set reserve Screen");
						}
						
						wait.until(ExpectedConditions.elementToBeClickable(By.xpath(removeButton)));
						UIMethods.jscriptclickbyxpath(removeButton, "Click Remove button", "Click");						
						Thread.sleep(1500);
						//selectDropdownValue(8, "NewAmount", txtNewAvailableReserve, "Available Reserve");	
						a = 1;
						break;						
					}
					
					if(i == getRowLength() && j >= 2) {
						Helper.clickCheckBox("//div[contains(@id,'gridview-')]/div/table["+ getRowLength() +"]/tbody/tr/td[1]", "Click Check box to set Reserves");
										
						/*if(!(txtExposure.isEmpty())) {
							wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@id,'gridview-')]/div/table["+ getRowLength() +"]/tbody/tr/td[2]")));
							selectDropdownValue(2, "Exposure", txtExposure, "Exposure drop down");
						}		*/
						
						if(!actualExposureName.trim().equals(expectedExposureName)) {
							selectDropdownValue(2, "Exposure", expectedExposureName, "Exposure drop down");
						}				
						selectDropdownValue(4, "CostType", txtCostType, "Cost Type");
						selectDropdownValue(5, "CostCategory", txtCostCategory, "Cost Category");
						selectDropdownValue(8, "NewAmount", txtNewAvailableReserve, "Available Reserve");
						break;
					}
				}
				
				// To break all the loops
				if(a==1) {
					break;
				}
				
				if(j==1) {
					// Remove last row				
					Helper.clickCheckBox("//div[contains(@id,'gridview-')]/div/table["+ getRowLength() +"]/tbody/tr/td[1]", "Click Check box to Remove");			
					String checkBoxStatus = driver.findElement(By.xpath("//div[contains(@id,'gridview-')]/div/table["+ getRowLength() +"]/tbody/tr/td[1]//img")).getAttribute("class");				
					if(!checkBoxStatus.contains("checked")) {
						try {
							UIMethods.jscriptclickbyxpath("//div[contains(@id,'gridview-')]/div/table["+ getRowLength() +"]/tbody/tr/td[1]/div/img", "Click check box to remove", "Click");
							//Helper.clickCheckBox("//div[contains(@id,'gridview-')]/div/table["+ getRowLength() +"]/tbody/tr/td[1]/div/img", "Click Check box to Remove");			
						} catch (ElementNotFoundException e) {
							Assert.fail("Failed to click Last row check box from Set reserve Screen");
						}
					}
					
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(removeButton)));
					UIMethods.jscriptclickbyxpath(removeButton, "Click Remove button", "Click");
				}
				Thread.sleep(1500);				
				
				// Click Next page icon if cost category not appear on the screen
				UIMethods.jscriptclickbyxpath(nextIcon, "Click Next icon to move next page", "Click");
				Thread.sleep(1000);
			}
			
		} else if (!driver.findElement(By.xpath(nextIcon)).isDisplayed() == true){
			for(int i=1;i<=getRowLength();i++) {
				String actualExposureName = driver.findElement(By.xpath("//div[contains(@id,'gridview-')]/div/table["+i+"]/tbody/tr[1]/td[2]/div")).getText();
				String actualCostType = driver.findElement(By.xpath("//div[contains(@id,'gridview-')]/div/table["+i+"]/tbody/tr[1]/td[4]/div")).getText();
				String actualCostCategory = driver.findElement(By.xpath("//div[contains(@id,'gridview-')]/div/table["+i+"]/tbody/tr[1]/td[5]/div")).getText();
				
				if(actualExposureName.trim().equals(expectedExposureName) && actualCostType.trim().equals(txtCostType) && actualCostCategory.trim().equals(txtCostCategory)) {				
					
					// Update New Available Reserves
					UIMethods.jscriptclickbyxpath("//div[contains(@id,'gridview-')]/div/table["+ i +"]/tbody/tr/td[8]", "Click New Available Reserves text box", "Click");				
					UIMethods.clearAndinputbyxpath("//input[contains(@id,'textfield') and @name='NewAmount']", "Enter New Available Reserves", txtNewAvailableReserve);
					
					String actualDropdownValue = driver.findElement(By.xpath("//input[contains(@id,'textfield') and @name='NewAmount']")).getAttribute("value");
					if(!actualDropdownValue.contains(txtNewAvailableReserve)) {
						Assert.fail("Failed to select/Enter New Available Reserves");
					}
					
					// Remove Extra row rows from the list (table)
					driver.findElement(By.xpath("//div[contains(@id,'gridview-')]/div/table[1]/tbody/tr/td[5]")).click();
					Thread.sleep(1500);				
					Helper.clickCheckBox("//div[contains(@id,'gridview-')]/div/table["+ getRowLength() +"]/tbody/tr/td[1]", "Click Check box to Remove");			
					String checkBoxStatus = driver.findElement(By.xpath("//div[contains(@id,'gridview-')]/div/table["+ getRowLength() +"]/tbody/tr/td[1]//img")).getAttribute("class");				
					if(!checkBoxStatus.contains("checked")) {
						Assert.fail("Failed to click Last row check box from Set reserve Screen");
					}
					
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(removeButton)));
					UIMethods.jscriptclickbyxpath(removeButton, "Click Remove button", "Click");
					
					Thread.sleep(1500);
					//selectDropdownValue(8, "NewAmount", txtNewAvailableReserve, "Available Reserve");					
					break;
				}
				
				if(i >= getRowLength()) {
					Helper.clickCheckBox("//div[contains(@id,'gridview-')]/div/table["+ getRowLength() +"]/tbody/tr/td[1]//img", "Click Check box to set Reserves");
									
					/*if(!(txtExposure.isEmpty())) {
						wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@id,'gridview-')]/div/table["+ getRowLength() +"]/tbody/tr/td[2]")));
						selectDropdownValue(2, "Exposure", txtExposure, "Exposure drop down");
					}	*/	
					
					if(!actualExposureName.trim().equals(expectedExposureName)) {
						selectDropdownValue(2, "Exposure", expectedExposureName, "Exposure drop down");
					}				
					selectDropdownValue(4, "CostType", txtCostType, "Cost Type");
					selectDropdownValue(5, "CostCategory", txtCostCategory, "Cost Category");
					selectDropdownValue(8, "NewAmount", txtNewAvailableReserve, "Available Reserve");
					
					//System.out.println("Value not found in existing reserve lines...");
					break;
				}			
			}
		}	
		
		
		driver.findElement(By.xpath("//span[@id='NewReserveSet:NewReserveSetScreen:ttlBar' and text()='Set Reserves']")).click();
		
		// writing reserve Line to make payment in payment screen
		String actualReserveLine = expectedExposureName+"; "+txtCostType+"/"+txtCostCategory;
		xlsread.WriteIntoExistingExcel(SheetName, "reserveLine", actualReserveLine, profileID, true);
		
		Helper.getScreenshot(driver, "Reserve_Screen", "TC_" + profileID + "_");
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(saveButton)));
		UIMethods.jscriptclickbyxpath(saveButton, "click Save", "Click"); 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(financialTitle)));
		
		if(driver.findElements(By.xpath(financialTitle)).size()!=0) {
			xlsread.WriteIntoExistingExcel(SheetName, "reserveStatus", "Pass", profileID, true);
		} else {
			xlsread.WriteIntoExistingExcel(SheetName, "reserveStatus", "Fail", profileID, false);
		}
		
	}
		
	/**
	 * It's used to select the drop down values from the Exposure Screen
	 * @param columnID - Field Column count which you are going to select
	 * @param fieldName - Name of the field. Need to capture from the DOM
	 * @param testData - Drop down value
	 * @param description - Description to select drop down value 	
	 * @throws InterruptedException 
	 */
	public void selectDropdownValue(int columnID, String fieldName, String testData, String description) throws InterruptedException {
		String expectedDropDownValue = testData;
		String actualDropdownValue;
		int rowLength = getRowLength();	
		
		UIMethods.jscriptclickbyxpath("//div[contains(@id,'gridview-')]/div/table["+ rowLength +"]/tbody/tr/td["+ columnID +"]", "Click "+ description +"", "Click");
		if(!fieldName.contains("NewAmount")) {
			UIMethods.clearAndinputbyxpath(Helper.getDropdownXpath(fieldName), "Select/Enter "+ description +"", expectedDropDownValue);
			actualDropdownValue = driver.findElement(By.xpath(Helper.getDropdownXpath(fieldName))).getAttribute("value");
			if(!actualDropdownValue.contains(expectedDropDownValue)) {
				Assert.fail("Failed to select/Enter "+ description + "");
			}
		} else {
			Thread.sleep(500);
			UIMethods.clearAndinputbyxpath("//input[contains(@id,'textfield') and @name='"+ fieldName +"']", "Enter "+ description +"", expectedDropDownValue);
			actualDropdownValue = driver.findElement(By.xpath("//input[contains(@id,'textfield') and @name='"+ fieldName +"']")).getAttribute("value");
			if(!actualDropdownValue.contains(expectedDropDownValue)) {
				Assert.fail("Failed to select/Enter "+ description + "");
			}
		}		
	}
	
	public int getRowLength() {
		List<WebElement> allRows = driver.findElements(By.xpath(mainTable));
		int rowLength = allRows.size()-1;	
		return rowLength;
	}
	
	/*public String getDropdownXpath(String fieldName) {		
		String actualXpath = "//input[contains(@id,'simplecombo') and @name='"+ fieldName +"']";
		return actualXpath;
	}*/
}