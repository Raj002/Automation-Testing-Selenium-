package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.testng.Assert;

public class SaveAndAssignClaimFinish {

	private WebDriver driver = null;
	WebDriverWait wait;

	// Page Objects
	String finishButton = "FNOLWizard:Finish";
	String searchButton = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_AssignScreen:NewClaimWizard_AssignDV:CommonAssign:CommonAssign_PickerButton";
	String exposureDownArrow = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_AssignScreen:NewExposureLV_tb:AddExposure_EXT_arrow";
	String policyLevelCoverage = "//*[@id='FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_AssignScreen:NewExposureLV_tb:AddExposure_EXT:0:item']";
	String farmLiability = "//*[@id='FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_AssignScreen:NewExposureLV_tb:AddExposure_EXT:0:item:0:item']";
	String farmLiabilityMedPay = "//*[@id='FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_AssignScreen:NewExposureLV_tb:AddExposure_EXT:0:item:0:item:2:item']";
	String farmEmpMedicalPayment = "//*[@id='FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_AssignScreen:NewExposureLV_tb:AddExposure_EXT:0:item:0:item:0:item']";

	public SaveAndAssignClaimFinish(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}

	public void SaveAndAssignClaimFinishpage() throws Exception {
		UIMethods.clickbyid(finishButton, "click finish button", "Click");
		Thread.sleep(2000);
	}

	// Assign claim and then Finish claim
	public void AssignClaimAndFinish(String excelFileName, String profileID) throws Exception {
		String SheetName = "ClaimsPolicy";
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtSearchForAssignmentLastName = xlsread.Exceldata(SheetName, "txtSearchForAssignmentLastName",profileID);
		String txtSearchForAssignmentFirstName = xlsread.Exceldata(SheetName, "txtSearchForAssignmentFirstName",profileID);
		String txtNotes = xlsread.Exceldata(SheetName, "txtNotes", profileID);

		UIMethods.clickbyid(searchButton, "Click Search", "Click");
		Thread.sleep(2000);
		UIMethods.inputbyid("AssigneePickerPopup:AssigneePickerScreen:AssignmentSearchDV:LastName","Populate Last Name field", txtSearchForAssignmentLastName);
		UIMethods.inputbyid("AssigneePickerPopup:AssigneePickerScreen:AssignmentSearchDV:FirstName","Populate First Name field", txtSearchForAssignmentFirstName);
		Thread.sleep(2000);
		UIMethods.clickbyxpath("//*[@id='AssigneePickerPopup:AssigneePickerScreen:AssignmentSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search_link']","Click Search", "Click");
		Thread.sleep(2000);
		UIMethods.clickbyid("AssigneePickerPopup:AssigneePickerScreen:AssignmentUserLV:0:_Select", "Click Assign","Click");
		Thread.sleep(2000);
		UIMethods.inputbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_AssignScreen:NewClaimWizard_AssignDV:Note","Add info to Notes", txtNotes);
		UIMethods.clickbyid(finishButton, "click finish button", "Click");

		// Adding this step here temporarily until it finds a new home for the
		// "New Claim Saved" page in CICC
		Thread.sleep(2000);
		Assert.assertEquals("Dennis Rivera", "Dennis Rivera");
	}

	public void ClickSearchIconFromAssignClaimAndAllExposuresToRadioButton() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(searchButton)));
		UIMethods.clickbyid(searchButton, "Click Search icon", "Click");

	}

	public void AddFarmLiabilityMedPayExposure(String excelFileName, String profileID) throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(exposureDownArrow)));
		UIMethods.clickbyid(exposureDownArrow, "Click New Exposure down arrow", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(policyLevelCoverage, "Click Policy Level Coverage", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(farmLiability, "Click Farm Liability", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(farmLiabilityMedPay, "Click Farm Liability - Med Pay", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(farmLiabilityMedPay, "Click Farm Liability - Med Pay", "Click");
	}

	public void AddFarmEmployeeMedicalPaymentsMedPayExposure(String excelFileName, String profileID) throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(exposureDownArrow)));
		UIMethods.clickbyid(exposureDownArrow, "Click New Exposure down arrow", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(policyLevelCoverage, "Click Policy Level Coverage", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(farmLiability, "Click Farm Employee Medical Payments", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(farmEmpMedicalPayment, "Click Farm Employee Medical Payments - Med Pay", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(farmEmpMedicalPayment, "Click Farm Employee Medical Payments - Med Pay", "Click");

	}

	public void AddFarmEmployersLiabilityBodilyInjuryExposure(String excelFileName, String profileID) throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(exposureDownArrow)));
		UIMethods.clickbyid(exposureDownArrow, "Click New Exposure down arrow", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(policyLevelCoverage, "Click Policy Level Coverage", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(farmLiability, "Click Farm Employers Liab", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(farmEmpMedicalPayment, "Click Farm Employers Liab - Bodily Injury", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(farmEmpMedicalPayment, "Click Farm Employers Liab - Bodily Injury", "Click");

	}

	public void SelectAssignClaimAndAllExposuresToRadioButton() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_AssignScreen:NewClaimWizard_AssignDV:CommonAssignChoice_Choice")));
		UIMethods.clickbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_AssignScreen:NewClaimWizard_AssignDV:CommonAssignChoice_Choice","Click Assign claim and all exposures to radio button", "Click");
	}

	public void SelectFinishButton() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(finishButton)));
		UIMethods.clickbyid(finishButton, "click finish button", "Click");
	}
}