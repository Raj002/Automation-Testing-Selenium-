package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.FetchPropertiesFiles;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class CreateRecovery {
	
	private WebDriver driver;
	
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	//Page Objects
	String issuedDate = "NewRecoverySet:NewRecoveryScreen:RecoveryDetailDV:IssueDate";
	String receiveDate = "NewRecoverySet:NewRecoveryScreen:RecoveryDetailDV:ReceiveDate";
	
	public CreateRecovery(WebDriver driver) {
		this.driver = driver;
	}
		
	public void createRecovery(String excelFileName, String profileID) throws Exception {		
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlPayer = xlsread.Exceldata(SheetName, "ddlPayer", profileID);
		String ddlReserveLine = xlsread.Exceldata(SheetName, "ddlReserveLine", profileID);
		String ddlRecoveryCategory = xlsread.Exceldata(SheetName, "ddlRecoveryCategory", profileID);
		String txtCheckNumber = xlsread.Exceldata(SheetName, "txtCheckNumber", profileID);
		String txtDateCheckIssued = xlsread.Exceldata(SheetName, "txtDateCheckIssued", profileID);
		String txtDateCheckReceived = xlsread.Exceldata(SheetName, "txtDateCheckReceived", profileID);
		String txtCheckAmount = xlsread.Exceldata(SheetName, "txtCheckAmount", profileID);
		String ddlRecoveryCode = xlsread.Exceldata(SheetName, "ddlRecoveryCode", profileID);
		String ddlLineCategory = xlsread.Exceldata(SheetName, "ddlLineCategory", profileID);
		String txtLineAmount = xlsread.Exceldata(SheetName, "txtLineAmount", profileID);

		// ddlPayer
		UIMethods.selectbyid("NewRecoverySet:NewRecoveryScreen:RecoveryDetailDV:Payer", "Select Payer", ddlPayer);
		Thread.sleep(2000);

		// ddlReserveLine
		UIMethods.selectbyid("NewRecoverySet:NewRecoveryScreen:RecoveryDetailDV:ReserveLine", "Select Reserve Line",ddlReserveLine);
		Thread.sleep(2000);

		// ddlRecoveryCategory
		UIMethods.selectbyid("NewRecoverySet:NewRecoveryScreen:RecoveryDetailDV:RecoveryCategory","Select Recovery Category", ddlRecoveryCategory);

		// txtCheckNumber
		UIMethods.inputbyid("NewRecoverySet:NewRecoveryScreen:RecoveryDetailDV:CheckNumber", "Enter Check #",txtCheckNumber);

		// txtDateCheckIssued
		UIMethods.clickbyid(issuedDate, "input Date Check Issued", "Click");
		Helper.clearTextBox(driver, driver.findElement(By.id(issuedDate)));
		String strExecutionType = (FetchPropertiesFiles.executionMode).toString();
		if (strExecutionType.equalsIgnoreCase("Saucelab")) {
			UIMethods.inputbyid(issuedDate, "Enter Date Check Issued", txtDateCheckIssued);
		} else {
			//txtDateCheckIssued = txtDateCheckIssued.replace("/", "");
			UIMethods.inputbyid(issuedDate, "Enter Date Check Issued", txtDateCheckIssued);
		}

		// txtDateCheckReceived
		Thread.sleep(2000);
		UIMethods.clickbyid(receiveDate, "Click on Date Check Received", "Click");
		Helper.clearTextBox(driver, driver.findElement(By.id(receiveDate)));
		if (strExecutionType.equalsIgnoreCase("Saucelab")) {
			UIMethods.inputbyid(receiveDate, "Enter Date Check Received", txtDateCheckReceived);
		} else {
			//txtDateCheckReceived = txtDateCheckReceived.replace("/", "");
			UIMethods.inputbyid(receiveDate, "Enter Date Check Received", txtDateCheckReceived);
		}

		// txtCheckAmount
		UIMethods.inputbyid("NewRecoverySet:NewRecoveryScreen:RecoveryDetailDV:InvoiceAmount", "Enter Check Amount", txtCheckAmount);
		
		Thread.sleep(1000);
		// ddlRecoveryCode
		UIMethods.selectbyid("NewRecoverySet:NewRecoveryScreen:RecoveryDetailDV:RecoveryCode", "Select Recovery Code", ddlRecoveryCode);
				
		// chkLineCheckbox
		UIMethods.clickbyid("NewRecoverySet:NewRecoveryScreen:RecoveryDetailDV:EditableRecoveryLineItemsLV:0:_Checkbox", "Click Line Checkbox", "Click");
		
		Thread.sleep(500);
		// ddlLineCategory
		UIMethods.selectbyid("NewRecoverySet:NewRecoveryScreen:RecoveryDetailDV:EditableRecoveryLineItemsLV:0:LineCategory", "Select Line Category", ddlLineCategory);
		Thread.sleep(500);
		
		// txtLineAmount
		UIMethods.inputbyid("NewRecoverySet:NewRecoveryScreen:RecoveryDetailDV:EditableRecoveryLineItemsLV:0:Amount", "Enter Line Amount", txtLineAmount);
		UIMethods.clickbyid("NewRecoverySet:NewRecoveryScreen:RecoveryDetailDV:InvoiceAmount", "Click Check Amount", "Click");
		Thread.sleep(1000);
		
		// Update Button
		Helper.highLightElement(driver, driver.findElement(By.xpath("//span[text()='pdate']")));
        UIMethods.jscriptclickbyxpath("//span[text()='pdate']", "click on Update button", "Click");
        Thread.sleep(4000);
	}
}