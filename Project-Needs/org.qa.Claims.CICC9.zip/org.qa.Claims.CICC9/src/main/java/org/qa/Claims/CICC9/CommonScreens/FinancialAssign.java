package org.qa.Claims.CICC9.CommonScreens;

import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class FinancialAssign {
	
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	public void FinancialAssignpage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlSelectList = xlsread.Exceldata(SheetName, "ddlSelectList", profileID);
		
		UIMethods.selectbyid("AssignClaimsPopup:AssignmentPopupScreen:AssignmentPopupDV:SelectFromList", "Input Select a list", ddlSelectList);
		Thread.sleep(2000);
		UIMethods.clickbyid("AssignClaimsPopup:AssignmentPopupScreen:AssignmentPopupDV:AssignmentPopupScreen_ButtonButton", "Click Assign Button", "Click");
		Thread.sleep(2000);
	}
	
	
	public void ExposureAssignpage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlSelectList = xlsread.Exceldata(SheetName, "ddlAssignSelectList", profileID);
		
		UIMethods.selectbyid("AssignExposuresPopup:AssignmentPopupScreen:AssignmentPopupDV:SelectFromList", "Input Select a list", ddlSelectList);
		Thread.sleep(1000);
		UIMethods.clickbyid("AssignExposuresPopup:AssignmentPopupScreen:AssignmentPopupDV:AssignmentPopupScreen_ButtonButton", "Click Assign Button", "Click");
		Thread.sleep(2000);
	}
	
	
	public void WorkplanAssignpage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");		
		String ddlSelectList = xlsread.Exceldata(SheetName, "ddlAssignSelectList", profileID);
		
		UIMethods.selectbyid("AssignActivitiesPopup:AssignmentPopupScreen:AssignmentPopupDV:SelectFromList", "Input Select a list", ddlSelectList);
		Thread.sleep(2000);
		UIMethods.clickbyid("AssignActivitiesPopup:AssignmentPopupScreen:AssignmentPopupDV:AssignmentPopupScreen_ButtonButton", "Click Assign Button", "Click");
		Thread.sleep(2000);
	}
}