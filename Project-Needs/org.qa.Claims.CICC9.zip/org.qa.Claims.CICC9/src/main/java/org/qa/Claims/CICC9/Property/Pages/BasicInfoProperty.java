package org.qa.Claims.CICC9.Property.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class BasicInfoProperty {

	private WebDriver driver = null;
	WebDriverWait wait;
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");

	// Page Objects
	String nameMenuIcon = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_MainContactsScreen:NewClaimPeopleDV:ReportedBy_Name:ReportedBy_NameMenuIcon";
	String relationInsuredField = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_MainContactsScreen:NewClaimPeopleDV:Claim_ReportedByType";
	String closeButton = "NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:NewClaimDuplicatesWorksheet_CloseButton";
	
	
	public BasicInfoProperty(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver,20);
	}

	public void BasicInformationSearch(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlRelationInsured = xlsread.Exceldata(SheetName, "ddlRelationInsured", profileID);
		String btnBasicSearchMenu = xlsread.Exceldata(SheetName, "btnBasicSearchMenu", profileID);
		String btnBasicNext = xlsread.Exceldata(SheetName, "btnBasicNext", profileID);
		String btnBasicNewPersonMenu = xlsread.Exceldata(SheetName, "btnBasicNewPersonMenu", profileID);
		// btnBasicNewPersonMenu
		if (!(btnBasicNewPersonMenu.isEmpty())) {
			UIMethods.clickbyid(nameMenuIcon, "Click arrow Button", "Click");
			Thread.sleep(2000);
			UIMethods.jscriptclickbyxpath("//*[@id='FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_MainContactsScreen:NewClaimPeopleDV:ReportedBy_Name:ClaimNewPersonOnlyPickerMenuItemSet:ClaimNewPersonOnlyPickerMenuItemSet_NewPersonMenuItem']", "Click New Person Option", "Click");
	        Thread.sleep(3000);
		}
		
		// btnBasicSearchMenu
		if (!(btnBasicSearchMenu.isEmpty())) {
			UIMethods.clickbyid(nameMenuIcon, "Click arrow Button", "Click");
			Thread.sleep(2000);
			UIMethods.jscriptclickbyxpath("//*[@id='FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_MainContactsScreen:NewClaimPeopleDV:ReportedBy_Name:MenuItem_Search']", "Click Search Option", "Click");
	        Thread.sleep(5000);	
		}
		
		System.out.println("The insured Relation value is " + ddlRelationInsured);
		// ddlRelationInsured
		UIMethods.selectbyid(relationInsuredField, "select Relation Insured", ddlRelationInsured);
				
		// btnBasicNext
		if (!(btnBasicNext.isEmpty())) {
			for (int intLoop = 1; intLoop <= 7; intLoop++) {
	        	UIMethods.clickbyxpath("//a[@id='FNOLWizard:Next']/span[text()='Next >']", "Click Next", "Click");
	        	Thread.sleep(4000);
	        	if(driver.findElements(By.id(closeButton)).size()> 0){
	        		UIMethods.jscriptclickbyxpath("//*[@id='NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:NewClaimDuplicatesWorksheet_CloseButton']", "Click Close Option", "Click");
	                Thread.sleep(3000);
	    		}
	        	try {
	        		driver.findElement(By.xpath("//span[contains(text(), ': Basic information')]/parent::div")).isDisplayed();
	        	} catch (Exception Ex) {
	        		break;
	        	}
	        	Thread.sleep(3000);
			}
		}
	}

	public void BasicInfoSearch(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlReportedName = xlsread.Exceldata(SheetName, "ddlReportedName", profileID);
		String ddlRelationInsured = xlsread.Exceldata(SheetName, "ddlRelationInsured", profileID);
		String btnBasicNext = xlsread.Exceldata(SheetName, "btnBasicNext", profileID);

		// ddlReportedName
		UIMethods.selectbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_MainContactsScreen:NewClaimPeopleDV:ReportedBy_Name", "select Reported Name", ddlReportedName);
		
		// ddlRelationInsured
		UIMethods.selectbyid(relationInsuredField, "select Relation Insured", ddlRelationInsured);
		
		// btnBasicNext
		if (!(btnBasicNext.isEmpty())) {
			for (int intLoop = 1; intLoop <= 7; intLoop++) {
	        	UIMethods.clickbyxpath("//a[@id='FNOLWizard:Next']/span[text()='Next >']", "Click Next", "Click");
	        	Thread.sleep(4000);
	        	if(driver.findElements(By.id(closeButton)).size()> 0){
	        		UIMethods.jscriptclickbyxpath("//*[@id='NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:NewClaimDuplicatesWorksheet_CloseButton']", "Click Close Option", "Click");
	                Thread.sleep(3000);
	    		}
	        	try {
	        		driver.findElement(By.xpath("//span[contains(text(), ': Basic information')]/parent::div")).isDisplayed();
	        	} catch (Exception Ex) {
	        		break;
	        	}
	        	Thread.sleep(3000);
			}
		}
	}
	
	// Select Search option
	public void SearchForClaimantJoe(String excelFileName, String profileID) throws Exception{
		UIMethods.clickbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_MainContactsScreen:NewClaimPeopleDV:ReportedBy_Name_helper", "Select down arrow", "Click");
		UIMethods.clickbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_MainContactsScreen:NewClaimPeopleDV:ReportedBy_Name:MenuItem_Search", "Select Search option", "Click");
	}
	
	// Search main Contact
	public void SearchForMainContact() throws Exception{
		UIMethods.clickbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_MainContactsScreen:NewClaimPeopleDV:MainContact_Name:MainContact_NameMenuIcon", "Click Main Contact Icon", "Click");
		UIMethods.clickbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_MainContactsScreen:NewClaimPeopleDV:MainContact_Name:MenuItem_Search", "Select Search option", "Click");
		Thread.sleep(2000);
	}
	
	public void PopulateRelationToInsured(String excelFileName, String profileID) throws Exception{
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");		
		String relationToInsured = xlsread.Exceldata(SheetName, "ddlRelationToInsured", profileID);
		
		Thread.sleep(2000);
		UIMethods.selectbyid(relationInsuredField, "Select Claimant from drop-down", relationToInsured);
		UIMethods.clickbyid("FNOLWizard:Next", "Select the Next button", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FNOLWizard:Next")));
		UIMethods.clickbyid("FNOLWizard:Next", "Select the Next button", "Click");
		UIMethods.clickbyid(closeButton, "Select Close button", "Click");
		UIMethods.clickbyid("FNOLWizard:Next", "Select the Next button", "Click");
	}
}