package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class InjuiryIncident extends Object_Repositories{
	
	private WebDriver driver = null;
	String txtInjuryLossParty;
	String injuryDescription;
	String ddlInjurySeverity;	
	String searchnewPolicy;

	NewPersonContactDetail  newperson;
	
	// Page Objects
	String injuredPerson = "//input[contains(@id,'Injured_Picker-inputEl')]";
	String injuredLossParty = "//input[contains(@id,'InjuryLossParty-inputEl')]";
	String describeInjuries = "//textarea[contains(@id,'InjuryDescription-inputEl')]";
	String severityField = "//input[contains(@id,'Severity-inputEl')]";
	String bodyPartsAddButton = "//a[contains(@id,'EditableBodyPartDetailsLV_tb:Add')]";
	
	String okButton = "//*[@id='NewInjuryIncidentPopup:NewInjuryIncidentScreen:Update']";
	
	public InjuiryIncident(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 15);
		newperson  = new NewPersonContactDetail(driver);
	}	
	
	public void AddInjuiryIncidentPage(String excelFileName, String profileID) throws Exception {			
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		
		txtInjuryLossParty = xlsread.Exceldata(SheetName, "ddlInjuryLossParty", profileID);
		ddlInjurySeverity = xlsread.Exceldata(SheetName, "ddlInjurySeverity", profileID);
		String ddlPrimaryBodyPart = xlsread.Exceldata(SheetName, "ddlPrimaryBodyPart", profileID);
		String ddlDetailedBodyPart = xlsread.Exceldata(SheetName, "ddlDetailedBodyPart", profileID);
		
        //Add Injuiry Details
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(returnToExposureLink)));
		UIMethods.jscriptclickbyxpath(claimantArrowIcon, "Click injury person arrow icon", "Click");
		Helper.getUIXpath(driver, "New Person").click();		
		newperson.NewPersonContactDetailpage(excelFileName, profileID);
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(injuredLossParty)));
		Helper.selectDropdownValue(driver, "xpath", injuredLossParty, "Select Injured Loss Party", txtInjuryLossParty);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(describeInjuries)));
		UIMethods.clearAndinputbyxpath(describeInjuries, "Enter describe injuries", "To testadd injury incident");
		
		Helper.selectDropdownValue(driver, "xpath", severityField, "Select Injured Severity", ddlInjurySeverity);		
		UIMethods.clickbyxpath(bodyPartsAddButton, "Click Body parts Add button", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(commonCheckBox)));
		Helper.clickCheckBox(commonCheckBox, "Select body parts first row");
		
		Helper.clickTableColumnRow("2", "1", "PrimaryBodyPart", "Click/Select Area of body", ddlPrimaryBodyPart);
		
		Helper.clickTableColumnRow("3", "1", "DetailedBodyPart", "Click/Select Body part", ddlDetailedBodyPart);
		
		driver.findElement(By.xpath(describeInjuries)).click();
		Thread.sleep(1000);
		
        Helper.highLightElement(driver, driver.findElement(By.xpath(okButton)));
        UIMethods.clickbyxpath(okButton, "Click Ok Button", "Click");
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(describeInjuries)));
	}
	
	public void FillOutInjuryDetailsSection(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");

		txtInjuryLossParty = xlsread.Exceldata(SheetName, "ddlInjuryLossParty", profileID);
		ddlInjurySeverity = xlsread.Exceldata(SheetName, "ddlInjurySeverity", profileID);
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(injuredLossParty)));
		Helper.selectDropdownValue(driver, "xpath", injuredLossParty, "Select Injured Loss Party", txtInjuryLossParty);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(describeInjuries)));
		UIMethods.clearAndinputbyxpath(describeInjuries, "Enter describe injuries", "To testadd injury incident");
		
		Helper.selectDropdownValue(driver, "xpath", severityField, "Select Injured Severity", ddlInjurySeverity);		
		UIMethods.clickbyxpath(describeInjuries, "Click Describe injuries field", "Click");
	}

	public void ClickOKButtonOnly() throws Exception {
		Thread.sleep(2000);
		UIMethods.clickbyxpath(okButton, "Click Ok Button", "Click");
	}
}