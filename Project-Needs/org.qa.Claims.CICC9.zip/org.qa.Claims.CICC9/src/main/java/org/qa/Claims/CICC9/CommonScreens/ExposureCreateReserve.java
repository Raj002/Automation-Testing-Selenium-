package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class ExposureCreateReserve {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	//Page Objects
	String claimExposureGroup = "//*[@id='Claim:MenuLinks:Claim_ClaimExposuresGroup']/div";
	String createReserve = "//*[@id='ClaimExposures:ClaimExposuresScreen:ClaimExposures_CreateReserve']/span[2]";
	
	public ExposureCreateReserve(WebDriver driver)
	{
		this.driver = driver;
	}	
	
	public void ExposuresPage() throws Exception{
		UIMethods.clickbyxpath(claimExposureGroup, "click ClaimExposuresGroup", "Click");
		Thread.sleep(2000);
        UIMethods.clickbyxpath("//*[@id='ClaimExposures:ClaimExposuresScreen:ExposuresLV:0:_Checkbox']", "click ExposuresLV:0:_Checkbox", "Click");
        UIMethods.clickbyxpath(createReserve, "click CreateReserve", "Click");
        Thread.sleep(2000);
	}
	
	public void ExposuresCreateReservePage() throws Exception {
		Helper.highLightElement(driver, driver.findElement(By.xpath(claimExposureGroup)));
		UIMethods.clickbyxpath(claimExposureGroup, "click ClaimExposuresGroup", "Click");
		Thread.sleep(2000);
        UIMethods.clickbyxpath("//*[@id='ClaimExposures:ClaimExposuresScreen:ExposuresLV:1:_Checkbox']", "click ExposuresLV:0:_Checkbox", "Click");
        UIMethods.clickbyxpath(createReserve, "click CreateReserve", "Click");
        Thread.sleep(3000);
	}
}