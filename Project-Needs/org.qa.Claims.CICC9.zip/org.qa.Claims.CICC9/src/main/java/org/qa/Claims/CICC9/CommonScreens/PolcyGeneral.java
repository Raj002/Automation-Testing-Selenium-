package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class PolcyGeneral {

	private WebDriver driver = null;
	WebDriverWait wait;

	public PolcyGeneral(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 10);
	}
	
	public void PolcyGeneralpage() throws Exception{
        UIMethods.clickbyxpath("//*[@id='Claim:MenuLinks:Claim_ClaimPolicyGroup']/div", "Click Policy", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='ClaimPolicyGeneral:ClaimPolicyGeneralScreen:ClaimPolicyGeneral_SelectPolicyButton']/span[2]")));
		UIMethods.clickbyxpath("//*[@id='ClaimPolicyGeneral:ClaimPolicyGeneralScreen:ClaimPolicyGeneral_SelectPolicyButton']/span[2]", "Click Select Policy", "Click");
		Thread.sleep(2000);
		try {
			Alert alert = driver.switchTo().alert();
			System.out.println("Found and clicked Alert window with text message as " + alert.getText());
			alert.accept();
			Thread.sleep(3000);
		} catch (Exception Ex) {
			Ex.printStackTrace();
		}		
     }
}