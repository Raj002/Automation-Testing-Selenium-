package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class WorkplanComplete {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	String searchnewPolicy;
	
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	//Page Objects
	String workPlan = "//*[text()='Workplan']";
	String checkAllCheckBox = "ClaimWorkplan:ClaimWorkplanScreen:WorkplanLV:_Checkbox";
	String completeField = "ClaimWorkplan:ClaimWorkplanScreen:ClaimWorkplan_CompleteButton";
	
	public WorkplanComplete(WebDriver driver)
	{
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}	
	
	public void workplanComplete(String excelFileName, String profileID) throws Exception{		
		/*ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtName = xlsread.Exceldata(SheetName, "txtName", profileID);
		String ddlNegotiationType = xlsread.Exceldata(SheetName, "ddlNegotiationType", profileID);
		String ddlRelatedTo = xlsread.Exceldata(SheetName, "ddlRelatedTo", profileID);*/
		
		UIMethods.clickbyxpath(workPlan, "Click Workplan", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(checkAllCheckBox)));
		UIMethods.clickbyid(checkAllCheckBox, "Click CheckAll", "Click");
		wait.until(ExpectedConditions.elementToBeClickable(By.id(completeField)));
		Helper.highLightElement(driver, driver.findElement(By.id(completeField)));
		UIMethods.clickbyid(completeField, "Click Complete", "Click");
		Thread.sleep(5000);        
	}
	
	public void WorkplanAssign() throws Exception{		
		UIMethods.clickbyxpath(workPlan, "Click Workplan", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(checkAllCheckBox)));
		UIMethods.clickbyid(checkAllCheckBox, "Click CheckAll", "Click");
		UIMethods.clickbyid("ClaimWorkplan:ClaimWorkplanScreen:ClaimWorkplan_AssignButton", "Click Workplan Assign", "Click");
		Thread.sleep(3000);        
	}
}