package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class ExposureClose {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	public ExposureClose(WebDriver driver)
	{
		this.driver = driver;
	}	
	
	public void ExposureClosePage(String excelFileName, String profileID) throws Exception{
		
		String SheetName = "ClaimsPolicy";
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtNoteCloseExposure = xlsread.Exceldata(SheetName, "txtNoteCloseExposure", profileID);
		String ddlOutcomeCloseExposure = xlsread.Exceldata(SheetName, "ddlOutcomeCloseExposure", profileID);
		
		UIMethods.clickbyxpath("//*[text()='Exposures']", "Click Exposures", "Click");
		Thread.sleep(3000);
		UIMethods.clickbyid("ClaimExposures:ClaimExposuresScreen:ExposuresLV:_Checkbox", "Click CheckAll", "Click");
		Thread.sleep(2000);
		UIMethods.clickbyid("ClaimExposures:ClaimExposuresScreen:ClaimExposures_CloseExposure", "Click Close Exposure", "Click");
		Thread.sleep(2000);
		UIMethods.clickbyid("CloseExposurePopup:CloseExposureScreen:CloseExposureInfoDV:Note", "Click Note", "Click");
		UIMethods.inputbyid("CloseExposurePopup:CloseExposureScreen:CloseExposureInfoDV:Note", "input Note", txtNoteCloseExposure);
		Thread.sleep(2000);
		UIMethods.selectbyid("CloseExposurePopup:CloseExposureScreen:CloseExposureInfoDV:Outcome", "input Outcome", ddlOutcomeCloseExposure);
		Thread.sleep(2000);
		UIMethods.clickbyid("CloseExposurePopup:CloseExposureScreen:Update", "Click Close Exposure", "Click");
		Thread.sleep(2000);
	}
}