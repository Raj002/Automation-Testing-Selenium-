package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class ClaimContactScreen {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	//Page Objects
	String newContactArrow = "//*[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_CreateNewContactButton_arrow']";
	String newPersonLink = "//*[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_CreateNewContactButton:ClaimContacts_NewPerson']";
	String addButton = "NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:ContactBasicsHeaderInputSet:EditableClaimContactRolesLV_tb:Add";
	
	
	public ClaimContactScreen(WebDriver driver)
	{
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}	
	
	public void ClaimContactScreenpage(String excelFileName, String profileID) throws Exception {
        //Read data from excel
        
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtClaimContactRoles = xlsread.Exceldata(SheetName, "txtClaimContactRoles", profileID);
		String txtFirstName1 = xlsread.Exceldata(SheetName, "txtFirstName1", profileID);
		String txtLastName1 = xlsread.Exceldata(SheetName, "txtLastName1", profileID);
		Thread.sleep(3000);
		//ClaimContactsScreen
        UIMethods.clickbyid("Claim:MenuLinks:Claim_ClaimPartiesGroup", "Click ClaimPartiesGroup", "Click");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newContactArrow)));
        UIMethods.jscriptclickbyxpath(newContactArrow, "Click CreateNewContactButton_arrow", "Click");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newPersonLink)));
        UIMethods.jscriptclickbyxpath(newPersonLink, "Click ClaimContacts_NewPerson", "Click");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(addButton)));
        UIMethods.clickbyid(addButton, "Click Add", "Click");
        Thread.sleep(5000);
        UIMethods.selectbyid("NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:ContactBasicsHeaderInputSet:EditableClaimContactRolesLV:0:Role", "Input Claim Contact Roles", txtClaimContactRoles);
        UIMethods.inputbyid("NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:PersonNameInputSet:FirstName", "Input First Name", txtFirstName1);
        UIMethods.inputbyid("NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:PersonNameInputSet:LastName", "Input Last name", txtLastName1);
        UIMethods.clickbyid("NewPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:Update", "Click Update", "Click");
        Thread.sleep(5000);
        }
}