package org.qa.Claims.CICC9.CommonScreens;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class NewMatter {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	String SheetName = "ClaimsPolicy";
	
	public NewMatter(WebDriver driver)
	{
		this.driver = driver;
		wait = new WebDriverWait(driver, 10);
	}	
	
	public void NewMatterpage(String excelFileName, String profileID) throws Exception{
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtGeneralName = xlsread.Exceldata(SheetName, "txtGeneralName", profileID);
		String ddlPlaintiff = xlsread.Exceldata(SheetName, "ddlPlaintiff", profileID);
		String ddlDefendant = xlsread.Exceldata(SheetName, "ddlDefendant", profileID);
		String ddlAssignedTo = xlsread.Exceldata(SheetName, "ddlAssignedTo", profileID);
		String txtExposure = xlsread.Exceldata(SheetName, "txtExposure", profileID);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewMatter:NewMatterScreen:NewMatterDV:Matter_Name")));
        UIMethods.inputbyid("NewMatter:NewMatterScreen:NewMatterDV:Matter_Name", "Input general name", txtGeneralName);
        Helper.waitForLoad(driver);
        UIMethods.selectbyid("NewMatter:NewMatterScreen:NewMatterDV:Plaintiff", "Input plaintiff", ddlPlaintiff);
        Helper.waitForLoad(driver);
        UIMethods.selectbyid("NewMatter:NewMatterScreen:NewMatterDV:Defendant", "Input defendant", ddlDefendant);
        Helper.waitForLoad(driver);
        UIMethods.clickbyid("NewMatter:NewMatterScreen:NewMatterDV:Litigated_true", "click Litigated_true", "Click");
        Helper.waitForLoad(driver);
        UIMethods.selectbyid("NewMatter:NewMatterScreen:NewMatterDV:AssignedTo", "Input assignedto", ddlAssignedTo);
        Helper.waitForLoad(driver);
        UIMethods.clickbyxpath("//a[@id='NewMatter:NewMatterScreen:NewMatterDV:Add']/span[text()='Add']", "click Add button", "Click");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewMatter:NewMatterScreen:NewMatterDV:0:exposure")));
        Thread.sleep(3000);
        UIMethods.inputbyid("NewMatter:NewMatterScreen:NewMatterDV:0:exposure", "Input exposure", txtExposure);
        UIMethods.clickbyxpath("//span[text()='pdate']", "click Update button", "Click");
        Helper.waitForLoad(driver);
        Thread.sleep(2000);
        
        // Validating if the error message exists on the screen
		if (driver.findElements(By.id("NewMatter:NewMatterScreen:_msgs_msgs")).size() != 0) {
			Assert.fail(driver.findElement(By.id("NewMatter:NewMatterScreen:_msgs_msgs")).getText());
		}
	}
}