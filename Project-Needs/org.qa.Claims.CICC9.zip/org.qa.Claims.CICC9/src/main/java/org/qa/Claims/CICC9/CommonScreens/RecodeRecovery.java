package org.qa.Claims.CICC9.CommonScreens;

import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class RecodeRecovery {	

    String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
		
	public void recoderecoverypage(String excelFileName, String profileID) throws Exception{        
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlLineCategory = xlsread.Exceldata(SheetName, "ddlLineCategory", profileID);
		
		Thread.sleep(1000);
		UIMethods.selectbyid("RecodeRecovery:EditableRecodeLineItemsLV:0:LineCategory", "input line category", ddlLineCategory);
		Thread.sleep(2000);
        UIMethods.clickbyxpath("//*[@id='RecodeRecovery:RecodeButton']", "click recode button", "Click");
        Thread.sleep(2000);
	}
	
}