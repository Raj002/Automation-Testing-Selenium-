package org.qa.Claims.CICC9.GL.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class BasicInfoGL {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	// Page Objects
	String arrowButton = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_MainContactsScreen:NewClaimPeopleDV:ReportedBy_Name:ReportedBy_NameMenuIcon";

	public BasicInfoGL(WebDriver driver) {
		this.driver = driver;
	}

	public void BasicInformationGLSearch(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");		
		String ddlRelationInsured = xlsread.Exceldata(SheetName, "ddlRelationInsured", profileID);
		String btnBasicSearchMenu = xlsread.Exceldata(SheetName, "btnBasicSearchMenu", profileID);
		String btnBasicNext = xlsread.Exceldata(SheetName, "btnBasicNext", profileID);
		String btnBasicNewPerson = xlsread.Exceldata(SheetName, "btnBasicNewPerson", profileID);
		
		Thread.sleep(3000);
		// btnBasicSearchMenu
		if (!(btnBasicSearchMenu.isEmpty())) {
			UIMethods.clickbyid(arrowButton, "Click arrow Button", "Click");
			Thread.sleep(2000);
			UIMethods.jscriptclickbyxpath("//*[@id='FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_MainContactsScreen:NewClaimPeopleDV:ReportedBy_Name:MenuItem_Search']", "Click Search Option", "Click");
	        Thread.sleep(5000);	
		}
		
		// ddlRelationInsured
		UIMethods.selectbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_MainContactsScreen:NewClaimPeopleDV:Claim_ReportedByType", "Input relation to insured", ddlRelationInsured);
		Thread.sleep(2000);
		
		// btnBasicNewPerson
		if (!(btnBasicNewPerson.isEmpty())) {
			UIMethods.clickbyid(arrowButton, "Click arrow Button", "Click");
			Thread.sleep(2000);
			UIMethods.jscriptclickbyxpath("//*[@id='FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_MainContactsScreen:NewClaimPeopleDV:ReportedBy_Name:ClaimNewPersonOnlyPickerMenuItemSet:ClaimNewPersonOnlyPickerMenuItemSet_NewPersonMenuItem']", "Click New Person Option", "Click");
	        Thread.sleep(5000);	
		}
		
		// btnBasicNext
		if (!(btnBasicNext.isEmpty())) {
			for (int intLoop = 1; intLoop <= 7; intLoop++) {
	        	UIMethods.clickbyxpath("//a[@id='FNOLWizard:Next']/span[text()='Next >']", "Click Next", "Click");
	        	Thread.sleep(4000);
	        	if(driver.findElements(By.id("NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:NewClaimDuplicatesWorksheet_CloseButton")).size()> 0){
	        		UIMethods.jscriptclickbyxpath("//*[@id='NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:NewClaimDuplicatesWorksheet_CloseButton']", "Click Close Option", "Click");
	                Thread.sleep(3000);
	    		}
	        	try {
	        		driver.findElement(By.xpath("//span[text()='Step 2 of 6: Basic information']/parent::div")).isDisplayed();
	        	} catch (Exception Ex) {
	        		break;
	        	}
	        	Thread.sleep(3000);
			}
		}
	}
	
	public void SelectReportedByName(String excelFileName, String profileID) throws Exception {		
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		
		String reportedByName = xlsread.Exceldata(SheetName, "ddlReportedByName", profileID);	
		UIMethods.inputbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_MainContactsScreen:NewClaimPeopleDV:ReportedBy_Name", "Select value from Name drop-down list", reportedByName);
	}
	
	public void SelectNextButton() {
		UIMethods.clickbyid("FNOLWizard:Next", "Click Next button", "Click");
	}
	
	public void SelectCloseButtonFromDuplicateClaimsMessage() {	
		UIMethods.clickbyid("NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:NewClaimDuplicatesWorksheet_CloseButton", "Click Close button", "Click");
	}
}