package org.qa.Claims.CICC9.Technology;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.lang.reflect.Field;

import org.apache.log4j.Logger;

/**
 * To perform keyboard actions on an UI
*/
public class RobotMethods {

	public static final Logger LOG = Logger.getLogger(RobotMethods.class);
	public Robot robo;

	public RobotMethods() {
		try {
			this.robo = new Robot();
		} catch (AWTException e) {

			e.printStackTrace();
		}

	}

	/**
	 * Method to perform tabbing action using Tab key on keyboard
	 * @param tabNum
	 */

	public void pageTabbing(int tabNum) {
		for (int i = 0; i < tabNum; i++) {
			robo.delay(50);
			robo.keyPress(KeyEvent.VK_TAB);
			robo.keyRelease(KeyEvent.VK_TAB);
			robo.delay(50);
		}
	}

	/**
	 * Method to perform tabbing action replication the action of the Tab button
	 * on keyboard
	 * 
	 * @param variable
	 */
	public void enterString(String variable) {
		try {
			robo.delay(10);
			for (int i = 0; i < variable.length(); i++) {
				char res = variable.charAt(i);
				robotMethod(res);
				robo.delay(30);
			}

			robo.delay(10);

		} catch (SecurityException e) {
			LOG.error("RobotMethods : Exception : " + e.getMessage());
		} catch (IllegalArgumentException e) {
			LOG.error("RobotMethods : Exception : " + e.getMessage());
		}

	}
	
	/**
	 * Method to perform alpha-numeric keyboard actions by replication of the same
	 * on keyboard
	 * @param res
	 */

	public void robotMethod(char res) {

		switch (res) {
		case '_':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_MINUS);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			robo.keyRelease(KeyEvent.VK_MINUS);
			break;
		case ' ':
			robo.keyPress(KeyEvent.VK_SPACE);
			robo.keyRelease(KeyEvent.VK_SPACE);
			robo.delay(5);
			break;
		case '/':
			robo.keyPress(KeyEvent.VK_SLASH);
			robo.keyRelease(KeyEvent.VK_SLASH);
			break;
		case '?':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_SLASH);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			robo.keyRelease(KeyEvent.VK_SLASH);
			break;
		case '!':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_1);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			robo.keyRelease(KeyEvent.VK_1);
			break;
		case '@':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_2);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			robo.keyRelease(KeyEvent.VK_2);
			break;
		case '#':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_3);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			robo.keyRelease(KeyEvent.VK_3);
			break;

		case '$':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_4);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			robo.keyRelease(KeyEvent.VK_4);
			break;
		case '%':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_5);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			robo.keyRelease(KeyEvent.VK_5);
			break;
		case '^':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_6);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			robo.keyRelease(KeyEvent.VK_6);
			break;
		case '&':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_7);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			robo.keyRelease(KeyEvent.VK_7);
			break;
		case '*':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_8);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			robo.keyRelease(KeyEvent.VK_8);
			break;
		case '(':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_9);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			robo.keyRelease(KeyEvent.VK_9);
			break;
		case ')':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_0);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			robo.keyRelease(KeyEvent.VK_0);
			break;
		case '+':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_EQUALS);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			robo.keyRelease(KeyEvent.VK_EQUALS);
			break;
		case '=':
			robo.keyPress(KeyEvent.VK_EQUALS);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_EQUALS);
			break;
		case '-':
			robo.keyPress(KeyEvent.VK_MINUS);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_MINUS);
			break;
		case '.':

			robo.keyPress(KeyEvent.VK_PERIOD);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_PERIOD);
			break;
		case ',':
			robo.keyPress(KeyEvent.VK_COMMA);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_COMMA);
			break;
		case ';':
			robo.keyPress(KeyEvent.VK_SEMICOLON);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SEMICOLON);
			break;
		case ':':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_SEMICOLON);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			robo.keyRelease(KeyEvent.VK_SEMICOLON);
			break;
		case '"':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_QUOTE);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			robo.keyRelease(KeyEvent.VK_QUOTE);
			break;
		case '\'':
			robo.keyPress(KeyEvent.VK_QUOTE);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_QUOTE);
			break;
		case '~':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_BACK_QUOTE);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_BACK_QUOTE);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			break;
		case '`':
			robo.keyPress(KeyEvent.VK_BACK_QUOTE);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_BACK_QUOTE);
			break;
		case '<':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_COMMA);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_COMMA);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			break;
		case '>':
			robo.delay(5);
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_PERIOD);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			robo.keyRelease(KeyEvent.VK_PERIOD);
			break;
		case '\\':
			robo.keyPress(KeyEvent.VK_BACK_SLASH);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_BACK_SLASH);
			break;
		case '|':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_BACK_SLASH);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_BACK_SLASH);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			break;
		case '[':
			robo.keyPress(KeyEvent.VK_OPEN_BRACKET);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_OPEN_BRACKET);
			break;
		case ']':
			robo.keyPress(KeyEvent.VK_CLOSE_BRACKET);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_CLOSE_BRACKET);
			break;
		case '{':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_OPEN_BRACKET);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			robo.keyRelease(KeyEvent.VK_OPEN_BRACKET);
			break;
		case '}':
			robo.keyPress(KeyEvent.VK_SHIFT);
			robo.keyPress(KeyEvent.VK_CLOSE_BRACKET);
			robo.delay(5);
			robo.keyRelease(KeyEvent.VK_SHIFT);
			robo.keyRelease(KeyEvent.VK_CLOSE_BRACKET);
			break;
		default:
			Class<KeyEvent> clas = KeyEvent.class;
			Field field = null;
			String temp = "";
			int keyCode=0;

			if (Character.isUpperCase(res)) {
				temp = "VK_" + res;
				try {
					field = clas.getField(temp.toUpperCase());
				} catch (NoSuchFieldException | SecurityException e) {
					LOG.error("RobotMethods : Exception : " + e.getMessage());
				}
				try {
					keyCode = field.getInt(null);
				} catch (IllegalArgumentException | IllegalAccessException e) {
					LOG.error("RobotMethods : Exception : " + e.getMessage());
				}
				robo.delay(5);
				robo.keyPress(KeyEvent.VK_SHIFT);
				robo.keyPress(keyCode);
				robo.keyRelease(KeyEvent.VK_SHIFT);
				robo.keyRelease(keyCode);
				break;

			} else {
				temp = "VK_" + res;
				try {
					field = clas.getField(temp.toUpperCase());
					keyCode = field.getInt(null);
				} catch (NoSuchFieldException | SecurityException e) {
					LOG.error("RobotMethods : Exception : " + e.getMessage());
				} catch (IllegalArgumentException e) {
					LOG.error("RobotMethods : Exception : " + e.getMessage());
				} catch (IllegalAccessException e) {
					LOG.error("RobotMethods : Exception : " + e.getMessage());
				}
				robo.delay(5);
				robo.keyPress(keyCode);
				robo.keyRelease(keyCode);
				break;
			}

		}

	}

}
