package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class DriverDetails {
	
	private WebDriver driver = null;
	WebDriverWait wait;

	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");

	// Page Objects
	String driverRelationToOwner = "FNOLContactPopup:FNOLContactScreen:ContactDV:FNOLContactInputSet:DriverRelationToOwner";
	String driverFirstName = "FNOLContactPopup:FNOLContactScreen:ContactDV:FNOLContactInputSet:FirstName";
	String driverLastName = "FNOLContactPopup:FNOLContactScreen:ContactDV:FNOLContactInputSet:LastName";
	String injuredOption = "FNOLContactPopup:FNOLContactScreen:ContactDV:InjuredBoolean_true";
	String injuryDescription = "FNOLContactPopup:FNOLContactScreen:ContactDV:InjuryIncidentInputSet:InjuryDescription";
	String severityTextBox = "FNOLContactPopup:FNOLContactScreen:ContactDV:InjuryIncidentInputSet:Severity";
	String okButton = "//a[@id='FNOLContactPopup:FNOLContactScreen:Update']/span[text()='OK']";

	public DriverDetails(WebDriver driver) {
		this.driver = driver;
	}

	public void DriverDetailspage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlRelationToOwner = xlsread.Exceldata(SheetName, "ddlRelationToOwner", profileID);
		String txtDriverFirstName = xlsread.Exceldata(SheetName, "txtDriverFirstName", profileID);
		String txtDriverLastName = xlsread.Exceldata(SheetName, "txtDriverLastName", profileID);
		String txtInjuryDescp = xlsread.Exceldata(SheetName, "txtInjuryDescp", profileID);
		String ddlInjurySeverity = xlsread.Exceldata(SheetName, "ddlInjurySeverity", profileID);
		String ddlPrimaryBodyPart = xlsread.Exceldata(SheetName, "ddlPrimaryBodyPart", profileID);
		String ddlDetailedPrimaryBodyPart = xlsread.Exceldata(SheetName, "ddlDetailedPrimaryBodyPart", profileID);

		UIMethods.inputbyid(driverRelationToOwner, "Input DriverRelationToOwner", ddlRelationToOwner);
		UIMethods.inputbyid(driverFirstName, "Input Driver FirstName", txtDriverFirstName);
		UIMethods.inputbyid(driverLastName, "Input Driver LastName", txtDriverLastName);
		UIMethods.clickbyid(injuredOption, "click injured", "Click");
		UIMethods.inputbyid(injuryDescription, "Input injury description", txtInjuryDescp);
		UIMethods.selectbyid(severityTextBox, "Input Severity", ddlInjurySeverity);
		// click Add button
		// WebElement addbodtpartsbutton =
		// driver.findElement(By.xpath("//a[@id='FNOLContactPopup:FNOLContactScreen:ContactDV:InjuryIncidentInputSet:EditableBodyPartDetailsLV_tb:Add']/span[text()='dd']"));
		// JavascriptExecutor js = (JavascriptExecutor)driver;
		// js.executeScript("arguments[0].click();", addbodtpartsbutton);
		// Thread.sleep(2000);
		// UIMethods.inputbyid("FNOLContactPopup:FNOLContactScreen:ContactDV:InjuryIncidentInputSet:EditableBodyPartDetailsLV:0:PrimaryBodyPart",
		// "input area of body part", ddlPrimaryBodyPart);
		// UIMethods.inputbyid("FNOLContactPopup:FNOLContactScreen:ContactDV:InjuryIncidentInputSet:EditableBodyPartDetailsLV:0:DetailedBodyPart",
		// "input detailed area of body part", ddlDetailedPrimaryBodyPart);
		// UIMethods.clickbyxpath("//a[@id='FNOLContactPopup:FNOLContactScreen:Update']/span[text()='OK']",
		// "click ok button", "Click");
		Thread.sleep(2000);
		// UIMethods.clickbyid("FNOLVehicleIncidentPopup:FNOLVehicleIncidentScreen:DamDescFront_EXT",
		// "click Front option", "Click");
		UIMethods.clickbyxpath(okButton, "click ok button", "Click");
		Thread.sleep(4000);
	}

	public void AddDriverDetailspage(String excelFileName, String profileID) throws Exception {		
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlRelationToOwner = xlsread.Exceldata(SheetName, "ddlRelationToOwner", profileID);
		String txtDriverFirstName = xlsread.Exceldata(SheetName, "txtDriverFirstName", profileID);
		String txtDriverLastName = xlsread.Exceldata(SheetName, "txtDriverLastName", profileID);
		String txtInjuryDescp = xlsread.Exceldata(SheetName, "txtInjuryDescp", profileID);
		String ddlGeneralInjuryType = xlsread.Exceldata(SheetName, "ddlGeneralInjuryType", profileID);
		String ddlDetailedInjuryType = xlsread.Exceldata(SheetName, "ddlDetailedInjuryType", profileID);
		String ddlInjurySeverity = xlsread.Exceldata(SheetName, "ddlInjurySeverity", profileID);
		String ddlPrimaryBodyPart = xlsread.Exceldata(SheetName, "ddlPrimaryBodyPart", profileID);
		String ddlDetailedPrimaryBodyPart = xlsread.Exceldata(SheetName, "ddlDetailedPrimaryBodyPart", profileID);

		UIMethods.selectbyid(driverRelationToOwner, "Input DriverRelationToOwner", ddlRelationToOwner);
		UIMethods.inputbyid(driverFirstName, "Input Driver FirstName", txtDriverFirstName);
		UIMethods.inputbyid(driverLastName, "Input Driver LastName", txtDriverLastName);
		UIMethods.clickbyid(injuredOption, "click injured", "Click");
		UIMethods.inputbyid(injuryDescription, "Input injury description", txtInjuryDescp);
        UIMethods.selectbyid("FNOLContactPopup:FNOLContactScreen:ContactDV:InjuryIncidentInputSet:PrimaryInjuryType", "Input General injury Type", ddlGeneralInjuryType);
        UIMethods.selectbyid("FNOLContactPopup:FNOLContactScreen:ContactDV:InjuryIncidentInputSet:DetailedInjuryType", "Input Detailed injury Type", ddlDetailedInjuryType);
        UIMethods.selectbyid(severityTextBox, "Input Severity", ddlInjurySeverity);
        Thread.sleep(2000);
        
	     //click Add Body Parts button
        UIMethods.clickbyid("FNOLContactPopup:FNOLContactScreen:ContactDV:InjuryIncidentInputSet:EditableBodyPartDetailsLV_tb:Add", "click Add Body Parts button", "Click");
        Thread.sleep(1000);
        UIMethods.clickbyid("FNOLContactPopup:FNOLContactScreen:ContactDV:InjuryIncidentInputSet:EditableBodyPartDetailsLV:0:_Checkbox", "click Checkbox", "Click");
        UIMethods.selectbyid("FNOLContactPopup:FNOLContactScreen:ContactDV:InjuryIncidentInputSet:EditableBodyPartDetailsLV:0:PrimaryBodyPart", "input area of body part", ddlPrimaryBodyPart);
        UIMethods.selectbyid("FNOLContactPopup:FNOLContactScreen:ContactDV:InjuryIncidentInputSet:EditableBodyPartDetailsLV:0:DetailedBodyPart", "input detailed area of body part", ddlDetailedPrimaryBodyPart);

        UIMethods.clickbyxpath(okButton, "click ok button", "Click");
        Thread.sleep(3000);
	}
}