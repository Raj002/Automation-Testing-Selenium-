package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class NewClaims extends Object_Repositories{

	public WebDriver driver = null;
		
	public NewClaims(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}
	
	public void NewClaimspage() throws Exception {
		
		// Added by RAJ
		Helper.waitForLoad(driver);	
		
        WebElement ClaimMenu = driver.findElement(By.xpath(claimMenuIcon));
        Actions action = new Actions(driver);
        action.moveToElement(ClaimMenu, ClaimMenu.getSize().width - 2, 2).click().build().perform();
        UIMethods.jscriptclickbyxpath(newClaimOption, "Click New Claim Option", "Click");        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FNOLWizard:FNOLWizard_FindPolicyScreen:ttlBar")));
	}

	public void Select_NewClaim_OR_Search_Option(String excelFileName, String profileID) {
		
		xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtClaimProceedWith = xlsread.Exceldata(SheetName, "proceedWith", profileID);
		String txtClaimNumber = xlsread.Exceldata(SheetName, "existingClaimNumber", profileID);
		
		Helper.waitForLoad(driver);
		WebElement ClaimMenu = driver.findElement(By.xpath(claimMenuIcon));
		Actions action = new Actions(driver);
		action.moveToElement(ClaimMenu, ClaimMenu.getSize().width - 2, 2).click().build().perform();
		
		if (txtClaimProceedWith.contains("Claim Search")) {
			UIMethods.inputbyid(claimNumberField, "input claimnumber", txtClaimNumber);
			UIMethods.jscriptclickbyxpath(searchIcon, "Click Search Icon", "Click");
		} else {
			UIMethods.jscriptclickbyxpath(newClaimOption, "Click New Claim Option", "Click");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FNOLWizard:FNOLWizard_FindPolicyScreen:ttlBar")));
		}

	}
	
	public void DesktopPage() throws Exception {		
		Helper.highLightElement(driver, driver.findElement(By.xpath(desktopMenu)));
		Helper.clickMainMenu(driver, "desktop");
	}

	public void ClickDesktop() throws Exception {
		Helper.highLightElement(driver, driver.findElement(By.xpath(desktopMenu)));
		Helper.clickMainMenu(driver, "desktop");
	}
	
}