package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class ValidationResults {

	private WebDriver driver = null;
	WebDriverWait wait;

	// Page Objects
	String errorMessage = "WebMessageWorksheet:WebMessageWorkSheetScreen:grpMsgs_msgs";
	String clearButton = "//*[@id='WebMessageWorksheet:WebMessageWorkSheetScreen:WebMessageWorksheet_ClearButton']/span[2]";

	public ValidationResults(WebDriver driver) {
		this.driver = driver;
	}

	public void ValidationResultspage() throws Exception {
		String errmsgActual = driver.findElement(By.id(errorMessage)).getText();
		String errmsgExpected = "No validation errors.";
		Thread.sleep(2000);
		if (errmsgExpected.equalsIgnoreCase(errmsgActual)) {
			UIMethods.jscriptclickbyxpath(clearButton, "click Clear button", "Click");
			Thread.sleep(2000);
			Report.pass("Verify Text", "Validation Errors", errmsgExpected + " should available in validation page", errmsgActual + " is exist in validation page");
		} else {
			Report.fail("Verify Text", "Validation Errors", errmsgExpected + " should available in validation page", errmsgActual + " is not same as in validation page");
		}
	}

	public void ValidationResultsMessage(String excelFileName, String profileID) throws Exception {
		String SheetName = "ClaimsPolicy";
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String errmsgExpected = xlsread.Exceldata(SheetName, "ValidationResultMessage", profileID);

		String errmsgActual = driver.findElement(By.id(errorMessage)).getText();
		Thread.sleep(2000);
		if (errmsgActual.contains(errmsgExpected)) {
			UIMethods.jscriptclickbyxpath(clearButton, "click Clear button", "Click");
			Thread.sleep(2000);
			Report.pass("Verify Text", "Validation Errors", errmsgExpected + " should available in validation page", errmsgActual + " is exist in validation page");
		} else {
			Report.fail("Verify Text", "Validation Errors", errmsgExpected + " should available in validation page", errmsgActual + " is not same as in validation page");
		}
	}
}