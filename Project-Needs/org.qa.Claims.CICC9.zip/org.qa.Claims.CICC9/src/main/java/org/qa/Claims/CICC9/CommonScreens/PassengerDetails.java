package org.qa.Claims.CICC9.CommonScreens;

import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class PassengerDetails {

	public void PassengerDetailsPage(String excelFileName, String profileID) throws Exception {
		// Fetch Data
		String SheetName = "ClaimsPolicy";
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");

		String txtPassengerFirstName = xlsread.Exceldata(SheetName, "txtPassengerFirstName", profileID);
		String txtPassengerLastName = xlsread.Exceldata(SheetName, "txtPassengerLastName", profileID);

		UIMethods.inputbyid("FNOLContactPopup:FNOLContactScreen:ContactDV:FNOLContactInputSet:FirstName","input First name", txtPassengerFirstName);
		UIMethods.inputbyid("FNOLContactPopup:FNOLContactScreen:ContactDV:FNOLContactInputSet:LastName","input Last name", txtPassengerLastName);
		UIMethods.clickbyxpath("//a[@id='FNOLContactPopup:FNOLContactScreen:Update']/span[text()='OK']","Click Ok button", "Click");
	}
}