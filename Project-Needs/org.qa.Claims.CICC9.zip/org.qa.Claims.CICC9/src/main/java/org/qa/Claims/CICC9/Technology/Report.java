package org.qa.Claims.CICC9.Technology;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.qa.Claims.CICC9.Utilities.Helper;


/**
 * Reusable component to Create and generate execution report
*/

public class Report {	
	
	public static Date sysDate = new Date();
	public static DateFormat dateFormat = new SimpleDateFormat("MM_dd_YYYY_HHmmss");	
	public static String foramttedSysDate=dateFormat.format(sysDate) ,foramttedSysDateNew , 
			moduleName = "", functionality = "" , testCaseScenario = "", tcID = "", reportsPath = "" ,  
			folderPath = "", docfileName = "" , gray = "LightGray" , red = "red", green = "green" ,Yellow = "Yellow"
			,Orange = "Orange" , black = "black" , blue = "LightSkyBlue";
	public static BufferedWriter bufferedWriter = null ,bufferedWriterindivScenario = null;
	public static int i = 0, ii = 0 , j = 0, a = 0 ,sno = 0 ,totalTC = 0 , passCount  = 0 ,failCount = 0;	

	// Added by RAJ
	public static String userName = System.getProperty("user.name");
	public static String osName = System.getProperty("os.name");
	public static String javaVersion = System.getProperty("java.version");
	public static String startTime;
	
	public static String start;
	public static String End;
	public static Calendar calendar;
	
	public Report(String module,String functionality){		
		moduleName=module;
		Report.functionality=functionality;
		calendar = Calendar.getInstance();
	}

	public Report(String testCaseID){
		
		testCaseScenario= testCaseID;	
		
	}

	public static void valueReset(){
	
		ii=ii-ii;
		i=i-i;
		j=j-j;
		a=a-a;
	}
	
	public static int count(){
		
		return j;
	}
	
	public static void reportCreation() throws UnknownHostException{	
		
		new File("Reports//"+functionality).mkdir();	
		new File("Reports//"+functionality+"//"+moduleName).mkdir();
		new File("Reports//"+functionality+"//"+moduleName+"//"+ foramttedSysDate).mkdir();		
		folderPath="Reports//"+functionality+"//"+moduleName+"//"+ foramttedSysDate;		
		sysDate = new Date();
		InetAddress hostName = Inet4Address.getLocalHost();
		
		//String foramttedSysDateNew = dateFormat.format(sysDate);		
		File htmlfilePath = new File("Reports//"+functionality+"//"+moduleName+"//"+ foramttedSysDate + "//"+ moduleName +"_Module Summary_.html");
			
		try {
			
			bufferedWriter = new BufferedWriter(new FileWriter(htmlfilePath));			
			bufferedWriter.write("<html>");
			bufferedWriter.write("<body bgcolor =" + "#eceff5" +  " style=\"font-family:calibri;\" >");
			bufferedWriter.write("<center><h1 style='background-color:DodgerBlue;'>SUMMARY REPORT</h1></center>");
			
			bufferedWriter.write("<center><table border=" + 2 + " width=" + 700+">");
			bufferedWriter.write("<tr>");
			bufferedWriter.write("<th width=" + 200  +" bgcolor =" + gray + "><center>"+functionality+"</center></th>");
			bufferedWriter.write("<th width=" + 500  +" bgcolor =" + gray + "><center>" +"Automated Test Exectution Report - " +sysDate + "</center></th>");		
			bufferedWriter.write("</tr>");
			bufferedWriter.write("</table></center>");
			bufferedWriter.write("<br>");
			
			// Environment informations
			bufferedWriter.write("<form><fieldset><legend><b>Environment</b></legend>");
			bufferedWriter.write("<center><table style='width:100%'>" + "<th width=" + 250
					+ " ><center>Parameter</center></th>" + "<th width=" + 250 + " ><center>Value</center></th>");

			bufferedWriter.write(
					"<center><table style='width:100%'>" + "<td width=" + 250 + " ><center>User Name</center></td>"
							+ "<td width=" + 250 + " ><center>" + userName + "</center></td>");
			bufferedWriter.write("</center></table>");

			bufferedWriter
					.write("<center><table style='width:100%'>" + "<td width=" + 250 + " ><center>OS Name</center></td>"
							+ "<td width=" + 250 + " ><center>" + osName + "</center></td>");
			bufferedWriter.write("</center></table>");

			bufferedWriter.write(
					"<center><table style='width:100%'>" + "<td width=" + 250 + " ><center>Java Version</center></td>"
							+ "<td width=" + 250 + " ><center>" + javaVersion + "</center></td>");
			bufferedWriter.write("</center></table>");

			
			bufferedWriter.write(
					"<center><table style='width:100%'>" + "<td width=" + 250 + " ><center>Host Name</center></td>"
							+ "<td width=" + 250 + " ><center>" + hostName + "</center></td>");
			bufferedWriter.write("</center></table>");
			 

			bufferedWriter.write(
					"<center><table style='width:100%'>" + "<td width=" + 250 + " ><center>Module Name</center></td>"
							+ "<td width=" + 250 + " ><center>" + moduleName + "</center></td>");
			bufferedWriter.write("</center></table>");
			bufferedWriter.write("</center></table></fieldset></form>");
			bufferedWriter.write("<br>");

			bufferedWriter.write("<center><table border=" + 2 + " >");
			bufferedWriter.write("<tr>");
			bufferedWriter.write("<th width=" + 100 + " bgcolor =" + gray + "><center>S.No</center></th>");
			bufferedWriter.write("<th width=" + 250 + " bgcolor =" + gray + "><center>TestCase Status</center></th>");
			bufferedWriter.write("<th width=" + 250 + " bgcolor =" + gray + "><center>TestCase ID</center></th>");
			bufferedWriter.write("<th width=" + 250 + " bgcolor =" + gray + "><center>Environment</center></th>");
			bufferedWriter.write("<th width=" + 250 + " bgcolor =" + gray + "><center>TimeStamp</center></th>");
			bufferedWriter.write("</tr>");	
			
		} catch (IOException e) {
			
			e.printStackTrace();
		} 
		
	}
	
	public static void reportPreparation(){
		
		try {	
			sno++;
			int count = count();
			if (count > 0) {
				failCount++;
				bufferedWriter.write("<tr>");
				bufferedWriter.write("<td width=" + 100 + "><font><center>" +  sno	+ "</center></font></td>");
				bufferedWriter.write("<td border=" + 3+ " width="+ 250	+ ">"+ "<a href="+ ""+ testCaseScenario + "//"+ tcID +"//"+testCaseScenario +"_"+foramttedSysDateNew + ".html"+ "><font color="+ red + "><b><center>FAIL</center></font></a></td>");
				bufferedWriter.write("<td width=" + 250 + "><font><center>" +  tcID	+ "</center></font></td>");
				bufferedWriter.write("<td width=" + 250	+ "><font><center>" + FetchPropertiesFiles.environment + "</center></font></td>");
				DateFormat dateFormat1 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				Date date = new Date();
				bufferedWriter.write("<td width=" + 250 + "><font color=" + black + ">"	+ dateFormat1.format(date)	+ "</font></td>");
				bufferedWriter.write("</tr>");
				
			} else {
				passCount++;
				bufferedWriter.write("<tr>");
				bufferedWriter.write("<td width=" + 100 + "><font><center>" +  sno	+ "</center></font></td>");
				bufferedWriter.write("<td border="	+ 2	+ " width="	+ 250	+ ">"	+ "<a href="	+ ""+ testCaseScenario + "//"+ tcID +"//"+testCaseScenario +"_" +foramttedSysDateNew + ".html"	+ "><font color="	+ green	+ "><b><center>PASS</center></font></a></td>");
				bufferedWriter.write("<td width=" + 250	+ "><font><center>"	+  tcID	+ "</center></font></td>");
				bufferedWriter.write("<td width=" + 250	+ "><font><center>"	+ FetchPropertiesFiles.environment	+ "</center></font></td>");
				DateFormat dateFormat2 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				Date date = new Date();
				bufferedWriter.write("<td width=" + 250	+ "><font color=" + black + ">"	+ dateFormat2.format(date)	+ "</font></td>");
				bufferedWriter.write("</tr>");
				
			}
					
			Report.valueReset();
			
		} catch (IOException e) {
			
			e.printStackTrace();
		
		}
	}
	
	public static void summaryPageConsolidation(){
		
		try {	
			
			bufferedWriter.write("</table>");
			bufferedWriter.write("<br></br>");
			bufferedWriter.write("<br></br>");	
			bufferedWriter.write("<center><table border="+5+" width="+250+">");
			bufferedWriter.write("<tr>");
			bufferedWriter.write("<th width="+250+" bgcolor ="+green+"><center> PASS </center></th>");
			bufferedWriter.write("<th width="+250+" bgcolor="+red+"><center> FAIL </center></th>");
			bufferedWriter.write("<th width="+250+" bgcolor="+Orange+"><center> TOTAL TC </center></th>");
			bufferedWriter.write("</tr>"); 	
		  	
			bufferedWriter.write("<tr>");		
			bufferedWriter.write("<td width="+250+"><font><center>"+ passCount +"</center></font></td>");
			bufferedWriter.write("<td width="+250+"><font><center>"+ failCount +"</center></font></td>");
		  	
			bufferedWriter.write("<td width="+250+"><font><center>"+ sno +"</center></font></td>");
			bufferedWriter.write("</tr>"); 
			bufferedWriter.write("</table></center>");
			
		} catch (IOException e) {
			e.printStackTrace();
		}	
		
	}
	
	public static void reportCompletion(){	
		
		try {
			summaryPageConsolidation();
			
			bufferedWriter.write("</body>");
			bufferedWriter.write("</html>");
		} catch (IOException e) {
			
			e.printStackTrace();
		} finally{
			
			try {
				bufferedWriter.close();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}		
	}
	
	public static String individualReport(String testcaseID) throws UnknownHostException {
		
		InetAddress hostName = Inet4Address.getLocalHost();
		startTime = Helper.getDateTime(0);
		start = startTime.substring(11, 19);
		
		tcID = testcaseID;
		sysDate = new Date();		
		foramttedSysDateNew = dateFormat.format(sysDate);
		new File("Reports//"+ functionality +"//"+ moduleName + "//"+ foramttedSysDate +"//"+testCaseScenario).mkdir();
		new File("Reports//"+ functionality +"//"+ moduleName + "//"+ foramttedSysDate +"//"+testCaseScenario+"//"+ testcaseID).mkdir();
		
//		new InsertImageIntoWordDocx("");
//		docfileName = InsertImageIntoWordDocx.createDoc("Reports//"+ functionality +"//"+ moduleName + "//"+ foramttedSysDate +"//"+testCaseScenario+"_"+testcaseID+".docx");
//		docfileName = InsertImageIntoWordDocx.createDoc("Reports//"+ functionality +"//"+ moduleName + "//"+ foramttedSysDate +"//"+testCaseScenario+"//"+ testcaseID+"//"+testcaseID+".docx");
		
//		new InsertImageIntoWordDocx(docfileName);
		
		File indivhtmlReportPath = new File("Reports//"+ functionality +"//"+moduleName+"//"+ foramttedSysDate + "//"+testCaseScenario +"//"+ testcaseID+"//"+testCaseScenario+"_" +foramttedSysDateNew + ".html");
		
		try {
			
			bufferedWriterindivScenario = new BufferedWriter(new FileWriter(indivhtmlReportPath));
			bufferedWriterindivScenario.write("<html>"
					+ "<body bgcolor =" + "#eceff5" +  " style='font-family:calibri;' >");
			
			// Report Header
			bufferedWriterindivScenario.write("<center><h1 style='background-color:DodgerBlue;'>EXECUTION REPORT</h1></center>");
						
			// Environment informations
			bufferedWriterindivScenario.write("<form><fieldset><legend><b>Environment</b></legend>");
			bufferedWriterindivScenario.write("<center><table style='width:100%'>" + "<th width=" + 250
					+ " ><center>Parameter</center></th>" + "<th width=" + 250 + " ><center>Value</center></th>");
			
			bufferedWriterindivScenario.write("<center><table style='width:100%'>"
					+ "<td width=" + 250 + " ><center>User Name</center></td>"
					+ "<td width=" + 250 + " ><center>" + userName + "</center></td>");
			bufferedWriterindivScenario.write("</center></table>");
			
			bufferedWriterindivScenario.write("<center><table style='width:100%'>"
					+ "<td width=" + 250 + " ><center>OS Name</center></td>"
					+ "<td width=" + 250 + " ><center>" + osName + "</center></td>");
			bufferedWriterindivScenario.write("</center></table>");
			
			bufferedWriterindivScenario.write("<center><table style='width:100%'>"
					+ "<td width=" + 250 + " ><center>Java Version</center></td>"
					+ "<td width=" + 250 + " ><center>" + javaVersion + "</center></td>");
			bufferedWriterindivScenario.write("</center></table>");			
			
			bufferedWriterindivScenario.write("<center><table style='width:100%'>"
					+ "<td width=" + 250 + " ><center>Host Name</center></td>"
					+ "<td width=" + 250 + " ><center>" + hostName + "</center></td>");
			bufferedWriterindivScenario.write("</center></table>");
			
			bufferedWriterindivScenario.write("<center><table style='width:100%'>"
					+ "<td width=" + 250 + " ><center>Module Name</center></td>"
					+ "<td width=" + 250 + " ><center>" + moduleName + "</center></td>");
			bufferedWriterindivScenario.write("</center></table>");
			
			bufferedWriterindivScenario.write("<center><table style='width:100%'>"
					+ "<td width=" + 250 + " ><center>TestCase ID</center></td>"
					+ "<td width=" + 250 + " ><center>" +  tcID + "</center></td>");
			bufferedWriterindivScenario.write("</center></table></fieldset></form>");			
			bufferedWriterindivScenario.write("<br>");	
			bufferedWriterindivScenario.write("<table border=" + 5 + " ");
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		return "Reports//"+ functionality +"//"+ moduleName + "//"+ foramttedSysDate +"//"+testCaseScenario;
	}
	
	public static void heading() {
		
  	  try {
  		  
  		  bufferedWriterindivScenario.write("<tr>");
  		  bufferedWriterindivScenario.write("<th width="+50+" bgcolor ="+gray+"><center>S.No</center></th>");
	  	  bufferedWriterindivScenario.write("<th width="+75+" bgcolor ="+gray+"><center>Status</center></th>");
	  	  bufferedWriterindivScenario.write("<th width="+500+" bgcolor="+gray+"><center>Test Steps</center></th>");
	  	  bufferedWriterindivScenario.write("<th width="+200+" bgcolor="+gray+"><center>Test data</center></th>");
	  	  bufferedWriterindivScenario.write("<th width="+250+" bgcolor="+gray+"><center>Expected</center></th>");
	  	  bufferedWriterindivScenario.write("<th width="+250+" bgcolor="+gray+"><center>Actual</center></th>");  	  
	  	  bufferedWriterindivScenario.write("<th width="+200+" bgcolor ="+gray+"><center>TimeStamp</center></th>");
	  	  bufferedWriterindivScenario.write("</tr>"); 
  	 
  	  } catch (IOException e) {
		
		e.printStackTrace();
  	  }
  	    	  
    }
	
	public static void pass(String description, String testData , String expected, String actual) {
	    
		 try{
			 
	  	  i=i+1;
	  	  ii=ii+1;
	  	  
	  	  bufferedWriterindivScenario.write("<tr>");
	  	  bufferedWriterindivScenario.write("<td border="+2+" width="+50+"><font color="+black+"><b><center>"+ii+"</center></b></font></td>");
	  	  bufferedWriterindivScenario.write("<td border="+2+" width="+75+"><font color="+green+"><b><center>Pass</center></b></font></td>");
	  	  bufferedWriterindivScenario.write("<td border="+2+" width="+500+">"+description+"</td>");
	  	  bufferedWriterindivScenario.write("<td border="+2+" width="+200+">"+testData+"</td>");
	  	  bufferedWriterindivScenario.write("<td border="+2+" width="+250+">"+expected+"</td>");
	  	  bufferedWriterindivScenario.write("<td border="+2+" width="+250+">"+actual+"</td>");
	  	  
	  	  DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	  	  Date date = new Date();
	  	  
	  	  bufferedWriterindivScenario.write("<td width="+200+"><font color="+black+">"+dateFormat.format(date)+"</font></td>");
	  	  bufferedWriterindivScenario.write("</tr>"); 
	  	  
	  	  System.out.println("PASS: "+description+"     "+dateFormat.format(date));
	   
		 }catch(Exception e){
	    	
	    	System.out.println("Error: "+e);
	    }
	 
	}
	
	public static void warn(String description, String testData , String expected, String actual) {
	    
		 try{
			 
	  	  i=i+1;
	  	  ii=ii+1;
	  	  
	  	  bufferedWriterindivScenario.write("<tr>");
	  	  bufferedWriterindivScenario.write("<td border="+2+" width="+50+"><font color="+black+"><b><center>"+ii+"</center></b></font></td>");
	  	  bufferedWriterindivScenario.write("<td border="+2+" width="+75+"><font color="+Orange+"><b><center>Pass</center></b></font></td>");
	  	  bufferedWriterindivScenario.write("<td border="+2+" width="+500+">"+description+"</td>");
	  	  bufferedWriterindivScenario.write("<td border="+2+" width="+200+">"+testData+"</td>");
	  	  bufferedWriterindivScenario.write("<td border="+2+" width="+250+">"+expected+"</td>");
	  	  bufferedWriterindivScenario.write("<td border="+2+" width="+250+">"+actual+"</td>");
	  	  
	  	  DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	  	  Date date = new Date();
	  	  
	  	  bufferedWriterindivScenario.write("<td width="+200+"><font color="+black+">"+dateFormat.format(date)+"</font></td>");
	  	  bufferedWriterindivScenario.write("</tr>"); 
	  	  
	  	  System.out.println("WARN: "+description+"     "+dateFormat.format(date));
	   
		 }catch(Exception e){
	    	
	    	System.out.println("Error: "+e);
	    }
	 
	}
	
	public static void fail(String description, String testData , String expected, String actual) {
		  
		try{
		   	 DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		   	 Date date = new Date();		   	 
		   	 String JPEGPath = UIMethods.takeSnapshotForFailures(testData, description,testCaseScenario+"//"+tcID);
		     j=j+1;
			 ii=ii+1;
			 bufferedWriterindivScenario.write("<tr>");
			 bufferedWriterindivScenario.write("<td border="+2+" width="+50+"><font color="+black+"><b><center>"+ii+"</center></b></font></td>");
			 bufferedWriterindivScenario.write("<td border="+2+" width="+75+"><font color="+red+"><a href="+JPEGPath+"><b><center>Fail</center></font></a></td>");
			 bufferedWriterindivScenario.write("<td border="+2+" width="+500+">"+description+"</td>");
			 bufferedWriterindivScenario.write("<td border="+2+" width="+200+">"+testData+"</td>");
			 bufferedWriterindivScenario.write("<td border="+2+" width="+250+">"+expected+"</td>");
			 bufferedWriterindivScenario.write("<td border="+2+" width="+250+"><font color="+red+">"+actual+"</td>");
			 bufferedWriterindivScenario.write("<td width="+200+"><font color="+black+">"+dateFormat.format(date)+"</font></td>");
			 bufferedWriterindivScenario.write("</tr>"); 
			 System.out.println("FAIL: "+description+"     "+dateFormat.format(date));
	        
		  }catch(Exception e)	{
			  
	    	System.out.println("Exception in Screenshot");
	    }
	  
	}
	
	public static void totalStatus() throws ParseException {
		// Modified by RAJ
		try {
			a = i + j;
			// Total Summary Report
			bufferedWriterindivScenario.write("</center></table>");
			bufferedWriterindivScenario.write("</table>");
			bufferedWriterindivScenario.write("<br>");
			bufferedWriterindivScenario.write("<center><table border=" + 5 + " width=" + 250 + ">");
			bufferedWriterindivScenario.write("<tr>" + "<th width=" + 250 + " bgcolor =" + green + "><center>PASS</center></th>"
							+ "<th width=" + 250 + " bgcolor=" + red + "><center>FAIL</center></th>" + "<th width="
							+ 250 + " bgcolor=" + Orange + "><center>Total Steps</center></th>" + "</tr>");
			bufferedWriterindivScenario.write("<tr>" + "<td width=" + 250 + "><font><center>" + i
					+ "</center></font></td>" + "<td width=" + 250 + "><font><center>" + j + "</center></font></td>"
					+ "<td width=" + 250 + "><font><center>" + a + "</center></font></td>" + "</tr>");
			bufferedWriterindivScenario.write("</table></center><br>");

			// Div panels
			bufferedWriterindivScenario.write("<form><fieldset><legend><b>Execution Summary</b></legend>");
			bufferedWriterindivScenario.write("<table cellspacing = '10' style='margin:0 auto;'><tr>");
			bufferedWriterindivScenario.write("<td><div style='background-color:#fff; width: 200px; height:100px;'><hr style='border-width: 0px;'>"
					+ "<p style='color:rgba(0,0,0,.87); font-family:Source Sans Pro, Arial; font-size:14px;'>Total Tests</p></br>"
					+ "<p align='right' style='color:rgba(0,0,0,.87); font-family:Source Sans Pro, Arial; font-size:14px;'>1</p>");

			bufferedWriterindivScenario.write("<td><div style='background-color:#fff; width: 200px; height:100px;'><hr style='border-width: 0px;'>"
					+ "<p style='color:rgba(0,0,0,.87); font-family:Source Sans Pro, Arial; font-size:14px;'>Total Steps</p></br>"
					+ "<p align='right' style='color:rgba(0,0,0,.87); font-family:Source Sans Pro, Arial; font-size:14px;'>" + a + "</p>");

			String endTime = Helper.getDateTime(0);
			String dateStart = startTime;
			String dateStop = endTime;

			// HH converts hour in 24 hours format (0-23), day calculation
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a");

			Date d1 = null;
			Date d2 = null;
			long diffSeconds = 0;
			long diffMinutes = 0;
			long diffHours = 0;
			long diffDays = 0;

			try {
				d1 = format.parse(dateStart);
				d2 = format.parse(dateStop);

				// in milliseconds
				long diff = d2.getTime() - d1.getTime();

				diffSeconds = diff / 1000 % 60;
				diffMinutes = diff / (60 * 1000) % 60;
				diffHours = diff / (60 * 60 * 1000) % 24;
				diffDays = diff / (24 * 60 * 60 * 1000);

			} catch (Exception e) {
				e.printStackTrace();
			}
			int days = (int) diffDays;
			int hours = (int) diffHours;
			int minutes = (int) diffMinutes;
			int seconds = (int) diffSeconds;

			String totalTime = String.format("%02d", days) + " Days," + String.format("%02d", hours) + ":"
					+ String.format("%02d", minutes) + ":" + String.format("%02d", seconds);
			
			bufferedWriterindivScenario.write("<td><div style='background-color:#fff; width: 200px; height:100px;'><hr style='border-width: 0px;'>"
							+ "<p style='color:rgba(0,0,0,.87); font-family:Source Sans Pro, Arial; font-size:14px;'>Total Time Taken (Overall)</p></br>"
							+ "<p align='right' style='color:rgba(0,0,0,.87); font-family:Source Sans Pro, Arial; font-size:14px;'>"
							+ totalTime + "</p>");
			
			bufferedWriterindivScenario.write("<td> <div style='background-color:#53d192; width: 200px; height:100px;'><hr style='border-width: 0px;'>"
					+ "<p style='color:white; font-family:Source Sans Pro, Arial; font-size:14px;'>Start</p></br>"
					+ "<p align='right' style='color:white; font-family:Source Sans Pro, Arial; font-size:14px;'>" + startTime + "</p>");
			
			bufferedWriterindivScenario.write("<td><div style='background-color:#f96868; width: 200px; height:100px;'><hr style='border-width: 0px;'>"
					+ "<p style='color:white; font-family:Source Sans Pro, Arial; font-size:14px;'>End</p></br>"
					+ "<p align='right' style='color:white; font-family:Source Sans Pro, Arial; font-size:14px;'>" + endTime + "</p>");

			bufferedWriterindivScenario.write("</table></fieldset></form>");	
			bufferedWriterindivScenario.write("</body></html>");
			bufferedWriterindivScenario.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void passSnapshot(String description, String testData, String expected, String actual) {
		 try{
			 
		  	  i=i+1;
		  	  ii=ii+1;		  	  
		  	  bufferedWriterindivScenario.write("<tr>");
		  	  bufferedWriterindivScenario.write("<td border="+2+" width="+50+"><font color="+black+"><b><center>"+ii+"</center></b></font></td>");
		  	  bufferedWriterindivScenario.write("<td border="+2+" width="+75+"><a href=\""+testData+".jpeg\"><font color="+green+"><b><center>Pass</center></b></font></td>");
		  	  bufferedWriterindivScenario.write("<td border="+2+" width="+500+">"+description+"</td>");
		  	  bufferedWriterindivScenario.write("<td border="+2+" width="+200+">"+testData+"</td>");
		  	  bufferedWriterindivScenario.write("<td border="+2+" width="+250+">"+expected+"</td>");
		  	  bufferedWriterindivScenario.write("<td border="+2+" width="+250+">"+actual+"</td>");		  	  
		  	  DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		  	  Date date = new Date();		  	  
		  	  bufferedWriterindivScenario.write("<td width="+200+"><font color="+black+">"+dateFormat.format(date)+"</font></td>");
		  	  bufferedWriterindivScenario.write("</tr>"); 		  	  
		  	  System.out.println("PASS: "+description+"     "+dateFormat.format(date));
		   
			 }catch(Exception e){
		    	
		    	System.out.println("Error: "+e);
		    }
		
	}	
}
