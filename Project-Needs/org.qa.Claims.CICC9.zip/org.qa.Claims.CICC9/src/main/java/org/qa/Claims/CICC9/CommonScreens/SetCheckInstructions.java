package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Technology.UtilityFunctions;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class SetCheckInstructions extends Object_Repositories {

	private WebDriver driver = null;

	String finishButton = "//a[@id='NormalCreateCheckWizard:Finish']";
	String invoiceNumber = "//input[contains(@id,'Check_InvoiceNumber-inputE')]";
	String invoiceDate = "//input[contains(@id,'Check_InvoiceDate-inputE')]";
	String alertOKButton = "//a[contains(@id,'button')]/span/span/span[2][text()='OK']";
	String warnClearButton = "//a[@id='WebMessageWorksheet:WebMessageWorksheetScreen:WebMessageWorksheet_ClearButton']";
	
	public SetCheckInstructions(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}

	public void SetCheckInstructionspage() throws Exception {
		
		Helper.highLightElement(driver, driver.findElement(By.xpath(finishButton)));
		UIMethods.clickbyxpath(finishButton, "click Finish button", "Click");
		Thread.sleep(3000);
		int i = 0;
		do {
			try {
				UIMethods.clickbyxpath(finishButton, "click Finish button", "Click");
				Thread.sleep(4000);
			} catch (Exception Ex) {
				Ex.printStackTrace();
			}
			i++;
		} while (i == 2 && wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(finishButton))));
	}

	public void SetCheckInstructionsWithAlert() throws Exception {
		
		clickOnFinishAndAcceptAlert();
		
		try {
			driver.findElement(By.xpath(finishButton)).isDisplayed();
			clickOnFinishAndAcceptAlert();
		} catch(Exception e) {
			
		}				
	}

	public void clickOnFinishAndAcceptAlert() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='NormalCreateCheckWizard:CheckWizard_CheckInstructionsScreen:ttlBar']")));
		UIMethods.inputbyxpath(invoiceNumber, "Enter Invoice Number", String.valueOf(Helper.generateRandomNum(10000, 99999)));
		UIMethods.inputbyxpath(invoiceDate, "Enter Invoice Date", Helper.getDate(0));
		
		if (driver.findElement(By.xpath(finishButton)).isDisplayed()) {
			// Click Finish Again
			try {
				UIMethods.jscriptclickbyxpath(finishButton, "Click Finish button from check instruction page", "Click");
				Thread.sleep(3000);
				
				// Handle OK button in Pop-up
				try {
					if (driver.findElements(By.xpath(alertOKButton)).size()!=0) {
						UIMethods.jscriptclickbyxpath(alertOKButton, "Click OK Button from alert", "Click");
						Thread.sleep(2000);
					}
				} catch (NoAlertPresentException Ex) {
					Ex.printStackTrace();
				}				
				
				// Handle warning message if appear, while clicking on Finish button
				if(driver.findElements(By.xpath(warnClearButton)).size()!=0) {
					for(int i=0;i<5;i++) {
						UIMethods.jscriptclickbyxpath(warnClearButton, "Click clear warning button", "Click");
						Thread.sleep(2000);
						try {
							driver.findElement(By.xpath(warnClearButton)).isDisplayed();
						} catch(Exception e) {
							break;
						}
					}
					
					// Click finish button after clearing warning message
					UIMethods.jscriptclickbyxpath(finishButton, "Click Finish button from check instruction page", "Click");
					Thread.sleep(3000);
				}
				
			} catch (Exception Ex) {
				Ex.printStackTrace();
			}
		}
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='ClaimFinancialsChecks:ClaimFinancialsChecksScreen:ttlBar']")));
		
	}
}