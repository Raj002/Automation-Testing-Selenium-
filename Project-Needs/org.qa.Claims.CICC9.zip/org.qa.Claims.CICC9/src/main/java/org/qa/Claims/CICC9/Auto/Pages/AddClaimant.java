package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class AddClaimant {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	//Page Objects
	String zipTextBox = "NewContactPopup:ContactDetailScreen:ContactBasicsDV:ClaimInputPrimaryAddressInputSet:ClaimInputAddressInputSet:Address_ZIP";
	String inputAddress1 = "NewContactPopup:ContactDetailScreen:ContactBasicsDV:ClaimInputPrimaryAddressInputSet:ClaimInputAddressInputSet:Address_AddressLine1";
	
	
	public AddClaimant(WebDriver driver)
	{
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}	
	
	public void AddClaimantpage(String excelFileName, String profileID) throws Exception{        
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtPersonLastName = xlsread.Exceldata(SheetName, "txtPersonLastName", profileID);
		String txtPersonFirstName = xlsread.Exceldata(SheetName, "txtPersonFirstName", profileID);
		String txtTaxID = xlsread.Exceldata(SheetName, "txtTaxID", profileID);
		String txtAddrZip = xlsread.Exceldata(SheetName, "txtAddrZip", profileID);
		String txtAddrState1 = xlsread.Exceldata(SheetName, "txtAddrState1", profileID);
		String txtAddrCity1 = xlsread.Exceldata(SheetName, "txtAddrCity1", profileID);
		String txtAddrLine1 = xlsread.Exceldata(SheetName, "txtAddrLine1", profileID);
		String txtClaimantType = xlsread.Exceldata(SheetName, "txtClaimantType", profileID);
		
		Thread.sleep(3000);
        //Add Claimant
        UIMethods.jscriptclickbyxpath("//*[@id='FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:Claimant_Picker:Claimant_PickerMenuIcon']", "Click Claimant_PickerMenuIcon", "Click");
        Thread.sleep(5000);
        UIMethods.jscriptclickbyxpath("//*[@id='FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:Claimant_Picker:ClaimNewContactPickerMenuItemSet:NewContactPickerMenuItemSet_NewPerson']", "Click NewContactPickerMenuItemSet_NewPerson", "Click");
        UIMethods.inputbyid("NewContactPopup:ContactDetailScreen:ContactBasicsDV:PersonNameInputSet:LastName", "Input LastName", txtPersonLastName);
        UIMethods.inputbyid("NewContactPopup:ContactDetailScreen:ContactBasicsDV:PersonNameInputSet:FirstName", "Input FirstName", txtPersonFirstName);
        UIMethods.inputbyid("NewContactPopup:ContactDetailScreen:ContactBasicsDV:AdditionalInfoInputSet:TaxID", "Input TaxID", txtTaxID);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(zipTextBox)));
        UIMethods.clickbyid(zipTextBox, "Click Address_ZIP", "Click");
        Helper.clearTextBox(driver, driver.findElement(By.id(zipTextBox)));
        UIMethods.inputbyid(zipTextBox, "Input Address_ZIP", txtAddrZip);
        UIMethods.inputbyid("NewContactPopup:ContactDetailScreen:ContactBasicsDV:ClaimInputPrimaryAddressInputSet:ClaimInputAddressInputSet:Address_State", "Input Address_State", txtAddrState1);
        UIMethods.inputbyid("NewContactPopup:ContactDetailScreen:ContactBasicsDV:ClaimInputPrimaryAddressInputSet:ClaimInputAddressInputSet:Address_City", "Input Address_City", txtAddrCity1);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(inputAddress1)));
        UIMethods.inputbyid(inputAddress1, "Input Address_AddressLine1", txtAddrLine1);
        UIMethods.clickbyid("NewContactPopup:ContactDetailScreen:ContactBasicsDV:PersonNameInputSet:FirstName", "Click FirstName", "Click");
        UIMethods.clickbyid("NewContactPopup:ContactDetailScreen:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:Update", "Click Update", "Click");
        UIMethods.selectbyid("FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:Claimant_Type", "Input Claimant_Type", txtClaimantType);
        Thread.sleep(5000);
        }
}