package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class NewEvaluation {

	private WebDriver driver = null;
	WebDriverWait wait;

	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	public NewEvaluation(WebDriver driver) {
		this.driver = driver;
	}

	public void NewEvaluationPage(String excelFileName, String profileID) throws Exception {		
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtEvaluationName = xlsread.Exceldata(SheetName, "txtEvaluationName", profileID);
		String ddlCategoryEvaluationType = xlsread.Exceldata(SheetName, "ddlCategoryEvaluationType", profileID);
		String ddlEvaluationRelatedTo = xlsread.Exceldata(SheetName, "ddlEvaluationRelatedTo", profileID);
		String txtInsuredLow = xlsread.Exceldata(SheetName, "txtInsuredLow", profileID);
		String txtInsuredHigh = xlsread.Exceldata(SheetName, "txtInsuredHigh", profileID);
		String txtInsuredTarget = xlsread.Exceldata(SheetName, "txtInsuredTarget", profileID);

		UIMethods.inputbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:EvaluationType", "Input Evaluation Name",txtEvaluationName);
		UIMethods.selectbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:SettlementCostEstimate_Name","input Evaluation Type", ddlCategoryEvaluationType);
		Thread.sleep(2000);
		UIMethods.selectbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:Note_RelatedTo","input Evaluation Related To", ddlEvaluationRelatedTo);
		Thread.sleep(3000);
		UIMethods.inputbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:LiabilityDistribution_InsuredLiability","input Insured Low", txtInsuredLow);
		Thread.sleep(1000);
		UIMethods.inputbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:LiabilityDistribution_InsuredLiabilityTo","input Insured High", txtInsuredHigh);
		Thread.sleep(1000);
		UIMethods.inputbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:LiabilityDistribution_InsuredLiabilityTarget","input Insured Target", txtInsuredTarget);
		UIMethods.clickbyid("NewEvaluation:NewEvaluationScreen:NewEvaluationDV:instructions_false","Click Special Service Instrutions", "Click");
		Thread.sleep(2000);
		UIMethods.clickbyxpath("//span[text()='pdate']", "click Update button", "Click");
		Thread.sleep(3000);
	}

	public void VerifyNotesInEvaluationPage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String lblNoteSubject = xlsread.Exceldata(SheetName, "lblNoteSubject", profileID);
		String lblNoteText = xlsread.Exceldata(SheetName, "lblNoteText", profileID);

		String lblSubjectActual = driver.findElement(By.id("ClaimEvaluations:ClaimEvaluationsScreen:NotesLV:0:Subject")).getText();
		if (lblNoteSubject.equalsIgnoreCase(lblSubjectActual)) {
			Report.pass("Verify Text", "Notes Subject", lblNoteSubject + " should available in Note Section",lblSubjectActual + " is exist in Note Section");
		} else {
			Report.fail("Verify Text", "Notes Subject", lblNoteSubject + " should available in Note Section",lblSubjectActual + " is not same as in Note Section");
		}
		// Verify Note Text
		String lblBodyTextActual = driver.findElement(By.id("ClaimEvaluations:ClaimEvaluationsScreen:NotesLV:0:Body")).getText();
		if (lblNoteText.equalsIgnoreCase(lblBodyTextActual)) {
			Report.pass("Verify Text", "Notes Body Text", lblNoteText + " should available in Text Section",lblBodyTextActual + " is exist in Note Text");
		} else {
			Report.fail("Verify Text", "Notes Body Text", lblNoteText + " should available in Text Section",lblBodyTextActual + " is not same as in Note Text");
		}
	}
}