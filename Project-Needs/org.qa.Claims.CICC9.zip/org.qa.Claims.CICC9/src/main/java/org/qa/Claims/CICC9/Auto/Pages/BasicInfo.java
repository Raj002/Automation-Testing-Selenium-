package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.CommonScreens.NewPersonContactDetail;
import org.qa.Claims.CICC9.CommonScreens.SearchAddressBook;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class BasicInfo extends Object_Repositories{
	
	private WebDriver driver=null;
	
	//Page Objects
	String howReportedField = "//input[contains(@id,'HowReported-inputEl')]";
	String arrowButton = "//a[contains(@id,'ReportedBy_NameMenuIcon')]/img";
	String searchOption = "//span[contains(@id,'MenuItem_Search-textEl') and text()='Search']";
	String reportName = "//input[contains(@id,'ReportedBy_Name-inputEl')]";
	String relationinsured = "//input[contains(@id,'Claim_ReportedByType-inputEl')]";
	String warCloseButton = "//a[@id='NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:NewClaimDuplicatesWorksheet_CloseButton']";
	String vehicleName = "(//div[contains(@id,'InsuredVehicleInputGroup-legendTitle')])[1]";
	
	public BasicInfo(WebDriver driver)
	{
		this.driver = driver;
		wait = new WebDriverWait(driver, 15);
	}	
	
	public void BasicInformationSearch(String excelFileName, String profileID) throws Exception {
		
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlHowReported = xlsread.Exceldata(SheetName, "txtHowReported", profileID);
		String nameOptions = xlsread.Exceldata(SheetName, "ddlnameOption", profileID);		
		String ddlReportName = xlsread.Exceldata(SheetName, "ddlReportName", profileID);
		String ddlRelationInsured = xlsread.Exceldata(SheetName, "ddlRelationInsured", profileID);
		
		if(driver.findElements(By.xpath(howReportedField)).size()!=0) {
			UIMethods.clearAndinputbyxpath(howReportedField, "Select how reported", ddlHowReported);
		}		
	   
		switch (nameOptions.toLowerCase()) {
		case "new person":
			UIMethods.clickbyxpath(arrowButton, "Click arrow Button", "Click");			
			UIMethods.jscriptclickbyxpath(newPersonOption, "Click New Person Option", "Click");
			NewPersonContactDetail  newperson  = new NewPersonContactDetail(driver);
			newperson.NewPersonContactDetailpage(excelFileName, profileID);
			break;
		case "search":
			UIMethods.clickbyxpath(arrowButton, "Click arrow Button", "Click");
			UIMethods.jscriptclickbyxpath(searchOption, "Click Search Option", "Click");
			SearchAddressBook addressBook = new SearchAddressBook(driver);
			addressBook.SearchCreatePolicyPage(excelFileName, profileID);
			break;
		default:
			 UIMethods.clearAndinputbyxpath(reportName, "Select Report Name", ddlReportName);
			break;
		}
		
		UIMethods.clearAndinputbyxpath(relationinsured, "Select Relatioin insured", ddlRelationInsured);
		
		if(driver.findElements(By.xpath(vehicleName)).size()!=0) {
			String autolVehicleName = driver.findElement(By.xpath(vehicleName)).getText();
			String actualVehicleName = autolVehicleName.trim();
			xlsread.WriteIntoExistingExcel(SheetName, "propertyName", actualVehicleName, profileID, true);
		}		
		
		UIMethods.jscriptclickbyxpath(nextButton, "Click Next button", "Click");
		Thread.sleep(2000);
		
		if (driver.findElements(By.xpath("//span[contains(text(), ': Basic information')]/parent::div")).size()!=0) {
			for (int intLoop = 1; intLoop <= 7; intLoop++) {
				UIMethods.jscriptclickbyxpath(nextButton, "Click Next button from basic info sreen", "Click");
				
				// Validating warning messages
	        	if(driver.findElements(By.xpath(warCloseButton)).size()> 0){
	        		UIMethods.jscriptclickbyxpath(warCloseButton, "Click Close Option", "Click");
	        		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(nextButton)));
	            }
	        	
	        	try {
	        		driver.findElement(By.xpath("//span[contains(text(), ': Basic information')]/parent::div")).isDisplayed();
	        	} catch (Exception Ex) {
	        		break;
	        	}
			}
		}	
		
		
	}
}