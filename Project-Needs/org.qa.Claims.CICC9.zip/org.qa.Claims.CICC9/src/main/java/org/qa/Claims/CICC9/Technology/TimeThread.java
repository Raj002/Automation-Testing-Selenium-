package org.qa.Claims.CICC9.Technology;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;

import org.apache.log4j.Logger;

public class TimeThread extends Thread {

	/**
	 * Thread class for setting a wait time for database and poll the same to
	 * get an update reflected in the database
	 * 
	 */

	public static final Logger LOG = Logger.getLogger(TimeThread.class);

	@SuppressWarnings("unused")
	private Timestamp t1;
	private java.util.Date date;
	private int interval;
	private static TimeThread timeThread = null;

	private TimeThread(int interval) {
		date = new java.util.Date();
		t1 = new Timestamp(date.getTime());
		this.interval = interval;

	}

	public static TimeThread createThreadObject(int timeInterval) {

		if (timeThread == null) {
			timeThread = new TimeThread(timeInterval);
			timeThread.interrupt();
			return timeThread;
		} else {
			timeThread.interrupt();
			return timeThread;
		}
	}

	public void run() {

		LOG.info("***********************Waiting for database to be udpated********************");

		Instant start = Instant.now();

		do {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				LOG.error("TimeThread : Exception : " + e.getMessage());
			}
			Instant end = Instant.now();
			Duration timeElapsed = Duration.between(start, end);
			timeElapsed = Duration.parse(interval + "");
			LOG.info("timeElapsed" + timeElapsed);

			if (timeElapsed.equals(Duration.parse(interval + ""))) {
				break;
			}

			LOG.info("Time taken: " + timeElapsed.toMillis() + " milliseconds");
		} while (true);
		interrupt();

	}

}
