package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class LossAddress {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	String SheetName = "ClaimsPolicy";

	String addressLine1 = "//input[@id='FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:AddressLine1-inputEl']";
	String addressCity = "//input[@id='FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:City-inputEl']";
	String addressZip = "//input[@id='FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:PostalCode-inputEl']";
	
	public LossAddress(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 15);
	}
	
	public void LossAddressPage(String excelFileName, String profileID) throws Exception {		
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtZipCode = xlsread.Exceldata(SheetName, "txtZipCode", profileID);
		String txtAddressCity = xlsread.Exceldata(SheetName, "txtAddressCity", profileID);
		String txtAdressLine = xlsread.Exceldata(SheetName, "txtAdressLine", profileID);
		
		UIMethods.inputbyxpath(addressLine1, "Enter Address line 1", txtAdressLine);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(addressCity)));
		UIMethods.inputbyxpath(addressCity, "Enter Address City", txtAddressCity);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(addressZip)));
		UIMethods.inputbyxpath(addressZip, "Enter Address Zip code", txtZipCode);		
      }
}