package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Property.Pages.NewPropertyIncident;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;
import org.testng.Assert;

public class AddClaimInfo extends Object_Repositories {
	
	public WebDriver driver;
	
	//Page Objects
	String lossDesctiption = "//textarea[contains(@id,'DV:Description-inputE')]";
	String inputLossCause = "//input[contains(@id,'Claim_LossCause-inputEl')]";
	String detailedLossCause = "//input[contains(@id,'DetailedLossCause-inputEl')]";
	String severityDropDown = "//input[contains(@id,'Severity-inputEl')]";
	String addressLine = "//input[contains(@id,'AddressLine1-inputEl')]";
	String addressCity = "//input[contains(@id,'GlobalAddressInputSet:City-inputEl')]";
	String addressState = "//input[contains(@id,'GlobalAddressInputSet:State-inputEl')]";
	String zipCode = "//input[contains(@id,'GlobalAddressInputSet:PostalCode-inputEl')]";
	String deductibleNoOption = "//input[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:CategorizationDV:Deductible_Applies_false-inputEl']";
	String heavyEquipment = "//input[contains(@id,'HeavyEquipmentIndicator_false-inputEl')]";
	String howReported = "//input[contains(@id,'Notification_HowReported-inputEl')]";
	String onPromises = "//input[contains(@id,'OnPremises_false-inputEl')]";
	String weatherCondition = "//input[contains(@id,'Claim_Weather-inputEl')]";
	String underlyingCoverage = "//input[@id='FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:UnderlyingCovEXT-inputEl']";
	
	public AddClaimInfo(WebDriver driver)
	{
		this.driver = driver;
		wait = new WebDriverWait(driver, 25);
	}	
	
	public void AddClaimInfoPage(String excelFileName, String profileID) throws Exception {
		
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		
		String txtLossDescription = xlsread.Exceldata(SheetName, "txtLossDescription", profileID);
		String txtLossCause = xlsread.Exceldata(SheetName, "txtLossCause", profileID);
		String txtDetailedLossCause = xlsread.Exceldata(SheetName, "txtDetailedLossCause", profileID);
		String txtAdressLine = xlsread.Exceldata(SheetName, "txtAdressLine", profileID);
		String txtAddressCity = xlsread.Exceldata(SheetName, "txtAddressCity", profileID);
		String txtAddressState = xlsread.Exceldata(SheetName, "txtAddressState", profileID);
		String txtZipCode = xlsread.Exceldata(SheetName, "txtZipCode", profileID);
		String btnAddVehicleClaim = xlsread.Exceldata(SheetName, "btnAddVehicleClaim", profileID);
		String txtHowReported = xlsread.Exceldata(SheetName, "txtHowReported", profileID);		
		
		UIMethods.inputbyxpath(lossDesctiption, "Input loss Description", txtLossDescription);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(inputLossCause)));
		Helper.selectDropdownValue(driver, "xpath", inputLossCause, "Select loss cause", txtLossCause);
		
		driver.findElement(By.xpath(addressLine)).click();
		Thread.sleep(1000);
		
		// Validating selected Loss cause value
		if(!Helper.getAttributeValue(driver, "xpath", inputLossCause).equals(txtLossCause)) {
			Assert.fail("Failed to select loss cause value/Drop down option may not be available..");
		}
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(detailedLossCause)));		
	    Helper.selectDropdownValue(driver, "xpath", detailedLossCause, "Select detailed loss cause", txtDetailedLossCause);	    
	    
		// Validating selected detailed Loss cause value
		if (!Helper.getAttributeValue(driver, "xpath", detailedLossCause).equals(txtDetailedLossCause)) {
			Assert.fail("Failed to select detailed loss cause value/Drop down option may not be available..");
		}
	 	
		driver.findElement(By.xpath(lossDesctiption)).click();
		// Select if Severity Drop down appears
		if(driver.findElements(By.xpath(severityDropDown)).size()!=0) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(severityDropDown)));
			Helper.selectDropdownValue(driver, "xpath", severityDropDown, "Select Severity", "Minor");
		}
		
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath(addressLine)));
		UIMethods.inputbyxpath(addressLine, "Enter Address Line", txtAdressLine);
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(addressCity)));
		UIMethods.inputbyxpath(addressCity, "Enter Address City", txtAddressCity);
		
		Helper.waitForLoad(driver);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(addressState)));
		Helper.selectDropdownValue(driver, "xpath", addressState, "Select Address state", txtAddressState);		
		driver.findElement(By.xpath(addressLine)).click();
	
		Helper.waitForLoad(driver);
		Thread.sleep(4000);
		UIMethods.clearAndinputbyxpath(zipCode, "Enter Zip code", txtZipCode);
		driver.findElement(By.xpath(addressLine)).click();
	    
	    if(driver.findElements(By.xpath(deductibleNoOption)).size()!=0) {
	    	Helper.selectDropdownValue(driver, "xpath", weatherCondition, "Select Weather Condition", "Clear");
	    	Thread.sleep(500);
	    	UIMethods.jscriptclickbyxpath(deductibleNoOption, "Click Deductible Applies on Physical Damage Radio button", "Click");
	    }	
	    
	    if(driver.findElements(By.xpath(heavyEquipment)).size()!=0) {
	    	UIMethods.jscriptclickbyxpath(heavyEquipment, "Select Heavy equipment radio button", "Click");
	    }
	    
	    if(driver.findElements(By.xpath(howReported)).size()!=0) {	
	    	Helper.waitForLoad(driver);
	    	wait.until(ExpectedConditions.elementToBeClickable(By.xpath(howReported)));
	    	Thread.sleep(2000);
			Helper.selectDropdownValue(driver, "xpath", howReported, "Select How reported", txtHowReported);
	    }
	    
	    // What was the underlying Coverage field will appear only in General Liability Umbrella policy type
	    if(driver.findElements(By.xpath(underlyingCoverage)).size()!=0) {
	    	Helper.waitForLoad(driver);
	    	Helper.selectDropdownValue(driver, "xpath", underlyingCoverage, "Select What was Underlying Coverage", "Employer's Liability");
	    }
	    
	    if(driver.findElements(By.xpath(onPromises)).size()!=0) {
	    	UIMethods.clickbyxpath(onPromises, "Select on Promises radio button", "Click");
	    }
	     
	    if (!(btnAddVehicleClaim.isEmpty())) {
			   UIMethods.jscriptclickbyxpath("//a[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:AddVehicleButton']/span/span", "Click Add Vehicle Button", "Click");
	           Thread.sleep(2000);
		}
	    
	    driver.findElement(By.xpath(lossDesctiption)).click();
		UIMethods.clickbyxpath(nextButton, "Click Add Claim Info Next button", "Click");
		Helper.waitForLoad(driver);
		Thread.sleep(4000);
		
		// Validating error message for property address details
		if(driver.findElements(By.xpath("//div[@class='message']")).size()!=0) {			
			String errorMessage = driver.findElement(By.xpath("//div[@class='message']")).getText();
			if(errorMessage.contains("One or more of the Property Incidents contain required fields that have not been answered")) {
				if(driver.findElements(By.xpath("//a[contains(@id,'Address1')]")).size()!=0) {					
					// Writing property name from Loss details screen to enter property name in Exposure screen
					String propertyName = driver.findElement(By.xpath("//a[contains(@id,'Address1')]")).getText();
					xlsread.WriteIntoExistingExcel(SheetName, "propertyName", propertyName.trim(), profileID, true);
					
					UIMethods.clickbyxpath("//a[contains(@id,'Address1')]", "Click Address link", "Click");
					NewPropertyIncident propertyincident = new NewPropertyIncident(driver);
					propertyincident.PropertyLiabilityIncidentPage(excelFileName, profileID);	
					UIMethods.clickbyxpath(nextButton, "Click Add Claim Info Next button", "Click");
				}
			}			
		}			
	}

	public void AddClaimInfoEditVehicleLink() throws Exception {
		Thread.sleep(2000);
		UIMethods.jscriptclickbyxpath("//a[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:VehicleIncidentIterator:0:VehicleIncidentDV:VehicleName:VehicleNameMenuIcon']","Click Arrow Button", "Click");
		Thread.sleep(500);
		UIMethods.jscriptclickbyxpath("//a[@id='FNOLWizard:AutoWorkersCompWizardStepSet:FNOLWizard_NewLossDetailsScreen:VehicleIncidentIterator:0:VehicleIncidentDV:VehicleName:EditVehicleMenu']","Click Edit Vehicle", "Click");
		Thread.sleep(5000);
	}
}