package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.CommonScreens.NewPersonContactDetail;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class NewVehicleIncident extends Object_Repositories {

	public WebDriver driver;
	
	// Page Objects
	String selectVehicle = "NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:Vehicle_Picker-inputEl";
	String lossParty = "NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:LossParty-inputEl";
	String vehicleType = "NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:Vehicle_VehicleType-inputEl";
	String vehicleYear = "//input[@id='NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:Vehicle_Year-inputEl']";
	String vehicleMake = "NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:Vehicle_Make-inputEl";
	String vehicleModel = "NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:Vehicle_Model-inputEl";
	String vinTextBox = "NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:Vehicle_VIN-inputEl";
	String validateVINButton = "//a[contains(@id,'Vehicle_Vin_Validation_EXT')]";
	String driverName = "NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:Driver_Picker-inputEl";
	String relatioToOwner = "NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:RelationToInsured-inputEl";
	String frontCheckBox = "//input[@id='NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:DamDescFront_EXT-inputEl']";
	String rentalCarOption = "//input[@id='NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:RentalRequired_false-inputEl']";

	public NewVehicleIncident(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 15);
	}

	public void NewVehicleDetailsInputpage(String excelFileName, String profileID) throws Exception {

		NewPersonContactDetail newperson = new NewPersonContactDetail(driver);

		xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlSelectVehicle = xlsread.Exceldata(SheetName, "ddlSelectVehicle", profileID);
		String ddlLossParty = xlsread.Exceldata(SheetName, "ddlLossParty", profileID);
		String ddlVehicleType = xlsread.Exceldata(SheetName, "ddlVehicleType", profileID);
		String vehicleyear = xlsread.Exceldata(SheetName, "txtVehicleYear", profileID);
		String vehiclemake = xlsread.Exceldata(SheetName, "txtVehicleMake", profileID);
		String vehiclemodel = xlsread.Exceldata(SheetName, "txtVehicleModel", profileID);
		String vehicleVin = xlsread.Exceldata(SheetName, "txtVehicleVin", profileID);
		String ddlRelationToOwner = xlsread.Exceldata(SheetName, "ddlRelationToOwner", profileID);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(returnToExposureLink)));
		Helper.selectDropdownValue(driver, "id", selectVehicle, "Select Vehicle", ddlSelectVehicle);
		Helper.waitForLoad(driver);		
		Helper.clickCheckBox(frontCheckBox, "click Front checkbox");		
		driver.findElement(By.xpath("//label[text()='Involved Vehicle']")).click();		
		Thread.sleep(4000);
		Helper.selectDropdownValue(driver, "id", lossParty, "Select Loss Party", ddlLossParty);
		Helper.waitForLoad(driver);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(vehicleYear)));
		driver.findElement(By.xpath(vehicleYear)).click();
		Thread.sleep(1000);
		
		Helper.selectDropdownValue(driver, "id", vehicleType, "Select Vehicle Type", ddlVehicleType);
		driver.findElement(By.id(vehicleModel)).click();
		Thread.sleep(2000);
		UIMethods.inputbyxpath(vehicleYear, "Enter vehicle year", vehicleyear);
		Thread.sleep(1000);
		UIMethods.inputbyid(vehicleMake, "Enter vehicle make", vehiclemake);
		Thread.sleep(1000);
		UIMethods.inputbyid(vehicleModel, "Enter vehicle model", vehiclemodel);

		/*// To Validate VIN
		if (driver.findElements(By.xpath(validateVINButton)).size() != 0) {
			wait.until(ExpectedConditions.elementToBeClickable(By.id(vinTextBox)));
			Thread.sleep(3000);
			driver.findElement(By.id(vinTextBox)).sendKeys("KMHDN56D65U132685");
			//UIMethods.inputbyid(vinTextBox, "Enter vehicle VIN", "KMHDN56D65U132685");
			UIMethods.clickbyxpath(validateVINButton, "Click Validate VIN button", "Click");
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@id,'loadmask-')]")));
		}*/

		driver.findElement(By.xpath("//input[contains(@id,'Driver_Picker-inputEl')]")).click();
		Thread.sleep(500);
		if(driver.findElements(By.xpath(firstDropdownOption)).size()!=0) {
			driver.findElement(By.xpath(firstDropdownOption)).click();
			Thread.sleep(500);
		} else {
			UIMethods.jscriptclickbyxpath("//a[contains(@id,'Driver_PickerMenuIcon')]/img", "Click Driver Name arrow icon", "Click");
			Thread.sleep(2000);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@id,'ClaimNewPersonOnlyPickerMenuItemSet_NewPersonMenuItem')]/a/span[text()='New Person']")));	
			UIMethods.jscriptclickbyxpath("//div[contains(@id,'ClaimNewPersonOnlyPickerMenuItemSet_NewPersonMenuItem')]/a/span[text()='New Person']", "Click New Person", "Click");
			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewContactPopup:ContactDetailScreen:ttlBar")));
			newperson.NewPersonContactDetailpage(excelFileName, profileID);
		}	

		Helper.selectDropdownValue(driver, "id", relatioToOwner, "Select Relation to owner", ddlRelationToOwner);
		
		UIMethods.jscriptclickbyxpath("//*[@id='NewVehicleIncidentPopup:NewVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:VehicleParked_true']","click Vehicle Parked", "Click");
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(rentalCarOption)));
		UIMethods.jscriptclickbyxpath(rentalCarOption, "click Rental Car", "Click");
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(okButton)));
		UIMethods.jscriptclickbyxpath(okButton, "click OK button", "Click");
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(returnToExposureLink)));
	}
}