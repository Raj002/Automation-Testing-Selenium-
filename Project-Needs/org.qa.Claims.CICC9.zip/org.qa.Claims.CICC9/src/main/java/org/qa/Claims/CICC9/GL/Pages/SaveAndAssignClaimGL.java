package org.qa.Claims.CICC9.GL.Pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class SaveAndAssignClaimGL {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	public SaveAndAssignClaimGL(WebDriver driver)
	{
		this.driver = driver;
	}	
	
	public void SaveAndAssignClaimGlPage(String excelFileName, String profileID) throws Exception {
		String SheetName = "ClaimsPolicy";
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlAssignClaim = xlsread.Exceldata(SheetName, "ddlAssignClaim", profileID);
		String btnSaveAssignFinish = xlsread.Exceldata(SheetName, "btnSaveAssignFinish", profileID);
		Thread.sleep(3000);
		UIMethods.selectbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_AssignScreen:NewClaimWizard_AssignDV:CommonAssign", "input assign claims all exposure to", ddlAssignClaim);
							
		Thread.sleep(3000);
        if (!(btnSaveAssignFinish.isEmpty())) {
        	Helper.highLightElement(driver, driver.findElement(By.xpath("//*[@id='FNOLWizard:Finish']")));
        	UIMethods.jscriptclickbyxpath("//*[@id='FNOLWizard:Finish']", "click finish button", "Click");
        	Thread.sleep(3000);
        }
        
		// Validate error message if exists on the screen
		// Added by RAJ
		if (driver.findElements(By.xpath("//span[@id='FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_AssignScreen:_msgs_msgs']/div")).size() != 0) {
			String errorMessage = driver.findElement(By.xpath("//span[@id='FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_AssignScreen:_msgs_msgs']/div")).getText();
			Report.fail("Validate Search Result", "Validation", "Search Result", "Service Down : " + errorMessage);
			Report.totalStatus();
			Report.reportPreparation();
			Report.reportCompletion();
			Assert.fail("Service Down : " + errorMessage);
		}
	}
	
	public void SaveAndAssignClaimGlFinish() throws Exception {
		UIMethods.clickbyid("FNOLWizard:Finish", "click finish button", "Click");
		Thread.sleep(3000);
	}
}