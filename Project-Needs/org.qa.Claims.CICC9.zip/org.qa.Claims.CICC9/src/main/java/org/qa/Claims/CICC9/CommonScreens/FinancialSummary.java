package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.testng.Assert;

public class FinancialSummary {
	
	WebDriver driver;
	WebDriverWait wait;
	
	String arrowIcon = "//img[contains(@id,'ClaimFinancialsSummary:ClaimFinancialsSummaryScreen:financialsPanel:FinancialsSummaryPanelSet')]";
	String quickCheckOption = "//span[contains(@id,'QuickMenu_QuickCheck-textEl') and text()='Quick Check']";
	String createCheckOption = "//span[contains(@id,'QuickMenu_CreateCheck-textEl') and text()='Create Check']";
	
	
	public FinancialSummary(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 15);
	}
	
	public void FinancialSummaryPage() throws Exception {
		Helper.clickClaimSubMenu(driver, "financials");	
		
		if(driver.findElement(By.xpath(arrowIcon))!=null) {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(arrowIcon)));
			UIMethods.jscriptclickbyxpath(arrowIcon, "Click arrow icon", "Click");
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(quickCheckOption)));
			UIMethods.jscriptclickbyxpath(quickCheckOption, "Click Quick Check option", "Click");
		} else {
			Assert.fail("Seems the Exposure isn't created properly..");
		}		
	}
}