package org.qa.Claims.CICC9.Technology;

public class BDDConstants {
	
	
	/***********************************************************************************************************
	 * Constants for the class CustomisedExceptions.java
	 ***********************************************************************************************************/
	public  final String ERRORINDBCONNECTIONFRAMEWORK = "Error in DB Connection Framework : ";
	public  final String QUERYNOTFOUNDEXCEPTION = "Database Query could not be found.";
	public  final String DBCONNECTIONPROPERTYFILENOTFOUND = "Database Conenction Property file could not be found.";
	public  final String DBDRIVERCLASSNOTFOUND = "Database Driver Class could not be found.";
	public  final String DBCONNECTIONNOTCREATED = "Database Connection could not be created.";
	public  final String ILLEGALACCESS = "Illegal Access attempt probably due to Wrong Credentials";
	public  final String INSTANTIAIONERROR = "Failed to create new instance of the class";
	public  final String NULLRESULTSET = "Result set doesn't return any value";
	
	
	
	/***********************************************************************************************************
	 * Constants for the class FetchPropertiesFiles.java 
	 ***********************************************************************************************************/
	
	public String BORDER="############################################################################################";
	public String EXESTARTS="********************************Execution Starts********************************************";
	public String ENVSTRING= "ENVIRONMENT : ";
	public String SCHEMASTRING= "DATABASE SCHEMA : ";
	public String SCHEMACFGSTRING= "DATABASE SCHEMA : ";
	public String JDBCSTRING= "DATABASE JDBC URL : ";
	public String SOAPSTRING="SOAP ENDPOINT : ";
	public String RESTSTRING ="REST ENDPOINT : ";
	public String FTPHOSTNAMESTRING="FTP HOSTNAME : ";
	
	//List of Environment
	public String TEST="Test";
	public String STAGE="Stage";
	public String DEV="Dev";
	
	public String environment="ENVIRONMENT";
	
	//Properties filename
	public String envProperties="environment.properties";
	public String dbProperties="DBconnection.properties";
	public String queryStringProperties="QueryString.properties";
	public String serverConnectionProperties="serverConnection.properties";
	public String seleniumObjects="SeleniumObjects.properties";
	
	//DBConnection properties variables
	public String testschemaName="TESTSCHEMANAME";
	public String devschemaName="DEVSCHEMANAME";
	public String stageschemaName="STAGESCHEMANAME";

	
	public String testCfgschemaName="TESTCFGSCHEMANAME";
	public String devCfgschemaName="DEVCFGSCHEMANAME";
	public String stageCfgschemaName="STAGECFGSCHEMANAME";

	
	public String testJdbcURL = "TESTjdbcURL";
	public String testUserName = "TESTdbUser";
	public String testPassword = "TESTdbPwd";
	
	public String stageJdbcURL = "STAGEjdbcURL";
	public String stageUserName = "STAGEdbUser";
	public String stagePassword = "STAGEdbPwd";
	
	public String devJdbcURL = "DEVjdbcURL";
	public String devUserName = "DEVdbUser";
	public String devPassword = "DEVdbPwd";
	
	public String int2JdbcURL = "INT2jdbcURL";
	public String int2UserName = "INT2dbUser";
	public String int2Password = "INT2dbPwd";
	
	public String rlseJdbcURL = "RLSEjdbcURL";
	public String rlseUserName = "RLSEdbUser";
	public String rlsePassword = "RLSEdbPwd";
	
	
	//Server connection properties variables
	public String syssoapUrl="SYSSOAPURL";
	public String sysrestUrl="SYSRESTURL";
	public String sys2soapUrl="SYS2SOAPURL";
	public String sys2restUrl="SYS2RESTURL";
	public String int2soapUrl="INT2SOAPURL";
	public String int2restUrl="INT2RESTURL";
	public String intsoapUrl="INTSOAPURL";
	public String intrestUrl="INTRESTURL";
	public String rlsesoapUrl="RLSESOAPURL";
	public String rlserestUrl="RLSERESTURL";
	
	public String ftpSYSHostName="SYSHOSTNAME";
	public String ftpSYSUserName="SYSUSERNAME";
	public String ftpSYSPassWord="SYSPASSWORD";
	
	public String ftpSYS2HostName="SYS2HOSTNAME";
	public String ftpSYS2UserName="SYS2USERNAME";
	public String ftpSYS2PassWord="SYS2PASSWORD";
	
	public String ftpINTHostName="INTHOSTNAME";
	public String ftpINTUserName="INTUSERNAME";
	public String ftpINTPassWord="INTPASSWORD";
	
	public String ftpINT2HostName="INT2HOSTNAME";
	public String ftpINT2UserName="INT2USERNAME";
	public String ftpINT2PassWord="INT2PASSWORD";
	
	public String ftpRLSEHostName="RLSEHOSTNAME";
	public String ftpRLSEUserName="RLSEUSERNAME";
	public String ftpRLSEPassWord="RLSEPASSWORD";
	
	public String int2esbIP = "INT2ESBIP";
	public String int2coreIP = "INT2COREIP";

	public String sys2esbIP = "SYS2ESBIP";
	public String sys2coreIP = "SYS2COREIP";
	
	public String intesbIP = "INT2ESBIP";
	public String intcoreIP = "INT2COREIP";

	public String sysesbIP = "SYSESBIP";
	public String syscoreIP = "SYSCOREIP";
	
	public String rlseesbIP = "RLSEESBIP";
	public String rlsecoreIP = "RLSECOREIP";

	public String pvsesbIP = "PVSESBIP";
	public String pvscoreIP = "PVSCOREIP";
	
	/***********************************************************************************************************
	 * Constants for the class ConnectionFramework.java
	 ***********************************************************************************************************/
	public String driver = "com.ibm.db2.jcc.DB2Driver";
	public String reqMsgPath = "src/test/resources/input/queries/";	
	public String querySTR	= "QueryString.properties";
	public String schemaNAME = "<schemaName>";
	public String cfgschemaNAME = "<schemaNameCFG>";
	
	/***********************************************************************************************************
	 * Constants for the class WebServices.java
	 ***********************************************************************************************************/
	
	public static String contentType  = "Content-Type";	
	public static String textXml = "text/xml";
	public static String applicationXml = "application/soap+xml;charset=UTF-8";
	public static String applicationRestXml = "application/xml";

	
}