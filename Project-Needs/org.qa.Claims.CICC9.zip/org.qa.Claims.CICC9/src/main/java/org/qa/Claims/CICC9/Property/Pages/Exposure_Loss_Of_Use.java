package org.qa.Claims.CICC9.Property.Pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.CommonScreens.NewExposureEntry;
import org.qa.Claims.CICC9.CommonScreens.NewPersonContactDetail;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class Exposure_Loss_Of_Use extends Object_Repositories {
	public WebDriver driver;

	// Page Objects
	String locationDropdown = "//input[contains(@id,'Address_Picker-inputEl')]";
	String locationCity = "//input[contains(@id,'City-inputEl')]";
	String locationState = "//input[@id='NewClaimWizard_NewExposurePopup:NewClaimWizard_ExposurePageScreen:NewClaimExposureDV:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:State-inputEl']";
	String locationZipCode = "//input[contains(@id,'PostalCode-inputEl')]";
	String addressLine1 = "//input[contains(@id,'AddressLine1-inputEl')]";
	String severityField = "//input[contains(@id,'Damage_Severity-inputEl')]";

	public Exposure_Loss_Of_Use(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}

	public void validateAndEnterLossOfUseExposure(String excelFileName, String profileID) throws Exception {
		NewPersonContactDetail newperson = new NewPersonContactDetail(driver);
		NewPropertyIncident newProperty = new NewPropertyIncident(driver);

		xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String expectedCoverageType = xlsread.Exceldata(SheetName, "CoverageType", profileID);
		String expectedCoverageSubType = xlsread.Exceldata(SheetName, "Coverage Subtype", profileID);
		String txtclaimantType = xlsread.Exceldata(SheetName, "txtClaimantType", profileID);
		String claimantNameOption = xlsread.Exceldata(SheetName, "claimantNameOption", profileID);
		String claimantNameVendorOption = xlsread.Exceldata(SheetName, "newVendorOptions", profileID);
		String claimantNameLegalOption = xlsread.Exceldata(SheetName, "newVendorOptions", profileID);
		String modeOfExposure = xlsread.Exceldata(SheetName, "ExposureMode", profileID);
		String lobType = xlsread.Exceldata(SheetName, "LOBType", profileID);
		
		String location_City = xlsread.Exceldata(SheetName, "locationCity", profileID);
		String location_State = xlsread.Exceldata(SheetName, "locationState", profileID);
		String location_Zip_Code = xlsread.Exceldata(SheetName, "locationZipCode", profileID);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newExposureTitle)));

		if (driver.findElements(By.xpath(primaryCoverage)).size() != 0) {
			String actualPrimaryCoverage = driver.findElement(By.xpath(primaryCoverage)).getText();
			Assert.assertEquals(actualPrimaryCoverage, expectedCoverageType);
		}

		if (driver.findElements(By.xpath(coverageSubType)).size() != 0) {
			String actualCoverageSubType = driver.findElement(By.xpath(coverageSubType)).getText();
			
			// This will remove the extra white spaces between the sentences
			if (actualCoverageSubType.contains("'") | expectedCoverageSubType.contains("'")) {
				String actual = actualCoverageSubType.replace(" ", "");
				String expected = expectedCoverageSubType.replace(" ", "");
				Assert.assertTrue(actual.contains(expected));
			} else {
				Assert.assertEquals(actualCoverageSubType, expectedCoverageSubType);
			}
		}

		UIMethods.jscriptclickbyxpath(riskUnit, "Select Coverage / Risk unit", "Click");
		Thread.sleep(1000);
		if (driver.findElements(By.xpath(firstDropdownOption)).size() != 0) {
			driver.findElement(By.xpath(firstDropdownOption)).click();
		}
		
		if (lobType.equalsIgnoreCase("property")) {
			for (int i = 0; i <= 4; i++) {
				try {
					Assert.assertTrue(Helper.getUIXpath(driver, "Coverage / Risk Unit").isDisplayed());
					// Address Number is now changed to Location Number
					Assert.assertTrue(Helper.getUIXpath(driver, "Location Number").isDisplayed());
				} catch (StaleElementReferenceException e) {
					e.getMessage();
				}
			}
		}
		
		// Validate UI from Loss Of Use Exposure
		Thread.sleep(1000);
		Assert.assertTrue(Helper.getUIXpath(driver, "Building Number").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Item Number").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Potential Large Loss?").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "CERC Exposure").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Coverage on Excess Basis").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Claimant").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Type").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Contact Prohibited?").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Primary Phone").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Address").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Location").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "City").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "State").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "ZIP Code").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Country").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Address 1").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Address 2").isDisplayed());
		//Assert.assertTrue(Helper.getUIXpath(driver, "Address 3").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "County").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Location Description").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Severity").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Description").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Loss of Use?").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Loss Estimate").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Number of Days").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Gross Sales").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Cost of Goods").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Operating Expenses").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Net Income").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Continuing Expenses").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Payroll").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Extra Expense").isDisplayed());
		//Assert.assertTrue(Helper.getUIXpath(driver, "Jurisdiction").isDisplayed());		

		// Validating details table
		Assert.assertTrue(Helper.getUIXpath(driver, "Insurer").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Claim #").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Policy #").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Contact").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Phone").isDisplayed());
		Assert.assertTrue(Helper.getUIXpath(driver, "Notes").isDisplayed());

		if (driver.findElement(By.xpath(lossParty)) != null) {
			String actualLossParty = driver.findElement(By.xpath(lossParty)).getText();
			if (actualLossParty.contains("Insured's loss")) {

				String insuredName = driver.findElement(By.xpath(getInsuredName)).getText();
				String actualInsuredName = insuredName.substring(5).trim();
				Thread.sleep(2000);
				Helper.selectDropdownValue(driver, "xpath", claimantNameField, "Select Claimant", actualInsuredName);
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(claimantTypeField)));
				
				// By default claimant type will be selected when we select Claimant name
				//Helper.selectDropdownValue(driver, "xpath", claimantTypeField, "Select Claimant Type", txtclaimantType);

				Thread.sleep(1000);
				UIMethods.jscriptclickbyxpath("//div[contains(@id,'Address_Picker-trigger-picker')]", "Click Locaiton Icon", "Click");
				//driver.findElement(By.xpath("//div[contains(@id,'Address_Picker-trigger-picker')]")).click();
				if(driver.findElements(By.xpath("(//div[contains(@id,'boundlist')]/div/ul/li[2])[2]")).size()!=0) {
					UIMethods.jscriptclickbyxpath("(//div[contains(@id,'boundlist')]/div/ul/li[2])[2]", "Select Location address", "Click");
					Thread.sleep(2000);
				} else {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locationDropdown)));
					UIMethods.clearAndinputbyxpath(locationDropdown, "Select New Option", "New...");
					Thread.sleep(1000);
					// Fields aren't populating while selecting New... option since i clicked in the extra expense field
					driver.findElement(By.xpath("//input[contains(@id,'ExtraExpense-inputEl')]")).click();
					Thread.sleep(1000);
					
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locationZipCode)));
					Helper.selectDropdownValue(driver, "xpath", locationCity, "Enter Location City", location_City);
					//UIMethods.inputbyxpath(locationCity, "Enter Location City", location_City);
					
					Helper.selectDropdownValue(driver, "xpath", locationState, "Select Location State", location_State);
					//UIMethods.clearAndinputbyxpath(locationState, "Select Location state", location_State);
					driver.findElement(By.xpath(addressLine1)).click();
					
					for(int i=0;i<=4;i++) {
						try {
							driver.findElement(By.xpath(location_Zip_Code)).isDisplayed();	
							UIMethods.clearAndinputbyxpath(locationZipCode, "Enter Location zip code", location_Zip_Code);
						} catch(Exception e) {
							e.getMessage();
						}
					}
					
					driver.findElement(By.xpath(addressLine1)).click();
				}
				driver.findElement(By.xpath("//input[contains(@id,'ExtraExpense-inputEl')]")).click();
				Thread.sleep(2000);
				UIMethods.clearAndinputbyxpath(severityField, "Select Severity", "Minor");
				
				// Drop down value isn't hiding since i clicked in the extra expense field
				driver.findElement(By.xpath("//input[contains(@id,'ExtraExpense-inputEl')]")).click();
				Thread.sleep(1000);

			} else if (actualLossParty.contains("Third-party")) {
				UIMethods.clickbyxpath(claimantArrowIcon, "Click Claimant arrow icon", "Click");
				Thread.sleep(1000);
				switch (claimantNameOption.toLowerCase()) {

				case "new person":
					UIMethods.clickbyWebElement(Helper.getUIXpath(driver, "New Person"), "Select New Person option","Click");
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewContactPopup:ContactDetailScreen:ttlBar")));
					newperson.NewPersonContactDetailpage(excelFileName, profileID);
					break;
				case "new vendor":
					UIMethods.clickbyWebElement(Helper.getUIXpath(driver, "New Vendor"), "Select New Vendor option","Click");
					Helper.getUIXpath(driver, "New Vendor").sendKeys(Keys.ARROW_RIGHT);
					NewExposureEntry.enterVendorDetails(claimantNameVendorOption, excelFileName, profileID);
					break;
				case "new company":
					UIMethods.clickbyWebElement(Helper.getUIXpath(driver, "New Company"), "Select New Company option","Click");
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("NewContactPopup:ContactDetailScreen:ttlBar")));
					newperson.NewPersonContactDetailpage(excelFileName, profileID);
					break;
				case "new legal":
					UIMethods.clickbyWebElement(Helper.getUIXpath(driver, "New Legal"), "Select New Legal option","Click");
					Helper.getUIXpath(driver, "New Legal").sendKeys(Keys.ARROW_RIGHT);
					NewExposureEntry.enterNewLegalDetails(claimantNameLegalOption, excelFileName, profileID);
					break;
				case "search":
					UIMethods.clickbyWebElement(Helper.getUIXpath(driver, "Search"), "Select Search option", "Click");
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("AddressBookPickerPopup:AddressBookSearchScreen:ttlBar")));

					// TO-DO Need to work application issue Search address book screen

					break;
				case "view contact details":
					UIMethods.clickbyWebElement(Helper.getUIXpath(driver, "View Contact Details"),"Select View Contact Details option", "Click");
					if (driver.findElements(By.xpath("//a[contains(@id,'ClaimContactDetailPopup:_')]")).size() != 0) {
						UIMethods.jscriptclickbyxpath("//a[contains(@id,'ClaimContactDetailPopup:_')]","Click Return to exposure link", "Click");
					}
					break;
				default:
					Assert.fail("Please provide the valid name to select claimant name options");
					break;
				}

				// Select Claimant Type
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(claimantTypeField)));
				Helper.selectDropdownValue(driver, "xpath", claimantTypeField, "Select Claimant Type", txtclaimantType);

				Thread.sleep(1000);
				UIMethods.jscriptclickbyxpath("//div[contains(@id,'Address_Picker-trigger-picker')]", "Click Locaiton Icon", "Click");
				if(driver.findElements(By.xpath("(//div[contains(@id,'boundlist')]/div/ul/li[2])[2]")).size()!=0) {
					UIMethods.jscriptclickbyxpath("(//div[contains(@id,'boundlist')]/div/ul/li[2])[2]", "Select Location address", "Click");
					Thread.sleep(2000);
				} else {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locationDropdown)));
					UIMethods.clearAndinputbyxpath(locationDropdown, "Select New Option", "New...");
					Thread.sleep(1000);
					// Fields aren't populating while selecting New... option since i clicked in the extra expense field
					driver.findElement(By.xpath("//input[contains(@id,'ExtraExpense-inputEl')]")).click();
					Thread.sleep(1000);
					
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locationZipCode)));
					Helper.selectDropdownValue(driver, "xpath", locationCity, "Enter Location City", location_City);
					//UIMethods.inputbyxpath(locationCity, "Enter Location City", location_City);
					
					Helper.selectDropdownValue(driver, "xpath", locationState, "Select Location State", location_State);
					//UIMethods.clearAndinputbyxpath(locationState, "Select Location state", location_State);
					driver.findElement(By.xpath(addressLine1)).click();
					
					for(int i=0;i<=4;i++) {
						try {
							driver.findElement(By.xpath(location_Zip_Code)).isDisplayed();	
							UIMethods.clearAndinputbyxpath(locationZipCode, "Enter Location zip code", location_Zip_Code);
						} catch(Exception e) {
							e.getMessage();
						}
					}
					
					driver.findElement(By.xpath(addressLine1)).click();
				}
				driver.findElement(By.xpath("//input[contains(@id,'ExtraExpense-inputEl')]")).click();
				Thread.sleep(2000);
				UIMethods.clearAndinputbyxpath(severityField, "Select Severity", "Minor");
				
				// Drop down value isn't hiding since i clicked in the extra expense field
				driver.findElement(By.xpath("//input[contains(@id,'ExtraExpense-inputEl')]")).click();
				Thread.sleep(1000);		
				
			} else {
				Report.fail("Loss Party isn't available in Exposure screen", "Loss Party", "Loss Party","Loss Party not available");
				Assert.fail("Loss Party is not available..");
			}
		} else {
			Report.fail("Loss Party isn't available in Exposure screen", "Loss Party", "Loss Party","Loss Party not available");
			Assert.fail("Loss Party is not available..");
		}

		// Click on OK Button from New Exposure Screen
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newExposureTitle)));

		Helper.getScreenshot(driver, "Loss_of_Use_Exposure",  modeOfExposure+"_TC_" +profileID+ "_");
		
		// Click OK Button During FNOL
		if (driver.findElements(By.xpath(okButton)).size() != 0) {
			UIMethods.jscriptclickbyxpath(okButton, "Click OK Button", "Click");
		}

		// Click Update Button Post FNOL
		if (driver.findElements(By.xpath(updateButton)).size() != 0) {
			UIMethods.jscriptclickbyxpath(updateButton, "Click Update Button", "Click");
		}
		
		// Writing Exposure created status into the Excel sheet in Status Column for
		// both during and post FNOL
		if (driver.findElements(By.xpath(saveAndAssignClaimLabel)).size() != 0 | driver.findElements(By.xpath(exposureScreenLabel)).size() != 0) {
			if (modeOfExposure.equalsIgnoreCase("during")) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(saveAndAssignClaimLabel)));
				if(driver.findElements(By.xpath(saveAndAssignClaimLabel)).size()!=0) {
					xlsread.WriteIntoExistingExcel(SheetName, "lossOfUseStatus", "Pass", profileID, true);
					xlsread.WriteIntoExistingExcel(SheetName, "statusForAllExposures", "Pass", profileID, true);
				} else {
					xlsread.WriteIntoExistingExcel(SheetName, "lossOfUseStatus", "Fail", profileID, false);
					xlsread.WriteIntoExistingExcel(SheetName, "statusForAllExposures", "Fail", profileID, false);
				}
			} else if (modeOfExposure.equalsIgnoreCase("post")) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(exposureScreenLabel)));
				if(driver.findElements(By.xpath(exposureScreenLabel)).size()!=0) {
					xlsread.WriteIntoExistingExcel(SheetName, "lossOfUseStatus", "Pass", profileID, true);
					xlsread.WriteIntoExistingExcel(SheetName, "statusForAllExposures", "Pass", profileID, true);
				} else {
					xlsread.WriteIntoExistingExcel(SheetName, "lossOfUseStatus", "Fail", profileID, false);
					xlsread.WriteIntoExistingExcel(SheetName, "statusForAllExposures", "Fail", profileID, false);
				}
			}
		}
	}
}
