package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class NewPersonContactDetail extends Object_Repositories{
	
	private WebDriver driver=null;
	
	//Page Objects	
	String firstName = "NewContactPopup:ContactDetailScreen:ContactBasicsDV:PersonNameInputSet:GlobalPersonNameInputSet:FirstName-inputEl";
	String lastName = "NewContactPopup:ContactDetailScreen:ContactBasicsDV:PersonNameInputSet:GlobalPersonNameInputSet:LastName-inputEl";
	String addressLine1 = "NewContactPopup:ContactDetailScreen:ContactBasicsDV:PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:AddressLine1-inputEl";
	String addressZipCode = "NewContactPopup:ContactDetailScreen:ContactBasicsDV:PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:PostalCode-inputEl";
	String addressCity = "NewContactPopup:ContactDetailScreen:ContactBasicsDV:PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:City-inputEl";
	String addressState = "NewContactPopup:ContactDetailScreen:ContactBasicsDV:PrimaryAddressInputSet:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:State-inputEl";
	String updateButton = "//a[@id='NewContactPopup:ContactDetailScreen:ContactBasicsDV_tb:ContactDetailToolbarButtonSet:CustomUpdateButton']/span";
	String validateAddressButton = "//a[contains(@id,'globalAddressContainer:Validate')]/span/span/span[2][text()='Validate Address']";
	
	// Exposure screen claimant name vendor option objects
	String contactName = "NewContactPopup:ContactDetailScreen:ContactBasicsDV:OrganizationName:GlobalContactNameInputSet:Name-inputEl";
	String organizationName = "NewContactPopup:ContactDetailScreen:ContactBasicsDV:OrganizationCompanyName-inputEl";
	
	public NewPersonContactDetail(WebDriver driver)
	{
		this.driver = driver;
		wait = new WebDriverWait(driver, 15);
	}	
	
	public void NewPersonContactDetailpage(String excelFileName, String profileID) throws Exception{		
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtcontactname = xlsread.Exceldata(SheetName, "txtContactName", profileID);
		String txtOrgName = xlsread.Exceldata(SheetName, "txtOrganizationName", profileID);		
		String txtPersonFirstName = xlsread.Exceldata(SheetName, "txtPersonFirstName", profileID);
		String txtPersonLastName = xlsread.Exceldata(SheetName, "txtPersonLastName", profileID);
		String txtAddrLine1 = xlsread.Exceldata(SheetName, "txtAddrLine1", profileID);
		String txtAddrCity = xlsread.Exceldata(SheetName, "txtAddrCity", profileID);
		String txtAddrState = xlsread.Exceldata(SheetName, "txtAddrState", profileID);
		String txtAddrZip = xlsread.Exceldata(SheetName, "txtAddrZip", profileID);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(updateButton)));
		
		// Below two objects are only appear in exposure -> claimant name -> vendor options screen		
		if(driver.findElements(By.id(contactName)).size()!=0) {
			wait.until(ExpectedConditions.elementToBeClickable(By.id(contactName)));
			UIMethods.clearAndInputbyid(contactName, "Enter Contact Name", txtcontactname);
		}
		if(driver.findElements(By.id(organizationName)).size()!=0) {
			wait.until(ExpectedConditions.elementToBeClickable(By.id(organizationName)));
			UIMethods.clearAndInputbyid(organizationName, "Enter Organization Name", txtOrgName);
		}
		
		// Enter New person basic information
		if(driver.findElements(By.id(firstName)).size()!=0) {
			wait.until(ExpectedConditions.elementToBeClickable(By.id(firstName)));
			UIMethods.inputbyid(firstName, "Enter First Name", txtPersonFirstName);
		}
		if(driver.findElements(By.id(lastName)).size()!=0) {
			wait.until(ExpectedConditions.elementToBeClickable(By.id(lastName)));
	        UIMethods.inputbyid(lastName, "Enter Last Name", txtPersonLastName);	        
		}		

		if(driver.findElements(By.id(addressLine1)).size()!=0) {
			wait.until(ExpectedConditions.elementToBeClickable(By.id(addressLine1)));
			UIMethods.inputbyid(addressLine1, "Enter Address Line1", txtAddrLine1);
			wait.until(ExpectedConditions.elementToBeClickable(By.id(addressZipCode)));
			UIMethods.inputbyid(addressZipCode, "Enter Zip Code", txtAddrZip);
			wait.until(ExpectedConditions.elementToBeClickable(By.id(addressCity)));
			UIMethods.inputbyid(addressCity, "Enter City", txtAddrCity);
			Thread.sleep(2000);
			wait.until(ExpectedConditions.elementToBeClickable(By.id(addressState)));
			Helper.selectDropdownValue(driver, "id", addressState, "Select address state", txtAddrState);
			
			/*if(driver.findElements(By.xpath(validateAddressButton)).size()!=0) {
				UIMethods.jscriptclickbyxpath(validateAddressButton,"Click Validate Address button", "Click");
				Thread.sleep(4000);
			}			
		}		*/
		
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(updateButton)));
			UIMethods.clickbyxpath(updateButton, "Click Update button", "Click");
			Thread.sleep(2000);
			Helper.waitForLoad(driver);
		}
	}
}