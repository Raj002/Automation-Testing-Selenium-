package org.qa.Claims.CICC9.Utilities;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.FetchPropertiesFiles;

public class Object_Repositories 
{
	public static WebDriverWait wait;
	public static ExcelXlsFileRead xlsread;
	public static String projectdir = System.getProperty("user.dir");
	public static String SheetName = "ClaimsPolicy";
	
	public static String saveIcon = "//span[@id='TabBar:UnsavedWorkTabBarLink-btnIconEl']";
	public static String updateButton = "//a[contains(@id,'Update')]";
	public static String finishButton = "//*[@id='FNOLWizard:Finish']";
	public static String nextButton = "//a[@id='FNOLWizard:Next']";
	public static String searchButton = "//a[@id='AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search']";
	//public static String okButton = "//span[text()='OK']";
	public static String okButton = "//a[contains(@id,'Update')]/span/span/span[2]";
	public static String saveAssignClaimDropdown = "//div[contains(@id,'boundlist')]/div/ul/li[2]";
	public static String saveAndAssignClaimLabel = "//span[contains(text(),'Save and Assign Claim')]";
	public static String summaryScreenLabel = "//span[@id='ClaimSummary:ClaimSummaryScreen:ttlBar' and text()='Summary']";
	public static String exposureScreenLabel = "//span[@id='ClaimExposures:ClaimExposuresScreen:ttlBar' and text()='Exposures']";
	public static String commonCheckBox = "//img[contains(@class,'x-grid-checkcolumn')]";
	public static String returnToExposureLink = "//a[contains(text(),'Return to New Exposure')]";
	public static String firstDropdownOption = "//div[contains(@id,'boundlist')]/div/ul/li[2]";
	public static String newPersonOption = "//span[contains(@id,'NewPersonMenuItem') and text()='New Person']";
	public static String mainTable = "//div[contains(@id,'gridview-')]/div/table";

	// Claim Menu objects
	public static String claimMenuIcon = "//SPAN[@id='TabBar:ClaimTab-btnWrap']/self::SPAN";
	public static String claimNumberField = "TabBar:ClaimTab:ClaimTab_FindClaim-inputEl";
	public static String searchIcon = "//div[@id='TabBar:ClaimTab:ClaimTab_FindClaim_Button']";
	public static String newClaimOption = "//a[@id= 'TabBar:ClaimTab:ClaimTab_FNOLWizard-itemEl']";
	
	public static String getInsuredName = "//span[contains(@id,'ClaimInfoBar:Insured')][2]";
	
	// ***************************** Main Menu Objects *****************************	
	public static String desktopMenu = "//span[@id='TabBar:DesktopTab-btnWrap']/span";
	public static String claimMenu = "//span[@id='TabBar:ClaimTab-btnWrap']/span";
	public static String searchMenu = "//span[@id='TabBar:SearchTab-btnWrap']/span";
	public static String addressBookMenu = "//span[@id='TabBar:AddressBookTab-btnWrap']/span";
	public static String dashboardmenu = "//span[@id='TabBar:DashboardTab-btnWrap']/span";
	public static String teamMenu = "//span[@id='TabBar:TeamTab-btnWrap']/span";
	public static String administrationMenu = "//span[@id='TabBar:AdminTab-btnWrap']/span";
	
	//***************************** Desktop sub Menu Objects *****************************	
	public static String desktopActivitiesSubMenu = "//td[@id='Desktop:MenuLinks:Desktop_DesktopActivities']/div/span";
	public static String desktopClaimsSubMenu = "//td[@id='Desktop:MenuLinks:Desktop_DesktopClaims']/div/span";
	public static String desktopExposuresSubMenu = "//td[@id='Desktop:MenuLinks:Desktop_DesktopExposures']/div/span";
	public static String desktopSubrogationsSubMenu = "//td[@id='Desktop:MenuLinks:Desktop_DesktopSubrogations']/div/span";
	public static String desktopPendingAssignmentsSubMenu = "//td[@id='Desktop:MenuLinks:Desktop_DesktopAwaitingAssignment']/div/span";
	public static String desktopQueuesSubMenu = "//td[@id='Desktop:MenuLinks:Desktop_DesktopQueuedActivities']/div/span";
	public static String desktopCalendarSubMenu = "//td[@id='Desktop:MenuLinks:Desktop_DesktopCalendarGroup']/div/span";
	public static String desktopMyCalendarTab = "//td[@id='Desktop:MenuLinks:Desktop_DesktopCalendarGroup:DesktopCalendarGroup_Calendar']/div/span";
	public static String desktopSupervisorCalendarTab = "//td[@id='Desktop:MenuLinks:Desktop_DesktopCalendarGroup:DesktopCalendarGroup_SupervisorCalendar']/div/span";
	public static String desktopBulkInvoicesSubMenu = "//td[@id='Desktop:MenuLinks:Desktop_BulkPay']/div/span";
	public static String desktopBulkRecoveriesSubMenu = "//td[@id='Desktop:MenuLinks:Desktop_BulkRecoveries']/div/span";
	public static String desktopMedicalBillsSubMenu = "//td[@id='Desktop:MenuLinks:Desktop_MedicalBills']/div/span";
	public static String desktopRegionsSubMenu = "//td[@id='Desktop:MenuLinks:Desktop_ClaimSUPRegions']/div/span";
	
	
	//***************************** Claims sub Menu Objects *****************************
	public static String claimsSummarySubMenu = "//td[@id='Claim:MenuLinks:Claim_ClaimSummaryGroup']/div/span";
	public static String claimsSummaryOverviewTab = "//td[@id='Claim:MenuLinks:Claim_ClaimSummaryGroup:ClaimSummaryGroup_ClaimSummary']/div/span";
	public static String claimsSummaryStatusTab = "//td[@id='Claim:MenuLinks:Claim_ClaimSummaryGroup:ClaimSummaryGroup_ClaimStatus']/div/span";
	public static String claimsSummaryHealthMetricsTab = "//td[@id='Claim:MenuLinks:Claim_ClaimSummaryGroup:ClaimSummaryGroup_ClaimKeyMetrics']/div/span";
	public static String claimsWorkPlanSubMenu = "//td[@id='Claim:MenuLinks:Claim_ClaimWorkplan']/div/span";
	public static String claimsLossDetailsSubMenu = "//td[@id='Claim:MenuLinks:Claim_ClaimLossDetailsGroup']/div/span";
	public static String claimsLossDetailsGeneralTab = "//td[@id='Claim:MenuLinks:Claim_ClaimLossDetailsGroup:ClaimLossDetailsGroup_ClaimLossDetails']/div/span";
	public static String claimsLossDetailsAssociationsTab = "//td[@id='Claim:MenuLinks:Claim_ClaimLossDetailsGroup:ClaimLossDetailsGroup_ClaimAssociations']/div/span";
	public static String claimsLossDetailsSpecialInvestigationTab = "//td[@id='Claim:MenuLinks:Claim_ClaimLossDetailsGroup:ClaimLossDetailsGroup_SIDetails']/div/span";
	public static String claimsExposuresSubMenu = "//td[@id='Claim:MenuLinks:Claim_ClaimExposures']/div/span";
	public static String claimsReinsuranceSubMenu = "//td[@id='Claim:MenuLinks:Claim_ReinsuranceSummary']/div/span";
	public static String claimsPartiesInvolvedSubMenu = "//td[@id='Claim:MenuLinks:Claim_ClaimPartiesGroup']/div/span";
	public static String claimsPartiesInvolvedContactsTab = "//td[@id='Claim:MenuLinks:Claim_ClaimPartiesGroup:ClaimPartiesGroup_ClaimContacts']/div/span";
	public static String claimsPartiesInvolvedUsersTab = "//td[@id='Claim:MenuLinks:Claim_ClaimPartiesGroup:ClaimPartiesGroup_ClaimUsers']/div/span";
	public static String claimsPolicySubMenu = "//td[@id='Claim:MenuLinks:Claim_ClaimPolicyGroup']/div/span";
	public static String claimsPolicyGeneralTab = "//td[@id='Claim:MenuLinks:Claim_ClaimPolicyGroup:ClaimPolicyGroup_ClaimPolicyGeneral']/div/span";
	public static String claimsPolicyVehiclesTab = "//td[@id='Claim:MenuLinks:Claim_ClaimPolicyGroup:ClaimPolicyGroup_ClaimPolicyVehicles']/div/span";
	public static String claimsPolicyEndrosementsTab = "//td[@id='Claim:MenuLinks:Claim_ClaimPolicyGroup:ClaimPolicyGroup_ClaimPolicyEndorsements']/div/span";
	public static String claimsPolicyAggregateLimitsTab = "//td[@id='Claim:MenuLinks:Claim_ClaimPolicyGroup:ClaimPolicyGroup_ClaimPolicyAggregateLimits']/div/span";
	public static String claimsPolicyDocumentsTab = "//td[@id='Claim:MenuLinks:Claim_ClaimPolicyGroup:ClaimPolicyGroup_PolicyDocuments']/div/span";
	public static String claimsFinancialsSubMenu = "//td[@id='Claim:MenuLinks:Claim_ClaimFinancialsGroup']/div/span";
	public static String claimsFinancialsSummaryTab = "//td[@id='Claim:MenuLinks:Claim_ClaimFinancialsGroup:ClaimFinancialsGroup_ClaimFinancialsSummary']/div/span";
	public static String claimsFinancialsTransactionTab = "//td[@id='Claim:MenuLinks:Claim_ClaimFinancialsGroup:ClaimFinancialsGroup_ClaimFinancialsTransactions']/div/span";
	public static String claimsFinancialsChecksTab = "//td[@id='Claim:MenuLinks:Claim_ClaimFinancialsGroup:ClaimFinancialsGroup_ClaimFinancialsChecks']/div/span";
	public static String claimsFinancialsReserveLogTab = "//td[@id='Claim:MenuLinks:Claim_ClaimFinancialsGroup:ClaimFinancialsGroup_ClaimFinancialReserves']/div/span";
	public static String claimsNotesSubMenu = "//td[@id='Claim:MenuLinks:Claim_ClaimNotes']/div/span";
	public static String claimsDocumentsSubMenu = "//td[@id='Claim:MenuLinks:Claim_ClaimDocuments']/div/span";
	public static String claimsPlanOfActionSubMenu = "//td[@id='Claim:MenuLinks:Claim_ClaimPlanOfActionGroup']/div/span";
	public static String claimsPlanOfActionEvaluationsTab = "//td[@id='Claim:MenuLinks:Claim_ClaimPlanOfActionGroup:ClaimPlanOfActionGroup_ClaimEvaluations']/div/span";
	public static String claimsPlanOfActionNegotiationsTab = "//td[@id='Claim:MenuLinks:Claim_ClaimPlanOfActionGroup:ClaimPlanOfActionGroup_ClaimNegotiations']/div/span";
	public static String claimsServicesSubMenu = "//td[@id='Claim:MenuLinks:Claim_ClaimServiceRequests']/div/span";
	public static String claimsLitigationSubMenu = "//td[@id='Claim:MenuLinks:Claim_ClaimMatters']/div/span";
	public static String claimsHistorySubMenu = "//td[@id='Claim:MenuLinks:Claim_ClaimHistory']/div/span";
	public static String claimsFNOLSnapshotSubMenu = "//td[@id='Claim:MenuLinks:Claim_ClaimSnapshotGroup']/div/span";
	public static String claimsFNOLLossDetailsTab = "//td[@id='Claim:MenuLinks:Claim_ClaimSnapshotGroup:ClaimSnapshotGroup_ClaimSnapshotLossDetails']/div/span";
	public static String claimsFNOLPartiesInvolvedTab = "//td[@id='Claim:MenuLinks:Claim_ClaimSnapshotGroup:ClaimSnapshotGroup_ClaimSnapshotPartiesInvolved']/div/span";
	public static String claimsFNOLPolicyTab = "//td[@id='Claim:MenuLinks:Claim_ClaimSnapshotGroup:ClaimSnapshotGroup_ClaimSnapshotPolicy']/div/span";
	public static String claimsFNOLExposureTab = "//td[@id='Claim:MenuLinks:Claim_ClaimSnapshotGroup:ClaimSnapshotGroup_ClaimSnapshotExposures']/div/span";
	public static String claimsFNOLNotesTab = "//td[@id='Claim:MenuLinks:Claim_ClaimSnapshotGroup:ClaimSnapshotGroup_ClaimSnapshotNotes']/div/span";
	public static String claimsFNOLDocumentsTab = "//td[@id='Claim:MenuLinks:Claim_ClaimSnapshotGroup:ClaimSnapshotGroup_ClaimSnapshotDocuments']/div/span";
	public static String claimsFNOLAdditionalFieldsTab = "//td[@id='Claim:MenuLinks:Claim_ClaimSnapshotGroup:ClaimSnapshotGroup_ClaimSnapshotExtraFields']/div/span";
	public static String claimsCalendarSubMenu = "//td[@id='Claim:MenuLinks:Claim_ClaimCalendarGroup']/div/span";
	public static String claimsCalendarMyCalendarTab = "//td[@id='Claim:MenuLinks:Claim_ClaimCalendarGroup:ClaimCalendarGroup_ClaimCalendar']/div/span";
	public static String claimsCalendarSupervisorCalendarTab = "//td[@id='Claim:MenuLinks:Claim_ClaimCalendarGroup:ClaimCalendarGroup_SupervisorClaimCalendar']/div/span";
	
	//***************************** Claims sub Menu Objects *****************************
	public static String searchClaimsMenu = "//td[@id='Search:MenuLinks:Search_ClaimSearchesGroup']/div/span";
	public static String searchClaimsSimpleSearchTab = "//td[@id='Search:MenuLinks:Search_ClaimSearchesGroup:ClaimSearchesGroup_SimpleClaimSearch']/div/span";
	public static String searchClaimsAdvancedSearchTab = "//td[@id='Search:MenuLinks:Search_ClaimSearchesGroup:ClaimSearchesGroup_ClaimSearch']/div/span";
	public static String searchClaimsAccountSearchTab = "//td[@id='Search:MenuLinks:Search_ClaimSearchesGroup:ClaimSearchesGroup_AccountSearch']/div/span";
	public static String searchActivitiesSubMenu = "//td[@id='Search:MenuLinks:Search_ActivitySearch']/div/span";
	public static String searchChecksSubMenu = "//td[@id='Search:MenuLinks:Search_PaymentSearch']/div/span";
	public static String searchRecoveriesSubMenu = "//td[@id='Search:MenuLinks:Search_RecoverySearch']/div/span";
	public static String searchBulkInvoicesSubMenu = "//td[@id='Search:MenuLinks:Search_BulkInvoiceSearch']/div/span";
	
	//***************************** Actions Menu item Objects *****************************
	public static String actionsMenu = "//span[@id='Claim:ClaimMenuActions-btnWrap']/span";
	public static String actionsNoteItem = "//div[@id='Claim:ClaimMenuActions:ClaimNewOtherMenuItemSet:ClaimMenuActions_NewOther:ClaimMenuActions_NewNote']/a/span";
	public static String actionsEmailItem = "//div[@id='Claim:ClaimMenuActions:ClaimNewOtherMenuItemSet:ClaimMenuActions_NewOther:ClaimMenuActions_Email']/a/span";
	public static String actionsMatterItem = "//div[@id='Claim:ClaimMenuActions:ClaimNewOtherMenuItemSet:ClaimMenuActions_NewOther:ClaimMenuActions_NewMatter']/a/span";
	public static String actionsEvaluationItem = "//div[@id='Claim:ClaimMenuActions:ClaimNewOtherMenuItemSet:ClaimMenuActions_NewOther:ClaimMenuActions_NewEvaluation']/a/span";
	public static String actionsNegotiationItem = "//div[@id='Claim:ClaimMenuActions:ClaimNewOtherMenuItemSet:ClaimMenuActions_NewOther:ClaimMenuActions_NewNegotiation']/a/span";
	public static String actionsServiceItem = "//div[@id='Claim:ClaimMenuActions:ClaimNewOtherMenuItemSet:ClaimMenuActions_NewOther:ClaimMenuActions_NewServiceRequest']/a/span";
	public static String actionsReserveItem = "//div[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewTransaction:ClaimMenuActions_NewTransaction_ReserveSet']/a/span";
	public static String actionsCheckItem = "//div[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewTransaction:ClaimMenuActions_NewTransaction_CheckSet']/a/span";
	public static String actionsManualCheckItem = "//div[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewTransaction:ClaimMenuActions_NewTransaction_Check']/a/span";
	public static String actionsRecoveryItem = "//div[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewTransaction:ClaimMenuActions_NewTransaction_RecoverySet']/a/span";
	public static String actionsCorrespondenceItem = "//div[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewActivity:NewActivityMenuItemSet:0:NewActivityMenuItemSet_Category']/a/span";
	public static String actionsFileReviewItem = "//div[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewActivity:NewActivityMenuItemSet:1:NewActivityMenuItemSet_Category']/a/span";
	public static String actionsGeneralItem = "//div[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewActivity:NewActivityMenuItemSet:2:NewActivityMenuItemSet_Category']/a/span";
	public static String actionsInterviewItem = "//div[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewActivity:NewActivityMenuItemSet:3:NewActivityMenuItemSet_Category']/a/span";
	public static String actionsInvestigationItem = "//div[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewActivity:NewActivityMenuItemSet:4:NewActivityMenuItemSet_Category']/a/span";
	public static String actionsMedicareItem = "//div[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewActivity:NewActivityMenuItemSet:5:NewActivityMenuItemSet_Category']/a/span";
	public static String actionsNewMailItem = "//div[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewActivity:NewActivityMenuItemSet:6:NewActivityMenuItemSet_Category']/a/span";
	public static String actionsReminderItem = "//div[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewActivity:NewActivityMenuItemSet:7:NewActivityMenuItemSet_Category']/a/span";
	public static String actionsRequestItem = "//div[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewActivity:NewActivityMenuItemSet:8:NewActivityMenuItemSet_Category']/a/span";
	public static String actionsWarningItem = "//div[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewActivity:NewActivityMenuItemSet:9:NewActivityMenuItemSet_Category']/a/span";
	public static String actionsChooseByPolicyCoverageItem = "//div[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewExposure:NewExposureMenuItemSet:NewExposureMenuItemSet_ByCoverage']/a/span";
	public static String actionsChooseByCoverageTypeItem = "//div[contains(@id,'NewExposureMenuItemSet_ByCoverageType')]/a/span[text()='Choose by Coverage Type']";
	public static String actionsAssignClaimItem = "//div[@id='Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions:ClaimMenuActions_Assign']/a/span";
	public static String actionsCloseClaimItem = "//div[@id='Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions:ClaimMenuActions_CloseClaim']/a/span";
	public static String actionsPrintClaimItem = "//div[@id='Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions:ClaimMenuActions_Print']/a/span";
	public static String actionsSyncStatusItem = "//div[@id='Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions:ClaimMenuActions_SyncStatus']/a/span";
	public static String actionsValidateClaimOnlyItem = "//div[@id='Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions:ClaimMenuActions_ClaimValidation']/a/span";
	public static String actionsValidateClaimExposureItem = "//div[@id='Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions:ClaimMenuActions_ClaimExposureValidation']/a/span";
	public static String actionsValidatePolicyItem = "//div[@id='Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions:ClaimMenuActions_PolicyValidation']/a/span";
	
	//***************************** Property Exposure Page Objects *****************************
	public static String newExposureTitle = "//span[contains(text(),'New Exposure')]";
	public static String lossParty = "//div[contains(@id,'LossParty-inputEl')]";			
	public static String primaryCoverage = "//div[contains(@id,'PrimaryCoverage-inputEl')]";			
	public static String coverageSubType = "//div[contains(@id,'CoverageSubType-inputEl')]";
	public static String riskUnit = "//div[contains(@id,'Coverage-trigger-picker')]";
	public static String claimantNameField = "//input[contains(@id,'Claimant_Picker-inputEl')]";	
	public static String claimantTypeField = "//input[contains(@id,'Claimant_Type-inputEl')]";
	public static String claimantArrowIcon = "(//a[contains(@id,'MenuIcon')]/img)[1]";
	public static String propertyNameArrowIcon = "(//a[contains(@id,'MenuIcon')]/img)[2]";
	public static String medPayNameArrowIcon = "(//a[contains(@id,'MenuIcon')]/img)[3]";
	public static String propertyNametextBox = "//input[contains(@id,'Property_Incident-inputEl')]";
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
