package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class NewVendor {

	private WebDriver driver = null;
	WebDriverWait wait;

	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");

	public NewVendor(WebDriver driver) {
		this.driver = driver;
	}

	public void addExistingContact(String excelFileName, String profileID) throws InterruptedException {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String addressBookType = xlsread.Exceldata(SheetName, "addressBookType", profileID);
		Thread.sleep(5000);

		/*UIMethods.clickbyid("ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_AddExistingButton","Click on Add Existing contact button", "Click");
		Thread.sleep(3000);*/
		UIMethods.selectbyid("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:ContactSubtype","Select address book type", addressBookType);
		Thread.sleep(2000);
		UIMethods.inputbyid("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:Keyword", "Enter name","john");
		UIMethods.clickbyid("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search_link","Click on search button", "Click");
		Thread.sleep(2000);
		UIMethods.clickbyid("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:_Select_link","Click on first search result", "Click");
		Thread.sleep(3000);
	}

	public void NewVendorPage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlRoles = xlsread.Exceldata(SheetName, "ddlRoles", profileID);
		String btnAddRoles = xlsread.Exceldata(SheetName, "btnAddRoles", profileID);
		String btnNewVendorUpdate = xlsread.Exceldata(SheetName, "btnNewVendorUpdate", profileID);

		Thread.sleep(3000);
		// Add Roles
		if (!(btnAddRoles.isEmpty())) {
			UIMethods.jscriptclickbyxpath("//*[@id='AddExistingPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:ContactBasicsHeaderInputSet:EditableClaimContactRolesLV_tb:Add']","Click Add Roles Button", "Click");

			Thread.sleep(10000);
			UIMethods.selectbyid("AddExistingPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:ContactBasicsHeaderInputSet:EditableClaimContactRolesLV:0:Role","Select Roles", ddlRoles);
			Thread.sleep(2000);
			UIMethods.jscriptclickbyxpath("//*[@id='AddExistingPartyInvolvedPopup:ContactDetailScreen:ContactBasicsDV:ContactBasicsHeaderInputSet:EditableClaimContactRolesLV:0:_Checkbox']","Click Chekbox", "Click");
			Thread.sleep(2000);
		}
		Thread.sleep(2000);

		// Update Button
		if (!(btnNewVendorUpdate.isEmpty())) {
			UIMethods.jscriptclickbyxpath("//span[text()='pdate']", "click Update button", "Click");
			Thread.sleep(2000);
		}
		Thread.sleep(5000);
	}
}