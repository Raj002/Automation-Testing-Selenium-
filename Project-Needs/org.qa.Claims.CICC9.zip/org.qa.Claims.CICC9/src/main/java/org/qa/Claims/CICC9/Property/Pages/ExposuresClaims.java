package org.qa.Claims.CICC9.Property.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class ExposuresClaims {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	public ExposuresClaims(WebDriver driver)
	{
		this.driver = driver;
	}	
	
	public void ExposureClaimpage() throws Exception{
		UIMethods.clickbyid("Claim:MenuLinks:Claim_ClaimExposuresGroup", "click ClaimExposuresGroup", "Click");
        UIMethods.clickbyid("ClaimExposures:ClaimExposuresScreen:ExposuresLV:0:_Checkbox", "click ExposuresLV:0:_Checkbox", "Click");
        UIMethods.clickbyxpath("//a[@id='ClaimExposures:ClaimExposuresScreen:ExposuresLV:0:Type']/span[text()='Personal Property']", "click Exposure Type", "Click");
        Thread.sleep(2000);
	}
}