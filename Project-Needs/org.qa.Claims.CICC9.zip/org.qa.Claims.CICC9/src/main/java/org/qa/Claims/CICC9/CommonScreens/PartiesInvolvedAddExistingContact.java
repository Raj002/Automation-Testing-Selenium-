package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class PartiesInvolvedAddExistingContact {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	public PartiesInvolvedAddExistingContact(WebDriver driver)
	{
		this.driver = driver;
	}	
	
	public void PartiesInvolvedAddExistingContactsPage() throws Exception{
		UIMethods.clickbyxpath("//*[@id='Claim:MenuLinks:Claim_ClaimPartiesGroup']/div", "Click parties involved link", "Click");
		Thread.sleep(6000);
		UIMethods.jscriptclickbyxpath("//*[@id='ClaimContacts:ClaimContactsScreen:PeopleInvolvedDetailedListDetail:PeopleInvolvedDetailedLV_tb:ClaimContacts_AddExistingButton']/span[2]", "Click add existing contact button", "Click");
		Thread.sleep(3000);
	}
}