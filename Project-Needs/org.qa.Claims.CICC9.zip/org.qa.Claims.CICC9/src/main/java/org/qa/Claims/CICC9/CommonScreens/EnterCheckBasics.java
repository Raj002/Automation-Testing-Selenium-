package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class EnterCheckBasics {

	private WebDriver driver = null;
	WebDriverWait wait;
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");

	//Page Objects
	String nextButton = "//*[text()='Next >']";
	String categoryAmount = "QuickCreateCheckWizard:QuickCheckWizard_QuickCheckBasicsScreen:QuickCheckBasicsDV:EditablePaymentLineItemsLV:0:Amount";
	
	public EnterCheckBasics(WebDriver driver) {
		this.driver = driver;
	}

	public void EnterCheckBasicsPage(String excelFileName, String profileID) throws Exception{
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
        String txtName = xlsread.Exceldata(SheetName, "txtName", profileID);
		String ddlCategory = xlsread.Exceldata(SheetName, "ddlCategory", profileID);
		String txtAmount = xlsread.Exceldata(SheetName, "txtAmount", profileID);
		
		Thread.sleep(2000);
		UIMethods.inputbyid("QuickCreateCheckWizard:QuickCheckWizard_QuickCheckBasicsScreen:QuickCheckBasicsDV:PrimaryPayee_Name", "Input Primary payee name", txtName);
        Thread.sleep(5000);
        Select select = new Select(driver.findElement(By.id("QuickCreateCheckWizard:QuickCheckWizard_QuickCheckBasicsScreen:QuickCheckBasicsDV:EditablePaymentLineItemsLV:0:LineCategory")));
        select.selectByIndex(1);
        Thread.sleep(3000);
        UIMethods.inputbyid(categoryAmount, "input Amount", txtAmount);
        Thread.sleep(3000);
        UIMethods.jscriptclickbyxpath(nextButton, "click Next button", "Click");
        Thread.sleep(2000);
	}
}