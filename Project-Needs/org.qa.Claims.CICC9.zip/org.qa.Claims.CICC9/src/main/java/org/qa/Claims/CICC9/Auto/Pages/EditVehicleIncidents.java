package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class EditVehicleIncidents {

	private WebDriver driver = null;
	WebDriverWait wait;

	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	// Page Objects
	String frontCheckBox = "//table[@id='FNOLVehicleIncidentPopup:FNOLVehicleIncidentScreen:8']/tbody/tr[3]/td[5]/input[@id='FNOLVehicleIncidentPopup:FNOLVehicleIncidentScreen:DamDescFront_EXT']";
	String okButton = "//span[text()='OK']";

	public EditVehicleIncidents(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 50);
	}

	public void editVehicleIncidents(String excelFileName, String profileID) throws Exception {			
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ddlVehicleDriverName = xlsread.Exceldata(SheetName, "ddlVehicleDriverName", profileID);
		String ddlVehicleRelationToOwner = xlsread.Exceldata(SheetName, "ddlVehicleRelationToOwner", profileID);
		
		Thread.sleep(2000);
        UIMethods.selectbyid("EditVehicleIncidentPopup:EditVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:Driver_Picker", "input Driver Name", ddlVehicleDriverName);
        Thread.sleep(2000);
        UIMethods.selectbyid("EditVehicleIncidentPopup:EditVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:RelationToInsured", "input RelationToInsured", ddlVehicleRelationToOwner);
        Thread.sleep(5000);
       // wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(frontCheckBox)));
        UIMethods.jscriptclickbyxpath("//table[@id='EditVehicleIncidentPopup:EditVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:5']/tbody/tr[2]/td[5]/input", "click Front Checkbox", "Click");
        Thread.sleep(2000);
        UIMethods.clickbyid("EditVehicleIncidentPopup:EditVehicleIncidentScreen:VehIncidentDetailDV:VehicleIncidentDV:VehicleParked_true", "click Vehicle Parked", "Click");
        Thread.sleep(2000);
        UIMethods.clickbyxpath(okButton, "click OK button", "Click");
        Thread.sleep(2000);
	}
	
	public void EditVehicle() throws Exception {
		Thread.sleep(3000);
		UIMethods.jscriptclickbyxpath(frontCheckBox, "click Front Checkbox", "Click");
		Thread.sleep(2000);
        UIMethods.clickbyxpath(okButton, "click OK button", "Click");
        Thread.sleep(2000);
	}
	
	public void UpdateVehicle() throws Exception {
		UIMethods.jscriptclickbyxpath("//*[@id='FNOLVehicleIncidentPopup:FNOLVehicleIncidentScreen:DamDescFront_EXT']", "click Front Checkbox", "Click");
        UIMethods.jscriptclickbyxpath(okButton, "click OK button", "Click");
        Thread.sleep(2000);
	}
}