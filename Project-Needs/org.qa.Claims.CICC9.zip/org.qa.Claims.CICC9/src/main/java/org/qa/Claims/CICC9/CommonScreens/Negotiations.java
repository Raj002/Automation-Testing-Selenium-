package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class Negotiations {

	private WebDriver driver = null;
	WebDriverWait wait;

	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	// Page Objects
	String negotiations = "ClaimPlanOfActionGroup:MenuLinks:ClaimPlanOfActionGroup_ClaimNegotiations";
	String newNegotiationsButton = "//span[text()='ew Negotiation']";
	String negotiationName = "NewNegotiation:NewNegotiationScreen:NewNegotiationDV:General_Name";

	public Negotiations(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}

	public void NewNegotiations(String excelFileName, String profileID) throws Exception {		
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtName = xlsread.Exceldata(SheetName, "txtName", profileID);
		String ddlNegotiationType = xlsread.Exceldata(SheetName, "ddlNegotiationType", profileID);
		String ddlRelatedTo = xlsread.Exceldata(SheetName, "ddlRelatedTo", profileID);

		UIMethods.clickbyxpath("//*[text()='Plan of Action']", "click Plan of Actions", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ClaimEvaluations:ClaimEvaluationsScreen:EditableEvaluationsLV_tb:CE_Add")));
		Helper.highLightElement(driver, driver.findElement(By.id(negotiations)));
		UIMethods.clickbyid(negotiations, "click Negotiations", "Click");
		Thread.sleep(3000);
		Helper.highLightElement(driver, driver.findElement(By.xpath(newNegotiationsButton)));;
		UIMethods.clickbyxpath(newNegotiationsButton, "click New Negotiations", "Click");
		Thread.sleep(3000);
		UIMethods.inputbyid(negotiationName, "input Name", txtName);
		Thread.sleep(2000);
		UIMethods.selectbyid("NewNegotiation:NewNegotiationScreen:NewNegotiationDV:Negotiation_Type","input Negotiation Type", ddlNegotiationType);
		Thread.sleep(2000);
		if (ddlRelatedTo.equals("EXISTING")) {
			ddlRelatedTo = CopyExposureData.exposuresdata;
		}
		UIMethods.selectbyid("NewNegotiation:NewNegotiationScreen:NewNegotiationDV:Note_RelatedTo", "input Related To",ddlRelatedTo);
		Thread.sleep(2000);
		Helper.highLightElement(driver, driver.findElement(By.id("NewNegotiation:NewNegotiationScreen:NewNegotiationDV_tb:Update")));
		UIMethods.clickbyid("NewNegotiation:NewNegotiationScreen:NewNegotiationDV_tb:Update", "click Update button", "Click");	
		//UIMethods.clickbyxpath("//span[text()='pdate']", "click Update button", "Click");
		Thread.sleep(3000);
	}
}