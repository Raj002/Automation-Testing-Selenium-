package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class NewCheckError {

	private WebDriver driver = null;

	public NewCheckError(WebDriver driver) {
		this.driver = driver;
	}
	
	public void NewCheckErrorpage() throws Exception{
		if(driver.findElements(By.id("WebMessageWorksheet:WebMessageWorkSheetScreen:WebMessageWorksheet_ClearButton")).size()> 0){
        	UIMethods.jscriptclickbyxpath("//*[@id='WebMessageWorksheet:WebMessageWorkSheetScreen:WebMessageWorksheet_ClearButton']", "Click Clear Button", "Click");
		}
		Thread.sleep(2000);
	}
}