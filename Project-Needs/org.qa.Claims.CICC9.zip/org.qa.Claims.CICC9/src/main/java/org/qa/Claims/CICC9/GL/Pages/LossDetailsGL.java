package org.qa.Claims.CICC9.GL.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class LossDetailsGL {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	String SheetName = "ClaimsPolicy";	
	
	public LossDetailsGL(WebDriver driver)
	{
		this.driver = driver;
	}	
	
	public void LossDetailsGLPage(String excelFileName, String profileID) throws Exception{		
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		
		String btnAddInjuiryLoss = xlsread.Exceldata(SheetName, "btnAddInjuiryLoss", profileID);
		String btnEditInjuiry = xlsread.Exceldata(SheetName, "btnEditInjuiry", profileID);
		String ddlInsuredFault = xlsread.Exceldata(SheetName, "ddlInsuredFault", profileID);
		String ddlInsuredWeather = xlsread.Exceldata(SheetName, "ddlInsuredWeather", profileID);
		String btnLossUpdateButton = xlsread.Exceldata(SheetName, "btnLossUpdateButton", profileID);
		
        
		//Loss Details Input
  		Thread.sleep(4000);
  		UIMethods.selectbyid("ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Notification_Fault", "input insured fault rating", ddlInsuredFault);
  		Thread.sleep(8000);  		
        UIMethods.selectbyid("ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:Claim_Weather", "input insured weather", ddlInsuredWeather);
        Thread.sleep(2000);
		
		if (!(btnAddInjuiryLoss.isEmpty())) {
        UIMethods.jscriptclickbyxpath("//*[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:EditableInjuryIncidentsLV_tb:Add']", "click Add Injuiry button", "Click");
        Thread.sleep(3000);
        }        
	
		//click edit injuiry link
        if (!(btnEditInjuiry.isEmpty())) {
		UIMethods.jscriptclickbyxpath("//*[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:EditableInjuryIncidentsLV:0:_Checkbox']", "Click checkbox", "Click");
		UIMethods.jscriptclickbyxpath("//*[@id='ClaimLossDetails:ClaimLossDetailsScreen:LossDetailsPanelSet:LossDetailsCardCV:LossDetailsDV:EditableInjuryIncidentsLV:0:Name']", "Click Name link", "Click");
		Thread.sleep(3000);
        }        
            //Loss Details Update
            if (!(btnLossUpdateButton.isEmpty())) {
    	        UIMethods.jscriptclickbyxpath("//*[@id='ClaimLossDetails:ClaimLossDetailsScreen:Update']/span[2]", "click update button", "Click");
    	        Thread.sleep(3000);
            }
	}
}