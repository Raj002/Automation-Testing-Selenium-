package org.qa.Claims.CICC9.Property.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.CommonScreens.NewPersonContactDetail;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class NewPropertyIncident extends Object_Repositories {

	public WebDriver driver = null;
	
	// Local variables
	String txtPropertyDescription;
	String txtDamageDescription;
	String ddlSeverity;
	String ddlPropertyName;
	String txtPropertyAddress1;
	String txtPropertyCity;
	String ddlPropertyState;
	String txtLocationNumber;
	String txtBuildingNumber;

	// Page Objects
	String propertyDescription = "//input[contains(@id,'PropertyDescription-inputEl')]";
	String damageDesctiption = "//textarea[contains(@id,'Description-inputEl')]";
	String severityDropdown = "//input[contains(@id,'Severity-inputEl')]";
	String habitableRDB = "//input[contains(@id,'PropertyHabitable_true-inputEl')]";
	String propertyName = "//input[contains(@id,'Address_Picker-inputEl')]";
	String propertyAddress1 = "//input[contains(@id,'AddressLine1-inputE')]";
	String propertyCity = "//input[contains(@id,'City-inputE')]";
	String propertyState = "//input[contains(@id,'State-inputE')]";
	String propertyZipCode = "//input[contains(@id,'PostalCode-inputE')]";
	String locationNumber = "//input[contains(@id,'Address_LocationNumber-inputE')]";
	String buildingNumber = "//input[contains(@id,'Address_BuildingNumber-inputE')]";
	String OkButton = "//span[text()='OK']";

	String propertyNameIcon = "//div[contains(@id,'Address_Picker-trigger-picker')]";
	
	public NewPropertyIncident(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 15);
	}

	public void PropertyIncidentPage(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		txtPropertyDescription = xlsread.Exceldata(SheetName, "txtPropertyDescription", profileID);
		txtDamageDescription = xlsread.Exceldata(SheetName, "txtDamageDescription", profileID);
		ddlSeverity = xlsread.Exceldata(SheetName, "ddlSeverity", profileID);
		ddlPropertyName = xlsread.Exceldata(SheetName, "ddlPropertyName", profileID);
		String txtAddrLine1 = xlsread.Exceldata(SheetName, "txtAddrLine1", profileID);
		String txtAddrCity = xlsread.Exceldata(SheetName, "txtAddrCity", profileID);
		String txtAddrState = xlsread.Exceldata(SheetName, "txtAddrState", profileID);
		String txtAddrZip = xlsread.Exceldata(SheetName, "txtAddrZip", profileID);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(returnToExposureLink)));
		UIMethods.inputbyxpath(propertyDescription, "Enter Property Description", txtPropertyDescription);
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(damageDesctiption)));
		UIMethods.inputbyxpath(damageDesctiption, "Enter Damage Description", txtDamageDescription);
		
		Helper.selectDropdownValue(driver, "xpath", severityDropdown, "Select Severity", ddlSeverity);	
		
		if(driver.findElements(By.xpath(habitableRDB)).size()!=0) {
			UIMethods.clickbyxpath(habitableRDB, "Select Is property Habitable radio button", "Click");
		}

		Helper.selectDropdownValue(driver, "xpath", propertyName, "Select Property Name", ddlPropertyName);
		Thread.sleep(500);

		// Enter Property details
		if (driver.findElements(By.xpath(propertyAddress1)).size() != 0) {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(propertyAddress1)));
			UIMethods.inputbyxpath(propertyAddress1, "Enter Address Line1", txtAddrLine1);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(propertyZipCode)));
			UIMethods.inputbyxpath(propertyZipCode, "Enter Zip Code", txtAddrZip);
			/*wait.until(ExpectedConditions.elementToBeClickable(By.xpath(propertyCity)));
			UIMethods.inputbyxpath(propertyCity, "Enter City", txtAddrCity);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(propertyState)));
			Helper.selectDropdownValue(driver, "xpath", propertyState, "Select address state", txtAddrState);*/
		}
		
		if(driver.findElements(By.xpath(locationNumber)).size()!=0) {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locationNumber)));
			UIMethods.inputbyxpath(locationNumber, "Enter Location Number", "12345");
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(buildingNumber)));
			UIMethods.inputbyxpath(buildingNumber, "Enter Building Number", "12345");
		}
				
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(OkButton)));
		UIMethods.jscriptclickbyxpath(OkButton, "Click Ok Button", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(newExposureTitle)));
	}

	public void PropertyLiabilityIncidentPage(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		txtPropertyDescription = xlsread.Exceldata(SheetName, "txtPropertyDescription", profileID);
		txtDamageDescription = xlsread.Exceldata(SheetName, "txtDamageDescription", profileID);
		ddlSeverity = xlsread.Exceldata(SheetName, "ddlSeverity", profileID);
		ddlPropertyName = xlsread.Exceldata(SheetName, "ddlPropertyName", profileID);
		txtPropertyAddress1 = xlsread.Exceldata(SheetName, "ddlPropertyAddress1", profileID);
		txtPropertyCity = xlsread.Exceldata(SheetName, "ddlPropertyCity", profileID);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(propertyDescription)));
		UIMethods.inputbyxpath(propertyDescription, "Enter Property Description", txtPropertyDescription);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(damageDesctiption)));
	
		UIMethods.inputbyxpath(damageDesctiption, "Enter Damage Description", txtDamageDescription);
		Helper.selectDropdownValue(driver, "xpath", severityDropdown, "Select Severity", ddlSeverity);	
		
		//Added by RAJ this field only appear property claim
		if(driver.findElements(By.xpath(habitableRDB)).size()!=0) {
			UIMethods.clickbyxpath(habitableRDB, "Select Is property Habitable radio button", "Click");
		}	
		
		/*driver.findElement(By.xpath(propertyNameIcon)).click();
		if(driver.findElements(By.xpath(firstDropdownOption)).size()!=0) {			
			UIMethods.jscriptclickbyxpath(firstDropdownOption, "Select Property Name", "Click");

		} else {
			Helper.selectDropdownValue(driver, "xpath", propertyName, "Select Severity", ddlPropertyName);
			wait.until(ExpectedConditions.elementToBeClickable(By.id(propertyAddress1)));
			UIMethods.inputbyid(propertyAddress1, "Input Property Address1", txtPropertyAddress1);
			wait.until(ExpectedConditions.elementToBeClickable(By.id(propertyCity)));
			UIMethods.inputbyid(propertyCity, "Input Property City", txtPropertyCity);
		}*/
		
		Helper.highLightElement(driver, driver.findElement(By.xpath(OkButton)));
		UIMethods.jscriptclickbyxpath(OkButton, "Click Ok Button", "Click");
	}
	
	public void PropertyIncidentWithoutHabitable(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		txtPropertyDescription = xlsread.Exceldata(SheetName, "txtPropertyDescription", profileID);
		txtDamageDescription = xlsread.Exceldata(SheetName, "txtDamageDescription", profileID);
		ddlSeverity = xlsread.Exceldata(SheetName, "ddlSeverity", profileID);
		ddlPropertyName = xlsread.Exceldata(SheetName, "ddlPropertyName", profileID);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(returnToExposureLink)));
		UIMethods.inputbyxpath(propertyDescription, "Enter Property Description", txtPropertyDescription);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(damageDesctiption)));
		UIMethods.inputbyxpath(damageDesctiption, "Enter Damage Description", txtDamageDescription);
		Helper.selectDropdownValue(driver, "xpath", severityDropdown, "Select Severity", ddlSeverity);	
		Helper.selectDropdownValue(driver, "xpath", propertyName, "Select Property name", ddlPropertyName);
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(OkButton)));		
		UIMethods.jscriptclickbyxpath(OkButton, "Click Ok Button", "Click");
	}

	public void NewPropertyIncidentPage(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		txtPropertyDescription = xlsread.Exceldata(SheetName, "txtPropertyDescription", profileID);
		txtDamageDescription = xlsread.Exceldata(SheetName, "txtDamageDescription", profileID);
		ddlSeverity = xlsread.Exceldata(SheetName, "ddlSeverity", profileID);
		ddlPropertyName = xlsread.Exceldata(SheetName, "ddlPropertyName", profileID);
		txtPropertyAddress1 = xlsread.Exceldata(SheetName, "txtPropertyAddress1", profileID);
		txtPropertyCity = xlsread.Exceldata(SheetName, "txtPropertyCity", profileID);
		ddlPropertyState = xlsread.Exceldata(SheetName, "ddlPropertyState", profileID);
		txtLocationNumber = xlsread.Exceldata(SheetName, "txtLocationNumber", profileID);
		txtBuildingNumber = xlsread.Exceldata(SheetName, "txtBuildingNumber", profileID);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(returnToExposureLink)));
		UIMethods.inputbyid(propertyDescription, "Input Property Description", txtPropertyDescription);
		UIMethods.inputbyid(damageDesctiption, "Input Damage Description", txtDamageDescription);
		UIMethods.selectbyid(severityDropdown, "Input Severity", ddlSeverity);
		UIMethods.clickbyid(habitableRDB, "Is property Habitable rdb", "Click");

		if (!(ddlPropertyName.isEmpty())) {
			String strExpected = "New";
			if (ddlPropertyName.contains(strExpected)) {
				UIMethods.selectbyid(propertyName, "input PropertyName", "New...");
			} else {
				UIMethods.selectbyid(propertyName, "input PropertyName", ddlPropertyName);
			}
			Thread.sleep(3000);
		}

		UIMethods.inputbyid(propertyAddress1, "Input Property Address1", txtPropertyAddress1);
		UIMethods.inputbyid(propertyCity, "Input Property City", txtPropertyCity);
		UIMethods.selectbyid(propertyState, "Input Property State", ddlPropertyState);
		UIMethods.inputbyid(locationNumber, "Input Location Number", txtLocationNumber);
		UIMethods.inputbyid(buildingNumber, "Input Buidling Number", txtBuildingNumber);
		UIMethods.jscriptclickbyxpath(OkButton, "Click Ok Button", "Click");

	}

	public void NewPropertyIncidentWithoutHB(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		txtPropertyDescription = xlsread.Exceldata(SheetName, "txtPropertyDescription", profileID);
		txtDamageDescription = xlsread.Exceldata(SheetName, "txtDamageDescription", profileID);
		ddlSeverity = xlsread.Exceldata(SheetName, "ddlSeverity", profileID);
		ddlPropertyName = xlsread.Exceldata(SheetName, "ddlPropertyName", profileID);
		txtPropertyAddress1 = xlsread.Exceldata(SheetName, "txtPropertyAddress1", profileID);
		txtPropertyCity = xlsread.Exceldata(SheetName, "txtPropertyCity", profileID);
		ddlPropertyState = xlsread.Exceldata(SheetName, "ddlPropertyState", profileID);
		txtLocationNumber = xlsread.Exceldata(SheetName, "txtLocationNumber", profileID);
		txtBuildingNumber = xlsread.Exceldata(SheetName, "txtBuildingNumber", profileID);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(returnToExposureLink)));
		UIMethods.inputbyid(propertyDescription, "Input Property Description", txtPropertyDescription);
		Thread.sleep(2000);
		UIMethods.inputbyid(damageDesctiption, "Input Damage Description", txtDamageDescription);
		Thread.sleep(2000);
		UIMethods.selectbyid(severityDropdown, "Input Severity", ddlSeverity);
		Thread.sleep(2000);
		UIMethods.selectbyid(propertyName, "Input Property Name", ddlPropertyName);
		Thread.sleep(2000);
		UIMethods.inputbyid(propertyAddress1, "Input Property Address1", txtPropertyAddress1);
		Thread.sleep(2000);
		UIMethods.inputbyid(propertyCity, "Input Property City", txtPropertyCity);
		Thread.sleep(2000);
		UIMethods.selectbyid(propertyState, "Input Property State", ddlPropertyState);
		Thread.sleep(2000);
		UIMethods.inputbyid(locationNumber, "Input Location Number", txtLocationNumber);
		Thread.sleep(2000);
		UIMethods.inputbyid(buildingNumber, "Input Buidling Number", txtBuildingNumber);
		Thread.sleep(2000);
		Helper.highLightElement(driver, driver.findElement(By.xpath("//span[text()='OK']")));
		UIMethods.jscriptclickbyxpath(OkButton, "Click Ok Button", "Click");
	}
}