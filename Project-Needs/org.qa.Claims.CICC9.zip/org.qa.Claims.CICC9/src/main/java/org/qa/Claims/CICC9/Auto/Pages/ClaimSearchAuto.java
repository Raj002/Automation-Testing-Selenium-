package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class ClaimSearchAuto extends Object_Repositories{
	
	private WebDriver driver=null;
	
	//Page Objects
	//String claimMenu = "//a/span[@id='TabBar:ClaimTab-btnWrap']/self::span";
	
	public ClaimSearchAuto(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 15);
	}
	
	public void ClaimsSearch(String excelFileName, String profileID) throws Exception { 
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtClaimNumber = xlsread.Exceldata(SheetName, "txtClaimNumber", profileID);
		
		// Added by RAJ
		Helper.waitForLoad(driver);

		WebElement ClaimMenu = driver.findElement(By.xpath(claimMenu));
		Actions action = new Actions(driver);
		action.moveToElement(ClaimMenu, ClaimMenu.getSize().width - 2, 2).click().build().perform();		
		UIMethods.inputbyid(claimNumberField, "input claimnumber", txtClaimNumber);
		UIMethods.jscriptclickbyxpath(searchIcon, "Click Search Icon", "Click");
		Thread.sleep(3000);		
	}
	
	public void SearchClaim(String excelFileName, String profileID) throws Exception {
		xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtClaimNumber = xlsread.Exceldata(SheetName, "txtClaimNumber", profileID);
        
        //***************click claims links and new claims
		WebElement ClaimMenu = driver.findElement(By.xpath(claimMenu));
		Actions action = new Actions(driver);
		action.moveToElement(ClaimMenu, ClaimMenu.getSize().width - 2, 2).click().build().perform();	
		UIMethods.inputbyid(claimNumberField, "input claimnumber", txtClaimNumber);
		UIMethods.jscriptclickbyxpath(searchIcon, "Click Search Icon", "Click");
		Thread.sleep(2000);		
	}
}