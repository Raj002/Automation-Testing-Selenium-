package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class SaveAndAssignClaim extends Object_Repositories{
	
	private WebDriver driver;
	
	WebDriverWait wait;
	
	//Page Objects
	String assignClaimAllExposureRadioButton = "//input[contains(@id,'CommonAssignChoice_Choice-inputEl')]";	
	String assignAllExposureDropdownField = "//input[contains(@id,'CommonAssign-inputE')]";	
	String finishButton = "//a[@id='FNOLWizard:Finish']/span";
	
	public SaveAndAssignClaim(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 30);
	}
	
	public void SaveAndAssignClaimpage() throws Exception {
		
		if(driver.findElements(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_DocumentsScreen:ttlBar")).size()!=0) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_DocumentsScreen:ttlBar")));
			UIMethods.jscriptclickbyxpath(nextButton, "click Next button", "Click");	
		}
				
		// Updated by RAJ
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Save and Assign Claim')]")));
		UIMethods.clickbyxpath("//input[contains(@id,'CommonAssignChoice_Choice-inputEl')]", "Select assign claim & all exposure to RADIO BUTTON", "Click");
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(assignAllExposureDropdownField)));
		UIMethods.jscriptclickbyxpath(assignAllExposureDropdownField, "Select assign claim and all exposure to: Drop down value", "Click");
		driver.findElement(By.xpath(firstDropdownOption)).click();		
				
		Helper.highLightElement(driver, driver.findElement(By.xpath(finishButton)));
		UIMethods.clickbyxpath(finishButton, "click finish button", "Click");
		Thread.sleep(9000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='NewClaimSaved:NewClaimSavedScreen:ttlBar' and text()='New Claim Saved']")));     
	}
	
	public void SaveAndAssignClaimpage(String TCNO) throws Exception {
		
		if(driver.findElements(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_DocumentsScreen:ttlBar")).size()!=0) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_DocumentsScreen:ttlBar")));
			UIMethods.jscriptclickbyxpath(nextButton, "click Next button", "Click");	
		}
				
		// Updated by RAJ
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Save and Assign Claim')]")));
		UIMethods.clickbyxpath("//input[contains(@id,'CommonAssignChoice_Choice-inputEl')]", "Select assign claim & all exposure to RADIO BUTTON", "Click");
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(assignAllExposureDropdownField)));
		UIMethods.jscriptclickbyxpath(assignAllExposureDropdownField, "Select assign claim and all exposure to: Drop down value", "Click");
		Thread.sleep(1000);
		if(driver.findElements(By.xpath(firstDropdownOption)).size()!=0) {
			driver.findElement(By.xpath(firstDropdownOption)).click();	
		}				
		
		Helper.getScreenshot(driver, "Save_And_Assign_Screen", "TC_" +TCNO+ "_");
		
		Helper.highLightElement(driver, driver.findElement(By.xpath(finishButton)));
		UIMethods.clickbyxpath(finishButton, "click finish button", "Click");
		Thread.sleep(9000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='NewClaimSaved:NewClaimSavedScreen:ttlBar' and text()='New Claim Saved']")));     
	}
}