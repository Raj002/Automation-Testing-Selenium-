package org.qa.Claims.CICC9.CommonScreens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class ActionMenuNavigations {
	private WebDriver driver = null;
	WebDriverWait wait;

	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");

	// Page Objects
	String claimMenuActions = "//*[@id='Claim:ClaimMenuActions_arrow']/span";
	String noteField = "CloseClaimPopup:CloseClaimScreen:CloseClaimInfoDV:Note";
	String newNoteSubMenu = "//*[@id='Claim:ClaimMenuActions:ClaimNewOtherMenuItemSet:ClaimMenuActions_NewOther:ClaimMenuActions_NewNote']";
	String emailSubMenu = "//div[@id='menu_item_Claim:ClaimMenuActions:ClaimNewOtherMenuItemSet:ClaimMenuActions_NewOther_Claim:ClaimMenuActions:ClaimNewOtherMenuItemSet:ClaimMenuActions_NewOther:ClaimMenuActions_Email']";
	String evaluationSubMenu = "//div[@id='menu_item_Claim:ClaimMenuActions:ClaimNewOtherMenuItemSet:ClaimMenuActions_NewOther_Claim:ClaimMenuActions:ClaimNewOtherMenuItemSet:ClaimMenuActions_NewOther:ClaimMenuActions_NewEvaluation']/a";
	
	public ActionMenuNavigations(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}

	public void ActionMenuClosePage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtNoteCloseClaim = xlsread.Exceldata(SheetName, "txtNoteCloseClaim", profileID);
		String ddlOutcomeCloseClaim = xlsread.Exceldata(SheetName, "ddlOutcomeCloseClaim", profileID);
		
		Thread.sleep(4000);
		//Updated by RAJ
		UIMethods.jscriptclickbyxpath(claimMenuActions, "Click Claim Menu Actions", "Click");
		Thread.sleep(5000);
		UIMethods.jscriptclickbyxpath("//div[@id='menu_item_Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions_Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions:ClaimMenuActions_CloseClaim']/a", "Click Close Claim", "Click");
		//UIMethods.clickbyxpath("//div[@id='menu_item_Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions_Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions:ClaimMenuActions_CloseClaim']/a", "Click Close Claim", "Click");
		Thread.sleep(7000);
		UIMethods.clickbyid(noteField, "Click Note", "Click");
		wait.until(ExpectedConditions.elementToBeClickable(By.id(noteField)));
		UIMethods.inputbyid(noteField, "input Note", txtNoteCloseClaim);
		Thread.sleep(3000);
		UIMethods.selectbyid("CloseClaimPopup:CloseClaimScreen:CloseClaimInfoDV:Outcome", "input Outcome", ddlOutcomeCloseClaim);
		Thread.sleep(3000);
		Helper.highLightElement(driver, driver.findElement(By.id("CloseClaimPopup:CloseClaimScreen:Update")));
		UIMethods.clickbyid("CloseClaimPopup:CloseClaimScreen:Update", "Click Close Claim", "Click");
		Thread.sleep(2000);
	}
	
	public void ActionMenuMatterPage() throws Exception{
		UIMethods.jscriptclickbyxpath(claimMenuActions, "Click ClaimMenuActions", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimNewOtherMenuItemSet:ClaimMenuActions_NewOther:ClaimMenuActions_NewMatter']", "Click Matter submenu", "Click");
		Thread.sleep(3000);
	}
	
	public void ActionMenuReservePage() throws Exception {
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath(claimMenuActions)));
		Thread.sleep(4000);
		UIMethods.jscriptclickbyxpath(claimMenuActions, "Click Claim Menu Actions", "Click");
		Thread.sleep(3000);
		UIMethods.jscriptclickbyxpath("//div[@id='menu_item_Claim:ClaimMenuActions:ClaimMenuActions_NewTransaction_Claim:ClaimMenuActions:ClaimMenuActions_NewTransaction:ClaimMenuActions_NewTransaction_ReserveSet']/a", "Click Reserve submenu", "Click");
		Thread.sleep(3000);
	}
	
	public void ActionMenuValidateClaimExposure() throws Exception{
		UIMethods.clickbyxpath("//*[text()='ctions']", "Click ClaimMenuActions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions:ClaimMenuActions_ClaimExposureValidation']", "Click Validate Claim and Exposure", "Click");
		Thread.sleep(2000);
		Helper.highLightElement(driver, driver.findElement(By.xpath("//*[@id='Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions:ClaimMenuActions_ClaimExposureValidation:4:item']")));
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions:ClaimMenuActions_ClaimExposureValidation:4:item']", "Click Ability to Pay Option", "Click");
		Thread.sleep(3000);
	}
	
	public void ActionMenuEvaluationPage() throws Exception{
		UIMethods.clickbyxpath("//*[text()='ctions']", "Click ClaimMenuActions", "Click");
		Thread.sleep(1000);									
		UIMethods.jscriptclickbyxpath(evaluationSubMenu, "Click Evaluation submenu from Actions", "Click");
		Thread.sleep(3000);
	}
	
	public void ActionMenuNotePage() throws Exception{
		UIMethods.clickbyxpath("//*[text()='ctions']", "Click ClaimMenuActions", "Click");
		Thread.sleep(1000);
		UIMethods.clickbyxpath(newNoteSubMenu, "Click New Note submenu", "Click");
		Thread.sleep(3000);
	}
	
	public void ActionMenuAssignClaim() throws Exception{
		UIMethods.clickbyxpath(claimMenuActions, "Click ClaimMenuActions", "Click");
		Thread.sleep(3000);
		UIMethods.jscriptclickbyxpath("//div[@id='menu_item_Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions_Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions:ClaimMenuActions_Assign']/a", "Click Assign Claim submenu", "Click");
		//UIMethods.clickbyxpath("//div[@id='menu_item_Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions_Claim:ClaimMenuActions:ClaimFileMenuItemSet:ClaimMenuActions_ClaimActions:ClaimMenuActions_Assign']/a", "Click Assign Claim submenu", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("AssignClaimsPopup:AssignmentPopupScreen:AssignmentPopupDV:SelectFromList")));
	}
	
	public void ActionMenuTransactionCheckPage() throws Exception{
		Thread.sleep(2000);
		UIMethods.jscriptclickbyxpath(claimMenuActions, "Click ClaimMenuActions", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewTransaction:ClaimMenuActions_NewTransaction_CheckSet']", "Click Transaction check", "Click");
		Thread.sleep(2000);
	}
	
	public void ActionMenuEmailPage() throws Exception{
		UIMethods.clickbyxpath(claimMenuActions, "Click ClaimMenuActions", "Click");
		Thread.sleep(2000);
		//Helper.clickElementByJS(driver, driver.findElement(By.xpath(emailOption)));
		UIMethods.jscriptclickbyxpath(emailSubMenu, "Click Email link from Actions Menu", "Click");
	}
	
	public void ActionMenuTransactionRecoveryPage() throws Exception{
		UIMethods.clickbyxpath(claimMenuActions, "Click ClaimMenuActions", "Click");
		UIMethods.clickbyxpath("//*[@id='Claim:ClaimMenuActions:ClaimMenuActions_NewTransaction:ClaimMenuActions_NewTransaction_RecoverySet']", "Click Transaction Recovery", "Click");
		Thread.sleep(2000);
	}
	
	public void ContactCenterActionMenuMatterPage() throws Exception{
        
		// Updated by RAJ
		Helper.waitForLoad(driver);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("top_frame");
        Thread.sleep(5000);
		
		UIMethods.clickbyxpath("//a[@id='ABContacts:ContactsMenuActions_arrow']/span", "Click Actions", "Click");
		Thread.sleep(2000);
		UIMethods.jscriptclickbyxpath("//*[@id='ABContacts:ContactsMenuActions:ContactsMenuActions_NewPersonMenuItem']", "New person Submenu", "Click");
		Thread.sleep(2000);
		UIMethods.jscriptclickbyxpath("//*[@id='ABContacts:ContactsMenuActions:ContactsMenuActions_NewPersonMenuItem:ContactsMenuActions_UserContactMenuItem']", "User Contact Submenu", "Click");
		Thread.sleep(3000);
	}
	
	public void ActionNotePage() throws Exception {
		UIMethods.jscriptclickbyxpath(claimMenuActions, "Click ClaimMenuActions", "Click");
		Thread.sleep(1000);
		UIMethods.jscriptclickbyxpath(newNoteSubMenu, "Click Note submenu", "Click");
		Thread.sleep(3000);
	}	
}