package org.qa.Claims.CICC9.Auto.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class AUFFClaimCreation extends Object_Repositories{
	
	private WebDriver driver=null;
	WebDriverWait wait;

	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	String locationServicesProvidedField = "//input[@id='FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:FNOLWizardCheckDV:SIL_State-inputEl']";
	String vendorRadioButton = "//input[@id='FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:FirstFinalReportedAgencyRadioButton_option1-inputEl']";
	String vendorArrowIcon = "//a[@id='FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:AutoFirstAndFinalReportedPanelSet:FNOLWizardAutoFirstAndFinalPanelSet:CompanySubtypeReporter:CompanySubtypeReporterMenuIcon']/img";
	
	String searchOption = "//div[@id='FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:AutoFirstAndFinalReportedPanelSet:FNOLWizardAutoFirstAndFinalPanelSet:CompanySubtypeReporter:ClaimSearchViewCompanySubtypesPickerMenuItemSet:Search_Parent']/a/span[text()='Search']";
	String nameField= "//input[@id='AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchDV:Keyword-inputEl']";
	
	
	public AUFFClaimCreation(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 15);
	}

	public void AUFFClaimCreationpage(String excelFileName, String profileID) throws Exception {
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String txtSILState = xlsread.Exceldata(SheetName, "txtSILState", profileID);
		String txtSearchKeyword = xlsread.Exceldata(SheetName, "txtSearchKeyword", profileID);
		
		//AU FF Claim Creation
		Helper.selectDropdownValue(driver, "xpath", locationServicesProvidedField, "Select Location were services were provided", txtSILState);
		UIMethods.clickbyxpath(vendorRadioButton, "Select Vedor radio butotn", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(vendorArrowIcon)));
        UIMethods.jscriptclickbyxpath(vendorArrowIcon, "Click Vendor icon", "Click");
        UIMethods.jscriptclickbyxpath(searchOption, "Click Search option", "Click");
        driver.findElement(By.xpath(searchOption)).sendKeys(Keys.ARROW_RIGHT);
        
        
        
       /* Actions action = new Actions(driver);
        WebElement focmenu = driver.findElement(By.id("FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:AutoFirstAndFinalReportedPanelSet:FNOLWizardAutoFirstAndFinalPanelSet:CompanySubtypeReporter:ClaimSearchViewCompanySubtypesPickerMenuItemSet:Search_Parent"));
        WebElement focmenu1 = driver.findElement(By.id("FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:AutoFirstAndFinalReportedPanelSet:FNOLWizardAutoFirstAndFinalPanelSet:CompanySubtypeReporter:ClaimSearchViewCompanySubtypesPickerMenuItemSet:Search_Parent:Search_AutoRepairShop"));
        action.moveToElement(focmenu);
        action.build().perform();
        action.moveToElement(focmenu1);
        //action.click();
        action.build().perform();*/
        UIMethods.jscriptclickbyxpath("//*[@id='FNOLWizard:FNOLWizard_AutoFirstAndFinalScreen:AutoFirstAndFinalReportedPanelSet:FNOLWizardAutoFirstAndFinalPanelSet:CompanySubtypeReporter:ClaimSearchViewCompanySubtypesPickerMenuItemSet:Search_Parent:Search_VendorCompany']", "Click Search Vendor Company", "Click");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(nameField)));        
        UIMethods.inputbyxpath(nameField, "Enter Name to Search", txtSearchKeyword);
        
        UIMethods.clickbyxpath(searchButton, "Click Search button", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("")));		
		UIMethods.clickbyid("AddressBookPickerPopup:AddressBookSearchScreen:AddressBookSearchLV:0:_Select_link", "Click Select_link", "Click");
	}
}