package org.qa.Claims.CICC9.Property.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class ClaimSimpleSearch {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	
	String exposureLink = "//div[@id='leftnavmenu']/a[@id='Desktop:MenuLinks:Desktop_DesktopExposures']/div";
	String searchMenu = "//*[@id='TabBar:SearchTab']";
	
	public ClaimSimpleSearch(WebDriver driver)
	{
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}	
	
	public void ClaimsSearchPropertyPage(String excelFileName, String profileID) throws Exception{
		// Added by RAJ
		Helper.waitForLoad(driver);
		driver.switchTo().defaultContent();
		driver.switchTo().frame("top_frame");
		Thread.sleep(5000);
		
        //***************Read data from excel
        String SheetName = "ClaimsPolicy";
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");

		String claimnumb = xlsread.Exceldata(SheetName, "txtClaimNo", profileID);
        
        //***************click claims links and new claims
		// Click on Claims TAB and navigate to New Claims option
        Helper.highLightElement(driver, driver.findElement(By.xpath(exposureLink)));
		UIMethods.clickbyxpath(exposureLink, "Click on Exposure link", "Click");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(searchMenu)));
		Helper.highLightElement(driver, driver.findElement(By.xpath(searchMenu)));
		UIMethods.clickbyxpath(searchMenu, "Click search link", "Click");
		
		if (claimnumb.equalsIgnoreCase("EXISTING")) {
			claimnumb = NewClaimSaved.intClaimNumber;
		}
		
		UIMethods.inputbyid("SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchDV:ClaimNumber", "input claimnumber", claimnumb);
		UIMethods.clickbyxpath("//*[@id='SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchDV:ClaimSearchAndResetInputSet:Search_link']", "click search button", "Click");
		Thread.sleep(4000);
		Helper.highLightElement(driver, driver.findElement(By.xpath("//*[@id='SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchResultsLV:0:ClaimNumber']")));
		UIMethods.clickbyxpath("//*[@id='SimpleClaimSearch:SimpleClaimSearchScreen:SimpleClaimSearchResultsLV:0:ClaimNumber']", "click claim link", "Click");
		Thread.sleep(4000);
	}
}