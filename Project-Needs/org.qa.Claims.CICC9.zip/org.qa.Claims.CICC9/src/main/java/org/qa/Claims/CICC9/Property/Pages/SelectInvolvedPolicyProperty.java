package org.qa.Claims.CICC9.Property.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class SelectInvolvedPolicyProperty extends Object_Repositories {
	
	public WebDriver driver;
	
	public SelectInvolvedPolicyProperty(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 15);
	}
	
	public void SelectInvolvedPolicyPropertypage() throws Exception {
		Thread.sleep(3000);
		if (driver.findElements(By.xpath("//span[contains(text(),'Select Involved Policy')]")).size() != 0) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FNOLWizard:FNOLWizard_PickPolicyRiskUnitsScreen:ttlBar")));
			UIMethods.jscriptclickbyxpath(commonCheckBox, "Click First checkbox from Select Involved Policy Properties/Vehicles", "Click");
			//Helper.clickCheckBox(commonCheckBox,"Click First checkbox from Select Involved Policy Properties/Vehicles");
			UIMethods.clickbyxpath(nextButton, "Click Next button", "Click");
		}	
	}
	
	// Just select Next button only
	public void SelectInvolvedPolicyPropertypageNextPageOnly() throws Exception {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FNOLWizard:FNOLWizard_PickPolicyRiskUnitsScreen:ttlBar")));		
		UIMethods.clickbyxpath(nextButton, "Click Next button", "Click");
	}
}