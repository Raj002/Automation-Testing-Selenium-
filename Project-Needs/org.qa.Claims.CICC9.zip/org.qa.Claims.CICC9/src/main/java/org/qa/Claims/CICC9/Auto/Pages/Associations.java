package org.qa.Claims.CICC9.Auto.Pages;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;

public class Associations {

	private WebDriver driver = null;
	WebDriverWait wait;

	public Associations(WebDriver driver) {
		this.driver = driver;
	}

	public void Association(String excelFileName, String profileID) throws Exception {
		String SheetName = "ClaimsPolicy";
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		String ClaimAssoTitle = xlsread.Exceldata(SheetName, "txtClaimAssoTitle", profileID);
		String ddlClaimAssoType = xlsread.Exceldata(SheetName, "ddlClaimAssoType", profileID);
		String UpdateBtn = xlsread.Exceldata(SheetName, "btnAssocUpdate", profileID);
		String lnkAssoc = xlsread.Exceldata(SheetName, "lnkAssoc", profileID);
		String btnNewAssoc = xlsread.Exceldata(SheetName, "btnNewAssoc", profileID);
		String btnAddClaims = xlsread.Exceldata(SheetName, "btnAddClaims", profileID);
		String btnSearch = xlsread.Exceldata(SheetName, "btnAssocSearch", profileID);

		if (!(lnkAssoc.isEmpty())) {
			UIMethods.clickbyid("ClaimLossDetailsGroup:MenuLinks:ClaimLossDetailsGroup_ClaimAssociations","click Associations Hyperlink", "Click");
			Thread.sleep(3000);
		}

		if (!(btnNewAssoc.isEmpty())) {
			UIMethods.clickbyid("ClaimAssociations:ClaimAssociationsScreen:ClaimAssociations_NewButton","click new association button", "Click");
			Thread.sleep(3000);
		}

		if (!(ClaimAssoTitle.isEmpty())) {
			if (ClaimAssoTitle.contains("UNIQUE")) {
				ClaimAssoTitle = ClaimAssoTitle.replace("UNIQUE", "");
				SimpleDateFormat formatter = new SimpleDateFormat("MMddyyhhmmssms");
				Calendar currentDate = Calendar.getInstance();
				ClaimAssoTitle = ClaimAssoTitle + formatter.format(currentDate.getTime());
			}
		}

		UIMethods.inputbyid("NewClaimAssociation:ClaimAssociationDetailScreen:ClaimAssociationDetailDV:Title","Enter  Title", ClaimAssoTitle);
		Thread.sleep(3000);
		UIMethods.selectbyid("NewClaimAssociation:ClaimAssociationDetailScreen:ClaimAssociationDetailDV:Type","Select Claim association Type", ddlClaimAssoType);
		Thread.sleep(2000);

		if (!(btnAddClaims.isEmpty())) {
			UIMethods.clickbyid("NewClaimAssociation:ClaimAssociationDetailScreen:ClaimAssociationDetailDV:EditableClaimsInAssociationLV_tb:Add","Click Add Claims Button", "Click");
			Thread.sleep(3000);
		}

		if (!(btnSearch.isEmpty())) {
			UIMethods.clickbyid("NewClaimAssociation:ClaimAssociationDetailScreen:ClaimAssociationDetailDV:EditableClaimsInAssociationLV:1:Claim:SelectClaim","Click Search Button", "Click");
			Thread.sleep(3000);
		}

		if (!(UpdateBtn.isEmpty())) {
			UIMethods.clickbyid("NewClaimAssociation:ClaimAssociationDetailScreen:Update", "Click Update Button",UpdateBtn);
			Thread.sleep(3000);
		}
	}
}