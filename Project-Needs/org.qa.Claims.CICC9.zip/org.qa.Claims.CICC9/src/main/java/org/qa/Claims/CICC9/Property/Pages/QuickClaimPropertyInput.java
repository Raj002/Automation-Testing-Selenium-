package org.qa.Claims.CICC9.Property.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;

public class QuickClaimPropertyInput extends Object_Repositories {
	
	private WebDriver driver=null;
	WebDriverWait wait;
	String SheetName = "ClaimsPolicy";
	String projectdir = System.getProperty("user.dir");
	
	//Page Objects
	//String finishButton = "//a[@id='FNOLWizard:Finish']/span[text()='inish']";
	String lossDescription = "FNOLWizard:NewClaimWizard_QuickClaimScreen:QuickClaimDV:Claim_Description-inputEl";
	String lossCause = "FNOLWizard:NewClaimWizard_QuickClaimScreen:QuickClaimDV:Claim_LossCause-inputEl";
	String detailedLossCause = "FNOLWizard:NewClaimWizard_QuickClaimScreen:QuickClaimDV:DetailedLossCause-inputEl";
	String lossLocation = "FNOLWizard:NewClaimWizard_QuickClaimScreen:QuickClaimDV:CCAddressInputSet:globalAddressContainer:Address_Picker-inputEl";
	String claimantName = "FNOLWizard:NewClaimWizard_QuickClaimScreen:QuickClaimDV:Claimant_Picker-inputEl";
	String claimantType = "FNOLWizard:NewClaimWizard_QuickClaimScreen:QuickClaimDV:Claimant_Type-inputEl";
	String propertyName = "FNOLWizard:NewClaimWizard_QuickClaimScreen:QuickClaimDV:IncidentLocation:CCAddressInputSet:globalAddressContainer:Address_Picker-inputEl";
	String propertyAddressLine1 = "FNOLWizard:NewClaimWizard_QuickClaimScreen:QuickClaimDV:IncidentLocation:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:AddressLine1-inputEl";
	//String propertyLocationNumber = "";
	//String propertyBuildNumber = "";
	
	String propertyCity = "FNOLWizard:NewClaimWizard_QuickClaimScreen:QuickClaimDV:IncidentLocation:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:City-inputEl";
	String propertyState = "FNOLWizard:NewClaimWizard_QuickClaimScreen:QuickClaimDV:IncidentLocation:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:State-inputEl";
	String propertyZipCode = "//input[@id='FNOLWizard:NewClaimWizard_QuickClaimScreen:QuickClaimDV:IncidentLocation:CCAddressInputSet:globalAddressContainer:globalAddress:GlobalAddressInputSet:PostalCode-inputEl']";
	
	String exposureSeverity = "FNOLWizard:NewClaimWizard_QuickClaimScreen:QuickClaimDV:fixedPropertySeverity-inputEl";
	
	public QuickClaimPropertyInput(WebDriver driver)
	{
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}	
	
	public void QuickClaimPropertyInputpage(String excelFileName, String profileID) throws Exception {		
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir+"\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		
		String reltoFrd = xlsread.Exceldata(SheetName, "ddlRelationToOwner", profileID);
		String lossdescription = xlsread.Exceldata(SheetName, "txtLossDescription", profileID);
		String losscause = xlsread.Exceldata(SheetName, "txtLossCause", profileID);
		String detailedloss = xlsread.Exceldata(SheetName, "txtDetailedLossCause", profileID);
		String losslocation = xlsread.Exceldata(SheetName, "ddlLossLocation", profileID);
		String claimantname = xlsread.Exceldata(SheetName, "ddlClaimant", profileID);
		String claimanttype = xlsread.Exceldata(SheetName, "ddlClaimantType", profileID);
		String propertyname = xlsread.Exceldata(SheetName, "ddlPropertyName", profileID);
		String propertyaddr1 = xlsread.Exceldata(SheetName, "txtPropertyAddress1", profileID);
		String propertycity = xlsread.Exceldata(SheetName, "txtPropertyCity", profileID);
		String propertystate = xlsread.Exceldata(SheetName, "txtPropertyState", profileID);
		String propertyzip = xlsread.Exceldata(SheetName, "txtPropertyZipCode", profileID);
		String propertylocnumber = xlsread.Exceldata(SheetName, "txtPropertyLocNumber", profileID);
		String propertybuildno = xlsread.Exceldata(SheetName, "txtPropertyBuildgNumber", profileID);
		String propertyseverity = xlsread.Exceldata(SheetName, "ddlSeverity", profileID);
			
		//continue Step 2 of 2: Quick Claim Property	
		Helper.selectDropdownValue(driver, "id", "FNOLWizard:NewClaimWizard_QuickClaimScreen:QuickClaimDV:Claim_ReportedByType-inputEl", "Select Relation to insured", reltoFrd);		
		
		wait.until(ExpectedConditions.elementToBeClickable(By.id(lossDescription)));		
		UIMethods.inputbyid(lossDescription, "Input loss description", lossdescription);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(lossCause)));
		Helper.selectDropdownValue(driver, "id",lossCause , "Select Loss cause", losscause);
		
		driver.findElement(By.id(propertyAddressLine1)).click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(detailedLossCause)));				
		Helper.selectDropdownValue(driver, "id",detailedLossCause , "Select detailed loss cause", detailedloss);	
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(lossLocation)));
		Helper.selectDropdownValue(driver, "id",lossLocation , "Select Loss Location", losslocation);		
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(claimantName)));
		Helper.selectDropdownValue(driver, "id",claimantName , "Select Claimant Name", claimantname);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(claimantType)));
		Helper.selectDropdownValue(driver, "id",claimantType , "Select Claimant Type", claimanttype);	
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(propertyName)));
		Helper.selectDropdownValue(driver, "id",propertyName , "Select Property Name", propertyname);	
		Helper.waitForLoad(driver);		
		
		// TO-DO Property location and build number fields aren't displayed in the page
		
		/*UIMethods.inputbyid("FNOLWizard:NewClaimWizard_QuickClaimScreen:QuickClaimDV:IncidentLocation:AddressInputSet:Address_LocationNumber", "Input propertylocnumber", propertylocnumber);
		Thread.sleep(2000);
		UIMethods.inputbyid("FNOLWizard:NewClaimWizard_QuickClaimScreen:QuickClaimDV:IncidentLocation:AddressInputSet:Address_BuildingNumber", "Input propertybuildno", propertybuildno);
		Thread.sleep(2000);*/
		
		UIMethods.inputbyid(propertyCity, "Input property city", propertycity);
		wait.until(ExpectedConditions.elementToBeClickable(By.id(propertyState)));
		Helper.selectDropdownValue(driver, "id",propertyState , "Select Property State", propertystate);		
		driver.findElement(By.id(propertyAddressLine1)).click();		
		Helper.waitForLoad(driver);
		Thread.sleep(1000);
		UIMethods.inputbyxpath(propertyZipCode, "Input property zip code", propertyzip);		
		driver.findElement(By.id(propertyAddressLine1)).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.id(exposureSeverity)));		
		Helper.selectDropdownValue(driver, "id",exposureSeverity , "Input property severity", propertyseverity);		
		UIMethods.inputbyid(propertyAddressLine1, "Input property address line 1", propertyaddr1);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(finishButton)));
		UIMethods.clickbyxpath(finishButton, "Click Finish Button", "Click");
		Thread.sleep(3000);
		
		//insert duplicate close        
        if(driver.findElements(By.xpath("//span[@id='NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:NewClaimDuplicatesWorksheet_CloseButton-btnEl']/span[2][text()='Clos']")).size()> 0){
        	UIMethods.jscriptclickbyxpath("//span[@id='NewClaimDuplicatesWorksheet:NewClaimDuplicatesScreen:NewClaimDuplicatesWorksheet_CloseButton-btnEl']/span[2][text()='Clos']", "click warning close button", "Click");
        }
		
		if(driver.findElements(By.xpath(finishButton)).size()> 0){
        	UIMethods.jscriptclickbyxpath(finishButton, "Click Finish Button", "Click");        
        }		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='NewClaimSaved:NewClaimSavedScreen:NewClaimSavedDV:GoToClaim']")));
	}
	
}