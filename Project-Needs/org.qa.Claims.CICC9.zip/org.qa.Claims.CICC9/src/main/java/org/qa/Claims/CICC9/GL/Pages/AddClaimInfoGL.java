package org.qa.Claims.CICC9.GL.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;

public class AddClaimInfoGL {

	private WebDriver driver = null;
	WebDriverWait wait;

	String SheetName = "ClaimsPolicy";

	// Page Objects
	String lossDetails_LossCause = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:Claim_LossCause";
	String lossDescription = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:Description";
	String lossDetails_DetailsLossCause = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:DetailedLossCause";
	String howReportedField = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:Notification_HowReported";
	String zipCode = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:AddressInputSet:Address_ZIP";
	String cityIcon = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:AddressInputSet:Address_ZIP:AutoFillIcon";
	String cityField = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:AddressInputSet:Address_City:AutoFillIcon";
	String address1Field = "FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:AddressInputSet:Address_AddressLine1";

	public AddClaimInfoGL(WebDriver driver) {
		this.driver = driver;
	}

	public void SelectNextButton() {
		wait = new WebDriverWait(driver, 20);
		UIMethods.clickbyid("FNOLWizard:Next", "Click Next button", "Click");
	}

	public void AddClaimInfoGLPage(String excelFileName, String profileID) throws Exception {
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		
		String txtLossDescription = xlsread.Exceldata(SheetName, "txtLossDescription", profileID);
		String ddlLossCause = xlsread.Exceldata(SheetName, "txtLossCause", profileID);
		String ddlDetailedLossCause = xlsread.Exceldata(SheetName, "ddlDetailedLossCause", profileID);
		String ddlUnderlyingCoverage = xlsread.Exceldata(SheetName, "ddlUnderlyingCoverage", profileID);
		String ddlHowReported = xlsread.Exceldata(SheetName, "ddlHowReported", profileID);
		String txtAdressLine = xlsread.Exceldata(SheetName, "txtAdressLine", profileID);
		String txtAddressCity = xlsread.Exceldata(SheetName, "txtAddressCity", profileID);
		String txtAddressState = xlsread.Exceldata(SheetName, "txtAddressState", profileID);
		String txtZipCode = xlsread.Exceldata(SheetName, "txtZipCode", profileID);
		String btnAddInjuiry = xlsread.Exceldata(SheetName, "btnAddInjuiry", profileID);
		String btnAddProperty = xlsread.Exceldata(SheetName, "btnAddProperty", profileID);
		String btnAddVehicle = xlsread.Exceldata(SheetName, "btnAddVehicle", profileID);
		String btnAddClaimNext = xlsread.Exceldata(SheetName, "btnAddClaimNext", profileID);
		
		Thread.sleep(3000);
		UIMethods.inputbyid(lossDescription,"Input Description", txtLossDescription);
		UIMethods.selectbyid(lossDetails_LossCause,"Input losscause", ddlLossCause);
		UIMethods.selectbyid(lossDetails_DetailsLossCause,"Input detailed losscause", ddlDetailedLossCause);
		Thread.sleep(2000);
		UIMethods.selectbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:UnderlyingCovEXT","Input Underlying Coverage", ddlUnderlyingCoverage);

		UIMethods.selectbyid(howReportedField,"Input How Reported", ddlHowReported);
		UIMethods.clickbyid(address1Field,"Click Address Line", "Click");
		Thread.sleep(2000);
		UIMethods.inputbyid(address1Field,"Input Address Line", txtAdressLine);
		if(!txtAddressCity.isEmpty()) {
			UIMethods.inputbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:AddressInputSet:Address_City","Input Address City", txtAddressCity);
			Thread.sleep(3000);
		}
		
		if(!txtAddressState.isEmpty()) {
			// txtAddressState
			UIMethods.selectbyid("FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:AddressInputSet:Address_State","Input Address State", txtAddressState);
			Thread.sleep(3000);
		}		

		// txtZipCode
		if (!(txtZipCode.isEmpty())) {
			//UIMethods.clickbyid(zipCode,"click Zip Code", "Click");
			Thread.sleep(1000);
			Helper.clearTextBox(driver, driver.findElement(By.id(zipCode)));
			UIMethods.inputbyid(zipCode,"Input Zip Code", txtZipCode);
			Thread.sleep(5000);
		}
		driver.findElement(By.id(address1Field)).click();
		Thread.sleep(2000);

		// btnAddInjuiry
		if (!(btnAddInjuiry.isEmpty())) {
			UIMethods.jscriptclickbyxpath("//*[@id='FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:EditableInjuryIncidentsLV_tb:Add']","click Add Injuiry button", "Click");
			Thread.sleep(2000);
		}

		// btnAddProperty
		if (!(btnAddProperty.isEmpty())) {
			UIMethods.jscriptclickbyxpath("//*[@id='FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:EditableFixedPropertyIncidentsGLLiabLV_tb:Add']","click Add Property button", "Click");
			Thread.sleep(2000);
		}

		// btnAddVehicle
		if (!(btnAddVehicle.isEmpty())) {
			UIMethods.jscriptclickbyxpath("//*[@id='FNOLWizard:GeneralPropertyWizardStepSet:NewClaimWizard_LossDetailsScreen:NewClaimLossDetailsDV:EditableVehicleIncidentsGLLV_tb:Add']","click Add Vehicle button", "Click");
			Thread.sleep(2000);
		}

		// btnAddClaimNext
		if (!(btnAddClaimNext.isEmpty())) {
			Helper.highLightElement(driver, driver.findElement(By.xpath("//span[text()='Next >']")));
			UIMethods.jscriptclickbyxpath("//span[text()='Next >']", "click Next button", "Click");
			Thread.sleep(4000);
		}
		Thread.sleep(3000);
	}

	public void FillOutRequiredFields(String excelFileName, String profileID) throws Exception {
		String projectdir = System.getProperty("user.dir");
		ExcelXlsFileRead xlsread = new ExcelXlsFileRead(projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");

		String lossDescription = xlsread.Exceldata(SheetName, "txtLossDescription", profileID);
		String lossCause = xlsread.Exceldata(SheetName, "txtLossCause", profileID);
		String detailedLossCause = xlsread.Exceldata(SheetName, "ddlDetailedLossCause", profileID);
		String howReported = xlsread.Exceldata(SheetName, "ddlHowReported", profileID);
		String lossLocationAddress1 = xlsread.Exceldata(SheetName, "txtlossLocationAddress1", profileID);
		String lossLocationZipCode = xlsread.Exceldata(SheetName, "txtLossLocationZipCode", profileID);

		UIMethods.inputbyid(lossDescription, "Input Description", lossDescription);
		UIMethods.selectbyid(lossCause, "Input losscause", lossCause);
		UIMethods.selectbyid(lossDetails_DetailsLossCause, "Input detailed losscause", detailedLossCause);
		UIMethods.inputbyid(howReportedField, "Input How Reported", howReported);
		UIMethods.clickbyid(zipCode, "click Zip Code", "Click");
		UIMethods.inputbyid(zipCode, "clear Zip Code", "\b\b\b\b\b\b\b\b");
		UIMethods.inputbyid(zipCode, "Input Zip Code", lossLocationZipCode);
		UIMethods.clickbyid(cityIcon, "Click autofill", "Click");
		wait = new WebDriverWait(driver, 20);
		UIMethods.clickbyid(cityField, "Click City autofill", "Click");
		wait = new WebDriverWait(driver, 20);
		UIMethods.clickbyid(address1Field, "Click Address Line", "Click");
		UIMethods.inputbyid(address1Field, "Input Address Line", lossLocationAddress1);
		UIMethods.inputbyid(address1Field, "Tab to the next field", "\t");
	}

}