package org.qa.Claims.CICC9.Technology;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;

import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.css.sac.InputSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class XmlParsing {

	String result;
	DocumentBuilderFactory dbFactory;
	InputStream stream;
	DocumentBuilder dBuilder;
	Document doc;
	XPath xPath;
	public void parseXml(String xml,boolean isNameSpacePresent)
	{
		
	try {
	        //File inputFile = new File("v:\\Acord-response.xml");
	        dbFactory = DocumentBuilderFactory.newInstance();
	        stream = new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8));	        
	        xPath =  XPathFactory.newInstance().newXPath();
	        if(isNameSpacePresent)
	        {
	        	dbFactory.setNamespaceAware(true);	        
		        dBuilder = dbFactory.newDocumentBuilder();
		        doc = dBuilder.parse(stream);
	        	doc.getDocumentElement().normalize();
	        	xPath.setNamespaceContext(new NamespaceContext() {
	        		
		            @Override
		            public Iterator getPrefixes(String arg0) {
		                return null;
		            }
		
		            @Override
		            public String getPrefix(String arg0) {
		                return null;
		            }
		
		            @Override
		            public String getNamespaceURI(String arg0) {
		                if("A".equals(arg0)) {
		                    return "http://www.ACORD.org/standards/PC_Surety/ACORD1/xml/";
		                }
		                return null;
		            }
		        });
	        }
	        else
	        {
	        	dBuilder = dbFactory.newDocumentBuilder();
		        doc = dBuilder.parse(stream);
	        }
	     } catch (ParserConfigurationException e) {
	        e.printStackTrace();
	     } catch (SAXException e) {
	        e.printStackTrace();
	     } catch (IOException e) {
	        e.printStackTrace();
	     }
		finally
		{
			try {
				stream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	}
	public String getValFromXml()
	{
		String expression = "//A:MsgStatus/A:MsgStatusCd";	        
	    NodeList nodeList;
		try {
			nodeList = (NodeList) xPath.compile(expression).evaluate(doc, XPathConstants.NODESET);
			for (int i = 0; i < nodeList.getLength(); i++) {
			       Node nNode = nodeList.item(i);
			       System.out.println("\nCurrent Element :" + nNode.getParentNode().getNodeName());
			       result = nNode.getTextContent();
			       System.out.println("\nCurrent Element value:" + nNode.getTextContent()+"\n");	
			    }
			    
		} catch (XPathExpressionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = " not found";
		}
		return result;
	}
	public String modifyXml(String path,String expression,String state)
	{
		//String expression = "//InsuredOrPrincipal/GeneralPartyInfo/Addr/StateProvCd";	        
	    NodeList nodeList;
		try {
			nodeList = (NodeList) xPath.compile(expression).evaluate(doc, XPathConstants.NODESET);
			for (int i = 0; i < nodeList.getLength(); i++) {
			       Node nNode = nodeList.item(i);
			       System.out.println("\nCurrent Element :" + nNode.getParentNode().getNodeName());
			       result = nNode.getTextContent();
			       System.out.println("\nCurrent Element value:" + nNode.getTextContent()+"\n");	
			    }
			nodeList.item(0).setTextContent(state);
			for (int i = 0; i < nodeList.getLength(); i++) {
			       Node nNode = nodeList.item(i);
			       System.out.println("\nCurrent Element :" + nNode.getParentNode().getNodeName());
			       result = nNode.getTextContent();
			       System.out.println("\nCurrent Element value:" + nNode.getTextContent()+"\n");	
			    }
			Transformer transformer;
			try {
				transformer = TransformerFactory.newInstance().newTransformer();
				transformer.transform(new DOMSource(doc), new StreamResult(new File(path+"/test-updated.xml")));
			} catch (TransformerFactoryConfigurationError | TransformerException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		        
		} catch (XPathExpressionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = " not found";
		}
		return result;
	}
}