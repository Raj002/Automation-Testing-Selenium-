package org.qa.Claims.CICC9.Technology;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.log4j.Logger;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.docx4j.dml.wordprocessingDrawing.Inline;
import org.docx4j.jaxb.Context;
import org.docx4j.openpackaging.exceptions.InvalidFormatException;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.WordprocessingML.BinaryPartAbstractImage;
import org.docx4j.wml.P;

/**
 * Reusable component for Web services
 * @author:  
 * Modified Date: 
 * Modified by:  
 */
public class InsertImageIntoWordDocx {
	
	public static String wordDocFileName =null;
	public static WordprocessingMLPackage wordMLPackage;
	private static final Logger LOG = Logger.getLogger(InsertImageIntoWordDocx.class);

	
	public InsertImageIntoWordDocx(String docFileName) {

		wordDocFileName = docFileName;
		try {
			wordMLPackage = WordprocessingMLPackage.createPackage();
			
		} catch (InvalidFormatException e) {			
			LOG.debug("Catch Exception: " + e.getMessage() , e);
		}
	}

	/**
	 * @param filePath
	 * @return filePath
	 * @MethodName createDoc
	 * @MethodDescription To create a Document and write file contents into a .docx file
	*/
	@SuppressWarnings("resource")
	public static String createDoc(String filePath){
		
	  XWPFDocument document= new XWPFDocument(); 	 
	   FileOutputStream out;
		try {
			out = new FileOutputStream(new File(filePath));
			document.write(out);
			out.close();
			LOG.info(filePath +" written successully");	
		} catch (IOException e) {
			LOG.debug("Catch Exception: " + e.getMessage(),e);
			
		} 
		
	   return filePath;
	}
	
	/**
	 * @param docFileName
	 * @param imgFileName
	 * @param description
	 * @MethodName writeDoc
	 * @MethodDescription Provide WordDocument fileName and FilePath Image File and Path which has to be inserted Heading of the Image
	 */
	public static void writeDoc(String docFileName , String imgFileName,String description){
		
		try {			
			imageInsert(imgFileName,description);	
			wordMLPackage.save(new java.io.File(docFileName));
		
		} catch (Exception e) {			
			LOG.debug("Catch Exception: " + e.getMessage(),e);
		}
	}
	
	/**
	 * @param imgFileName
	 * @param contentForImg
	 * @MethodName imageInsert
	 * @MethodDescription Insert Image file in to a document
	 */
	public static void imageInsert(String imgFileName,String contentForImg){
		
		String filenameHint = null , altText = null;     
        int id1 = 0 , id2 = 1 , offset = 0 ,numRead = 0;
     
		try {			
			
			File file = new File(imgFileName);		
			InputStream is = new FileInputStream(file );
	        long length = file.length();  	      
	        if (length > Integer.MAX_VALUE) {
	        	System.out.println("File too large!!");
	        }
	        byte[] bytes = new byte[(int)length];	       
	        while (offset < bytes.length && (numRead=is.read(bytes, offset, bytes.length-offset)) >= 0) {
	            offset += numRead;
	        }
	       
	        if (offset < bytes.length) {
	            System.out.println("Could not completely read file "+file.getName());
	        }
	        is.close();	        
	        P p = newImage( wordMLPackage, bytes, filenameHint, altText, id1, id2 );
	        wordMLPackage.getMainDocumentPart().addParagraphOfText(contentForImg);
			wordMLPackage.getMainDocumentPart().addObject(p);
				
		} catch (Exception e) {
			
			LOG.debug("Catch Exception: " + e.getMessage(),e);
		}
	}

	/**
	 * 
	 * @param wordMLPackage
	 * @param bytes
	 * @param filenameHint
	 * @param altText
	 * @param id1
	 * @param id2
	 * @return P	
	 * @MethodName imageInsert
	 * @MethodDescription Create image, without any specified width in twips
	 */
	public static P newImage(WordprocessingMLPackage wordMLPackage,
			byte[] bytes, String filenameHint, String altText, int id1, int id2) {
		
		Inline inline = null;	
        BinaryPartAbstractImage imagePart;
		try {
			imagePart = BinaryPartAbstractImage.createImagePart(wordMLPackage, bytes);
				
			inline = imagePart.createImageInline( filenameHint, altText,id1, id2, false);
		} catch (Exception e) {			
			LOG.debug("Catch Exception: " + e.getMessage(),e);
		}
        
        // Now add the inline in w:p/w:r/w:drawing
		org.docx4j.wml.ObjectFactory factory = Context.getWmlObjectFactory();
		org.docx4j.wml.P  p = factory.createP();
		org.docx4j.wml.R  run = factory.createR();		
		p.getContent().add(run);        
		org.docx4j.wml.Drawing drawing = factory.createDrawing();
		run.getContent().add(drawing);		
		drawing.getAnchorOrInline().add(inline);
		
		return p;
		
	}	
	
	/**
	 * @param wordMLPackage
	 * @param bytes
	 * @param filenameHint
	 * @param altText
	 * @param id1
	 * @param id2
	 * @param cx
	 * @return P
	 * @MethodName imageInsert
	 * @MethodDescription Create image, specifying width in twips
	 */
	public static P newImage(WordprocessingMLPackage wordMLPackage,
			byte[] bytes, String filenameHint, String altText, int id1, int id2, long cx) {
		
        BinaryPartAbstractImage imagePart = null;
        Inline inline = null;
		try {
			imagePart = BinaryPartAbstractImage.createImagePart(wordMLPackage, bytes);		
			inline = imagePart.createImageInline( filenameHint, altText, id1, id2, cx, false);
		} catch (Exception e) {		
			LOG.debug("Catch Exception: " + e.getMessage(),e);
		}        
       
		org.docx4j.wml.ObjectFactory factory = Context.getWmlObjectFactory();
		org.docx4j.wml.P  p = factory.createP();
		org.docx4j.wml.R  run = factory.createR();		
		p.getContent().add(run);
		org.docx4j.wml.Drawing drawing = factory.createDrawing();		
		run.getContent().add(drawing);		
		drawing.getAnchorOrInline().add(inline);
		
		return p;
		
	}	

}