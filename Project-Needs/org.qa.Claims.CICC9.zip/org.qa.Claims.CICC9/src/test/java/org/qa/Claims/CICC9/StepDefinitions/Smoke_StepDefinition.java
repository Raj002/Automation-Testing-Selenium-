package org.qa.Claims.CICC9.StepDefinitions;

import java.net.UnknownHostException;
import java.text.ParseException;

import org.jbehave.core.annotations.AfterScenario;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.openqa.selenium.WebDriver;
import org.qa.Claims.CICC9.Auto.Pages.*;
import org.qa.Claims.CICC9.CommonScreens.*;
import org.qa.Claims.CICC9.GL.Pages.*;
import org.qa.Claims.CICC9.Property.Pages.*;
import org.qa.Claims.CICC9.Technology.FetchPropertiesFiles;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.signInAction;
import org.qa.Claims.CICC9.Utilities.signOutAction;

/**
 * @author n0296668 This class contains collection of Step Definitions Which
 *         will execute the Smoke test Stories
 */
public class Smoke_StepDefinition {
	signInAction loginPage;
	signOutAction logoutPage;
	ActionMenuNavigations actionMenuNavigation;
	AddClaimInfo addclaiminfo;
	AddClaimInfoGL addclaiminfoGL;
	AddClaimant addclaimant1;
	AddClaimInfoProperty addClaimProperty;
	AUFFClaimCreation auffclaimcreatn;
	BasicInfo basicinfo;
	BasicInfoGL basicinfoGL;
	BasicInfoProperty basicInfoProperty;
	ClaimSearchAuto claimsSearch;
	ClaimContactScreen claimcontscreen;
	CreateRecovery createRecovery;
	EditLossDetailsPage editlossdetails;
	ExposureClose exposureClose;
	EditVehicleIncidents editVehicle;
	EditInjuiry EditInjuiryIncident;
	Exposures exposu;
	EnterCheckBasics enterChecks;
	FinancialSummary financialSummary;
	NewExposureEntry exposureentry;
	FNOLPayment fnolpayments;
	GLSearchInjuiryPerson GLSrchInjuiryPerson;
	InjuiryIncident AddInjuiryIncident;
	LossAddress lossaddr;
	LossDetails lossdet;
	LossCause losscse;
	LossDetailsGL LossDetailsGL;
	ManagePartiesNext manageparties;
	NewClaims newclaims;
	NewClaimSaved newclmsaved;
	NewExposureEntry newExposureEntry;
	NewUserContact newUserContact;
	NewVehicleIncident vehicledet;
	NewVendor newvendor;
	NewMatter newMatter;
	NewPropertyIncident newPropertyIncident;
	NewPersonContactDetail newpersn;
	PartiesInvolvedContacts partiesinv;
	PartiesInvolvedNewPerson partiesinvnewperson;
	PartiesInvolvedAddExistingContact Partiesaddexisitingcontacts;
	PayeeInformation payeeinfo;
	PaymentInformation paymentinfo;
	PropertyIncident propincident;
	SaveAndAssignClaim saveAssign;
	SaveAndAssignClaimGL saveassignGL;
	SetReserves setreserve;
	SearchAddressBook searchaddressbook;
	SearchCreatePolicy searchCreatepolicy;
	SelectInvolvedPolicyVehicles selectInvolvedPolVeh;
	SelectInvolvedPolicyProperty selectinvolvedpolprop;
	SelectNewExposures selectNewExposure;
	Services serv;
	SetCheckInstructions setCheckInstruction;
	Summary summary;
	WorkplanComplete workplanComplete;
	SearchCreatePolicy srchcreatepolicy;
	SearchAddressBook srchAddressBook;
	QuickClaimProperty QuickClmProp;
	QuickClaimPropertyInput QuickClmPropInput;

	WebDriver driver;
	FetchPropertiesFiles objFetProp = new FetchPropertiesFiles();
	String environment;
	String reportPath;

	@Given("For the $functionality functionality, $projectName is going to be triggered")
	public void projectDetails(String functionality, String projectName) {
		new Report(projectName, functionality);
		try {
			Report.reportCreation();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
	}

	@Given("Automation Test scenario $testScenario")
	public void scenarioMapping(String testScenario) throws UnknownHostException {
		new Report(testScenario);
		reportPath = Report.individualReport(testScenario);
		// Report.heading();
	}

	@SuppressWarnings("static-access")
	@Then("Start the browser Session")
	public void startSession() throws Exception {

		// Environment setup
		objFetProp.getProperties();
		environment = objFetProp.getEnvConnection();

		// Returning browser and launching browser
		driver = UIMethods.browser(FetchPropertiesFiles.browserName);
		UIMethods.StartBrowser();

		// Creating Objects for the pages
		loginPage = new signInAction(driver);
		actionMenuNavigation = new ActionMenuNavigations(driver);
		addclaiminfo = new AddClaimInfo(driver);
		addclaiminfoGL = new AddClaimInfoGL(driver);
		addclaimant1 = new AddClaimant(driver);
		addClaimProperty = new AddClaimInfoProperty(driver);
		auffclaimcreatn = new AUFFClaimCreation(driver);
		AddInjuiryIncident = new InjuiryIncident(driver);
		basicinfo = new BasicInfo(driver);
		basicinfoGL = new BasicInfoGL(driver);
		basicInfoProperty = new BasicInfoProperty(driver);
		createRecovery = new CreateRecovery(driver);
		claimsSearch = new ClaimSearchAuto(driver);
		claimcontscreen = new ClaimContactScreen(driver);
		editlossdetails = new EditLossDetailsPage(driver);
		editVehicle = new EditVehicleIncidents(driver);
		exposureentry = new NewExposureEntry(driver);
		exposu = new Exposures(driver);
		enterChecks = new EnterCheckBasics(driver);
		EditInjuiryIncident = new EditInjuiry(driver);
		financialSummary = new FinancialSummary(driver);
		fnolpayments = new FNOLPayment(driver);
		newExposureEntry = new NewExposureEntry(driver);
		GLSrchInjuiryPerson = new GLSearchInjuiryPerson(driver);
		lossdet = new LossDetails(driver);
		lossaddr = new LossAddress(driver);
		losscse = new LossCause(driver);
		LossDetailsGL = new LossDetailsGL(driver);
		manageparties = new ManagePartiesNext(driver);
		newclmsaved = new NewClaimSaved(driver);
		newclaims = new NewClaims(driver);
		newUserContact = new NewUserContact();
		newvendor = new NewVendor(driver);
		newMatter = new NewMatter(driver);
		newPropertyIncident = new NewPropertyIncident(driver);
		newpersn = new NewPersonContactDetail(driver);
		partiesinv = new PartiesInvolvedContacts(driver);
		partiesinvnewperson = new PartiesInvolvedNewPerson(driver);
		Partiesaddexisitingcontacts = new PartiesInvolvedAddExistingContact(driver);
		payeeinfo = new PayeeInformation(driver);
		paymentinfo = new PaymentInformation(driver);
		propincident = new PropertyIncident(driver);
		searchaddressbook = new SearchAddressBook(driver);
		selectInvolvedPolVeh = new SelectInvolvedPolicyVehicles();
		selectinvolvedpolprop = new SelectInvolvedPolicyProperty(driver);
		selectNewExposure = new SelectNewExposures(driver);
		searchCreatepolicy = new SearchCreatePolicy(driver);
		setreserve = new SetReserves(driver);
		serv = new Services(driver);
		saveAssign = new SaveAndAssignClaim(driver);
		saveassignGL = new SaveAndAssignClaimGL(driver);
		setCheckInstruction = new SetCheckInstructions(driver);
		summary = new Summary(driver);
		vehicledet = new NewVehicleIncident(driver);
		exposureClose = new ExposureClose(driver);
		workplanComplete = new WorkplanComplete(driver);
		srchcreatepolicy = new SearchCreatePolicy(driver);
		QuickClmProp = new QuickClaimProperty(driver);
		QuickClmPropInput = new QuickClaimPropertyInput(driver);

		logoutPage = new signOutAction(driver);
	}

	@When("Login to Claim Center application")
	public void loginapp() throws Exception {
		loginPage.ClaimsLogin();
	}

	@When("Login to Claims Contact Center application")
	public void loginContactCenterapp() throws Exception {
		loginPage.ClaimsContactCenterLogin();
	}

	@Then("Execute the Smoke Test Auto-01")
	public void SmokeTest01() throws Exception {
		String excelFileName = "SmokeTest01";
		String profileID = "TestDataST01";

		newclaims.NewClaimspage();
		searchCreatepolicy.SearchPolicyAUFFpage(excelFileName, profileID);
		lossaddr.LossAddressPage(excelFileName, profileID);
		auffclaimcreatn.AUFFClaimCreationpage(excelFileName, profileID);
		losscse.LossCausepage(excelFileName, profileID);
		addclaimant1.AddClaimantpage(excelFileName, profileID);
		fnolpayments.FNOLPaymentpage(excelFileName, profileID);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		claimcontscreen.ClaimContactScreenpage(excelFileName, profileID);
	}

	@Then("Execute the Smoke Test Auto-02")
	public void SmokeTest02() throws Exception {
		String excelFileName = "SmokeTest02";
		String profileID = "TestDataST02";
		//String profileID1 = "TestDataST02Basic";
		String profileID2 = "TestDataST02Loss";
		String profileID3 = "TestDataST02Save";

		newclaims.NewClaimspage();
		searchCreatepolicy.SearchCreatePolicypage(excelFileName, profileID);
		//selectInvolvedPolVeh.SelectInvolvedPolicyVehiclespage();
		basicinfo.BasicInformationSearch(excelFileName, profileID);
		//searchaddressbook.SearchCreatePolicyPage(excelFileName, profileID);
		//basicinfo.BasicInformationSearch(excelFileName, profileID1);
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID);
		serv.clickNextButton();
		saveAssign.SaveAndAssignClaimpage();
		selectNewExposure.ExposuresPropertyDamageCollisionVehicle();
		newExposureEntry.NewExposureVehiclePage(excelFileName, profileID);
		saveAssign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		summary.Summarypage();
		editlossdetails.editLossDetailsPage();
		lossdet.LossDetailspage(excelFileName, profileID);
		editVehicle.editVehicleIncidents(excelFileName, profileID);
		lossdet.LossDetailspage(excelFileName, profileID2);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymentinfo.PaymentInformationPage(excelFileName, profileID);
		setCheckInstruction.SetCheckInstructionspage();
		actionMenuNavigation.ActionMenuTransactionRecoveryPage();
		createRecovery.createRecovery(excelFileName, profileID);
	}

	@Then("Execute the Smoke Test Auto-03")
	public void SmokeTest03() throws Exception {
		String excelFileName = "SmokeTest03";
		String profileID = "TestDataST03";
		String profileID1 = "TestDataST03BasicSearch1";
		String profileID2 = "TestDataST03AddClaim01";

		newclaims.NewClaimspage();
		searchCreatepolicy.SearchCreatePolicypage(excelFileName, profileID);
		selectinvolvedpolprop.SelectInvolvedPolicyPropertypage();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		searchaddressbook.SearchCreatePolicyPage(excelFileName, profileID);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		addClaimProperty.AddClaimInfoPage(excelFileName, profileID);
		propincident.PropertyIncidentPage(excelFileName, profileID);
		addClaimProperty.AddClaimInfoPage(excelFileName, profileID2);
		manageparties.ManagePartiesNextPage(excelFileName, profileID);
		saveAssign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		selectNewExposure.ExposuresBuildingProperty();
		newExposureEntry.NewExposurePropertyPage(excelFileName, profileID);
		summary.Summarypage();
		editlossdetails.editLossDetailsPage();
		lossdet.LossDetailspage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymentinfo.PaymentInformationPage(excelFileName, profileID);
		setCheckInstruction.SetCheckInstructionspage();
	}

	@Then("Execute the Smoke Test Auto-04")
	public void SmokeTest04() throws Exception {
		String excelFileName = "SmokeTest04";
		String profileID1 = "GLScenario01-1";
		String profileID2 = "GLScenario01-2";

		newclaims.NewClaimspage();
		searchCreatepolicy.SearchCreatePolicypage(excelFileName, profileID1);
		basicinfoGL.BasicInformationGLSearch(excelFileName, profileID1);
		searchaddressbook.SearchCreatePolicyPage(excelFileName, profileID1);
		basicinfoGL.BasicInformationGLSearch(excelFileName, profileID2);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID1);
		manageparties.ClickManagePartiesNext(excelFileName, profileID1);
		saveassignGL.SaveAndAssignClaimGlPage(excelFileName, profileID1);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		selectNewExposure.GLExposureBodilyExposurePage();
		newExposureEntry.GLNewExposureBodilyInjuiryPage(excelFileName, profileID1);
		GLSrchInjuiryPerson.GLSearchInjuiryPersonPage();
		searchaddressbook.SearchCreatePolicyPage(excelFileName, profileID1);
		AddInjuiryIncident.AddInjuiryIncidentPage(excelFileName, profileID1);
		newExposureEntry.GLNewExposureBodilyInjuiryPage(excelFileName, profileID2);
		summary.Summarypage();
		editlossdetails.editLossDetailsPage();
		LossDetailsGL.LossDetailsGLPage(excelFileName, profileID1);
		EditInjuiryIncident.InjuiryIncidentPage(excelFileName, profileID1);
		//LossDetailsGL.LossDetailsGLPage(excelFileName, profileID2);
		Partiesaddexisitingcontacts.PartiesInvolvedAddExistingContactsPage();
		searchaddressbook.SearchCreatePolicyPage(excelFileName, profileID2);
		newvendor.NewVendorPage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID1);
		paymentinfo.PaymentInformationPage(excelFileName, profileID1);
		setCheckInstruction.SetCheckInstructionsWithAlert();
	}

	@Then("Execute the Smoke Test Auto-05")
	public void smokeTest05() throws Exception {
		String excelFileName = "SmokeTest05";
		String profileID = "TestDataST05";

		//newclaims.NewClaimspage();
		claimsSearch.ClaimsSearch(excelFileName, profileID);
		partiesinv.PartiesInvolvedContactspage();
		partiesinvnewperson.PartiesInvolvedNewPersonpage(excelFileName, profileID);
	}

	@Then("Execute the Smoke Test Auto-06")
	public void smokeTest06() throws Exception {
		String excelFileName = "SmokeTest06";
		String profileID = "TestDataST06";

		actionMenuNavigation.ContactCenterActionMenuMatterPage();
		newUserContact.NewPersonContactDetailpage(excelFileName, profileID);
	}

	@Then("Execute the Smoke Test Auto-07")
	public void smokeTest07() throws Exception {
		String excelFileName = "SmokeTest07";
		String profileID = "TestDataST07";
		String profileID1 = "TestDataST07Loss";

		newclaims.NewClaimspage();
		searchCreatepolicy.SearchCreateUnverifiedPolicypage(excelFileName, profileID);
		searchCreatepolicy.namesearchpage();
		searchaddressbook.SearchCreatePolicyPage(excelFileName, profileID);
		searchCreatepolicy.SearchCreateUnverifiedAutoPolicyPage(excelFileName, profileID);
		basicinfo.BasicInformationSearch(excelFileName, profileID);
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID);
		serv.clickNextButton();
		saveAssign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		summary.Summarypage();
		editlossdetails.editLossDetailsPage();
		lossdet.LossDetailspage(excelFileName, profileID);
		vehicledet.NewVehicleDetailsInputpage(excelFileName, profileID);
		lossdet.LossDetailspage(excelFileName, profileID1);
	}

	@Then("Execute the Smoke Test Auto-08")
	public void smokeTest08() throws Exception {
		String excelFileName = "SmokeTest08";
		String profileID = "TestDataST08";
		String profileID1 = "TestDataST08BasicSearch1";
		String profileID2 = "TestDataST08AddClaim01";
		String profileID3 = "TestDataST08AddPropIncident";
		String profileID4 = "TestDataST08EditPropIncident";

		newclaims.NewClaimspage();
		searchCreatepolicy.SearchCreatePolicypage(excelFileName, profileID);
		selectinvolvedpolprop.SelectInvolvedPolicyPropertypage();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		searchaddressbook.SearchCreatePolicyPage(excelFileName, profileID);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		addClaimProperty.AddClaimInfoPage(excelFileName, profileID);
		propincident.PropertyIncidentPage(excelFileName, profileID4);
		addClaimProperty.AddClaimInfoPage(excelFileName, profileID3);
		newPropertyIncident.PropertyIncidentPage(excelFileName, profileID);
		addClaimProperty.AddClaimInfoPage(excelFileName, profileID2);
		manageparties.ManagePartiesNextPage(excelFileName, profileID);
		saveAssign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		selectNewExposure.ExposuresBuildingProperty();
		newExposureEntry.NewExposurePropertyPage(excelFileName, profileID);
		workplanComplete.workplanComplete(excelFileName, profileID);
		exposureClose.ExposureClosePage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuClosePage(excelFileName, profileID);
	}

	@Then("Execute the Smoke Test Auto-09")
	public void smokeTest09() throws Exception {
		String excelFileName = "SmokeTest09";
		String profileID = "TestDataST09";
		String profileID1 = "TestDataST09BasicSearch1";
		String profileID2 = "TestDataST09AddClaim01";
		String profileID3 = "TestDataST09AddPropIncident";
		String profileID4 = "TestDataST09EditPropIncident";

		newclaims.NewClaimspage();
		searchCreatepolicy.SearchCreatePolicypage(excelFileName, profileID);
		selectinvolvedpolprop.SelectInvolvedPolicyPropertypage();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		searchaddressbook.SearchCreatePolicyPage(excelFileName, profileID);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		addClaimProperty.AddClaimInfoPage(excelFileName, profileID);
		propincident.PropertyIncidentPage(excelFileName, profileID4);
		addClaimProperty.AddClaimInfoPage(excelFileName, profileID3);
		newPropertyIncident.PropertyIncidentPage(excelFileName, profileID);
		addClaimProperty.AddClaimInfoPage(excelFileName, profileID2);
		manageparties.ClickManagePartiesNext(excelFileName, profileID);
		saveAssign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		selectNewExposure.ExposuresLocationLevelBuildingProperty();
		newExposureEntry.NewExposurePropertyPage(excelFileName, profileID);
		summary.Summarypage();
		editlossdetails.editLossDetailsPage();
		lossdet.LossDetailspage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymentinfo.PaymentInformationPage(excelFileName, profileID);
		setCheckInstruction.SetCheckInstructionspage();
	}

	/*@Then("Execute the Smoke Test Auto-10")
	public void SmokeTest10() throws Exception {
		String excelFileName = "SmokeTest10";
		String profileID = "TestDataST10";
		String profileID1 = "TestDataST10Basic";
		String profileID2 = "TestDataST10Loss";

		newclaims.NewClaimspage();
		searchCreatepolicy.SearchCreatePolicypage(excelFileName, profileID);
		selectInvolvedPolVeh.SelectInvolvedPolicyVehiclespage();
		basicinfo.BasicInformationSearch(excelFileName, profileID);
		searchaddressbook.SearchCreatePolicyPage(excelFileName, profileID);
		basicinfo.BasicInformationSearch(excelFileName, profileID1);
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID);
		serv.Servicespage();
		saveAssign.SaveAndAssignClaimpage(excelFileName, profileID);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		selectNewExposure.ExposuresPropertyDamageComprehensiveVehicle();
		newExposureEntry.NewExposureVehicle(excelFileName, profileID);
		summary.Summarypage();
		editlossdetails.editLossDetailsPage();
		lossdet.LossDetailspage(excelFileName, profileID);
		editVehicle.editVehicleIncidents(excelFileName, profileID);
		lossdet.LossDetailspage(excelFileName, profileID2);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.PayeeInformationpage(excelFileName, profileID);
		paymentinfo.PaymentInformationPage(excelFileName, profileID);
		setCheckInstruction.SetCheckInstructionspage();
		actionMenuNavigation.ActionMenuTransactionRecoveryPage();
		createRecovery.createRecovery(excelFileName, profileID);
	}*/

	@Then("Execute the Smoke Test Auto-11")
	public void SmokeTest11() throws Exception {
		String excelFileName = "SmokeTest11";
		String profileID1 = "GLScenario01-1";
		String profileID2 = "GLScenario01-2";

		newclaims.NewClaimspage();
		searchCreatepolicy.SearchCreatePolicyGLPage(excelFileName, profileID1);
		basicinfoGL.BasicInformationGLSearch(excelFileName, profileID1);
		searchaddressbook.SearchCreatePolicyPage(excelFileName, profileID1);
		basicinfoGL.BasicInformationGLSearch(excelFileName, profileID2);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID1);
		AddInjuiryIncident.AddInjuiryIncidentPage(excelFileName, profileID1);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID2);
		manageparties.ClickNextBtnOnly();
		// Added by RAJ
		saveassignGL.SaveAndAssignClaimGlPage(excelFileName, profileID1);
		// saveassignGL.SaveAndAssignClaimGlFinish();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		selectNewExposure.GLPremisesBodilyExposureSelection();
		newExposureEntry.GLNewExposureBodilyInjuiryPage(excelFileName, profileID1);
		summary.Summarypage();
		editlossdetails.editLossDetailsPage();
		LossDetailsGL.LossDetailsGLPage(excelFileName, profileID1);
		EditInjuiryIncident.InjuiryIncidentPage(excelFileName, profileID1);
		LossDetailsGL.LossDetailsGLPage(excelFileName, profileID2);
		Partiesaddexisitingcontacts.PartiesInvolvedAddExistingContactsPage();
		searchaddressbook.SearchCreatePolicyPage(excelFileName, profileID2);
		newvendor.NewVendorPage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID1);
		paymentinfo.PaymentInformationPage(excelFileName, profileID1);
		setCheckInstruction.SetCheckInstructionsWithAlert();
	}

	/*@Then("Execute the Smoke Test GL-12") // GL - 01
	public void GLScenario01() throws Exception {
		String excelFileName = "SmokeTest12";
		String profileID1 = "GLScenario01-1";
		String profileID2 = "GLScenario01-2";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID1);
		basicinfoGL.BasicInformationGLSearch(excelFileName, profileID1);
		srchAddressBook.SearchCreatePolicyPage(excelFileName, profileID1);
		basicinfoGL.BasicInformationGLSearch(excelFileName, profileID2);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID1);
		manageparties.ClickManagePartiesNext(excelFileName, profileID1);
		saveassignGL.SaveAndAssignClaimGlPage(excelFileName, profileID1);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		summary.Summarypage();
		editlossdetails.editLossDetailsPage();
		LossDetailsGL.LossDetailsGLPage(excelFileName, profileID1);
		AddInjuiryIncident.AddInjuiryIncidentPage(excelFileName, profileID1);
		LossDetailsGL.LossDetailsGLPage(excelFileName, profileID2);
		selectNewExposure.GLExposurePersonalInjuiryPage();
		exposureentry.GLNewExposureGeneralPage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuReservePage();
		setreserve.SetReservespage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.PayeeInformationpage(excelFileName, profileID1);
		paymentinfo.PaymentInformationPage(excelFileName, profileID1);
		setCheckInstruction.SetCheckInstructionsWithAlert();
	}*/

	@Then("Execute the Smoke Test GL-13") // GL -08
	public void GLScenario08() throws Exception {
		String excelFileName = "SmokeTest13";
		String profileID1 = "GLScenario08-1";
		String profileID2 = "GLScenario08-2";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyGLPage(excelFileName, profileID1);
		basicinfoGL.BasicInformationGLSearch(excelFileName, profileID1);
		srchAddressBook.SearchCreatePolicyPage(excelFileName, profileID1);
		basicinfoGL.BasicInformationGLSearch(excelFileName, profileID2);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID1);
		AddInjuiryIncident.AddInjuiryIncidentPage(excelFileName, profileID1);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID2);
		manageparties.ClickManagePartiesNext(excelFileName, profileID1);
		saveassignGL.SaveAndAssignClaimGlPage(excelFileName, profileID1);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		selectNewExposure.GLExposurePersonalLiabilityPage();
		exposureentry.GLNewExposureGeneralPage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuMatterPage();
		newMatter.NewMatterpage(excelFileName, profileID1);
	}

	/*@Then("Execute the Smoke Test Property-14") // Property - 01
	public void PropertyScenario01() throws Exception {
		String excelFileName = "SmokeTest14";
		String profileID = "PropertyScenario01";
		String profileID1 = "PropertyScenario01Basic";
		String profileID2 = "PropertyScenario01ClaimInfo";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyPageFarmProperty(excelFileName, profileID);
		selectinvolvedpolprop.SelectInvolvedPolicyPropertypage();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		addClaimProperty.AddClaimInfoPage(excelFileName, profileID);
		propincident.PropertyIncidentPage(excelFileName, profileID);
		addClaimProperty.AddClaimInfoPage(excelFileName, profileID2);
		manageparties.ClickNextBtnOnly();
		saveAssign.SaveAndAssignClaimpage(excelFileName, profileID);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		workplanComplete.workplanComplete(excelFileName, profileID);
		actionMenuNavigation.ActionMenuClosePage(excelFileName, profileID2);
	}*/

	@Then("Execute the Smoke Test Property-15") // Property - 06
	public void PropertyScenario06() throws Exception {
		String excelFileName = "SmokeTest15";
		String profileID = "PropertyScenario06";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyQuickClaimPage(excelFileName, profileID);
		QuickClmProp.QuickClaimPropertypage();
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		QuickClmPropInput.QuickClaimPropertyInputpage(excelFileName, profileID);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		exposu.Exposurespage();
		setreserve.setReserve(excelFileName, profileID);
		financialSummary.FinancialSummaryPage();
		enterChecks.EnterCheckBasicsPage(excelFileName, profileID);
		setCheckInstruction.SetCheckInstructionspage();
	}

	@When("Logout from Claim Center application")
	public void logoutapp() throws Exception {
		logoutPage.ClaimsLogout();
	}

	@Then("Complete the Test Scenario")
	public void scenariocompletion() throws ParseException {
		UIMethods.stopBrowser();
		Report.totalStatus();
		Report.reportPreparation();
	}	
	
	@Then("Create the execution report")
	public void completeReport() {
		Report.reportCompletion();
	}
}