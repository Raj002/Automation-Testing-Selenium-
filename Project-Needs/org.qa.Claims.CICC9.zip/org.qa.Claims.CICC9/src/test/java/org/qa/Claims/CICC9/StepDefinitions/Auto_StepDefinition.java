package org.qa.Claims.CICC9.StepDefinitions;

import java.io.IOException;
import java.net.UnknownHostException;
import java.text.ParseException;

import org.jbehave.core.annotations.AfterScenario;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.openqa.selenium.WebDriver;
import org.qa.Claims.CICC9.Auto.Pages.*;
import org.qa.Claims.CICC9.CommonScreens.*;
import org.qa.Claims.CICC9.Property.Pages.*;
import org.qa.Claims.CICC9.Technology.FetchPropertiesFiles;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.signInAction;
import org.qa.Claims.CICC9.Utilities.signOutAction;

/**
 * @author n0296668 
 * This class contains collection of Step Definitions Which will execute the Auto LOB Regression Stories
 */
public class Auto_StepDefinition {

	// Pages Reference variables
	AddClaimInfo addclaiminfo;
	AddOfficials addofficials;
	AddWitness addwitness;
	AddDriver vehicledet;
	ActionMenuNavigations actionMenuNavigation;
	Associations associations;
	BasicInfo basicinfo;
	ClaimAdvancedSearch claimadvsearch;
	ClaimSearchAuto claimsearchtab;
	CreateRecovery createRecovery;
	DriverDetails driverdet;
	EditLossDetailsPage editlossdet;
	EditVehicleIncidents editvehicleincident;
	EnterCheckBasics enterChecks;
	ExposuresType exposureType;
	ExposureEditVehicleIncidents editVehicleIncidents;
	ExposureCreateReserve createReserve;
	FinancialTransactions finantrans;
	FinancialSummary financialSummary;
	FinancialChecks financechk;
	InjuiryIncident AddInjuiryIncident;
	LossDetails lossdet;
	signInAction loginPage;
	signOutAction logoutPage;
	NewExposureEntry exposureentry;
	NewVehicleIncident newVehicleIncident;
	NewPropertyIncident newPropertyIncident;
	NewCheckError newchkerr;
	NewClaims newclaims;
	NewClaimSaved newclmsaved;
	NewExposurePopup newexppopup;
	NewPersonContactDetail newpersn;
	Negotiations negotiations;
	NewMatter newmatter;
	NewEvaluation newEvaluation;
	Note note;
	PolcyGeneral policygeneral;
	PayeeInformation payeeinfo;
	PaymentInformation paymenetinfo;
	PartiesInvolvedContacts partiesinv;
	PartiesInvolvedNewPerson partiesinvnewperson;
	PassengerDetails passenger;
	ReserveDetails reservedet;
	SetCheckInstructions setchkinstruc;
	SaveAndAssignClaim saveassign;
	SaveAndAssignClaimFinish saveassignfinish;
	SearchCreatePolicy srchcreatepolicy;
	SearchAddressBook searchBook;
	SelectInvolvedPolicyVehicles selectinvolvedpolveh;
	SelectNewExposures selectNewExposure;
	Services serv;
	SelectPolicy selectpolicy;
	SetReserves setreserv;
	SetCheckInstructions setchk;
	Summary summary;
	SummaryClaimStatusSubrogation summarySubrogation;
	Subrogation subrogation;
	VehicleDetailsInput vehicledetinput;
	ValidationResults validationerros;
	TotalLossSalvage totalLossSalvage;

	// Common reference variables
	WebDriver driver;
	FetchPropertiesFiles objFetProp = new FetchPropertiesFiles();
	String environment;
	String reportPath;

	@Given("For the $functionality functionality, $projectName is going to be triggered")
	public void projectDetails(String functionality, String projectName) {
		new Report(projectName, functionality);
		try {
			Report.reportCreation();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
	}

	@Given("Automation Test scenario $testScenario")
	public void scenarioMapping(String testScenario) throws UnknownHostException {
		new Report(testScenario);
		reportPath = Report.individualReport(testScenario);
		//Report.heading();
	}

	@SuppressWarnings("static-access")
	@Then("Start the browser Session")
	public void startSession() throws IOException {
		
		// Environment setup
		objFetProp.getProperties();
		environment = objFetProp.getEnvConnection();

		// Returning browser and launching browser
		driver = UIMethods.browser("IE");
		UIMethods.StartBrowser();

		// Creating Objects for the pages
		loginPage = new signInAction(driver);
		actionMenuNavigation = new ActionMenuNavigations(driver);
		addwitness = new AddWitness(driver);
		addofficials = new AddOfficials(driver);
		addclaiminfo = new AddClaimInfo(driver);
		associations = new Associations(driver);
		basicinfo = new BasicInfo(driver);
		createRecovery = new CreateRecovery(driver);
		claimadvsearch = new ClaimAdvancedSearch();
		claimsearchtab = new ClaimSearchAuto(driver);
		createReserve = new ExposureCreateReserve(driver);
		driverdet = new DriverDetails(driver);
		exposureentry = new NewExposureEntry(driver);
		editlossdet = new EditLossDetailsPage(driver);
		editvehicleincident = new EditVehicleIncidents(driver);
		enterChecks = new EnterCheckBasics(driver);
		exposureType = new ExposuresType(driver);
		editVehicleIncidents = new ExposureEditVehicleIncidents(driver);
		finantrans = new FinancialTransactions(driver);
		financialSummary = new FinancialSummary(driver);
		financechk = new FinancialChecks(driver);
		lossdet = new LossDetails(driver);
		newPropertyIncident = new NewPropertyIncident(driver);
		newpersn = new NewPersonContactDetail(driver);
		newclaims = new NewClaims(driver);
		newexppopup = new NewExposurePopup(driver);
		newclmsaved = new NewClaimSaved(driver);
		newchkerr = new NewCheckError(driver);
		negotiations = new Negotiations(driver);
		newmatter = new NewMatter(driver);
		newVehicleIncident = new NewVehicleIncident(driver);
		policygeneral = new PolcyGeneral(driver);
		payeeinfo = new PayeeInformation(driver);
		paymenetinfo = new PaymentInformation(driver);
		partiesinv = new PartiesInvolvedContacts(driver);
		partiesinvnewperson = new PartiesInvolvedNewPerson(driver);
		passenger = new PassengerDetails();
		reservedet = new ReserveDetails();
		selectpolicy = new SelectPolicy();
		selectNewExposure = new SelectNewExposures(driver);
		searchBook = new SearchAddressBook(driver);
		setchk = new SetCheckInstructions(driver);
		srchcreatepolicy = new SearchCreatePolicy(driver);
		setchkinstruc = new SetCheckInstructions(driver);
		selectinvolvedpolveh = new SelectInvolvedPolicyVehicles();
		serv = new Services(driver);
		saveassignfinish = new SaveAndAssignClaimFinish(driver);
		saveassign = new SaveAndAssignClaim(driver);
		setreserv = new SetReserves(driver);
		setchkinstruc = new SetCheckInstructions(driver);
		summary = new Summary(driver);
		summarySubrogation = new SummaryClaimStatusSubrogation(driver);
		subrogation = new Subrogation();
		vehicledet = new AddDriver();
		vehicledetinput = new VehicleDetailsInput(driver);
		totalLossSalvage = new TotalLossSalvage(driver);
		newEvaluation = new NewEvaluation(driver);
		AddInjuiryIncident = new InjuiryIncident(driver);
		note = new Note(driver);
		validationerros = new ValidationResults(driver);
		logoutPage = new signOutAction(driver);
	}

	@When("Login to Claim Center application")
	public void loginApplication() throws Exception {
		loginPage.ClaimsLogin();
	}

	@Then("Execute the Auto E2E Core Scenario-01")
	public void AutoScenario01() throws Exception {
		String excelFileName = "AutoScenario01";
		String profileID = "AutoScenario01";
		String profileID1 = "AutoScenarioBasicInfo";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID);
		selectinvolvedpolveh.SelectInvolvedPolicyVehiclespage();
		basicinfo.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicinfo.BasicInformationSearch(excelFileName, profileID1);
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID);
		vehicledet.VehicleDetailspage();
		driverdet.DriverDetailspage(excelFileName, profileID);
		vehicledetinput.VehicleDetailsInputpage(excelFileName, profileID);
		addwitness.AddWitnesspage(excelFileName, profileID);
		addofficials.AddOfficialspage(excelFileName, profileID);
		serv.clickNextButton();
		saveassign.SaveAndAssignClaimpage();
		selectNewExposure.ExposuresLiabilityBodilyInjuryVehicle();
		exposureentry.NewExposureVehiclePage(excelFileName, profileID);
		saveassignfinish.SaveAndAssignClaimFinishpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		summary.Summarypage();
		editlossdet.editLossDetailsPage();
		lossdet.LossDetailspage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuReservePage();
		setreserv.setReserve(excelFileName, profileID);
		actionMenuNavigation.ActionMenuMatterPage();
		newmatter.NewMatterpage(excelFileName, profileID);
		finantrans.FinancialTransactionspage();
		reservedet.ReserveDetailspage();
		newchkerr.NewCheckErrorpage();
		payeeinfo.enterPayeeDetails(profileID);
		paymenetinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionspage();
	}

	@Then("Execute the Auto E2E Core Scenario-03")
	public void AutoScenario03() throws Exception {
		String excelFileName = "AutoScenario03";
		String profileID = "AutoScenario03";
		String profileID1 = "AutoScenario03BasicInfo";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID);
		selectinvolvedpolveh.SelectInvolvedPolicyVehiclespage();
		basicinfo.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicinfo.BasicInformationSearch(excelFileName, profileID1);
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID);
		vehicledet.VehicleDetailspage();
		driverdet.DriverDetailspage(excelFileName, profileID);
		vehicledetinput.VehicleDetailsInputpage(excelFileName, profileID);
		serv.clickNextButton();
		saveassign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		summary.Summarypage();
		editlossdet.editLossDetailsPage();
		lossdet.LossDetailspage(excelFileName, profileID);
		selectNewExposure.ExposuresPropertyCollision();
		exposureentry.NewExposureVehicle(excelFileName, profileID);
		editVehicleIncidents.exposureEditVehicleIncidents(excelFileName, profileID);
		financialSummary.FinancialSummaryPage();
		enterChecks.EnterCheckBasicsPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionspage();
	}

	@Then("Execute the Auto E2E Core Scenario-04")
	public void AutoScenario04() throws Exception {
		String excelFileName = "AutoScenario04";
		String profileID = "AutoScenario04";
		String profileID1 = "AutoScenarioBasicInfo";
		String profileID2 = "exposure";
		String profileID3 = "payeepayment";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreateUnverifiedPolicypage(excelFileName, profileID);
		srchcreatepolicy.newpersonpage();
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		srchcreatepolicy.addcoverage(excelFileName, profileID);
		//srchcreatepolicy.addcoverage(excelFileName, profileID1);
		srchcreatepolicy.SearchCreateUnverifiedAutoPolicyPage(excelFileName, profileID);
		basicinfo.BasicInformationSearch(excelFileName, profileID);
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID);
		vehicledet.AddPassengerpage();
		passenger.PassengerDetailsPage(excelFileName, profileID);
		vehicledet.VehicleDetailspage();
		driverdet.DriverDetailspage(excelFileName, profileID);
		vehicledetinput.VehicleDetailsInputpage(excelFileName, profileID);
		vehicledetinput.addCitation(excelFileName, profileID);
		vehicledetinput.VehicleDetailsInputpage(excelFileName, profileID1);
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID1);
		serv.clickNextButton();
		saveassign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuValidateClaimExposure();
		validationerros.ValidationResultsMessage(excelFileName, profileID);
		selectNewExposure.ExposuresPiPMedical();
		exposureentry.ExposureMedicalPIP(excelFileName, profileID);
		AddInjuiryIncident.AddInjuiryIncidentPage(excelFileName, profileID);
		exposureentry.ExposureMedicalPIP(excelFileName, profileID2);
		actionMenuNavigation.ActionMenuValidateClaimExposure();
		validationerros.ValidationResultsMessage(excelFileName, profileID);
		policygeneral.PolcyGeneralpage();
		selectpolicy.SelectPolicypage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuReservePage();
		setreserv.setReserve(excelFileName, profileID);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymenetinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionspage();
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID3);
		paymenetinfo.PaymentInformationPage(excelFileName, profileID3);
		setchkinstruc.SetCheckInstructionspage();
	}

	@Then("Execute the Auto E2E Core Scenario-05")
	public void AutoScenario05() throws Exception {
		String excelFileName = "AutoScenario05";
		String profileID = "AutoScenario05";
		String profileID1 = "AutoScenario05BasicInfo";
		String profileID2 = "AutoScenario05ClaimInfo";
		String profileID3 = "AutoScenario05Exposure";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID);
		selectinvolvedpolveh.SelectInvolvedPolicyVehiclespage();
		basicinfo.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicinfo.BasicInformationSearch(excelFileName, profileID1);
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID);
		vehicledet.VehicleDetailspage();
		driverdet.AddDriverDetailspage(excelFileName, profileID);
		vehicledetinput.ServiceNeededSection();
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID2);
		serv.clickNextButton();
		saveassign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		summary.Summarypage();
		editlossdet.editLossDetailsPage();
		lossdet.lnkEditSecondVehicle();
		editvehicleincident.editVehicleIncidents(excelFileName, profileID1);
		lossdet.LossDetailspage(excelFileName, profileID);
		selectNewExposure.ExposuresPropertyCollision();
		exposureentry.NewExposureVehicle(excelFileName, profileID);
		createReserve.ExposuresPage();
		setreserv.setReserve(excelFileName, profileID);
		selectNewExposure.ExposuresBodilyInjury();
		exposureentry.GLNewExposureBodilyInjuiryPage(excelFileName, profileID3);
		createReserve.ExposuresCreateReservePage();
		setreserv.setReserve(excelFileName, profileID3);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymenetinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionsWithAlert();
		financialSummary.FinancialSummaryPage();
		enterChecks.EnterCheckBasicsPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionspage();
	}

	@Then("Execute the Auto E2E Core Scenario-08")
	public void AutoScenario08() throws Exception {
		String excelFileName = "AutoScenario08";
		String profileID = "AutoScenario08";
		String profileID1 = "AutoScenario08loss";
		String profileID2 = "AutoScenario08assocupdate";
		String ProfileID3 = "AutoScenario08BasicInfo";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID);
		selectinvolvedpolveh.SelectInvolvedPolicyVehiclespage();
		basicinfo.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicinfo.BasicInformationSearch(excelFileName, ProfileID3);
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID);
		serv.clickNextButton();
		saveassign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		summary.Summarypage();
		editlossdet.editLossDetailsPage();
		lossdet.LossDetailspage(excelFileName, profileID);
		editvehicleincident.editVehicleIncidents(excelFileName, profileID1);
		lossdet.LossDetailspage(excelFileName, profileID1);
		associations.Association(excelFileName, profileID);
		claimadvsearch.ClaimsSearch(excelFileName, profileID);
		associations.Association(excelFileName, profileID2);
		selectNewExposure.ExposuresPropertyCollision();
		exposureentry.NewExposureVehicle(excelFileName, profileID);
		actionMenuNavigation.ActionMenuReservePage();
		setreserv.setReserve(excelFileName, profileID);
	}

	@Then("Execute the Auto E2E Core Scenario-09")
	public void AutoScenario09() throws Exception {
		String excelFileName = "AutoScenario09";
		String profileID = "AutoScenario09";
		String ProfileID1 = "AutoScenario09-1";
		String ProfileID2 = "AutoScenario09-2";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID);
		selectinvolvedpolveh.SelectInvolvedPolicyVehiclespage();
		basicinfo.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicinfo.BasicInformationSearch(excelFileName, ProfileID1);
		addclaiminfo.AddClaimInfoEditVehicleLink();
		editvehicleincident.EditVehicle();
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID);
		serv.clickNextButton();
		saveassign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		summary.Summarypage();
		editlossdet.editLossDetailsPage();
		lossdet.LossDetailspage(excelFileName, profileID);
		selectNewExposure.ExposuresBodilyInjuryNew();
		exposureentry.GLNewExposureBodilyInjuiryPage(excelFileName, profileID);
		AddInjuiryIncident.AddInjuiryIncidentPage(excelFileName, profileID);
		exposureentry.GLNewExposureBodilyInjuiryPage(excelFileName, ProfileID1);
		selectNewExposure.ExposuresBodilyInjuryVehicleNew();
		exposureentry.GLNewExposureBodilyInjuiryVehiclePage(excelFileName, profileID);
		newVehicleIncident.NewVehicleDetailsInputpage(excelFileName, profileID);
		exposureentry.GLNewExposureBodilyInjuiryVehiclePage(excelFileName, ProfileID1);
		editlossdet.editLossDetailsPage();
		actionMenuNavigation.ActionMenuValidateClaimExposure();
		validationerros.ValidationResultspage();
		createReserve.ExposuresPage();
		setreserv.setReserve(excelFileName, profileID);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymenetinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionsWithAlert();
		createReserve.ExposuresPage();
		setreserv.setReserve(excelFileName, ProfileID1);
		actionMenuNavigation.ActionMenuValidateClaimExposure();
		validationerros.ValidationResultspage();
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(ProfileID1);
		paymenetinfo.PaymentInformationAddItemPage(excelFileName, ProfileID1);
		setchkinstruc.SetCheckInstructionsWithAlert();
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(ProfileID2);
		paymenetinfo.PaymentInformationAddItemPage(excelFileName, ProfileID2);
		setchkinstruc.SetCheckInstructionsWithAlert();
	}

	@Then("Execute the Auto E2E Core Scenario-10")
	public void AutoScenario10() throws Exception {
		String excelFileName = "AutoScenario10";
		String profileID = "AutoScenario10";

		newclaims.ClickDesktop();
		claimsearchtab.SearchClaim(excelFileName, profileID);
		partiesinv.PartiesInvolvedContactspage();
		partiesinvnewperson.PartiesInvolvedNewPersonpage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymenetinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionspage();
		financechk.FinancialCheckspage();
	}

	@Then("Execute the Auto E2E Core Scenario-13")
	public void AutoScenario13() throws Exception {
		String excelFileName = "AutoScenario13";
		String profileID = "AutoScenario13";
		String ProfileID1 = "AutoScenario13BasicInfo";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID);
		selectinvolvedpolveh.SelectInvolvedPolicyVehiclespage();
		basicinfo.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicinfo.BasicInformationSearch(excelFileName, ProfileID1);
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID);
		addclaiminfo.AddClaimInfoEditVehicleLink();
		editvehicleincident.UpdateVehicle();
		addclaiminfo.AddClaimInfoPage(excelFileName, ProfileID1);
		serv.clickNextButton();
		saveassign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		summary.Summarypage();
		editlossdet.editLossDetailsPage();
		lossdet.LossDetailspage(excelFileName, profileID);
		selectNewExposure.ExposuresPropertyCollision();
		exposureentry.NewExposureVehicle(excelFileName, profileID);
		actionMenuNavigation.ActionMenuReservePage();
		setreserv.setReserve(excelFileName, profileID);
		actionMenuNavigation.ActionMenuValidateClaimExposure();
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymenetinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionspage();
	}

	@Then("Execute the Auto E2E Core Scenario-14")
	public void AutoScenario14() throws Exception {
		String excelFileName = "AutoScenario14";
		String profileID = "AutoScenario14";
		String ProfileID1 = "AutoScenario14-1";
		String ProfileID2 = "AutoScenario14-2";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID);
		selectinvolvedpolveh.SelectInvolvedPolicyVehiclespage();
		basicinfo.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicinfo.BasicInformationSearch(excelFileName, ProfileID1);
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID);
		serv.clickNextButton();
		saveassign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		summary.Summarypage();
		editlossdet.editLossDetailsPage();
		lossdet.LossDetailspage(excelFileName, profileID);
		newVehicleIncident.NewVehicleDetailsInputpage(excelFileName, profileID);
		lossdet.LossDetailspage(excelFileName, ProfileID2);
		editvehicleincident.editVehicleIncidents(excelFileName, ProfileID2);
		lossdet.LossDetailspage(excelFileName, ProfileID1);
		selectNewExposure.ExposuresPropertyDamageCollision();
		exposureentry.NewExposureVehicle(excelFileName, profileID);
		actionMenuNavigation.ActionMenuReservePage();
		setreserv.setReserve(excelFileName, profileID);
		actionMenuNavigation.ActionMenuValidateClaimExposure();
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymenetinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionspage();
	}

	@Then("Execute the Auto E2E Core Scenario-17")
	public void AutoScenario17() throws Exception {
		String excelFileName = "AutoScenario17";
		String profileID = "AutoScenario17";
		String profileID1 = "AutoScenario17loss";
		String ProfileID2 = "AutoScenario17BasicInfo";
		String ProfileID3 = "AutoScenario17ExpProperty";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID);
		selectinvolvedpolveh.SelectInvolvedPolicyVehiclespage();
		basicinfo.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicinfo.BasicInformationSearch(excelFileName, ProfileID2);
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID);
		serv.clickNextButton();
		saveassign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		summary.Summarypage();
		editlossdet.editLossDetailsPage();
		lossdet.LossDetailspage(excelFileName, profileID);
		editvehicleincident.editVehicleIncidents(excelFileName, profileID1);
		lossdet.LossDetailspage(excelFileName, profileID1);
		selectNewExposure.ExposuresLiabilityProperty();
		exposureentry.NewExposurePropertyIncidentPage(excelFileName, profileID);
		newPropertyIncident.PropertyLiabilityIncidentPage(excelFileName, profileID);
		exposureentry.NewExposurePropertyPage(excelFileName, ProfileID3);
		summarySubrogation.SummarySubrogationpage(excelFileName, profileID);
		subrogation.Subrogationpage(excelFileName, profileID);
	}

	@Then("Execute the Auto E2E Core Scenario-18")
	public void AutoScenario18() throws Exception {
		String excelFileName = "AutoScenario18";
		String profileID = "AutoScenario18";
		String profileID1 = "AutoScenario18loss";
		String ProfileID2 = "AutoScenario18BasicInfo";
		String ProfileID3 = "AutoScenario18ExpProperty";

		//loginPage.ClaimsLogin();
		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID);
		selectinvolvedpolveh.SelectInvolvedPolicyVehiclespage();
		basicinfo.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicinfo.BasicInformationSearch(excelFileName, ProfileID2);
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID);
		serv.clickNextButton();
		saveassign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		summary.Summarypage();
		editlossdet.editLossDetailsPage();
		lossdet.LossDetailspage(excelFileName, profileID);
		editvehicleincident.editVehicleIncidents(excelFileName, profileID1);
		lossdet.LossDetailspage(excelFileName, profileID1);
		selectNewExposure.ExposuresLiabilityProperty();
		exposureentry.NewExposurePropertyIncidentPage(excelFileName, profileID);
		newPropertyIncident.PropertyLiabilityIncidentPage(excelFileName, profileID);
		exposureentry.NewExposurePropertyPage(excelFileName, ProfileID3);
		actionMenuNavigation.ActionMenuReservePage();		
		//setreserv.SetReservespage(excelFileName, profileID);
		setreserv.setReserve(excelFileName, profileID);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymenetinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionspage();
	}

	@Then("Execute the Auto E2E Core Scenario-19")
	public void AutoScenario19() throws Exception {
		String excelFileName = "AutoScenario19";
		String profileID = "AutoScenario19";
		String ProfileID2 = "AutoScenario19BasicInfo";
		String ProfileID3 = "AutoScenario19ExpProperty";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID);
		selectinvolvedpolveh.SelectInvolvedPolicyVehiclespage();
		basicinfo.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicinfo.BasicInformationSearch(excelFileName, ProfileID2);
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID);
		serv.clickNextButton();
		saveassign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		selectNewExposure.ExposuresCollisionVehicle();
		exposureentry.NewExposureVehicleIncident(excelFileName, profileID);
		newVehicleIncident.NewVehicleDetailsInputpage(excelFileName, profileID);
		exposureentry.NewExposureVehicle(excelFileName, ProfileID3);
		exposureType.Exposurespage();
		totalLossSalvage.LossSalvagepage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuReservePage();
		setreserv.setReserve(excelFileName, profileID);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymenetinfo.PaymentInformationPage(excelFileName, profileID);
		setchk.SetCheckInstructionsWithAlert();
		actionMenuNavigation.ActionMenuTransactionRecoveryPage();
		createRecovery.createRecovery(excelFileName, profileID);
	}

	@Then("Execute the Auto E2E Core Scenario-20")
	public void AutoScenario20() throws Exception {
		String excelFileName = "AutoScenario20";
		String profileID1 = "AutoScenario20-1";
		String profileID2 = "AutoScenario20-2";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID1);
		selectinvolvedpolveh.SelectInvolvedPolicyVehiclespage();
		basicinfo.BasicInformationSearch(excelFileName, profileID1);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID1);
		basicinfo.BasicInformationSearch(excelFileName, profileID2);
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID1);
		serv.clickNextButton();
		saveassign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		summary.Summarypage();
		editlossdet.editLossDetailsPage();
		lossdet.LossDetailsAutoSC20Page(excelFileName, profileID1);
		selectNewExposure.ExposuresPropertyCollision();
		exposureentry.NewExposureVehicle(excelFileName, profileID1);
	}

	@Then("Execute the Auto E2E Core Scenario-21")
	public void AutoScenario21() throws Exception {
		String excelFileName = "AutoScenario21";
		String profileID1 = "AutoScenario21-1";
		String profileID2 = "AutoScenario21-2";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID1);
		selectinvolvedpolveh.SelectInvolvedPolicyVehiclespage();
		basicinfo.BasicInformationSearch(excelFileName, profileID1);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID1);
		basicinfo.BasicInformationSearch(excelFileName, profileID2);
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID1);
		serv.clickNextButton();
		saveassign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		summary.Summarypage();
		editlossdet.editLossDetailsPage();
		lossdet.LossDetailsAutoSC20Page(excelFileName, profileID1);
		selectNewExposure.ExposuresPropertyCollision();
		exposureentry.NewExposureVehicle(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuMatterPage();
		newmatter.NewMatterpage(excelFileName, profileID1);
	}

	@Then("Execute the Auto E2E Core Scenario-22")
	public void AutoScenario22() throws Exception {
		String excelFileName = "AutoScenario22";
		String profileID1 = "AutoScenario22-1";
		String profileID2 = "AutoScenario22-2";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID1);
		selectinvolvedpolveh.SelectInvolvedPolicyVehiclespage();
		basicinfo.BasicInformationSearch(excelFileName, profileID1);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID1);
		basicinfo.BasicInformationSearch(excelFileName, profileID2);
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID1);
		serv.clickNextButton();
		saveassign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		summary.Summarypage();
		editlossdet.editLossDetailsPage();
		lossdet.LossDetailsAutoSC20Page(excelFileName, profileID1);
		selectNewExposure.ExposuresPropertyCollision();
		exposureentry.NewExposureVehicle(excelFileName, profileID1);
		negotiations.NewNegotiations(excelFileName, profileID1);
	}

	@Then("Execute the Auto E2E Core Scenario-23")
	public void AutoScenario23() throws Exception {
		String excelFileName = "AutoScenario23";
		String profileID = "AutoScenario23";
		String profileID1 = "AutoScenario23BasicInfo";
		String profileID2 = "AutoScenario23ClaimInfo";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID);
		selectinvolvedpolveh.SelectInvolvedPolicyVehiclespage();
		basicinfo.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicinfo.BasicInformationSearch(excelFileName, profileID1);
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID);
		vehicledet.VehicleDetailspage();
		driverdet.AddDriverDetailspage(excelFileName, profileID);
		vehicledetinput.ServiceNeededSection();
		addclaiminfo.AddClaimInfoPage(excelFileName, profileID2);
		serv.clickNextButton();
		saveassign.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		summary.Summarypage();
		editlossdet.editLossDetailsPage();
		lossdet.LossDetailspage(excelFileName, profileID);
		selectNewExposure.ExposuresPropertyCollision();
		exposureentry.NewExposureVehicle(excelFileName, profileID);
		actionMenuNavigation.ActionMenuEvaluationPage();
		newEvaluation.NewEvaluationPage(excelFileName, profileID);
		actionMenuNavigation.ActionNotePage();
		note.NewNotePage(excelFileName, profileID);
		newEvaluation.VerifyNotesInEvaluationPage(excelFileName, profileID);
	}

	@When("Logout from Claim Center application")
	public void logoutapp() throws Exception {
		logoutPage.ClaimsLogout();
	}

	@Then("Complete the Test Scenario")
	public void scenariocompletion() throws ParseException {
		UIMethods.stopBrowser();
		Report.totalStatus();
		Report.reportPreparation();
	}

	@Then("Create the execution report")
	public void completeReport() {
		Report.reportCompletion();
	}

	@AfterScenario
	public void AfterEveryScenario() {
		UIMethods.stopBrowser();
	}
}