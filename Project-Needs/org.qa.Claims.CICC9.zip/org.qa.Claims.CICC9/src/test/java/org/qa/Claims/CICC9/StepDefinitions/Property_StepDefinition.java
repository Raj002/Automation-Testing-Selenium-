package org.qa.Claims.CICC9.StepDefinitions;

import java.io.IOException;
import java.net.UnknownHostException;
import java.text.ParseException;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.openqa.selenium.WebDriver;
import org.qa.Claims.CICC9.Auto.Pages.*;
import org.qa.Claims.CICC9.CommonScreens.*;
import org.qa.Claims.CICC9.Property.Pages.*;
import org.qa.Claims.CICC9.Property.Pages.ClaimSimpleSearch;
import org.qa.Claims.CICC9.Technology.FetchPropertiesFiles;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.signInAction;
import org.qa.Claims.CICC9.Utilities.signOutAction;

/**
 * @author n0296668 This class contains collection of Step Definitions Which will execute the Property LOB Regression Stories
 */
public class Property_StepDefinition {
	signInAction loginPage;
	AddSource addSource;
	AddClaimInfoProperty claimInfoProperty;
	ActionMenuNavigations actionMenuNavigation;
	AddEvaluation addevaluation;
	BasicInfoProperty basicInfoProperty;
	BulkRecoveries bulkRecoveries;
	CopyExposureData copyexposuredata;
	ClaimSimpleSearch claimstabact;
	CreateRecovery createRecovery;
	Exposures exposu;
	EnterCheckBasics enterChecks;
	EditLossDetailsPage editlossdet;
	ExposuresType exposureType;
	FinancialChecks financhk;
	FinancialAssign financialAssign;
	FinancialSummary financialSummary;
	FinancialTransactions finantrans;
	InjuiryIncident injuryIncident;
	LossDetails lossdet;
	ManagePartiesNext manageParties;
	NewPersonContactDetail newpersn;
	NewExposureEntry newExposureEntry;
	Note notepage;
	NewEmail newEmail;
	NewClaims newclaims;
	NewEvaluation newEvaluation;
	NewUserContact newUserContact;
	NewClaimSaved newclmsaved;
	NewVehicleIncident newVehicleIncident;
	NewPropertyLiabilityIncident newPropertyIncident;
	NewPropertyIncident newPropertyIncidentpage;
	Negotiations negotiations;
	NewVendor newvendor;
	PartiesInvolvedAddExistingContact addExistingContact;
	PolicySelection polictSelect;
	PropertyIncident propertyIncident;
	PayeeInformation payeeinfo;
	PaymentInformation paymentinfo;
	QuickClaimProperty QuickClmProp;
	QuickClaimPropertyInput QuickClmPropInput;
	RecoveryDetails recoverydetails;
	RecodeRecovery recoderecovery;
	SaveAndAssignClaim saveAssignClaim;
	SearchCreatePolicy srchcreatepolicy;
	SelectInvolvedPolicyProperty selectInvolvedProperty;
	SelectNewExposures selectNewExposure;
	SetCheckInstructions setchkinstruc;
	SetReserves setreserv;
	SearchAddressBook searchAddressBook;
	Summary summaryloss;
	SearchAddressBook srchAddressBook;
	VoidRecovery voidrecovery;
	WorkplanComplete workplanComplete;
	TransferRecovery transferRecovery;
	signOutAction logoutPage;

	WebDriver driver;
	FetchPropertiesFiles objFetProp = new FetchPropertiesFiles();
	String environment;
	String reportPath;

	@Given("For the $functionality functionality, $projectName is going to be triggered")
	public void projectDetails(String functionality, String projectName) throws UnknownHostException {
		new Report(projectName, functionality);
		Report.reportCreation();
	}

	// Below are inbuilt methods to generate detailed reports
	@Given("Automation Test scenario $testScenario")
	public void scenarioMapping(String testScenario) throws UnknownHostException {
		new Report(testScenario);
		reportPath = Report.individualReport(testScenario);
		//Report.heading();
	}

	@SuppressWarnings("static-access")
	@Then("Start the browser Session")
	public void startSession() throws IOException {
		
		//Environment Setup
		objFetProp.getProperties();
		environment = objFetProp.getEnvConnection();
		
		//Launch the browser session
		driver = UIMethods.browser("IE");
		UIMethods.StartBrowser();
		
		// Creating Objects for the pages
		loginPage = new signInAction(driver);
		addSource = new AddSource(driver);
		addevaluation = new AddEvaluation(driver);
		actionMenuNavigation = new ActionMenuNavigations(driver);
		addExistingContact = new PartiesInvolvedAddExistingContact(driver);
		basicInfoProperty = new BasicInfoProperty(driver);
		bulkRecoveries = new BulkRecoveries(driver);
		claimstabact = new ClaimSimpleSearch(driver);
		createRecovery = new CreateRecovery(driver);
		copyexposuredata = new CopyExposureData(driver);
		claimInfoProperty = new AddClaimInfoProperty(driver);
		exposu = new Exposures(driver);
		enterChecks = new EnterCheckBasics(driver);
		editlossdet = new EditLossDetailsPage(driver);
		exposureType = new ExposuresType(driver);
		finantrans = new FinancialTransactions(driver);
		financhk = new FinancialChecks(driver);
		financialSummary = new FinancialSummary(driver);
		financialAssign = new FinancialAssign();
		injuryIncident = new InjuiryIncident(driver);
		lossdet = new LossDetails(driver);
		manageParties = new ManagePartiesNext(driver);
		newEmail = new NewEmail(driver);
		newpersn = new NewPersonContactDetail(driver);
		newPropertyIncidentpage = new NewPropertyIncident(driver);
		newEvaluation = new NewEvaluation(driver);
		notepage = new Note(driver);
		newExposureEntry = new NewExposureEntry(driver);
		newclaims = new NewClaims(driver);
		newUserContact = new NewUserContact();
		newclmsaved = new NewClaimSaved(driver);
		newVehicleIncident = new NewVehicleIncident(driver);
		newPropertyIncident = new NewPropertyLiabilityIncident(driver);
		negotiations = new Negotiations(driver);
		newvendor = new NewVendor(driver);
		polictSelect = new PolicySelection(driver);
		propertyIncident = new PropertyIncident(driver);
		payeeinfo = new PayeeInformation(driver);
		paymentinfo = new PaymentInformation(driver);
		QuickClmProp = new QuickClaimProperty(driver);
		QuickClmPropInput = new QuickClaimPropertyInput(driver);
		recoverydetails = new RecoveryDetails();
		recoderecovery = new RecodeRecovery();
		summaryloss = new Summary(driver);
		searchAddressBook = new SearchAddressBook(driver);
		srchcreatepolicy = new SearchCreatePolicy(driver);
		saveAssignClaim = new SaveAndAssignClaim(driver);
		selectInvolvedProperty = new SelectInvolvedPolicyProperty(driver);
		setchkinstruc = new SetCheckInstructions(driver);
		selectNewExposure = new SelectNewExposures(driver);
		setreserv = new SetReserves(driver);
		voidrecovery = new VoidRecovery(driver);
		workplanComplete = new WorkplanComplete(driver);
		transferRecovery = new TransferRecovery();
		logoutPage = new signOutAction(driver);
	}

	@When("Login to Claim Center application")
	public void loginapp() throws Exception {
		loginPage.ClaimsLogin();
	}

	@Then("Execute the Property E2E Core Scenario-01")
	public void PropertyScenario01() throws Exception {
		String excelFileName = "PropertyScenario01";
		String profileID = "PropertyScenario01";
		String profileID1 = "PropertyScenario01Basic";
		String profileID2 = "PropertyScenario01ClaimInfo";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyPageFarmProperty(excelFileName, profileID);
		selectInvolvedProperty.SelectInvolvedPolicyPropertypage();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID);
		propertyIncident.PropertyIncidentPage(excelFileName, profileID);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID2);
		manageParties.ClickNextBtnOnly();
		saveAssignClaim.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		workplanComplete.workplanComplete(excelFileName, profileID);
		actionMenuNavigation.ActionMenuClosePage(excelFileName, profileID2);
	}

	@Then("Execute the Property E2E Core Scenario-02")
	public void PropertyScenario02() throws Exception {
		String excelFileName = "PropertyScenario02";
		String profileID = "PropertyScenario02";
		String profileID1 = "PropertyScenario02-1";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreateUnverifiedPolicypage(excelFileName, profileID);
		srchcreatepolicy.newpersonpage();
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		srchcreatepolicy.SearchCreateUnverifiedAutoPolicyPage(excelFileName, profileID);
		basicInfoProperty.BasicInfoSearch(excelFileName, profileID);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID);
		newPropertyIncidentpage.NewPropertyIncidentPage(excelFileName, profileID);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID1);
		manageParties.ClickNextBtnOnly();
		saveAssignClaim.SaveAndAssignClaimpage();
		newclmsaved.FetchClaimNumber();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		logoutPage.ClaimsLogoutWithHandlePopup();
		
		loginPage.ClaimsLogBackIn();
		claimstabact.ClaimsSearchPropertyPage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuAssignClaim();
		financialAssign.FinancialAssignpage(excelFileName, profileID);
		summaryloss.Summarypage();
		editlossdet.editLossDetailsPage();
		lossdet.LossDetailspage(excelFileName, profileID);
		selectNewExposure.ExposuresBuildingProperty();
		newExposureEntry.GLNewExposureDrugistPage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuReservePage();
		setreserv.setReserve(excelFileName, profileID);
		addExistingContact.PartiesInvolvedAddExistingContactsPage();
		srchAddressBook.SearchCreatePolicyPage(excelFileName, profileID);
		newvendor.NewVendorPage(excelFileName, profileID);
		polictSelect.PolicySelectionPage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymentinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionsWithAlert();
		actionMenuNavigation.ActionMenuTransactionRecoveryPage();
		createRecovery.createRecovery(excelFileName, profileID);
		summaryloss.ClickSummary();
		summaryloss.VerifyClaimStatus(excelFileName, profileID);
	}

	@Then("Execute the Property E2E Core Scenario-03")
	public void PropertyScenario03() throws Exception {
		String excelFileName = "PropertyScenario03";
		String profileID = "PropertyScenario03";
		String profileID1 = "PropertyScenario03Basic";
		String profileID2 = "PropertyScenario03ClaimInfo";
		String profileID3 = "PropertySc03AddProperty";
		String profileID4 = "PropertySc03UpdateProperty";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyPageFarmProperty(excelFileName, profileID);
		selectInvolvedProperty.SelectInvolvedPolicyPropertypageNextPageOnly();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID);
		newPropertyIncident.NewPropertyIncidentPage(excelFileName, profileID);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID2);
		manageParties.ClickNextBtnOnly();
		saveAssignClaim.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		selectNewExposure.ExposuresPropertyDamage();
		newExposureEntry.NewExposurePersonalPropertyPage(excelFileName, profileID);
		summaryloss.Summarypage();
		editlossdet.PropertyAddressLink();
		propertyIncident.EditPropertyIncidentPage();
		propertyIncident.ClickAssessmentTab();
		propertyIncident.PropertyIncidentAssessmentPage(excelFileName, profileID);
		addSource.AddSourcepage(excelFileName, profileID);
		propertyIncident.PropertyIncidentAssessmentPage(excelFileName, profileID3);
		editlossdet.PropertyAddressLink();
		propertyIncident.EditPropertyIncidentPage();
		propertyIncident.ClickAssessmentTab();
		propertyIncident.PropertyIncidentAssessmentPage(excelFileName, profileID);
		addSource.AddSourcepage(excelFileName, profileID);
		propertyIncident.PropertyIncidentAssessmentPage(excelFileName, profileID4);
		editlossdet.PropertyAddressLink();
		propertyIncident.EditPropertyIncidentPage();
		propertyIncident.ClickAssessmentTab();
		propertyIncident.PropertyIncidentAssessmentPage(excelFileName, profileID);
		addSource.AddSourcepage(excelFileName, profileID);
		propertyIncident.PropertyIncidentAssessmentPage(excelFileName, profileID4);
		actionMenuNavigation.ActionMenuReservePage();
		setreserv.setReserve(excelFileName, profileID);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymentinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionsWithAlert();

	}

	@Then("Execute the Property E2E Core Scenario-06")
	public void PropertyScenario06() throws Exception {
		String excelFileName = "PropertyScenario06";
		String profileID = "PropertyScenario06";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyQuickClaimPage(excelFileName, profileID);
		QuickClmProp.QuickClaimPropertypage();
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		QuickClmPropInput.QuickClaimPropertyInputpage(excelFileName, profileID);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		exposu.Exposurespage();
		setreserv.setReserve(excelFileName, profileID);
		financialSummary.FinancialSummaryPage();
		enterChecks.EnterCheckBasicsPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionspage();
	}

	@Then("Execute the Property E2E Core Scenario-07")
	public void PropertyScenario07() throws Exception {
		String excelFileName = "PropertyScenario07";
		String profileID = "PropertyScenario07";
		String profileID1 = "PropertyScenario07Basic";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyPageFarmProperty(excelFileName, profileID);
		selectInvolvedProperty.SelectInvolvedPolicyPropertypageNextPageOnly();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID);
		manageParties.ClickNextBtnOnly();
		saveAssignClaim.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		selectNewExposure.ExposuresBuildingProperty();
		newExposureEntry.NewExposurePropertyIncidentPage(excelFileName, profileID);
		newPropertyIncidentpage.PropertyIncidentPage(excelFileName, profileID);
		newExposureEntry.ClickUpdateButton();
		summaryloss.Summarypage();
		editlossdet.editLossDetailsPage();
		lossdet.LossDetailspage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuEmailPage();
		newEmail.NewEmailPage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuEvaluationPage();
		newEvaluation.NewEvaluationPage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuReservePage();
		setreserv.setReserve(excelFileName, profileID);
	}

	@Then("Execute the Property E2E Core Scenario-08")
	public void PropertyScenario08() throws Exception {
		String excelFileName = "PropertyScenario08";
		String profileID = "PropertyScenario08";
		String profileID1 = "PropertyScenario08Basic";
		String profileID2 = "PropertyScenario08-1";
		String profileID3 = "PropertyScenario08-2";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyPageFarmProperty(excelFileName, profileID);
		selectInvolvedProperty.SelectInvolvedPolicyPropertypageNextPageOnly();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicInfoProperty.SearchForMainContact();
		searchAddressBook.SearchCreatePolicyPage(excelFileName, profileID);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID);
		manageParties.ClickNextBtnOnly();
		saveAssignClaim.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		selectNewExposure.ExposuresPersonalProperty();
		newExposureEntry.NewExposurePersonalPropertyPage(excelFileName, profileID);
		exposu.Exposurespage();
		setreserv.setReserve(excelFileName, profileID);
		actionMenuNavigation.ActionMenuValidateClaimExposure();
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymentinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionsWithAlert();
		logoutPage.ClaimsLogoutWithHandlePopup();

		loginPage.ClaimsLogBackIn();
		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyPageFarmProperty(excelFileName, profileID);
		selectInvolvedProperty.SelectInvolvedPolicyPropertypageNextPageOnly();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID2);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID);
		manageParties.ClickNextBtnOnly();
		saveAssignClaim.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		selectNewExposure.ExposuresPersonalProperty();
		newExposureEntry.NewExposurePersonalPropertyPage(excelFileName, profileID2);
		exposu.Exposurespage();
		setreserv.setReserve(excelFileName, profileID2);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID2);
		paymentinfo.PaymentInformationPage(excelFileName, profileID2);
		setchkinstruc.SetCheckInstructionsWithAlert();
		logoutPage.ClaimsLogoutWithHandlePopup();

		loginPage.ClaimsLogBackIn();
		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyPageFarmProperty(excelFileName, profileID);
		selectInvolvedProperty.SelectInvolvedPolicyPropertypageNextPageOnly();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID3);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID);
		manageParties.ClickNextBtnOnly();
		saveAssignClaim.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		selectNewExposure.ExposuresPersonalProperty();
		newExposureEntry.NewExposurePersonalPropertyPage(excelFileName, profileID3);
		exposu.Exposurespage();
		setreserv.setReserve(excelFileName, profileID3);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID3);
		paymentinfo.PaymentInformationPage(excelFileName, profileID3);
		setchkinstruc.SetCheckInstructionsWithAlert();
		actionMenuNavigation.ActionMenuAssignClaim();
		financialAssign.FinancialAssignpage(excelFileName, profileID);
	}

	@Then("Execute the Property E2E Core Scenario-10")
	public void PropertyScenario10() throws Exception {
		String excelFileName = "PropertyScenario10";
		String profileID = "PropertyScenario10";
		String profileID1 = "PropertyScenario10Basic";
		String profileID2 = "PropertyScenario10ClaimInfo";
		String profileID3 = "PropertyScenario10Loss";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyPageFarmProperty(excelFileName, profileID);
		selectInvolvedProperty.SelectInvolvedPolicyPropertypage();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID);
		propertyIncident.PropertyIncidentPage(excelFileName, profileID);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID2);
		manageParties.ClickNextBtnOnly();
		saveAssignClaim.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		summaryloss.Summarypage();
		editlossdet.editLossDetailsPage();
		lossdet.AddInjuryButton();
		injuryIncident.AddInjuiryIncidentPage(excelFileName, profileID);
		lossdet.LossDetailspage(excelFileName, profileID);
		newVehicleIncident.NewVehicleDetailsInputpage(excelFileName, profileID);
		lossdet.LossDetailspage(excelFileName, profileID3);
	}

	@Then("Execute the Property E2E Core Scenario-11")
	public void PropertyScenario11() throws Exception {
		String excelFileName = "PropertyScenario11";
		String profileID = "PropertyScenario11";
		String profileID1 = "PropertyScenario11Basic";
		String profileID2 = "PropertyScenario11ClaimInfo";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyPageFarmProperty(excelFileName, profileID);
		selectInvolvedProperty.SelectInvolvedPolicyPropertypage();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID);
		propertyIncident.PropertyIncidentPage(excelFileName, profileID);
		claimInfoProperty.AddInjuries();
		injuryIncident.AddInjuiryIncidentPage(excelFileName, profileID);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID2);
		manageParties.ClickNextBtnOnly();
		saveAssignClaim.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		selectNewExposure.ExposuresBuildingProperty();
		newExposureEntry.NewExposurePropertyPage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymentinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionspage();
		actionMenuNavigation.ActionMenuAssignClaim();
		financialAssign.FinancialAssignpage(excelFileName, profileID);
	}

	@Then("Execute the Property E2E Core Scenario-12")
	public void PropertyScenario12() throws Exception {
		String excelFileName = "PropertyScenario12";
		String profileID = "PropertyScenario12";

		claimstabact.ClaimsSearchPropertyPage(excelFileName, profileID);
		selectNewExposure.SelectNewExposuresPage();
		newExposureEntry.NewExposurePropertyPage(excelFileName, profileID);
		summaryloss.Summarypage();
		actionMenuNavigation.ActionMenuReservePage();
		setreserv.setReserve(excelFileName, profileID);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymentinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionspage();
		financhk.FinancialCheckspage();
	}

	@Then("Execute the Property E2E Core Scenario-13")
	public void PropertyScenario13() throws Exception {
		String excelFileName = "PropertyScenario13";
		String profileID = "PropertyScenario13-1";
		String profileID2 = "PropertyScenario13-2";

		claimstabact.ClaimsSearchPropertyPage(excelFileName, profileID);
		summaryloss.VerifyLossDate(excelFileName, profileID);
		summaryloss.VerifyClaimStatus(excelFileName, profileID);
		exposureType.Exposurespage();
		exposu.VerifyLossParty(excelFileName, profileID);
		summaryloss.Summarypage();
		editlossdet.PropertyAddressLink();
		propertyIncident.EditPropertyIncidentPage();
		propertyIncident.ClickAssessmentTab();
		propertyIncident.PropertyIncidentAssessmentPage(excelFileName, profileID);
		addSource.AddSourceWithAssessor(excelFileName, profileID);
		propertyIncident.PropertyIncidentAssessmentPage(excelFileName, profileID2);
		actionMenuNavigation.ActionMenuValidateClaimExposure();
	}

	@Then("Execute the Property E2E Core Scenario-14")
	public void PropertyScenario14() throws Exception {
		String excelFileName = "PropertyScenario14";
		String profileID = "PropertyScenario14";
		String profileID1 = "PropertyScenario14Basic";
		String profileID2 = "PropertyScenario14ClaimInfo";
		String profileID3 = "PropertyScenario14Search";
		String profileID4 = "PropertyScenario14Exposure";
		String profileID5 = "PropertyScenario14Recovery";
		String profileID6 = "PropertyScenario14Update";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyPageFarmProperty(excelFileName, profileID);
		selectInvolvedProperty.SelectInvolvedPolicyPropertypageNextPageOnly();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		searchAddressBook.SearchCreatePolicyPage(excelFileName, profileID);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID);
		newPropertyIncident.NewPropertyIncidentPage(excelFileName, profileID);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID2);
		manageParties.ClickNextBtnOnly();
		saveAssignClaim.SaveAndAssignClaimpage();
		newclmsaved.FetchClaimNumber();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		selectNewExposure.ExposuresBuildingProperty();
		newExposureEntry.NewExposurePropertyPage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuReservePage();
		setreserv.setReserve(excelFileName, profileID4);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymentinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionspage();
		newclaims.DesktopPage();
		bulkRecoveries.BulkRecoveryPage(excelFileName, profileID); 
		
		// Commented by RAJ below steps aren't covered as per Test Case from ALM (Test Plan -> Subject -> Claim Center -> Automation -> Core Regression - Configurations -> Property -> Prop_E2E_Core_Scenario 14
		
		/*searchAddressBook.SearchCreatePolicyPage(excelFileName, profileID3);
		bulkRecoveries.BulkRecoveryPage(excelFileName, profileID5);
		bulkRecoveries.RemoveUnwantedLineItems();
		bulkRecoveries.BulkRecoveryPage(excelFileName, profileID6);*/
	}

	@Then("Execute the Property E2E Core Scenario-15")
	public void PropertyScenario15() throws Exception {
		String excelFileName = "PropertyScenario15";
		String profileID = "PropertyScenario15";
		String profileID1 = "PropertyScenario15-1";
		String profileID2 = "PropertyScenario15-2";

		claimstabact.ClaimsSearchPropertyPage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuTransactionRecoveryPage();
		createRecovery.createRecovery(excelFileName, profileID);
		finantrans.PropertyFinancialTransactionspage();
		recoverydetails.recoverydetailsvoid();
		voidrecovery.voidrecoveryPage();
		finantrans.PropertyFinancialTransactionsVoidedstatus();
		actionMenuNavigation.ActionMenuTransactionRecoveryPage();
		createRecovery.createRecovery(excelFileName, profileID);
		finantrans.PropertyFinancialTransactionsAmtpage();
		recoverydetails.recoverydetailsrecode();
		recoderecovery.recoderecoverypage(excelFileName, profileID1);
		finantrans.PropertyFinancialTransactionsrecodedAmtpage();
		actionMenuNavigation.ActionMenuTransactionRecoveryPage();
		createRecovery.createRecovery(excelFileName, profileID2);
		finantrans.PropertyFinancialTransactionsAmtpage();
		recoverydetails.recoveryDetailsTransfer();
		transferRecovery.clickClaimSearch();
		finantrans.FinancialSearchClaims(excelFileName, profileID);
		transferRecovery.TransferRecoveryPage(excelFileName, profileID);
		finantrans.VerifyTransactionStatus();
	}

	@Then("Execute the Property E2E Core Scenario-16")
	public void PropertyScenario16() throws Exception {
		String excelFileName = "PropertyScenario16";
		String profileID = "PropertyScenario16";
		String profileID1 = "PropertyScenario16PropertyInc";

		claimstabact.ClaimsSearchPropertyPage(excelFileName, profileID);
		selectNewExposure.PersonalLiaPropertyExposuresPage();
		newExposureEntry.NewExposurePropertyIncidentPage(excelFileName, profileID);
		newPropertyIncidentpage.NewPropertyIncidentWithoutHB(excelFileName, profileID);
		newExposureEntry.NewExposurePropertyPage(excelFileName, profileID1);
		copyexposuredata.getExposureName(excelFileName, profileID);
		addevaluation.AddEvaluationPage(excelFileName, profileID);
		actionMenuNavigation.ActionNotePage();
		notepage.NewNotePage(excelFileName, profileID);
		// verify notes and delete note to be added after getting clarification
		// from QA, in application this is not working as expected
		negotiations.NewNegotiations(excelFileName, profileID);
		// negotiation some details not able to find
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymentinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionspage();
	}

	@Then("Execute the Property E2E Core Scenario-17")
	public void PropertyScenario17() throws Exception {
		String excelFileName = "PropertyScenario17";
		String profileID = "PropertyScenario17";
		String profileID1 = "PropertyScenario17Basic";
		String profileID3 = "PropertySc17AddProperty";
		String profileID4 = "PropertySc17Assign";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyPageFarmProperty(excelFileName, profileID);
		selectInvolvedProperty.SelectInvolvedPolicyPropertypageNextPageOnly();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID);
		manageParties.ClickManagePartiesNext(excelFileName, profileID);
		saveAssignClaim.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		summaryloss.Summarypage();
		editlossdet.editLossDetailsPage();
		lossdet.AddPropertiesButton();
		newPropertyIncident.NewPropertyIncidentPage(excelFileName, profileID);
		editlossdet.PropertyAddressLink();
		propertyIncident.ClickAssessmentTab();
		propertyIncident.PropertyIncidentAssessmentPage(excelFileName, profileID);
		addSource.AddSourcepage(excelFileName, profileID);
		propertyIncident.PropertyIncidentAssessmentPage(excelFileName, profileID3);
		lossdet.LossDetailspage(excelFileName, profileID);
		selectNewExposure.ExposuresPropertyDamage();
		newExposureEntry.NewExposurePersonalPropertyPage(excelFileName, profileID);
		exposu.ExposureAssignPage();
		financialAssign.ExposureAssignpage(excelFileName, profileID);
		exposureType.Exposurespage();
		exposu.ExposureDetailsPage(excelFileName, profileID);
		workplanComplete.WorkplanAssign();
		financialAssign.WorkplanAssignpage(excelFileName, profileID4);
		workplanComplete.workplanComplete(excelFileName, profileID4);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails( profileID);
		paymentinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionspage();
	}

	@Then("Execute the Property E2E Core Scenario-20")
	public void PropertyScenario20() throws Exception {
		String excelFileName = "PropertyScenario20";
		String profileID = "PropertyScenario20";
		String profileID1 = "PropertyScenario20Basic";
		String profileID2 = "PropertyScenario20-1";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyPageFarmProperty(excelFileName, profileID);
		selectInvolvedProperty.SelectInvolvedPolicyPropertypageNextPageOnly();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID);
		manageParties.ClickNextBtnOnly();
		saveAssignClaim.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		selectNewExposure.ExposuresCoverageBuildingProperty();
		newExposureEntry.NewExposurePropertyIncidentPage(excelFileName, profileID);
		newPropertyIncidentpage.PropertyIncidentWithoutHabitable(excelFileName, profileID);
		newExposureEntry.ClickUpdateButton();
		actionMenuNavigation.ActionMenuReservePage();
		setreserv.setReserve(excelFileName, profileID);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails( profileID);
		paymentinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionsWithAlert();
		logoutPage.ClaimsLogoutWithHandlePopup();
		
		loginPage.ClaimsLogBackIn();
		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyPageFarmProperty(excelFileName, profileID);
		selectInvolvedProperty.SelectInvolvedPolicyPropertypageNextPageOnly();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID2);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID);
		manageParties.ClickNextBtnOnly();
		saveAssignClaim.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		selectNewExposure.ExposuresCoverageBuildingProperty();
		newExposureEntry.NewExposurePropertyIncidentPage(excelFileName, profileID);
		newPropertyIncidentpage.PropertyIncidentWithoutHabitable(excelFileName, profileID);
		newExposureEntry.ClickUpdateButton();
		workplanComplete.workplanComplete(excelFileName, profileID);
	}

	@Then("Execute the Property E2E Core Scenario-21")
	public void PropertyScenario21() throws Exception {
		String excelFileName = "PropertyScenario21";
		String profileID = "PropertyScenario21";
		String profileID1 = "PropertyScenario21AddClaimInfo";
		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyPageFarmProperty(excelFileName, profileID);
		selectInvolvedProperty.SelectInvolvedPolicyPropertypageNextPageOnly();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		searchAddressBook.SearchCreatePolicyPage(excelFileName, profileID);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID);
		newPropertyIncident.NewPropertyLiabilityIncidentPage(excelFileName, profileID);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID1);
		manageParties.ClickNextBtnOnly();
		saveAssignClaim.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		// selectNewExposure.ExposuresBuildingProperty();
		selectNewExposure.ExposuresCoverageBuildingProperty();
		newExposureEntry.NewExposurePropertyPage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuReservePage();
		setreserv.setReserve(excelFileName, profileID);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymentinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionspage();
	}

	@Then("Execute the Property E2E Core Scenario-22")
	public void PropertyScenario22() throws Exception {
		String excelFileName = "PropertyScenario22";
		String profileID = "PropertyScenario22";
		String profileID1 = "PropertyScenario22Basic";
		String profileID2 = "PropertyScenario22ClaimInfo";
		String profileID3 = "PropertyScenario22AddClaimProp";
		String profileID4 = "PropertyScenario22Payment2";
		String profileID5 = "PropertyScenario22Payment3";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyPageFarmProperty(excelFileName, profileID);
		selectInvolvedProperty.SelectInvolvedPolicyPropertypage();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID);
		propertyIncident.PropertyIncidentPage(excelFileName, profileID);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID3);
		newPropertyIncident.NewPropertyIncidentPage(excelFileName, profileID3);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID2);
		manageParties.ClickNextBtnOnly();
		saveAssignClaim.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		selectNewExposure.ExposuresBuildingProperty();
		newExposureEntry.NewExposurePropertyPage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuValidateClaimExposure();
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymentinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionspage();		
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID4);
		paymentinfo.PaymentInformationPage(excelFileName, profileID4);
		setchkinstruc.SetCheckInstructionspage();
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID5);
		paymentinfo.PaymentInformationPage(excelFileName, profileID5);
		setchkinstruc.SetCheckInstructionspage();
	}

	@Then("Execute the Property E2E Core Scenario-23")
	public void PropertyScenario23() throws Exception {
		String excelFileName = "PropertyScenario23";
		String profileID = "PropertyScenario23";
		String profileID1 = "PropertyScenario23Basic";
		String profileID2 = "PropertyScenario23ClaimInfo";
		String profileID4 = "PropertyScenario23Payment2";
		String profileID5 = "PropertyScenario23Payment3";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyPageFarmProperty(excelFileName, profileID);
		selectInvolvedProperty.SelectInvolvedPolicyPropertypage();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID);
		propertyIncident.PropertyIncidentPage(excelFileName, profileID);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID2);
		manageParties.ClickNextBtnOnly();
		saveAssignClaim.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		selectNewExposure.ExposuresBuildingProperty();
		newExposureEntry.NewExposurePropertyPage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuValidateClaimExposure();
		actionMenuNavigation.ActionMenuReservePage();
		setreserv.setReserve(excelFileName, profileID);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymentinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionspage();
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID4);
		paymentinfo.PaymentInformationPage(excelFileName, profileID4);
		setchkinstruc.SetCheckInstructionspage();
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID5);
		paymentinfo.PaymentInformationPage(excelFileName, profileID5);
		setchkinstruc.SetCheckInstructionspage();
	}

	@Then("Execute the Property E2E Core Scenario-34")
	public void PropertyScenario34() throws Exception {
		String excelFileName = "PropertyScenario34";
		String profileID = "PropertyScenario34";
		String profileID1 = "PropertyScenario34Basic";
		String profileID2 = "PropertyScenario34ClaimInfo";
		String profileID3 = "PropertyScenario34EditProperty";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyPageFarmProperty(excelFileName, profileID);
		selectInvolvedProperty.SelectInvolvedPolicyPropertypage();
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID);
		searchAddressBook.SearchCreatePolicyPage(excelFileName, profileID);
		basicInfoProperty.BasicInformationSearch(excelFileName, profileID1);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID);
		newPropertyIncident.NewPropertyLiabilityIncidentPage(excelFileName, profileID);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID3);
		propertyIncident.PropertyIncidentWithoutHBE(excelFileName, profileID3);
		claimInfoProperty.AddClaimInfoPage(excelFileName, profileID2);
		manageParties.ClickNextBtnOnly();
		saveAssignClaim.SaveAndAssignClaimpage();
		newclmsaved.NewClaimSavedPage(excelFileName, profileID);
		selectNewExposure.ExposuresGreenUpdgrates();
		newExposureEntry.NewExposurePersonalPropertyPage(excelFileName, profileID);
		actionMenuNavigation.ActionMenuReservePage();
		setreserv.setReserve(excelFileName, profileID);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID);
		paymentinfo.PaymentInformationPage(excelFileName, profileID);
		setchkinstruc.SetCheckInstructionspage();
	}

	// Logout
	@When("Logout from Claim Center application")
	public void logoutapp() throws Exception {
		logoutPage.ClaimsLogout();
	}

	@Then("Complete the Test Scenario")
	public void scenariocompletion() throws ParseException {
		UIMethods.stopBrowser();
		Report.totalStatus();
		Report.reportPreparation();
	}

	@Then("Create the execution report")
	public void completeReport() {
		Report.reportCompletion();
	}
	
}