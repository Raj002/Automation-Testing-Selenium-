package org.qa.Claims.CICC9.StepDefinitions;

import java.io.IOException;
import java.net.UnknownHostException;

import org.jbehave.core.annotations.Alias;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.openqa.selenium.WebDriver;
import org.qa.Claims.CICC9.Auto.Pages.AddClaimInfo;
import org.qa.Claims.CICC9.Auto.Pages.BasicInfo;
import org.qa.Claims.CICC9.Auto.Pages.SaveAndAssignClaim;
import org.qa.Claims.CICC9.CommonScreens.CopyExposureData;
import org.qa.Claims.CICC9.CommonScreens.LossDetails;
import org.qa.Claims.CICC9.CommonScreens.ManagePartiesNext;
import org.qa.Claims.CICC9.CommonScreens.NewClaims;
import org.qa.Claims.CICC9.CommonScreens.PayeeInformation;
import org.qa.Claims.CICC9.CommonScreens.PaymentInformation;
import org.qa.Claims.CICC9.CommonScreens.SearchCreatePolicy;
import org.qa.Claims.CICC9.CommonScreens.SelectNewExposures;
import org.qa.Claims.CICC9.CommonScreens.Services;
import org.qa.Claims.CICC9.CommonScreens.SetCheckInstructions;
import org.qa.Claims.CICC9.CommonScreens.SetReserves;
import org.qa.Claims.CICC9.Property.Pages.NewClaimSaved;
import org.qa.Claims.CICC9.Property.Pages.SelectInvolvedPolicyProperty;
import org.qa.Claims.CICC9.Technology.ExcelXlsFileRead;
import org.qa.Claims.CICC9.Technology.FetchPropertiesFiles;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.Helper;
import org.qa.Claims.CICC9.Utilities.Object_Repositories;
import org.qa.Claims.CICC9.Utilities.signInAction;
import org.qa.Claims.CICC9.Utilities.signOutAction;
import org.testng.Assert;

public class Create_Exposure_During_PreORPost_FNOL {
	
	// Pages Reference variables
	NewClaims newClaims;
	SearchCreatePolicy searchCreatePolicy;
	SelectInvolvedPolicyProperty selectInvolvedProperty;
	BasicInfo basicInfo;
	AddClaimInfo addClaimInfo;
	ManagePartiesNext manageParties;
	Services services;
	SelectNewExposures selectNewExposure;
	SaveAndAssignClaim saveAssignClaim;
	NewClaimSaved newClaimSaved;
	SetReserves setReserve;
	PaymentInformation paymentInformation;
	CopyExposureData copyExposureName;
	PayeeInformation payeeInformation;
	SetCheckInstructions checkPage;
	LossDetails lossDetails;
	
	signInAction loginPage;
	signOutAction logoutPage;
	ExcelXlsFileRead xlsread;

	// Common reference variables
	WebDriver driver;
	FetchPropertiesFiles objFetProp = new FetchPropertiesFiles();
	String environment;
	String reportPath;
	String excelFileName;
	String lobType;
	String claimProceedWith;
	

	@Given("For the $functionality functionality, $projectName is going to be triggered")
	public void projectDetails(String functionality, String projectName) {
		new Report(projectName, functionality);
		try {
			Report.reportCreation();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
	}

	@Given("The test scenario $testScenario")
	public void scenarioMapping(String testScenario) throws UnknownHostException {
		new Report(testScenario);
		reportPath = Report.individualReport(testScenario);
		try {
			startSession();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("static-access")
	public void startSession() throws IOException {

		// Environment setup
		objFetProp.getProperties();
		environment = objFetProp.getEnvConnection();

		// Returning browser and launching browser
		driver = UIMethods.browser("IE");
		UIMethods.StartBrowser();

		// Creating Objects for the pages
		loginPage = new signInAction(driver);
		newClaims = new NewClaims(driver);
		searchCreatePolicy = new SearchCreatePolicy(driver);
		selectInvolvedProperty = new SelectInvolvedPolicyProperty(driver);
		basicInfo = new BasicInfo(driver);
		addClaimInfo = new AddClaimInfo(driver);
		manageParties = new ManagePartiesNext(driver);
		services = new Services(driver);
		selectNewExposure = new SelectNewExposures(driver);		
		saveAssignClaim = new SaveAndAssignClaim(driver);
		newClaimSaved = new NewClaimSaved(driver);
		setReserve = new SetReserves(driver);		
		paymentInformation = new PaymentInformation(driver);
		copyExposureName = new CopyExposureData(driver);
		payeeInformation = new PayeeInformation(driver);
		checkPage = new SetCheckInstructions(driver);
		lossDetails = new LossDetails(driver);
		
		logoutPage = new signOutAction(driver);
	}

	@When("Login to Claim Center application")
	public void loginApplication() throws Exception {
		loginPage.ClaimsLogin();
	}

	@Then("Execute the $TC to create Exposure during FNOL claim creation from $StartRow to $EndRow")
	public void Exposure_Creation_During_FNOL(String TCNO, String startRow, String endRow) throws Exception {
		excelFileName = "During_FNOL";

		xlsread = new ExcelXlsFileRead(Object_Repositories.projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		lobType = xlsread.Exceldata(Object_Repositories.SheetName, "LOBType", TCNO);

		newClaims.NewClaimspage();
		searchCreatePolicy.search_Policy_During_Post_FNOL(excelFileName, TCNO);
		selectInvolvedProperty.SelectInvolvedPolicyPropertypage();
		basicInfo.BasicInformationSearch(excelFileName, TCNO);
		addClaimInfo.AddClaimInfoPage(excelFileName, TCNO);

		// Based on LOB Type it will do page navigation
		if (lobType.equalsIgnoreCase("property") | lobType.equalsIgnoreCase("general liability")) {
			manageParties.ClickNextBtnOnly();
		} else if (lobType.equalsIgnoreCase("auto")) {
			services.clickNextButton();
		}

		selectNewExposure.create_Exposure_During_OR_Post_FNOL(excelFileName, TCNO, startRow, endRow);
		saveAssignClaim.SaveAndAssignClaimpage(TCNO);
		newClaimSaved.NewClaimSavedPage(excelFileName, TCNO);
	}

	@Then("Execute the $TC to create Exposure Post FNOL claim creation from $StartRow to $EndRow")
	public void Create_Exposure_After_Claim_Creation(String TCNO, String startRow, String endRow) throws Exception {
		excelFileName = "Post_FNOL";

		xlsread = new ExcelXlsFileRead(Object_Repositories.projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		claimProceedWith = xlsread.Exceldata(Object_Repositories.SheetName, "proceedWith", TCNO);
		lobType = xlsread.Exceldata(Object_Repositories.SheetName, "LOBType", TCNO);

		newClaims.Select_NewClaim_OR_Search_Option(excelFileName, TCNO);

		if (claimProceedWith.contains("Claim Search")) {
			selectNewExposure.create_Exposure_During_OR_Post_FNOL(excelFileName, TCNO, startRow, endRow);
			Helper.getScreenshot(driver, "Exposure_Summary_Screen", "TC_" + TCNO + "_");

		} else {
			searchCreatePolicy.search_Policy_During_Post_FNOL(excelFileName, TCNO);
			selectInvolvedProperty.SelectInvolvedPolicyPropertypage();
			basicInfo.BasicInformationSearch(excelFileName, TCNO);
			addClaimInfo.AddClaimInfoPage(excelFileName, TCNO);

			// Based on LOB Type it will do page navigation
			if (lobType.equalsIgnoreCase("property") | lobType.equalsIgnoreCase("general liability")) {
				manageParties.ClickNextBtnOnly();
			} else if (lobType.equalsIgnoreCase("auto")) {
				services.clickNextButton();
			}

			saveAssignClaim.SaveAndAssignClaimpage(TCNO);
			newClaimSaved.NewClaimSavedPage(excelFileName, TCNO);
			selectNewExposure.create_Exposure_During_OR_Post_FNOL(excelFileName, TCNO, startRow, endRow);
			Helper.getScreenshot(driver, "Exposure_Summary_Screen", "TC_" + TCNO + "_");
		}
	}
	
	@Then("Execute the $TC to Set Reserve and Make Payments from $StartRow to $EndRow")
	public void Create_Reserve_And_Make_Payment(String TCNO, String startRow, String endRow) throws Exception {
		excelFileName = "ReserveAndPayments";
		
		xlsread = new ExcelXlsFileRead(Object_Repositories.projectdir + "\\src\\test\\resources\\input\\" + excelFileName + ".xls");
		claimProceedWith = xlsread.Exceldata(Object_Repositories.SheetName, "proceedWith", TCNO);
		
		if(claimProceedWith.contains("Claim Search")) {			
			newClaims.Select_NewClaim_OR_Search_Option(excelFileName, TCNO);
			
			// Update Insured's Fault Rating in Loss details screen
			Helper.clickClaimSubMenu(driver, "loss details");
			lossDetails.updateInsureFaultRating();			
			
			// Set reserve Amount and Make payments
			copyExposureName.getExposureName(excelFileName, TCNO);
			setReserve.setReserve(excelFileName, TCNO);
			Helper.clickActionsMenu(driver, "check");
			payeeInformation.enterPayeeDetails(TCNO);
			paymentInformation.PaymentInformationAddItemPage(excelFileName, TCNO);
			checkPage.clickOnFinishAndAcceptAlert();
			
			// This loop will create exposure multiple times based on the test data given in the test data sheet
			for (int i = Integer.valueOf(startRow); i <= Integer.valueOf(endRow); i++) {
				String TCNO_Row_ID = String.valueOf(i);
				
				copyExposureName.getExposureName(excelFileName, TCNO_Row_ID);
				setReserve.setReserve(excelFileName, TCNO_Row_ID);
				Helper.clickActionsMenu(driver, "check");
				payeeInformation.enterPayeeDetails(TCNO_Row_ID);
				paymentInformation.PaymentInformationAddItemPage(excelFileName, TCNO_Row_ID);
				checkPage.clickOnFinishAndAcceptAlert();
			}
			
		} else {
			Assert.fail("Please provide valid options to set and make payments...");
		}		
	}
	
	@Then("Complete the Test Scenario")
	public void scenariocompletion() throws Exception {
		logoutPage.ClaimsLogout();

		UIMethods.stopBrowser();
		Report.totalStatus();
		Report.reportPreparation();
	}

	@Then("Create the execution report")
	public void completeReport() {
		Report.reportCompletion();
	}
}
