package org.qa.Claims.CICC9.StepDefinitions;


import java.util.List;

import org.jbehave.core.ConfigurableEmbedder;
import org.jbehave.core.embedder.Embedder;
import org.testng.annotations.Test;


public abstract class TestNGStory extends ConfigurableEmbedder {

   @Test
   public void run() throws Throwable {
      Embedder embedder = configuredEmbedder();
      try {
         embedder.runStoriesAsPaths(storyPaths());
      } finally {
         embedder.generateCrossReference();
      }
   }

   protected abstract List<String> storyPaths();
}
