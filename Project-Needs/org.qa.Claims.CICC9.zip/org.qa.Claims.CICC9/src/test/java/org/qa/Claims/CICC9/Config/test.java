package org.qa.Claims.CICC9.Config;

public class test 
{
	public static void main(String[] args) {
		String count = "of 2";
		System.out.println(count.substring(3));
	}
}
