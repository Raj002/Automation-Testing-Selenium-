package org.qa.Claims.CICC9.Config;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.testng.Assert;
import org.testng.TestNG;
import org.testng.annotations.Test;


public class TaskRunner {
	
	Properties prop;
	InputStream propFile = null;
	
	@Test
	public void SuiteRunner() {

		prop = new Properties();		
		try {
			propFile = new FileInputStream(".//src/test/resources/Config.Properties");
			prop.load(propFile);
		} catch(Exception e) {
			e.printStackTrace();
		}

		TestNG runner = new TestNG();
		List<String> suiteFiles = new ArrayList<>();
		System.out.println(prop.getProperty("TESTING_TYPE"));

		if (prop.getProperty("TESTING_TYPE").contains("Regression Test")) {			
			suiteFiles.add(".//src/test/resources/SuiteFiles/Regression_Suite.xml");
			
		} else if (prop.getProperty("TESTING_TYPE").contains("Smoke Test")) {			
			suiteFiles.add(".//src/test/resources/SuiteFiles/Smoke_Suite.xml");
			
		} else if (prop.getProperty("TESTING_TYPE").contains("Exposure FNOL")) {
			suiteFiles.add(".//src/test/resources/SuiteFiles/Exposure_Suite.xml");
			
		} else if (prop.getProperty("TESTING_TYPE").contains("Reserve And Payment")){
			suiteFiles.add(".//src/test/resources/SuiteFiles/Reserve_Payment.xml");
			
		} else {
			Assert.fail("Please provide valid testing type...");
		}

		runner.setTestSuites(suiteFiles);
		runner.run();
	}
	
}
