package org.qa.Claims.CICC9.StepDefinitions;

import java.io.IOException;
import java.net.UnknownHostException;
import java.text.ParseException;

import org.jbehave.core.annotations.AfterScenario;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.openqa.selenium.WebDriver;
import org.qa.Claims.CICC9.Auto.Pages.*;
import org.qa.Claims.CICC9.CommonScreens.*;
import org.qa.Claims.CICC9.GL.Pages.*;
import org.qa.Claims.CICC9.Property.Pages.*;
import org.qa.Claims.CICC9.Technology.FetchPropertiesFiles;
import org.qa.Claims.CICC9.Technology.Report;
import org.qa.Claims.CICC9.Technology.UIMethods;
import org.qa.Claims.CICC9.Utilities.signInAction;
import org.qa.Claims.CICC9.Utilities.signOutAction;

/**
 * @author n0296668 
 * This class contains collection of Step Definitions Which will execute the GL LOB Regression Stories
 */
public class GL_StepDefinition {

	// Pages Reference variables
	signInAction loginPage;
	ActionMenuNavigations actionMenuNavigation;
	AddClaimInfoGL addclaiminfoGL;
	BasicInfoGL basicinfo;
	InjuiryIncident AddInjuiryIncident;
	EditLossDetailsPage editloss;
	Exposures exposure;
	ExposureCreateReserve createReserve;
	FinancialChecks financechk;
	LossDetailsGL LossDetailsGL;
	LossDetails lossDetails;
	ManagePartiesNext ManagePartiesNext;
	NewClaimSaved newclmsaved;
	NewClaims newclaims;
	NewExposureEntry exposureentry;
	NewPersonContactDetail newpersn;
	NewMatter newMatter;
	NewVendor newvendor;
	NewVehicleIncident newVehicleIncidents;
	NewPropertyLiabilityIncident NewPropLiabilityIncident;
	PartiesInvolvedAddExistingContact Partiesaddexisitingcontacts;
	PayeeInformation payeeinfo;
	PaymentInformation paymentinfo;
	Summary summary;
	SearchAddressBook srchAddressBook;
	SearchCreatePolicy srchcreatepolicy;
	SaveAndAssignClaimGL saveassignGL;
	SetCheckInstructions setchk;
	SetReserves setreserve;
	SelectNewExposures selectNewExposure;
	VehicleDetailsInput vehicledetinput;
	signOutAction logoutPage;

	// Common reference variables
	WebDriver driver;
	FetchPropertiesFiles objFetProp = new FetchPropertiesFiles();
	String environment;
	String reportPath;

	@Given("For the $functionality functionality, $projectName is going to be triggered")
	public void projectDetails(String functionality, String projectName) {
		new Report(projectName, functionality);
		try {
			Report.reportCreation();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
	}

	@Given("Automation Test scenario $testScenario")
	public void scenarioMapping(String testScenario) throws UnknownHostException {
		new Report(testScenario);
		reportPath = Report.individualReport(testScenario);
		//Report.heading();
	}

	@SuppressWarnings("static-access")
	@Then("Start the browser Session")
	public void startSession() throws IOException {
		
		// Environment setup
		objFetProp.getProperties();
		environment = objFetProp.getEnvConnection();
				
		//Launch the browser session
		driver = UIMethods.browser("IE");
		UIMethods.StartBrowser();

		// Creating Objects for the pages
		loginPage = new signInAction(driver);
		addclaiminfoGL = new AddClaimInfoGL(driver);
		AddInjuiryIncident = new InjuiryIncident(driver);
		actionMenuNavigation = new ActionMenuNavigations(driver);
		basicinfo = new BasicInfoGL(driver);
		createReserve = new ExposureCreateReserve(driver);
		exposureentry = new NewExposureEntry(driver);
		editloss = new EditLossDetailsPage(driver);
		exposure = new Exposures(driver);
		financechk = new FinancialChecks(driver);
		LossDetailsGL = new LossDetailsGL(driver);
		lossDetails = new LossDetails(driver);
		ManagePartiesNext = new ManagePartiesNext(driver);
		newclmsaved = new NewClaimSaved(driver);
		newclaims = new NewClaims(driver);
		newvendor = new NewVendor(driver);
		newMatter = new NewMatter(driver);
		newpersn = new NewPersonContactDetail(driver);
		NewPropLiabilityIncident = new NewPropertyLiabilityIncident(driver);
		newVehicleIncidents = new NewVehicleIncident(driver);
		payeeinfo = new PayeeInformation(driver);
		paymentinfo = new PaymentInformation(driver);
		Partiesaddexisitingcontacts = new PartiesInvolvedAddExistingContact(driver);
		srchcreatepolicy = new SearchCreatePolicy(driver);
		selectNewExposure = new SelectNewExposures(driver);
		saveassignGL = new SaveAndAssignClaimGL(driver);
		srchAddressBook = new SearchAddressBook(driver);
		summary = new Summary(driver);
		setreserve = new SetReserves(driver);
		setchk = new SetCheckInstructions(driver);
		vehicledetinput = new VehicleDetailsInput(driver);
		logoutPage = new signOutAction(driver);
	}

	@When("Login to Claim Center application")
	public void loginapp() throws Exception {
		loginPage.ClaimsLogin();
	}
	
	@Then("Execute the GL E2E Core Scenario-01")
	public void GLScenario01() throws Exception {
		String excelFileName = "GLScenario01";
		String profileID1 = "GLScenario01-1";
		String profileID2 = "GLScenario01-2";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID1);
		srchAddressBook.SearchCreatePolicyPage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID2);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID1);
		ManagePartiesNext.ClickManagePartiesNext(excelFileName, profileID1);
		saveassignGL.SaveAndAssignClaimGlPage(excelFileName, profileID1);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		summary.Summarypage();
		editloss.editLossDetailsPage();
		LossDetailsGL.LossDetailsGLPage(excelFileName, profileID1);
		AddInjuiryIncident.AddInjuiryIncidentPage(excelFileName, profileID1);
		LossDetailsGL.LossDetailsGLPage(excelFileName, profileID2);
		selectNewExposure.GLExposurePersonalInjuiryPage();
		exposureentry.GLNewExposureGeneralPage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuReservePage();
		setreserve.setReserve(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID1);
		paymentinfo.PaymentInformationPage(excelFileName, profileID1);
		setchk.SetCheckInstructionsWithAlert();
	}

	@Then("Execute the GL E2E Core Scenario-02")
	public void GLScenario02() throws Exception {
		String excelFileName = "GLScenario02";
		String profileID1 = "GLScenario01-1";
		String profileID2 = "GLScenario01-2";
		String profileID3 = "GLScenario01-3";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyGLpage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID1);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID2);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID1);
		NewPropLiabilityIncident.NewPropertyLiabilityIncidentPage(excelFileName, profileID1);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID2);
		vehicledetinput.VehicleDetailsInputpage(excelFileName, profileID1);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID3);
		ManagePartiesNext.ClickManagePartiesNext(excelFileName, profileID1);
		saveassignGL.SaveAndAssignClaimGlPage(excelFileName, profileID1);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		selectNewExposure.GLExposureDrugistPropertyPage();
		exposureentry.GLNewExposureDrugistPage(excelFileName, profileID1);
		exposure.Exposurespage();
		setreserve.setReserve(excelFileName, profileID1);
		summary.Summarypage();
		editloss.editLossDetailsPage();
		LossDetailsGL.LossDetailsGLPage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID1);
		paymentinfo.PaymentInformationPage(excelFileName, profileID1);
		setchk.SetCheckInstructionspage();
	}

	@Then("Execute the GL E2E Core Scenario-03")
	public void GLScenario03() throws Exception {
		// Prerequisite Needs to create company name and vendor before running
		// this script

		String excelFileName = "GLScenario03";
		String profileID1 = "GLScenario01-1";
		String profileID2 = "GLScenario01-2";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID1);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID2);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID1);
		NewPropLiabilityIncident.NewPropertyLiabilityIncidentPage(excelFileName, profileID1);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID2);
		ManagePartiesNext.ClickManagePartiesNext(excelFileName, profileID1);
		saveassignGL.SaveAndAssignClaimGlPage(excelFileName, profileID1);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		selectNewExposure.GLExposurePollutionLiabilityPage();
		exposureentry.GLNewExposureGeneralPage(excelFileName, profileID1);
		exposure.Exposurespage();
		setreserve.setReserve(excelFileName, profileID1);
		Partiesaddexisitingcontacts.PartiesInvolvedAddExistingContactsPage();
		//Commented by RAJ
		//srchAddressBook.SearchCreatePolicyPage(excelFileName, profileID1);
		newvendor.addExistingContact(excelFileName, profileID1);
		newvendor.NewVendorPage(excelFileName, profileID1);
		summary.Summarypage();
		editloss.editLossDetailsPage();
		LossDetailsGL.LossDetailsGLPage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID1);
		paymentinfo.PaymentInformationPage(excelFileName, profileID1);
		setchk.SetCheckInstructionspage();
	}

	@Then("Execute the GL E2E Core Scenario-04")
	public void GLScenario04() throws Exception {
		String excelFileName = "GLScenario04";
		String profileID1 = "GLScenario04-1";
		String profileID2 = "GLScenario04-2";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyGLPage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID1);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID2);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID1);
		AddInjuiryIncident.AddInjuiryIncidentPage(excelFileName, profileID1);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID2);
		ManagePartiesNext.ManagePartiesNextPage(excelFileName, profileID1);
		saveassignGL.SaveAndAssignClaimGlPage(excelFileName, profileID1);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		selectNewExposure.GLExposureEmploymentPracticesPage();
		exposureentry.GLNewExposureGeneralPage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuReservePage();
		setreserve.setReserve(excelFileName, profileID1);
		summary.Summarypage();
		editloss.editLossDetailsPage();
		LossDetailsGL.LossDetailsGLPage(excelFileName, profileID1);
		Partiesaddexisitingcontacts.PartiesInvolvedAddExistingContactsPage();
		srchAddressBook.SearchCreatePolicyPage(excelFileName, profileID1);
		newvendor.NewVendorPage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID1);
		paymentinfo.PaymentInformationPage(excelFileName, profileID1);
		setchk.SetCheckInstructionsWithAlert();
	}

	@Then("Execute the GL E2E Core Scenario-06")
	public void GLScenario06() throws Exception {
		String excelFileName = "GLScenario06";
		String profileID1 = "GLScenario06-1";
		String profileID2 = "GLScenario06-2";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyGLPage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID1);
		srchAddressBook.SearchCreatePolicyPage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID2);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID1);
		AddInjuiryIncident.AddInjuiryIncidentPage(excelFileName, profileID1);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID2);
		ManagePartiesNext.ManagePartiesNextPage(excelFileName, profileID1);
		saveassignGL.SaveAndAssignClaimGlPage(excelFileName, profileID1);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		selectNewExposure.GLExposurePersonalInjuiryPage();
		exposureentry.GLNewExposureGeneralPage(excelFileName, profileID1);
		summary.Summarypage();
		editloss.editLossDetailsPage();
		LossDetailsGL.LossDetailsGLPage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails( profileID1);
		paymentinfo.PaymentInformationPage(excelFileName, profileID1);
		setchk.SetCheckInstructionsWithAlert();
	}

	@Then("Execute the GL E2E Core Scenario-07")
	public void GLScenario07() throws Exception {
		String excelFileName = "GLScenario07";
		String profileID1 = "GLScenario07-1";
		String profileID2 = "GLScenario07-2";
		String profileID3 = "GLScenario07-3";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyGLPage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID1);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID2);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID1);
		ManagePartiesNext.ManagePartiesNextPage(excelFileName, profileID1);
		saveassignGL.SaveAndAssignClaimGlPage(excelFileName, profileID1);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		summary.Summarypage();
		editloss.editLossDetailsPage();
		lossDetails.LossDetailspage(excelFileName, profileID1);
		newVehicleIncidents.NewVehicleDetailsInputpage(excelFileName, profileID1);
		LossDetailsGL.LossDetailsGLPage(excelFileName, profileID3);
		selectNewExposure.GLExposurePropertyDamagePage();
		exposureentry.NewExposureVehicle(excelFileName, profileID1);
		exposure.Exposurespage();
		setreserve.setReserve(excelFileName, profileID1);
		summary.Summarypage();
		editloss.editLossDetailsPage();
		LossDetailsGL.LossDetailsGLPage(excelFileName, profileID2);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails( profileID1);
		paymentinfo.PaymentInformationPage(excelFileName, profileID1);
		setchk.SetCheckInstructionsWithAlert();
	}

	@Then("Execute the GL E2E Core Scenario-08")
	public void GLScenario08() throws Exception {
		String excelFileName = "GLScenario08";
		String profileID1 = "GLScenario08-1";
		String profileID2 = "GLScenario08-2";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyGLPage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID1);
		srchAddressBook.SearchCreatePolicyPage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID2);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID1);
		AddInjuiryIncident.AddInjuiryIncidentPage(excelFileName, profileID1);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID2);
		ManagePartiesNext.ClickManagePartiesNext(excelFileName, profileID1);
		saveassignGL.SaveAndAssignClaimGlPage(excelFileName, profileID1);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		selectNewExposure.GLExposurePersonalLiabilityPage();
		exposureentry.GLNewExposureGeneralPage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuMatterPage();
		newMatter.NewMatterpage(excelFileName, profileID1);
	}

	@Then("Execute the GL E2E Core Scenario-09")
	public void GLScenario09() throws Exception {
		String excelFileName = "GLScenario09";
		String profileID1 = "GLScenario09-1";
		String profileID2 = "GLScenario09-2";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyGLPage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID1);
		srchAddressBook.SearchCreatePolicyPage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID2);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID1);
		AddInjuiryIncident.AddInjuiryIncidentPage(excelFileName, profileID1);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID2);
		ManagePartiesNext.ClickManagePartiesNext(excelFileName, profileID1);
		saveassignGL.SaveAndAssignClaimGlPage(excelFileName, profileID1);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		selectNewExposure.GLExposurePersonalInjuiryPage();
		exposureentry.GLNewExposureGeneralPage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuMatterPage();
		newMatter.NewMatterpage(excelFileName, profileID1);
		summary.Summarypage();
		editloss.editLossDetailsPage();
		LossDetailsGL.LossDetailsGLPage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID1);
		paymentinfo.PaymentInformationPage(excelFileName, profileID1);
		setchk.SetCheckInstructionsWithAlert();
	}

	@Then("Execute the GL E2E Core Scenario-10")
	public void GLScenario10() throws Exception {
		String excelFileName = "GLScenario10";
		String profileID1 = "GLScenario10-1";
		String profileID2 = "GLScenario10-2";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyGLPage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID1);
		srchAddressBook.SearchCreatePolicyPage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID2);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID1);
		AddInjuiryIncident.AddInjuiryIncidentPage(excelFileName, profileID1);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID2);
		ManagePartiesNext.ClickManagePartiesNext(excelFileName, profileID1);
		saveassignGL.SaveAndAssignClaimGlPage(excelFileName, profileID1);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		selectNewExposure.GLExposureUmbrellaPage();
		exposureentry.GLNewExposureGeneralPage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuReservePage();
		setreserve.setReserve(excelFileName, profileID1);
		summary.Summarypage();
		editloss.editLossDetailsPage();
		LossDetailsGL.LossDetailsGLPage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID1);
		paymentinfo.PaymentInformationPage(excelFileName, profileID1);
		setchk.SetCheckInstructionsWithAlert();
	}

	@Then("Execute the GL E2E Core Scenario-11")
	public void GLScenario11() throws Exception {
		String excelFileName = "GLScenario11";
		String profileID1 = "GLScenario11-1";
		String profileID2 = "GLScenario11-2";
		String profileID3 = "GLScenario11-3";
		String profileID4 = "GLScenario11-4";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID1);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID2);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID1);
		AddInjuiryIncident.AddInjuiryIncidentPage(excelFileName, profileID1);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID2);
		ManagePartiesNext.ManagePartiesNextPage(excelFileName, profileID1);
		saveassignGL.SaveAndAssignClaimGlPage(excelFileName, profileID1);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		selectNewExposure.GLExposuresLiabilityBodilyInjury();
		exposureentry.GLNewExposureBodilyInjuiryPage(excelFileName, profileID1);
		createReserve.ExposuresPage();
		setreserve.setReserve(excelFileName, profileID1);
		summary.Summarypage();
		editloss.editLossDetailsPage();
		LossDetailsGL.LossDetailsGLPage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID1);
		paymentinfo.PaymentInformationPage(excelFileName, profileID1);
		setchk.SetCheckInstructionsWithAlert();
		logoutPage.ClaimsLogoutWithHandlePopup();

		loginPage.ClaimsLogBackIn();
		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicypage(excelFileName, profileID3);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID3);
		newpersn.NewPersonContactDetailpage(excelFileName, profileID3);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID4);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID3);
		AddInjuiryIncident.AddInjuiryIncidentPage(excelFileName, profileID3);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID4);
		ManagePartiesNext.ManagePartiesNextPage(excelFileName, profileID3);
		saveassignGL.SaveAndAssignClaimGlPage(excelFileName, profileID3);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		selectNewExposure.GLExposuresLiabilityBodilyInjury();
		exposureentry.GLNewExposureBodilyInjuiryPage(excelFileName, profileID3);
		createReserve.ExposuresPage();
		setreserve.setReserve(excelFileName, profileID3);
		summary.Summarypage();
		editloss.editLossDetailsPage();
		LossDetailsGL.LossDetailsGLPage(excelFileName, profileID3);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails(profileID3);
		paymentinfo.PaymentInformationPage(excelFileName, profileID3);
		setchk.SetCheckInstructionsWithAlert();
		financechk.FinancialCheckspage();
	}

	@Then("Execute the GL E2E Core Scenario-12")
	public void GLScenario12() throws Exception {
		String excelFileName = "GLScenario12";
		String profileID1 = "GLScenario12-1";
		String profileID2 = "GLScenario12-2";

		newclaims.NewClaimspage();
		srchcreatepolicy.SearchCreatePolicyGLPage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID1);
		srchAddressBook.SearchCreatePolicyPage(excelFileName, profileID1);
		basicinfo.BasicInformationGLSearch(excelFileName, profileID2);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID1);
		AddInjuiryIncident.AddInjuiryIncidentPage(excelFileName, profileID1);
		addclaiminfoGL.AddClaimInfoGLPage(excelFileName, profileID2);
		ManagePartiesNext.ClickManagePartiesNext(excelFileName, profileID1);
		saveassignGL.SaveAndAssignClaimGlPage(excelFileName, profileID1);
		newclmsaved.NewClaimSavedPage(excelFileName, profileID1);
		selectNewExposure.GLExposurePersonalLiabilityPage();
		exposureentry.GLNewExposureGeneralPage(excelFileName, profileID1);
		summary.Summarypage();
		editloss.editLossDetailsPage();
		LossDetailsGL.LossDetailsGLPage(excelFileName, profileID1);
		actionMenuNavigation.ActionMenuTransactionCheckPage();
		payeeinfo.enterPayeeDetails( profileID1);
		paymentinfo.PaymentInformationPage(excelFileName, profileID1);
		setchk.SetCheckInstructionsWithAlert();
		financechk.FinancialCheckspage();
	}

	@When("Logout from Claim Center application")
	public void logoutapp() throws Exception {
		logoutPage.ClaimsLogout();
	}
	
	@Then("Test Scenario has been executed")
	public void scenariocompletion() throws ParseException {
		UIMethods.stopBrowser();
		Report.totalStatus();
		Report.reportPreparation();
	}

	@Then("Create the execution report")
	public void completeReport() {
		Report.reportCompletion();
	}

	/*@AfterScenario
	public void AfterEveryScenario() {
		UIMethods.stopBrowser();
	}*/
}