# CICC 9 Automation base

Automation Testing Using Selenium, BDD (JBehave) and customized HTML reports

Automation base is a behavior driven development (BDD) approach using JBehave framework to write automation test script to test Web. 

Getting Started
-------------
These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

Documentation
-------------
* [Installation](doc/installation.md)
* [Run tests](doc/run_tests.md)

Prerequisites
--------------
Java
Maven  
SVN

Installing
-------------
Clone the repository into your local machine to get a working project

Configuring environment, project suite (Smoke/Regression)
-------------
Open Config.Properties file which is presented under project directory - > src/test/resources

Running the tests - command line mode
-------------------
Before running the project please make sure that the Config.Properties files are updated

cd to project path  

mvn clean test  

Running the tests - from IDE  
-------------------
Right click on the project - Run As - > Maven Clean
Right click on the project - Maven - > Update Project
Right click on the project - Run As - > Maven test

Built With
-------------
* [Selenium](http://www.seleniumhq.org/) - The web framework to automate browsers
* [Maven](https://maven.apache.org/) - Dependency Management

Versioning (SVN)
-------------
For the versions available, see the this repository (https://svn-forge.lmig.com/svn/ci/qa-claims/Claims/org.qa.Claims.CICC9/) 

Authors
-------------
**Rajkumar R**  - Skype: Rajendiran, Rajkumar Email: Rajkumar.Rajendiran@LibertyMutual.com