# Run automation

- Open Config.Properties file Which is available under src/test/resources folder
- Update your configurations (Execution Mode, Browser Name, Project suite name)

- Goto root project. Right click on the project name
- Run mvn clean to delete /target content folder - Run As - > Maven Clean
- Update Maven project - > Right click on the project - > Maven - > Update project

- To run the project
- Right click on the project - > Run As - > Maven test
