  
# Setup procedure  

- Install Java latest version 
- Install Maven
- Clone repository SVN clone https://svn-forge.lmig.com/svn/ci/qa-claims/Claims/org.qa.Claims.CICC9