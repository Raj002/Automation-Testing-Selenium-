package org.qa.Underwrite.REST.TestCases;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Map;

import org.json.simple.parser.JSONParser;
import org.qa.lmpw.rest.utilities.DBConnection;
import org.qa.lmpw.rest.utilities.Utilities;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.builder.ResponseBuilder;
import io.restassured.filter.Filter;
import io.restassured.filter.FilterContext;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.FilterableResponseSpecification;

/**
 * @author n0296668
 *
 */
public class REST_Services {

	public Response GETResponse = null;
	public ArrayList<String> SOVLocationID = null;
	public ArrayList<String> FormerLocationID = null;
	
	String agreementID  = Utilities.getProperty("AGREEMENT_ID");
	String baseURI = Utilities.getProperty("BASE_URL");
	
	final String access_Token = Utilities.getProperty("ACCESS_TOKEN");
	final String client_ID = Utilities.getProperty("CLIENT_ID");
	
	@BeforeClass
	public void Setup() {
		GETResponse = given().headers("X-Access-Token",access_Token, "X-Client-ID",client_ID).auth().preemptive().oauth2(access_Token).
				when().get(baseURI + "locations/" + agreementID);
		
	}
	
	@Test (description = "GET - > Validate status code, statusLine, Response time and location id")
	public void TC001() throws IOException {		
		
		given().
			auth().preemptive().oauth2(access_Token).filter(new Filter() {

				public Response filter(FilterableRequestSpecification requestSpec,
						FilterableResponseSpecification responseSpec, FilterContext ctx) {
					assertThat(requestSpec.getHeaders().getValue("Authorization"), equalTo("Bearer " + access_Token));
					return new ResponseBuilder().setBody("ok").setStatusCode(200).build();
				}
			}).
			
		when().
			get(baseURI + "locations/" + agreementID).
			
		then().assertThat().
			statusCode(Utilities.EXPECTED_RESPONSE_STATUS_CODE_200);		

		
		JsonPath json = GETResponse.jsonPath();
		Map<String, Object> headers = json.getMap("headerDataCargo");
		
		Object agreement_ID = headers.get("agreementId");
		Object accountName = headers.get("accountName");
		Object policyNumber = headers.get("policyNumber");
		Object effectiveDate = headers.get("effectiveDate");
		Object expirationDate = headers.get("expirationDate");
		Object policyForm = headers.get("policyForm");
		Object insuredName = headers.get("insuredName");
		Object proposalUW = headers.get("proposalUW");
		Object proposalUA = headers.get("proposalUA");
		Object ebUW = headers.get("ebUW");
		Object ebUA = headers.get("ebUA");
		Object sovLocations = headers.get("sovLocations");
		Object autoMatchedLocations = headers.get("autoMatchedLocations");
		
		DBConnection.getDB2Value("headers", "AGRMNT_ID");
		
		String APIHeaders[] = {String.valueOf(agreement_ID),String.valueOf(accountName),String.valueOf(policyNumber),String.valueOf(insuredName),String.valueOf(effectiveDate),String.valueOf(expirationDate),String.valueOf(policyForm),
							String.valueOf(sovLocations),String.valueOf(autoMatchedLocations),String.valueOf(proposalUW),String.valueOf(proposalUA),String.valueOf(ebUW),String.valueOf(ebUA)};
		
		String DBHeaders[] = {"AGRMNT_ID","ACCOUNT_NAME","PLCY_NBR","AGRMNT_NM","AGRMNT_EFFCTV_DT","AGRMNT_EXPRTN_DT","PLCY_FORM",
								"NBR_ADDR_UPLD","NBR_ADDR_AUTO_MTCH","UW_NM","EBUW_NM","EBUA_NM"};
		for(int i = 0; i<12 ; i++) {
			System.out.println(DBHeaders[i] + " : " + DBConnection.getDB2Value("headers", DBHeaders[i]) + " - > " + APIHeaders[i]);
		}
		
		
		/*System.out.println(columnName[1] + " : " + DBConnection.getDB2Value("headers", columnName[1]).toString());
		System.out.println(columnName[2] + " : " + DBConnection.getDB2Value("headers", columnName[2]).toString());
		System.out.println(columnName[3] + " : " + DBConnection.getDB2Value("headers", columnName[3]).toString());
		System.out.println(columnName[4] + " : " + DBConnection.getDB2Value("headers", columnName[4]).toString());
		System.out.println(columnName[5] + " : " + DBConnection.getDB2Value("headers", columnName[5]).toString());
		System.out.println(columnName[6] + " : " + DBConnection.getDB2Value("headers", columnName[6]).toString());
		System.out.println(columnName[7] + " : " + DBConnection.getDB2Value("headers", columnName[7]).toString());
		System.out.println(columnName[8] + " : " + DBConnection.getDB2Value("headers", columnName[8]).toString());
		System.out.println(columnName[9] + " : " + DBConnection.getDB2Value("headers", columnName[9]).toString());
		System.out.println(columnName[10] + " : " + DBConnection.getDB2Value("headers", columnName[10]).toString());
		System.out.println(columnName[11] + " : " + DBConnection.getDB2Value("headers", columnName[11]).toString());*/
		
		
		
	}
	
	@Test(description = "POST - > Validate posted data from DB", enabled = false)
	public void TC002() throws UnsupportedEncodingException {
		
		// Sending POST request to the server and validate the status code
		given().
			contentType(ContentType.JSON).headers("X-Access-Token",access_Token, "X-Client-ID",client_ID).
			auth().oauth2(access_Token).
			body("[{\r\n" + 
				"	\"sov_locId\": " + Utilities.getProperty("SOV_LOCATION_ID") + ",\r\n" + 
				"	\"fmr_locId\": " + Utilities.getProperty("FORMER_LOCATION_ID") + "\r\n" + 
				"}]").
		when().
			post(baseURI+"save-data").
			
		then().assertThat().
			statusCode(Utilities.EXPECTED_RESPONSE_STATUS_CODE_200);
		
		// Update SOV_SUB_LOC_TEMP table to save SOV and Former Location ID's
		DBConnection.getDB2Value("save data", "SOV_SUB_LOC_TEMP_ID");
		SOVLocationID = DBConnection.getDB2Value("select", "SOV_SUB_LOC_TEMP_ID");
		FormerLocationID = DBConnection.getDB2Value("select", "MTCH_SUB_LOC_ID");
		
		// Validate saved SOV and Former location ID's from DB2 with the actual input
		for (int i = 0; i < SOVLocationID.size(); i++) {
			if (!SOVLocationID.get(i).equals(Utilities.getProperty("SOV_LOCATION_ID"))) {
				Assert.fail("Save SOV data batch update was FAILED - > " + Utilities.getProperty("AGREEMENT_ID"));
			}
			
			if (!FormerLocationID.get(i).equals(Utilities.getProperty("FORMER_LOCATION_ID"))) {
				Assert.fail("Save SOV data batch update was FAILED - > " + Utilities.getProperty("AGREEMENT_ID"));
			}
		}
	}	
	
	@Test (description = "POST - > Start-Over the locations", enabled = false)
	public void TC03() {
		
		given().headers("X-Access-Token",access_Token, "X-Client-ID",client_ID).auth().oauth2(access_Token).
		when().
			post(baseURI + "start-over/" + agreementID).
			
		then().assertThat().
			statusCode(Utilities.EXPECTED_RESPONSE_STATUS_CODE_200);

		// Update SOV_SUB_LOC_TEMP table to revoke updated Former location ID's
		DBConnection.getDB2Value("save data", "SOV_SUB_LOC_TEMP_ID");
		SOVLocationID = DBConnection.getDB2Value("select", "SOV_SUB_LOC_TEMP_ID");
		FormerLocationID = DBConnection.getDB2Value("select", "MTCH_SUB_LOC_ID");		
		
		// Validating revoked location ID's from DB2 with the actual input
		for (int i = 0 ; i < SOVLocationID.size(); i++) {
			if (!SOVLocationID.get(i).equals(Utilities.getProperty("SOV_LOCATION_ID"))) {
				Assert.fail("Save SOV data batch update was FAILED - > " + Utilities.getProperty("AGREEMENT_ID"));
			}
			
			if (FormerLocationID.get(i) == null) {
				System.out.println("start over sov data update was successful for agreement ID -> " +Utilities.getProperty("AGREEMENT_ID"));
				
			} else {
				Assert.fail("Save SOV data batch update was FAILED - > " + Utilities.getProperty("AGREEMENT_ID"));
			}
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public static void validateDB2Data(ArrayList<String> LID, ArrayList<String> FID) {

		for (int i = 1; i < LID.size(); i++) {
			if (!LID.get(i).equals(Utilities.getProperty("SOV_LOCATION_ID"))) {
				Assert.fail("Save SOV data batch update was FAILED - > " + Utilities.getProperty("AGREEMENT_ID"));
			}

			if (!FID.get(i).equals(Utilities.getProperty("FORMER_LOCATION_ID"))) {
				Assert.fail("Save SOV data batch update was FAILED - > " + Utilities.getProperty("AGREEMENT_ID"));
			}
		}
	}	
}
