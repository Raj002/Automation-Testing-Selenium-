package org.qa.lmpw.rest.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * @author n0296668
 *
 */
public class DBConnection 
{
	// DB reference variables
	static String db2_jdbc_driver = Utilities.getProperty("DB2_JDBC_DRIVER");
	static String db2_db_url = Utilities.getProperty("DB2_DB_URL");
	static String db2_userName = Utilities.getProperty("DB2_USER");
	static String db2_password = Utilities.getProperty("DB2_PASS");
	
	static Connection con = null;
	static Statement stmt = null;
	static ResultSet resultset = null;
	static PreparedStatement pr = null;
	static boolean found = false;
	static String data = null;
	static ArrayList<String> list = null;
	
	/**
	 * Please provide valid column name which you want to get values from the Database
	 *
	 */
	public static ArrayList<String> getDB2Value(String testType, String columnName) {		
		try {
			// Register DB2Driver
			Class.forName(db2_jdbc_driver).newInstance();

			// Open a connection
			con = DriverManager.getConnection(db2_db_url, db2_userName, db2_password);

			// Execute a query
			stmt = con.createStatement();

			// Create prepared statement to execute query
			String sqlQuery = null;
			String testName = testType;
			
			switch (testName.toLowerCase()) {
			case "headers":
				sqlQuery = getHeaderQuery();
				break;

			case "save data":
				sqlQuery = selectQuery();
				break;

			case "start over":
				sqlQuery = updateStartOver();
				break;

			case "select":
				sqlQuery = selectQuery();
				break;

			default:
				System.err.println("Please provide valid option to execute DB Query...");
				break;
			}
			
			pr = con.prepareStatement(sqlQuery);
			resultset = pr.executeQuery();
			if (resultset != null) {
				list = new ArrayList<String>();
				while (resultset.next()) {
					found = true;
					data = resultset.getString(columnName);
					list.add(data);			
				}
			}
			if (found == false) {
				System.out.println("No informaiton found...");
			}

		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
			}
			try {
				if (con != null)
					con.close();
			} catch (SQLException se) {
				se.printStackTrace();
			} 
		} 

		return list;
	}
	
	
	
	public static String getQuery() {
		String actualGetQuery = "SELECT SSLT.SOV_SUB_LOC_TEMP_ID, SSLT.SUB_LOC_NM, SSLT.ADDR_LN_1_TXT, SSLT.CITY_TWN_NM, SP.ST_PRVN_CD, SSLT.POSTL_CD, SSLT.OCPNCY_DSC, SSLT.TIV " + 
				"FROM SCOUT.SOV_SUB_LOC_TEMP SSLT JOIN SCOUT.SOV_LOAD SL ON SL.SOV_LOAD_ID = SSLT.SOV_LOAD_ID  JOIN  SCOUT.ST_PRVN SP  ON SP.ST_PRVN_ID = SSLT.ST_PRVN_ID " + 
				"WHERE SL.AGRMNT_ID = " + Utilities.getProperty("AGREEMENT_ID") + " AND SL.STAT_TYP_ID=20 and SSLT.SOV_WAS_AUTO_MTCH='N' AND SSLT.MTCH_SUB_LOC_ID IS NULL";		
		return actualGetQuery;
	}
	
	public static String getHeaderQuery() {
		String actualHeaderQuery = "SELECT AGR.AGRMNT_ID, ACT.ACCOUNT_NAME, PLCY.PLCY_NBR, SLP.PGM_PLCY_NBR, AGR.AGRMNT_NM, AGR.AGRMNT_EFFCTV_DT, AGR.AGRMNT_EXPRTN_DT, CD.CD_NM AS PLCY_FORM, " + 
				"SOV.NBR_ADDR_UPLD, (SELECT COUNT(*) FROM SCOUT.SOV_SUB_LOC_TEMP SSLT JOIN SCOUT.SOV_LOAD SL ON SL.SOV_LOAD_ID = SSLT.SOV_LOAD_ID WHERE SL.AGRMNT_ID = " + Utilities.getProperty("AGREEMENT_ID") + "" + 
				" AND SL.STAT_TYP_ID =20 AND SSLT.SOV_WAS_AUTO_MTCH='Y') AS NBR_ADDR_AUTO_MTCH, UW_NM, UA_NM, EBUW_NM, EBUA_NM FROM SCOUT.AGRMNT AGR JOIN SCOUT.ACCOUNT_AGREEMENT " + 
				"AA ON AGR.AGRMNT_ID = AA.AGREEMENT_ID AND AA.STAT_TYP_ID = 20  JOIN SCOUT.ACCOUNT ACT ON AA.ACCOUNT_ID = ACT.ACCOUNT_ID AND ACT.STAT_TYP_ID = 20 JOIN " + 
				"SCOUT.CODE CD ON AGR.PLCY_FRM_VER_TYP_ID = CD.CD_ID LEFT JOIN SCOUT.SOV_LOAD SOV ON AGR.AGRMNT_ID = SOV.AGRMNT_ID AND SOV.STAT_TYP_ID =20 LEFT JOIN " + 
				"SCOUT.PLCY PLCY ON AGR.AGRMNT_ID = PLCY.AGRMNT_ID AND PLCY.STAT_TYP_ID = 20 LEFT JOIN SCOUT.SL_PGM SLP on AGR.AGRMNT_ID = SLP.AGRMNT_ID AND " + 
				"SLP.STAT_TYP_ID = 20 LEFT JOIN (SELECT AOP.AGRMNT_ID, CONCAT(PERSN.FRST_NM || ' ', PERSN.LAST_NM) as UW_NM FROM SCOUT.AGRMNT_ORG_PERSN AOP JOIN " + 
				"SCOUT.ORG_PERSN_ROLE OPR ON AOP.ORG_PERSN_ROLE_ID = OPR.ORG_PERSN_ROLE_ID  JOIN SCOUT.PERSN PERSN ON OPR.PERSN_ID = PERSN.PERSN_ID WHERE " + 
				"AOP.TEAM_FUNC_ROLE_TYP_ID = 4105 AND AOP.STAT_TYP_ID=20) UW ON AGR.AGRMNT_ID = UW.AGRMNT_ID LEFT JOIN (SELECT AOP.AGRMNT_ID, CONCAT(PERSN.FRST_NM || ' ', PERSN.LAST_NM) " + 
				"as UA_NM FROM SCOUT.AGRMNT_ORG_PERSN AOP JOIN SCOUT.ORG_PERSN_ROLE OPR ON AOP.ORG_PERSN_ROLE_ID = OPR.ORG_PERSN_ROLE_ID  JOIN SCOUT.PERSN PERSN ON " + 
				"OPR.PERSN_ID = PERSN.PERSN_ID WHERE AOP.TEAM_FUNC_ROLE_TYP_ID =4106 AND AOP.STAT_TYP_ID=20) UA ON AGR.AGRMNT_ID = UA.AGRMNT_ID LEFT JOIN " + 
				"(SELECT AOP.AGRMNT_ID, CONCAT(PERSN.FRST_NM || ' ', PERSN.LAST_NM) as EBUW_NM FROM SCOUT.AGRMNT_ORG_PERSN AOP JOIN SCOUT.ORG_PERSN_ROLE OPR ON " + 
				"AOP.ORG_PERSN_ROLE_ID = OPR.ORG_PERSN_ROLE_ID  JOIN SCOUT.PERSN PERSN ON OPR.PERSN_ID = PERSN.PERSN_ID WHERE AOP.TEAM_FUNC_ROLE_TYP_ID = 4108 AND " + 
				"AOP.STAT_TYP_ID=20) EBUW ON AGR.AGRMNT_ID = EBUW.AGRMNT_ID LEFT JOIN (SELECT AOP.AGRMNT_ID, CONCAT(PERSN.FRST_NM || ' ', PERSN.LAST_NM) as EBUA_NM FROM " + 
				"SCOUT.AGRMNT_ORG_PERSN AOP JOIN SCOUT.ORG_PERSN_ROLE OPR ON AOP.ORG_PERSN_ROLE_ID = OPR.ORG_PERSN_ROLE_ID  JOIN SCOUT.PERSN PERSN ON OPR.PERSN_ID = PERSN.PERSN_ID " + 
				"WHERE AOP.TEAM_FUNC_ROLE_TYP_ID =4109  AND AOP.STAT_TYP_ID=20) EBUA ON AGR.AGRMNT_ID = EBUA.AGRMNT_ID   WHERE AGR.AGRMNT_ID = " + Utilities.getProperty("AGREEMENT_ID") + " AND AGR.STAT_TYP_ID=20";	
		return actualHeaderQuery;
	}
	
	public static String udpdateSaveData() {
		String actualSaveDataQuery = "UPDATE SCOUT.SOV_SUB_LOC_TEMP SSLT SET SSLT.MTCH_SUB_LOC_ID = " + Utilities.getProperty("FORMER_LOCATION_ID") + " WHERE SSLT.SOV_SUB_LOC_TEMP_ID = " + Utilities.getProperty("SOV_LOCATION_ID");
		return actualSaveDataQuery;
	}
	
	public static String updateStartOver() {
		String actualStartOverQuery = "UPDATE SCOUT.SOV_SUB_LOC_TEMP SSLT SET SSLT.MTCH_SUB_LOC_ID = NULL WHERE SSLT.MTCH_SUB_LOC_ID IN ( SELECT SSLT.MTCH_SUB_LOC_ID " + 
				"FROM SCOUT.SOV_SUB_LOC_TEMP SSLT JOIN SCOUT.SOV_LOAD SL ON SL.SOV_LOAD_ID = SSLT.SOV_LOAD_ID " + 
				"WHERE SL.AGRMNT_ID = " + Utilities.getProperty("AGREEMENT_ID") + " AND SL.STAT_TYP_ID=20 AND SSLT.MTCH_SUB_LOC_ID IS NOT NULL AND SSLT.SOV_WAS_AUTO_MTCH='N')";
		return actualStartOverQuery;
	}
	
	public static String selectQuery() {
		String actualQuery = "select SOV_SUB_LOC_TEMP_ID, MTCH_SUB_LOC_ID from SCOUT.SOV_SUB_LOC_TEMP where SOV_SUB_LOC_TEMP_ID = " + Utilities.getProperty("SOV_LOCATION_ID");
		return actualQuery;
	}
	
}
