package org.qa.Underwrite.REST;

import java.util.ArrayList;

import org.qa.lmpw.rest.utilities.DBConnection;
import org.testng.annotations.Test;

/**
 * @author n0296668
 *
 */
public class DBTest {
	
	ArrayList<String> DB2 = null;

	@Test
	public void DBtest() {

		DB2 = DBConnection.getDB2Value("headers", "ACCOUNT_NAME");

		int i = 0;
		do {
			System.out.println("SOV_SUB_LOC_TEMP_ID : " + DB2.get(i));
			i++;
		} while (i < DB2.size());
	
	
	}
	
	

}
