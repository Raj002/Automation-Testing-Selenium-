package org.qa.lmpw.rest.utilities;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;


/**
 * @author n0296668
 *
 */
public class Utilities
{

	// Response status codes
	public static int EXPECTED_RESPONSE_STATUS_CODE_200 = 200;
	public static int EXPECTED_RESPONSE_STATUS_CODE_201 = 201;
	public static int EXPECTED_RESPONSE_STATUS_CODE_400 = 400;
	public static int EXPECTED_RESPONSE_STATUS_CODE_401 = 401;
	public static int EXPECTED_RESPONSE_STATUS_CODE_500 = 500;

	public static Properties prop = null;
	public static FileInputStream fis = null;
	
	/**
	 * Get parameter values from property file
	 * @param propertyName
	 * @return
	 */
	public static String getProperty(String propertyName) {
		File source = new File(System.getProperty("user.dir") + "/Config.properties");

		try {
			prop = new Properties();
			fis = new FileInputStream(source);
			prop.load(fis);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return prop.getProperty(propertyName);
	}
	
	/**
	 * This method can be used to read data from note pad file
	 * @param fileName - Provide valid DB query file name
	 *
	 */
	public static String readDataFromNotePad(String fileName)
	{
		String data = null ;
		String actualQuery = null;
		FileReader fileReader = null;
		try {
			fileReader = new FileReader(".//src//test//resources//DBQueries//" + fileName + ".txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		BufferedReader bufferedReader= new BufferedReader(fileReader);
		try {
			while((data=bufferedReader.readLine())!=null)
			{
				actualQuery = data;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally
		{
			try {
				bufferedReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			try {
				fileReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return actualQuery;
	}	
}
