package stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.qa.amazon.Managers.ObjectManager;
import org.qa.amazon.Pages.HomePage;
import org.qa.amazon.Technology.ConfigReader;
import org.qa.amazon.Technology.UIMethods;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GetProductDetails {

	public WebDriver driver;
	public ObjectManager objManager;
	public ConfigReader config;
	public HomePage homePage;
	
	@Given("^User is on home page$")
	public void user_is_on_home_page() throws Throwable {
		driver = UIMethods.StartBrowser("chrome");
		
		objManager = new ObjectManager(driver);
		config = objManager.getConfigInstance();
		homePage = objManager.getHomePageInstance();
		
	}

	@When("^User search for \"([^\"]*)\" by selecting dropdown option as \"([^\"]*)\"$")
	public void user_search_for_by_selecting_dropdown_option_as(String searchText, String dropDownOption) throws Throwable {
		
		homePage.selectDropdownValue(dropDownOption);
		homePage.typeValueInSearchBox(searchText);
		homePage.clickSearchIcon();
		
	}

	@When("^Click on first product item$")
	public void click_on_first_product_item() throws Throwable {

		
	}

	@Then("^Get all the product details$")
	public void get_all_the_product_details() throws Throwable {

		
	}

	@Then("^Close the browser$")
	public void close_the_browser() throws Throwable {
	    

	}
	
	
	
}
