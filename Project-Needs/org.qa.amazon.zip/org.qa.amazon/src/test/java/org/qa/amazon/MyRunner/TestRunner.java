package org.qa.amazon.MyRunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features="FeatureFiles/GetProductDetails.feature",
		glue= {"stepDefinitions"},
		format= {"pretty","html:test-output", "json:json_output/cucumber.json", 
				"junit:junit_xml/cucumber.xml","rerun:target/cucumber-reports/rerun.txt"},
		plugin = "json:target/cucumber-reports/CucumberTestReport.json",
		monochrome=true,
		strict=true,
		dryRun=false)
public class TestRunner {

}