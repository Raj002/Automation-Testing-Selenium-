package org.qa.amazon.Technology;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.qa.amazon.Managers.ObjectManager;

import io.github.bonigarcia.wdm.WebDriverManager;

public class UIMethods
{
	public static WebElement element = null;
	public static String browser;
	public static WebDriver driver = null;
	public static WebDriverWait wait = null;
	public static String projectdir = System.getProperty("user.dir");
	
	static ObjectManager objs = new ObjectManager(driver);
	private static Utilities utilities = objs.getUtilsInstance();
	private static ConfigReader config = objs.getConfigInstance();
	
	public static Logger logger = Logger.getLogger(UIMethods.class);
	
	/**
	 * Launch the browser based on the input Available browser options
	 * GoogleChrome , IE, FireFox
	 * 
	 * @param tcId
	 * @return
	 * @throws MalformedURLException
	 * @throws IOException
	 */
	public static WebDriver launchBrowser(String browserName) throws MalformedURLException {
		browser = browserName.toLowerCase();
		String proxyPassword = config.GetPropertyValue("PROXY_PASSWORD");
		
		if (browser.equals("mozilla")) {
			System.setProperty("webdriver..driver", "");
			driver = new FirefoxDriver();

		} else if (browser.equals("ie")) {
			String strExecutionType = (config.GetPropertyValue("EXECUTION_TYPE")).toString().toLowerCase();
			
			if (strExecutionType.equalsIgnoreCase("local")) {
				System.setProperty("webdriver.ie.driver", projectdir + "/src/test/resources/executableDrivers/IEDriverServer.exe");
				
				DesiredCapabilities capab = DesiredCapabilities.internetExplorer();
				capab.setCapability(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING, false);
				capab.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, false);
				capab.setCapability(InternetExplorerDriver.UNEXPECTED_ALERT_BEHAVIOR, true);
				capab.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				capab.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
				capab.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
				driver = new InternetExplorerDriver(capab);
				
			} else {
				
				DesiredCapabilities capab = DesiredCapabilities.internetExplorer();
				capab.setCapability("platform", "Windows 10");
				capab.setCapability("version", "11");
				capab.setCapability(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING, false);
				capab.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, false);
				capab.setCapability(InternetExplorerDriver.UNEXPECTED_ALERT_BEHAVIOR, true);
				capab.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				capab.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
				capab.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
				capab.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
				capab.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);		
				
				capab.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
				capab.setCapability("parent-tunnel", "LMSauceLabs");
				capab.setCapability("tunnel-identifier", "nonprod");
				capab.setCapability("disable-popup-blocking", true);
				capab.setCapability("name", "Claim Center 9 ");
				capab.setCapability("passed", "true");
				driver = new RemoteWebDriver(new URL(config.GetPropertyValue("SAUCE_LAB_URL")),capab);
			}
		} else if (browser.equals("chrome")) {
			WebDriverManager.chromedriver().arch64().setup();
			ChromeOptions chromeOptions = new ChromeOptions();
			chromeOptions.addArguments("disable-extensions");
			chromeOptions.addArguments("disable-infobars");
			chromeOptions.addArguments("no-sandbox");
			driver = new ChromeDriver(chromeOptions);
			
		} else if (browser.equalsIgnoreCase("chromeheadless")) {
		
			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("headless");
			options.addArguments("window-size=1200x600");
			driver = new ChromeDriver(options);
		} 
		
		return driver;
	}
	
	 public static WebDriver getDriver() {
	        return driver;
	    }
	
	/**
	 * Maximize Browser window
	 * 
	 * @param browserName
	 * @return
	 * @throws IOException 
	 * @throws InterruptedException 
	 */
	public static WebDriver StartBrowser(String browserName) throws IOException, InterruptedException {

		driver = launchBrowser(browserName);

		try {
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			
			String appURL = config.GetPropertyValue("APPLICATION_URL");
			System.out.println("Applicatioin URL : " + appURL);
			
			driver.get("https://www.amazon.com");
			logger.info(driver.getCurrentUrl() + " is launched successfully");
			
			Thread.sleep(5000);
		} catch (Exception e) {
			logger.warn(config.GetPropertyValue("APPLICATION_URL") + " Failed to launch the given URL");
		}
		
		return driver;
	}

	/**
	 * Delete All the Cookies
	 */
	public static void deleteBrowserCookies() {
		driver.manage().deleteAllCookies();
	}
	
	/**
	 * Stop Browser
	 */
	public static void stopBrowser() {

		try {
			driver.close();
			driver.quit();
			if (isAlertPresent()) {
				Alert alert = driver.switchTo().alert();
				alert.accept();
				Thread.sleep(3000);
			}
			if (browser.equals("IE")) {
				Runtime.getRuntime().exec("taskkill /F /IM iexplore.exe");
			} else if (browser.equals("Chrome")) {
				Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
			}
		} catch (Exception ex) {
			System.out.println("Killed process");
		}
	}
	
	/**
	 * Verify Screen
	 * 
	 * @param fieldName
	 * @param pageName
	 * @return
	 * @throws IOException 
	 */
	public static void PageVerification(WebElement element, String screenName) throws Exception {
		try {
			if (element.isDisplayed() == true) {
				logger.info(screenName + " screen is loaded successfully");
			}
		} catch (Exception ex) {
			logger.warn(screenName + " screen is not loaded successfully");
		}
	}
	
	
	// ################################## Alert Methods ##################################
	
	/**
	 * Verify presence of alert
	 * @return
	 */
	
	public static boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException ex) {
			return false;
		}
	}
	
	/**
	 * Accept alert
	 */
	public static void acceptAlert() {
		String alertText = null;
		try {
			Alert al = driver.switchTo().alert();
			alertText = driver.switchTo().alert().getText();
			al.accept();
			logger.info("Alert accepted - " + alertText);
		} catch (NoAlertPresentException e) {
			logger.warn("failed to accept alert - " + alertText);
		}
	}
	
	/**
	 * Select drop down value using XPATH Object
	 * @param objects - XPATH of drop down WebElement
	 * @param description
	 * @param testData
	 */
	public static void selectDropdownByXpath(String description, String objects, String testData) {
		try {
			int count = driver.findElements(By.xpath(objects)).size();
			if (count == 1) {
				String dropText = driver.findElement(By.xpath(objects)).getText();
				String[] drop = objects.split("/option");
				new Select(driver.findElement(By.xpath(drop[0]))).selectByVisibleText(dropText);
				logger.info(description + " -> "+ testData + " is selected ");
			}
		} catch (Exception e) {

			logger.warn(description + " is Not Found / Not Selected" + e);
		}
	}
	
	/**
	 * Select drop down value using ID Object
	 * @param objects - ID of drop down WebElement
	 * @param description
	 * @param testData
	 */
	public static void selectDropdownByID(String description, String objects, String testData) {
		try {

			int count = driver.findElements(By.id(objects)).size();
			if (count == 1) {
				new Select(driver.findElement(By.id(objects))).selectByVisibleText(testData);
				logger.info(description + " -> " + testData + " is selected ");
			}
		} catch (Exception e) {
			logger.warn(description + " is Not Found / Not Selected" + e);
		}
	}
	
	/**
	 * Select drop down value using web element
	 * @param description
	 * @param element
	 * @param testData
	 */
	public static void selectDropdownByWebElement(String description, WebElement element, String testData) {
		try {
			if (element.isDisplayed() && element.isEnabled()) {
				Thread.sleep(500);
				new Select(element).selectByVisibleText(testData);
				logger.info(description + " -> " + testData + " is selected ");
			}
		} catch (Exception e) {
			logger.warn(description + " is Not Found / Not Selected" + e);
		}
	}
	
	public static String getSelectedValue(WebElement element) {
		String dropDownValue = new Select(element).getFirstSelectedOption().getText();
		
		if (dropDownValue.isEmpty()) {
			return null;
		} else {
			return dropDownValue;
		}
		
	}
	
	/**
	 * Click the WebElement using ID Object
	 * 
	 * @param objects - ID (Attribute Value) of WebElement
	 * @param description
	 */
	public static boolean clickbyid(String description, String objects) {
		boolean boolReturn = false;
		
		for (int i = 1; i <= 1; i++) {
			try {
				int count = driver.findElements(By.id(objects)).size();
				if (count == 1) {
					driver.findElement(By.id(objects)).click();
					logger.info(description + " is Clicked");
					boolReturn = true;
				}
			} catch (Exception e) {
				logger.warn(description + " is Not Found / Not Clicked" + e);
				e.printStackTrace();
				boolReturn = false;
			}
		}
		return boolReturn;
	}
	
	/**
	 * Click the WebElement using Name Object
	 * 
	 * @param objects - Name (Attribute Value) of WebElement
	 * @param description
	 */
	public static void clickbyname(String description, String objects) {
		try {
			int count = driver.findElements(By.name(objects)).size();
			if (count == 1) {
				driver.findElement(By.name(objects)).click();
				logger.info(description + " is Clicked");
			} 
		} catch (Exception e) {
			logger.info(description + " is Not Found / Not Clicked");
			e.printStackTrace();
		}
	}
	
	/**
	 * Click the WebElement using XPATH Object
	 * 
	 * @param objects - XPATH of WebElement
	 * @param description
	 */
	public static boolean clickbyxpath(String description, String objects) {		
		boolean boolReturn = false;		
		
		for (int i=1; i<=1; i++) {
			try {
				Thread.sleep(500);
				int count = driver.findElements(By.xpath(objects)).size();
				System.out.println(count);
				if (count >= 1) {
					driver.findElement(By.xpath(objects)).click();
					logger.info(description + " is Clicked");
					boolReturn= true;
				}	
			} catch (Exception e) {
				logger.info(description + " is Not Found / Not Clicked" + e);
				e.printStackTrace();
				boolReturn= false;
			}
		}
		return boolReturn;
	}
	
	/**
	 * Click the WebElement using XPATH Object through JavaScript
	 * 
	 * @param objects - XPATH of WebElement
	 * @param description
	 */
	public static boolean JSClickByXpath(String description, String objects) {
		boolean boolReturn = false;

		for (int i = 1; i <= 1; i++) {
			try {
				Thread.sleep(500);
				int count = driver.findElements(By.xpath(objects)).size();
				if (count >= 1) {
					WebElement chose = driver.findElement(By.xpath(objects));
					JavascriptExecutor js = (JavascriptExecutor) driver;
					js.executeScript("arguments[0].click();", chose);
					logger.info(description + " is Clicked");
					boolReturn = true;
				}
			} catch (Exception e) {
				logger.warn(description + " is Not Found / Not Clicked" + e);
				boolReturn = false;
			}
		}
		return boolReturn;
	}
	
	/**
	 * Click the WebElement using cssSelector object
	 * 
	 * @param objects - cssSelector of WebElement
	 * @param description
	 */
	public static void clickbyCssSelector(String description, String objects) {
		try {
			Thread.sleep(500);
			int count = driver.findElements(By.cssSelector(objects)).size();
			if (count == 1) {
				driver.findElement(By.cssSelector(objects)).click();
				logger.info(description + " is Clicked");
			}
		} catch (Exception e) {
			logger.warn(description + " is Not Found / Not Clicked" + e);
		}
	}
	
	/**
	 * Click the WebElement using linkText object
	 * 
	 * @param objects - linkText of WebElement
	 * @param description
	 */
	public static void clickbylinktext(String description, String objects) {
		try {
			int count = driver.findElements(By.linkText(objects)).size();
			if (count == 1) {
				driver.findElement(By.linkText(objects)).click();
				logger.info(description + " is Clicked");
			}
		} catch (Exception e) {
			logger.warn(description + " is Not Found / Not Clicked" + e);
		}
	}

	/**
	 * Click the given WeElement object
	 * 
	 * @param objects - WebElement
	 * @param description
	 */
	public static void clickbyWebElement(String description, WebElement element) {
		try {
			Thread.sleep(500);
			if (element.isEnabled()) {
				element.click();
				logger.info(description + " is Clicked");
			}
		} catch (Exception e) {
			logger.warn(description + " is Not Found / Not Clicked" + e);
		}
	}
	
	/**
	 * Double Click the given WebElement object
	 * 
	 * @param element - WebElement
	 * @param description
	 * @param testData
	 */
	public static void doubleClickbyWebElement(String description, WebElement element) {
		try {
			Thread.sleep(500);
			if (element.isEnabled()) {
				Actions action = new Actions(driver);
				action.doubleClick(element).perform();
				logger.info(description + " is Clicked");
			}
		} catch (Exception e) {
			logger.warn(description+ " is Not Found / Not Clicked" + e);
		}
	}
	
	public static void clearAndInputByWebElement(String description, WebElement element, String testData) {
		for (int i = 1; i <= 2; i++) {
			try {
				if (element.isDisplayed() && element.isDisplayed()) {
					element.clear();
					element.sendKeys(testData);
					logger.info(description + " is Cleared & Entered " + testData);
				}
			} catch (Exception e) {
				logger.warn(description + " is Not Found / Not Cleared" + e);
			}
		}
	}
	
	/**
	 * Clear and Input the text box field using ID Object
	 * 
	 * @param objects - ID of WebElement
	 * @param description
	 * @param testData
	 */
	public static void clearAndInputbyid(String description, String objects, String testData) {
		for (int i = 1; i <= 1; i++) {
			try {
				int count = driver.findElements(By.id(objects)).size();
				if (count == 1) {
					driver.findElement(By.id(objects)).clear();
					driver.findElement(By.id(objects)).sendKeys(testData);
					logger.info(description + " is Cleared & Entered " + testData);
				}
			} catch (Exception e) {
				logger.warn(description + " is Not Found / Not Cleared" + e);
			}
		}
	}

	/**
	 * Clear and Input the text box field using XPATH Object
	 * 
	 * @param objects - XPATH of WebElement
	 * @param description
	 * @param testData
	 */
	public static void clearAndinputbyxpath(String description, String objects, String testData) {
		try {
			int count = driver.findElements(By.xpath(objects)).size();
			if (count >= 1) {
				driver.findElement(By.xpath(objects)).clear();
				Thread.sleep(400);
				driver.findElement(By.xpath(objects)).sendKeys(testData);
				logger.info(description + " is Cleared & Entered " + testData);
			}
		} catch (Exception e) {
			logger.warn(description + " is Not Found / Not Cleared" + e);
			e.printStackTrace();
		}
	}

	/**
	 * Clear and Input the text box field using cssSelector Object
	 * 
	 * @param objects - cssSelector of WebElement
	 * @param description
	 * @param testData
	 */
	public static void clearAndinputbyCssSelector(String description, String objects, String testData) {
		try {
			int count = driver.findElements(By.cssSelector(objects)).size();
			if (count == 1) {
				driver.findElement(By.cssSelector(objects)).clear();
				driver.findElement(By.cssSelector(objects)).sendKeys(testData);
				logger.info(description + " is Cleared & Entered " + testData);
			}
		} catch (Exception e) {
			logger.warn(description + " is Not Found / Not Cleared" + e);
		}
	}
	
	/**
	 * Type test data on the given WebElement
	 * 
	 * @param objects - WebElement
	 * @param description
	 * @param testData
	 *//*
	public static void inputbyWebElement(String description, WebElement element, String testData) {
		for (int i = 1; i <= 1; i++) {
			// Exit if data is Empty
			if (testData == "" || testData == null)
				break;
			try {
				element.clear();
				Thread.sleep(500);
				if (element.isEnabled()) {
					element.sendKeys(testData);
					logger.info(description + " is Entered");
					String actualValue = utilities.getTextBoxValue(element);
					String expectedValue = testData;
					if (!actualValue.trim().equalsIgnoreCase(expectedValue.trim()))
						logger.warn("Actual : " + actualValue + ", Expected : " + expectedValue + " -> Not Matched");
				}
			} catch (Exception e) {
				logger.warn(description + " is Not Found / Not Entered" + e);
			}
		}		
	}

	*//**
	 * Type test data on the given ID Object
	 * 
	 * @param objects - ID of WebElement
	 * @param description
	 * @param testData
	 *//*
	public static void inputbyid(String description, String objects, String testData) {
		for (int i = 1; i <= 1; i++) {
			// Exit if data is Empty
			if (testData == "" || testData == null)
				break;
			try {
				int count = driver.findElements(By.id(objects)).size();
				if (count == 1) {
					driver.findElement(By.id(objects)).sendKeys(testData);
					logger.info(description + " is Entered");
					String actualValue = utilities.getTextBoxValue(driver.findElement(By.id(objects)));
					String expectedValue = testData;
					if (!actualValue.trim().equalsIgnoreCase(expectedValue.trim()))
						logger.warn("Actual : " + actualValue + ", Expected : " + expectedValue + " -> Not Matched");
				}
			} catch (Exception e) {
				logger.warn(description + " is Not Found / Not Entered" + e);
			}
		}
	}

	*//**
	 * Type test data on the given WebElement using Name Object
	 * 
	 * @param objects - Name of WebElement
	 * @param description
	 * @param testData
	 *//*
	public static void inputbyname(String description, String objects, String testData) {
		for (int i = 1; i <= 1; i++) {
			// Exit if data is Empty
			if (testData == "" || testData == null)
				break;
			try {
				int count = driver.findElements(By.name(objects)).size();
				if (count == 1) {
					driver.findElement(By.name(objects)).sendKeys(testData);
					logger.info(description + " is Entered");
					String actualValue = utilities.getTextBoxValue(driver.findElement(By.name(objects)));
					String expectedValue = testData;
					if (!actualValue.trim().equalsIgnoreCase(expectedValue.trim()))
						logger.warn("Actual : " + actualValue + ", Expected : " + expectedValue + " -> Not Matched");
				}
			} catch (Exception e) {
				logger.warn(description + " is Not Found / Not Entered" + e);
			}
		}
	}

	*//**
	 * Type test data on the given WebElement using XPATH Object
	 * 
	 * @param objects - XPATH of WebElement
	 * @param description
	 * @param testData
	 *//*
	public static void inputbyxpath(String description, String objects, String testData) {
		for (int i = 1; i <= 1; i++) {
			// Exit if data is Empty
			if (testData == "" || testData == null)
				break;
			try {
				int count = driver.findElements(By.xpath(objects)).size();
				if (count == 1) {
					driver.findElement(By.xpath(objects)).sendKeys(testData);
					logger.info(description + " is Entered");
					String actualValue = utilities.getTextBoxValue(driver.findElement(By.xpath(objects)));
					String expectedValue = testData;
					if (!actualValue.trim().equalsIgnoreCase(expectedValue.trim()))
						logger.warn("Actual : " + actualValue + ", Expected : " + expectedValue + " -> Not Matched");
				}
			} catch (Exception e) {
				logger.warn(description + " is Not Found / Not Entered" + e);
			}
		}
	}
	
	*//**
	 * Select drop down value using XPATH Object
	 * @param objects - XPATH of drop down WebElement
	 * @param description
	 * @param testData
	 *//*
	public static void selectDropdownByXpath(String description, String objects, String testData) {
		try {
			int count = driver.findElements(By.xpath(objects)).size();
			if (count == 1) {
				String dropText = driver.findElement(By.xpath(objects)).getText();
				String[] drop = objects.split("/option");
				utilities.waitUntilSelectOptionPupulated(new Select(driver.findElement(By.xpath(drop[0]))), driver);
				new Select(driver.findElement(By.xpath(drop[0]))).selectByVisibleText(dropText);
				logger.info(description + " -> "+ testData + " is selected ");
			}
		} catch (Exception e) {

			logger.warn(description + " is Not Found / Not Selected" + e);
		}
	}
	
	*//**
	 * Select drop down value using ID Object
	 * @param objects - ID of drop down WebElement
	 * @param description
	 * @param testData
	 *//*
	public static void selectDropdownByID(String description, String objects, String testData) {
		try {

			int count = driver.findElements(By.id(objects)).size();
			if (count == 1) {
				utilities.waitUntilSelectOptionPupulated(new Select(driver.findElement(By.id(objects))), driver);
				new Select(driver.findElement(By.id(objects))).selectByVisibleText(testData);
				logger.info(description + " -> " + testData + " is selected ");
			}
		} catch (Exception e) {
			logger.warn(description + " is Not Found / Not Selected" + e);
		}
	}
	
	*//**
	 * Retry to click WebElement
	 * @param by - Object of WebElement
	 * @return
	 *//*
	public boolean retryingFindClick(By by) {
		boolean result = false;
		int attempts = 0;
		while (attempts < 2) {
			try {
				driver.findElement(by).click();
				result = true;
				break;
			} catch (StaleElementReferenceException e) {
			}
			attempts++;
		}
		return result;
	}
	
	*//**
	 * Click on a button by its Name
	 * @param element
	 * @param buttonText
	 * @param description
	 * @param testData
	 * @param buttonNumber
	 *//*
	public static void clickButtonByButtonText(String description, WebElement element, String buttonText, int buttonNumber) {
		List<WebElement> allButtons;
		boolean flag = false;
		int count = 1;
		try {
			allButtons = element.findElements(By.tagName("button"));
			for (WebElement button : allButtons) {
				System.out.println(button.getText());
				if (button.getText().equals(buttonText)) {
					if (count == buttonNumber) {
						button.click();
						flag = true;
						break;
					}
					count++;
				}
			}
			if (flag == true)
				logger.info(buttonText + " Button Found");			
		} catch (Exception e) {
			logger.warn(buttonText + " Button not Found");
		}
	}	
	
	*//**
	 * Get Number of buttons in the page using button Text
	 * @param buttonText
	 * @return
	 *//*
	public static int numberOfButtonByButtonText(String buttonText) {
		List<WebElement> allButtons;
		int count = 0;
		try {
			allButtons = driver.findElements(By.tagName("button"));
			for (WebElement button : allButtons) {
				if (button.getText().equals(buttonText)) {
					count++;
				}
			}
		} catch (Exception e) {
			logger.warn(buttonText + "Button Not Found");
		}
		return count;
	}
	
	*//**
	 * Click button where label Nth Occurrence
	 * @param labelName - Button label name
	 * @param occurnence - Occurrence of button
	 * @return
	 *//*
	public UIMethods clickButtonWhereLabelNthOccurence(String labelName, String occurrence) {
		boolean isFlagged = false;
		while (!isFlagged) {
			try {
				By buttonBy = By.xpath("(//*[contains(text(),'" + labelName + "')]/parent :: a[@class = 'button'])["
						+ occurrence + "]");
				utilities.findObject(driver, buttonBy, 30);
				WebElement buttonEle = driver.findElement(buttonBy);
				buttonEle.isDisplayed();
				((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + buttonEle.getLocation().y + ")");
				buttonEle.click();
				break;
			} catch (StaleElementReferenceException e) {
				logger.info("Into Stale");
				continue;
			}
		}
		return this;
	}
	
	*//**
	 * Click button where any letter under lined with the given character
	 * @param labelName - Button label name
	 * @param underLinedLetter - Under lined character
	 * @return
	 *//*
	public UIMethods clickButtonWhereAnyLetterUnderLined(String labelName, String underLinedLetter) {
		boolean isFlagged = false;

		while (!isFlagged) {
			try {
				By buttonBy = By.xpath("//span[@class='underlined' and text() = '" + underLinedLetter + "']");
				utilities.findObject(driver, buttonBy, 30);
				WebElement buttonEle = driver.findElement(buttonBy);
				buttonEle.click();
				break;
			} catch (StaleElementReferenceException e) {
				logger.info("Into Stale");
				continue;
			}
		}
		return this;
	}*/
	
	
	

	
	
	
	
}
