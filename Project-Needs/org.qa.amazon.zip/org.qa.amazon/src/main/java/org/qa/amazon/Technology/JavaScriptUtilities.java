package org.qa.amazon.Technology;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;

import com.aventstack.extentreports.ExtentTest;

/**
 * @author n0296668
 *	Contains all the Java Script Generic functions which will help us to do actions on the web page
 */
public class JavaScriptUtilities
{
	public WebDriver ldriver = null;
	private static final Logger logger = Logger.getLogger(JavaScriptUtilities.class);
	
	public JavaScriptUtilities(WebDriver driver){
		ldriver = driver;
	}
	
	/**
	 * This method clears the text box using JavaScriptExecutor class
	 */
	public void clearTextBoxByJS(WebElement element) {
		try {
			((JavascriptExecutor) ldriver).executeScript("arguments[0].value ='';", element);
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			logger.warn("Failed to clear text box value : " +e.getMessage());			
		}		
	}
	
	/**
	 * Change color of WebElement using JSExecutor
	 * 
	 * @param color - RGB Color to change the element
	 * @param element - Element to change the color
	 */
	public void changeColorOfWebElementByJS(String color, WebElement element) {
		JavascriptExecutor js = ((JavascriptExecutor) ldriver);
		js.executeScript("arguments[0].style.backgroundColor = '" + color + "'", element);

		try {
			Thread.sleep(20);
		} catch (InterruptedException e) {
		}
	}
	
	/**
	 * Flash the Element using JSExecutor
	 * 
	 * @param element - Element to flash
	 */
	public void flashElementByJS(WebElement element) {
		String bgcolor = element.getCssValue("backgroundColor");
		for (int i = 0; i < 10; i++) {
			changeColorOfWebElementByJS("rgb(0,200,0)", element);
			changeColorOfWebElementByJS(bgcolor, element);
		}
	}
	
	/**
	 * Highlight element using JSExecutor
	 * 
	 * @param element - Pass the element to highlight on the page
	 * @throws InterruptedException
	 */
	public void highLightElementByJS(WebElement element) {
		for (int i = 0; i < 2; i++) {
			try {
				JavascriptExecutor js = ((JavascriptExecutor) ldriver);
				js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "color: yellow; border: 2px solid yellow;");
				Thread.sleep(1000);
				js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "");
			} catch (InterruptedException e) {
				logger.warn("Failed to highlight element : " +e.getMessage());
			}
		}
	}
	
	/**
	 * Get page title using JSExecutor
	 * 
	 * @return Title of the page
	 */
	public String getPageTitleByJS() {
		JavascriptExecutor js = ((JavascriptExecutor) ldriver);
		String title = js.executeScript("return document.title;").toString();
		return title;
	}
	
	/**
	 * Refresh browser using JSExecutor
	 * 
	 */
	public void refreshBrowserByJS() {
		JavascriptExecutor js = ((JavascriptExecutor) ldriver);
		js.executeScript("history.go(0)");
	}
	
	/**
	 * Scroll inside div frame using JSExecutor
	 * 
	 * @param divID - Element object to scroll inside div
	 * @throws InterruptedException
	 */
	public void scrollDownInsideDIVByJS(String divID) throws InterruptedException {
		JavascriptExecutor js = ((JavascriptExecutor) ldriver);
		String domObject = String.format("var topPos = document.querySelector(" + divID + "); topPos.scrollIntoView(false); ");
		js.executeScript(domObject);
		Thread.sleep(3000);
	}
	
	/**
	 * Scroll the page down using JSExecutor
	 * 
	 */
	public void scrollPageDownByJS() {
		JavascriptExecutor js = ((JavascriptExecutor) ldriver);
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
	}
	
	/**
	 * Scroll the page until the element gets displayed using JSExecutor
	 * 
	 * @param element - Pass the element to scroll on the page
	 */
	public void scrollIntoElementViewByJS(WebElement element) {
		JavascriptExecutor js = ((JavascriptExecutor) ldriver);
		js.executeScript("arguments[0].scrollIntoView(true);", element);
	}
	
	/**
	 * Click Element using Java Script Executor
	 * 
	 * @param element - Element to click
	 */
	public void clickElementByJS(WebElement element) {
		JavascriptExecutor js = ((JavascriptExecutor) ldriver);
		js.executeScript("argument[0].click();", element);
	}
	
	/**
	 * Generate Custom Java Script Alert on the browser
	 * 
	 * @param message - Custom message that you want to display on the browser
	 * @throws InterruptedException
	 */
	public void generateAlertByJS(String message) {
		JavascriptExecutor js = ((JavascriptExecutor) ldriver);
		js.executeScript("alert('" + message + "')");		
		try
		{
			Thread.sleep(2000);
			ldriver.switchTo().alert().accept();
		}
		catch(NoAlertPresentException e)
		{
			e.printStackTrace();
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}		
	}
	
	/**
	 * Growl is a JQuery plugin which is designed to provide informative messages in
	 * the browser
	 * 
	 * @param js - {@link JavascriptExecutor} reference driver
	 * @param error - Provide your error message
	 * @param notice - Provide your notice message
	 * @param warning - Provide your warning message
	 * @throws InterruptedException
	 */
	public void JQueryGrowlByJS(String errorMessage, String noticeMessage, String warningMessage)
			throws InterruptedException {

		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		
		// Check for jQuery on the page, add it if need be
		js.executeScript("if (!window.jQuery) {"
				+ "var jquery = document.createElement('script'); jquery.type = 'text/javascript';"
				+ "jquery.src = 'https://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js';"
				+ "document.getElementsByTagName('head')[0].appendChild(jquery);" + "}");
		Thread.sleep(2000);

		// Use jQuery to add jquery-growl to the page
		js.executeScript("$.getScript('https://the-internet.herokuapp.com/js/vendor/jquery.growl.js')");

		// Use jQuery to add jquery-growl styles to the page
		js.executeScript("$('head').append('<link rel=\"stylesheet\" "
				+ "href=\"https://the-internet.herokuapp.com/css/jquery.growl.css\" " + "type=\"text/css\" />');");
		Thread.sleep(2000);

		String title = ldriver.getTitle();

		// jquery-growl w/ no frills
		js.executeScript("$.growl({ title: 'GET', message: '" + title + "' });");

		// jquery-growl w/ colorized output
		js.executeScript("$.growl.error({ title: 'ERROR', message: '" + errorMessage + "' });");
		js.executeScript("$.growl.notice({ title: 'Notice', message: '" + noticeMessage + "' });");
		js.executeScript("$.growl.warning({ title: 'Warning!', message: '" + warningMessage + "' });");
		Thread.sleep(2000);
	}
	
	/**
	 * Capture Java Script error logs during runtime based on the page
	 * @param pageName - Page name or Screen name which you want to capture JSLogs
	 * @throws IOException
	 */
	public void captureJSLogsInfo(String pageName) throws IOException {
		String projectDir = System.getProperty("user.dir");
		String currentDate = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		
		// Making file directory
		new File(projectDir + "//JSErrorLogs//").mkdir();
		String filePath = projectDir + "/JSErrorLogs/" + pageName + "_" + currentDate + ".txt";

		File src = new File(filePath);
		src.createNewFile();
		BufferedWriter output = new BufferedWriter(new FileWriter(src));

		// Capture JSLogs
		LogEntries logging = ldriver.manage().logs().get(LogType.BROWSER);

		for (LogEntry logEntry : logging) {
			output.write(new Date(logEntry.getTimestamp()) + " " + logEntry.getLevel() + " " + logEntry.getMessage());
			output.newLine();
			System.out.println(new Date(logEntry.getTimestamp()) + " " + logEntry.getLevel() + " " + logEntry.getMessage());
		}

		output.close();
	}
	
}
