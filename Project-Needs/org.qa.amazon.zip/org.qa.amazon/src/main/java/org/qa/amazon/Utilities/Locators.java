package org.qa.amazon.Utilities;

public class Locators {

	/* Home Page Locators */
	public static final String DROP_DOWN_CSS = "#searchDropdownBox";
	public static final String SEARCH_BOX_ID = "twotabsearchtextbox";
	public static final String SEARCH_BUTTON_ID = "nav-search-submit-text";
	public static final String SEARCH_BUTTON_XPATH = "//*[@id='navbar']//input[@value='Go' ]";
	
	
	
	
}
