package org.qa.amazon.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.qa.amazon.Managers.ObjectManager;
import org.qa.amazon.Technology.JavaScriptUtilities;
import org.qa.amazon.Technology.UIMethods;
import org.qa.amazon.Technology.Utilities;
import org.qa.amazon.Utilities.Locators;

public class HomePage {

	private WebDriver driver;
	private ObjectManager objManager;
	private Utilities utils;
	private JavaScriptUtilities jsUtils;
	
	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		objManager = new ObjectManager(driver);
		utils = objManager.getUtilsInstance();
		jsUtils = objManager.getJSUtilsInstance();
	}

	// Home Page Objects
	@FindBy(how = How.CSS, using = Locators.DROP_DOWN_CSS)
	WebElement dropDown;

	@FindBy(how = How.ID, using = Locators.SEARCH_BOX_ID)
	WebElement searchTextBox;

	@FindBy(how = How.XPATH, using = Locators.SEARCH_BUTTON_XPATH)
	WebElement searchIcon;
	
	@FindBy(how = How.XPATH, using = "//div[@data-index='0']")
	WebElement firstResult;

	/** 
	 * Select drop down value based on the given parameter
	 * @param option
	 */
	public void selectDropdownValue(String option) {
		utils.waitForElement(dropDown, 10);
		UIMethods.selectDropdownByWebElement("Select Book option from dropdown list", dropDown, option);
		UIMethods.getSelectedValue(dropDown);
	}
	
	/**
	 * Type test data into search text box
	 * @param testData
	 */
	public void typeValueInSearchBox(String testData) {
		utils.waitForElement(searchTextBox, 5);
		UIMethods.clearAndInputByWebElement("Enter science in  search text box", searchTextBox, testData);
	}
	
	/**
	 * Click search icon when user enter values
	 */
	public void clickSearchIcon() {
		UIMethods.clickbyWebElement("Click Search Icon", searchIcon);
		utils.waitForElement(firstResult, 20);
	}
	
	
	
	
	
}
