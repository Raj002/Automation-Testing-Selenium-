package org.qa.amazon.Technology;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.log4testng.Logger;

public class Utilities {

	private WebDriver driver = null;
	private WebDriverWait wait = null;
	private int DEFAULT_WAIT_4_PAGE = 10;

	private static final Logger logger = Logger.getLogger(Utilities.class); 
	
	
	/**
	 * 
	 * @param gDriver - Reference of browser driver
	 * @param explicitWaitTime - Explicit wait time
	 */
	public Utilities(WebDriver gDriver, int explicitWaitTime) {
		this.driver = gDriver;		
		
	}

	/**
	 * This method can be used to check whether the page is loaded completely whenever you navigate to new page
	 * it will wait for the given wait time in seconds
	 * @param timeOutInSeconds - Time in seconds to load page completely
	 * @return
	 */
	public boolean waitForPageTOLoadCompletely(int timeOutInSeconds) {
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
			}
		};
		System.out.println("Page loaded values" + expectation);
		WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
		try {
			wait.until(expectation);
			return true;
		} catch (Throwable error) {
			Assert.fail("Page is not loaded in 30 SECONDS ");
			return false;
		}
	}
	
	/**
	 * Applied explicit wait condition until the visibility of element within the given amount of time
	 * @param element - Element to wait 
	 * @param timeOutInSeconds - Time in seconds to wait for an element
	 */
	public void waitForElement(WebElement element, int timeOutInSeconds) {
		wait = new WebDriverWait(driver, timeOutInSeconds);
		try {
			wait.until(ExpectedConditions.visibilityOf(element));
			driver.manage().timeouts().implicitlyWait(DEFAULT_WAIT_4_PAGE, TimeUnit.SECONDS);
		} catch (TimeoutException e) {
			logger.warn("Element '" + element + "' not found after waiting for it's visibility");
		} catch (NoSuchElementException e) {
			logger.warn("Element '" + element + "' not found, unable to locate it in the DOM");
		} catch (Exception e) {
			logger.warn("Element '" + element + "' not found");
		}
	}
	
	
	
	
	
	
	
	/**
	 * Get the screenshot of invoked page and store it under project directory -> "Screenshots" folder
	 * 
	 * @param driver - Reference of your browser driver
	 * @param subFolder - Name of sub folder
	 * @param screenshotName - Name of the captured screen shot
	 * @return destination Captured screenshot path
	 * @throws IOException
	 */
	public static String getScreenShot(WebDriver driver,String screenShotName) throws IOException {
		String destination = null;
		String currentDate = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		
		try {
			File source = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);			
			new File(System.getProperty("user.dir")+"//ScreenShots//").mkdir();
			destination = System.getProperty("user.dir") + "/ScreenShots/" + screenShotName + "_" + currentDate + ".png";
			File finalDestination = new File(destination);
			FileUtils.copyFile(source, finalDestination);
		} catch (IOException e) {
			e.getMessage();
		}		
		return destination;
	}
	
}
