package org.qa.amazon.Managers;

import org.openqa.selenium.WebDriver;
import org.qa.amazon.Technology.ConfigReader;
import org.qa.amazon.Technology.JavaScriptUtilities;
import org.qa.amazon.Technology.Utilities;

public class ObjectManager {

	public static String projectdir = System.getProperty("user.dir");
	static String configFilePath = projectdir + "/Configs/Configurations.properties";

	private WebDriver driver = null;
	private ConfigReader config = null;
	private JavaScriptUtilities JSUtils = null;
	private Utilities utils = null;

	public ObjectManager(WebDriver driver) {
		this.driver = driver;
	}

	public ConfigReader getConfigInstance() {

		return (config == null) ? config = new ConfigReader(configFilePath) : config;
	}

	public JavaScriptUtilities getJSUtilsInstance() {

		return (JSUtils == null) ? JSUtils = new JavaScriptUtilities(driver) : JSUtils;
	}

	public Utilities getUtilsInstance() {

		return (utils == null) ? utils = new Utilities(driver, 10) : utils;
	}

}
