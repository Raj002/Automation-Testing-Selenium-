package org.qa.amazon.Technology;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import java.util.Properties;

import org.apache.log4j.Logger;

/**
 * @author n0296668
 *	Read data from property file
 *	Using GetPropertyValue(String Key) we can get single property value, returns string
 *	Using GetPropertyValue() we can get all the property values, returns Map<String, String>
 */
public class ConfigReader {
	
	static Properties properties;
	static BufferedReader reader;
	String propertyPath = null;
	static Map<String, String> map = null;
	public static Logger Log = Logger.getLogger(ConfigReader.class);
	
	public ConfigReader(String propertyFilePath) {
		
		this.propertyPath = propertyFilePath;
		properties = new Properties();
		map = new HashMap<String, String>();
		try {
			properties.load(new FileInputStream(new File(propertyFilePath)));

		} catch (IOException e) {
			Log.warn("Failed to load property file. " + e.getMessage());
			System.err.println("Couldn't load properties correctly..." + e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * Get all the values from property file
	 * @return null if the v=key doesn't match
	 */
	public Map<String, String> GetPropertyValue() {
		
		for (Entry<Object, Object> entry : properties.entrySet()) {
			map.put((String) entry.getKey(), (String) entry.getValue());
		}
		return map;
	}
	
	/**
	 * Get value from property file
	 * @param key - Key to get value
	 * @return null if the key doesn't match
	 */
	public String GetPropertyValue(String key) {	
		
		for(Entry<Object, Object> entry: properties.entrySet()) {
			map.put((String)entry.getKey(), (String)entry.getValue());
			if(map.containsKey(key) == true) {
				return map.get(key);
			}			
		}
		return null;
	}
	
}
