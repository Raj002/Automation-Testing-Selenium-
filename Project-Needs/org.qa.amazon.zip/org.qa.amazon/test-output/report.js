$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("FeatureFiles/GetProductDetails.feature");
formatter.feature({
  "line": 1,
  "name": "Get amazon product details",
  "description": "The purpose of this feature is to search the science book and fetch the first product details",
  "id": "get-amazon-product-details",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "Get first product details from the search result",
  "description": "",
  "id": "get-amazon-product-details;get-first-product-details-from-the-search-result",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "User is on home page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User search for \"Science\" by selecting dropdown option as \"Books\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Click on first product item",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Get all the product details",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "Close the browser",
  "keyword": "Then "
});
formatter.match({
  "location": "GetProductDetails.user_is_on_home_page()"
});
formatter.result({
  "duration": 2559407899,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Science",
      "offset": 17
    },
    {
      "val": "Books",
      "offset": 59
    }
  ],
  "location": "GetProductDetails.user_search_for_by_selecting_dropdown_option_as(String,String)"
});
formatter.result({
  "duration": 2298034,
  "status": "passed"
});
formatter.match({
  "location": "GetProductDetails.click_on_first_product_item()"
});
formatter.result({
  "duration": 18263,
  "status": "passed"
});
formatter.match({
  "location": "GetProductDetails.get_all_the_product_details()"
});
formatter.result({
  "duration": 22183,
  "status": "passed"
});
formatter.match({
  "location": "GetProductDetails.close_the_browser()"
});
formatter.result({
  "duration": 18801,
  "status": "passed"
});
});