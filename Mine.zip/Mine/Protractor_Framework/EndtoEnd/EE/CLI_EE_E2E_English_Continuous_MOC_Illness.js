/**
 * Created by n0238696 on 7/11/2017.
 */

var Getting_StartedPage = require('./../../PageObjects/PageObject_GettingStarted.js');
var ResuableFunction = require('./../..//PageWise/helpers/helpers.js');
var AboutYouPage = require('./../../PageObjects/PageObject_AboutYouPage.js');
var AboutAbsencePage = require('./../../PageObjects/PageObject_AboutYourAbsence.js');
var MedicalContactsPage = require('./../../PageObjects/PageObject_ContactsPage.js');
var ReviewPage = require('./../../PageObjects/PageObject_ER_ReviewPage.js');
var ConfirmationPage = require('./../../PageObjects/PageObject_ConfirmationPage.js');
var ViewSubmissionPage = require('./../../PageObjects/PageObject_ViewSubmissionPage.js');



describe ('New EE_CLI - End to End Validations', function() {

    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 900000;


    it('New CLI_EE_E2E_Continuous_MOC_Illness', function () {

        ResuableFunction.MLC_Login();
        ResuableFunction.EmployeeCLI();
        Getting_StartedPage.clickStart("Employee-English");

        //AboutYouPage.UniqueID_EmpID_SSN('EmpID');
        AboutYouPage.EnterSSN('112224440');
        AboutYouPage.ValidateFirstNameEE();
        AboutYouPage.ValidateLastNameEE();
        AboutYouPage.SelectGender('Female');
        AboutYouPage.EnterDateofBirth('01011987');
        AboutYouPage.EnterResdentialAddress1('123 Test');
        AboutYouPage.EnterResdentialcity('Dover');
        AboutYouPage.EnterPostalCode('23345');
        AboutYouPage.SelectState('NH');
        AboutYouPage.EnterPersonalPhone('9997775550');
        AboutYouPage.EnterPersonalEmail('TESTemail@test.com');
        AboutYouPage.SelectEmploymentState('AK');
        AboutYouPage.ClickContinue_ViewAboutYourAbsence();

        AboutAbsencePage.SelectLeaveorClaimCategory('Yes');
        AboutAbsencePage.SelectLeaveorClaimtype('MOC','Female');
        AboutAbsencePage.SelectClaimantCondition('Illness');
        AboutAbsencePage.EnterDateQuestion_1('11/01/2017');
        AboutAbsencePage.EnterDateQuestion_2('11/01/2017');
        AboutAbsencePage.SelectAccidentResult('Yes');
        AboutAbsencePage.SelectMotorAccident('Yes');
        AboutAbsencePage.SelectOnJob('Yes');
        AboutAbsencePage.SelectGoingHospital('No');
        AboutAbsencePage.SelectSurgery('No');
        AboutAbsencePage.EnterSurgeryDescription('user text 1');
        AboutAbsencePage.EnterSurgeryComplicationtxt('user text 2');
        AboutAbsencePage.ClickContinue();

        //MedicalContactsPage.EnterPhyFirstName("Phyfirstname");
        //MedicalContactsPage.EnterPhyLastName("Phylastname");
        //MedicalContactsPage.EnterPhyPhoneNumber("9898112200");
        MedicalContactsPage.EnternoValues_ClickContinue_ViewReviewPage();

        ReviewPage.ClickSubmit_ViewConfirmation();

        ConfirmationPage.VerifyPageHeader();
        ConfirmationPage.VerifySubmissionText_Date();
        ConfirmationPage.clickViewSubmission();

        ViewSubmissionPage.lbl_Continous_MOC_Illness();
        ViewSubmissionPage.Click_CloseButton();

    }, 300000000);

});





