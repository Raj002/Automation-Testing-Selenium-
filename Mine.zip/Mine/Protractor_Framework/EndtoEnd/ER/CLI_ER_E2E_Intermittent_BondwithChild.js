/**
 * Created by n0238696 on 7/11/2017.
 */

var Getting_StartedPage = require('./../../PageObjects/PageObject_GettingStarted.js');
var ResuableFunction = require('./../..//PageWise/helpers/helpers.js');
var AboutYouPage = require('./../../PageObjects/PageObject_AboutYouPage.js');
var AboutAbsencePage = require('./../../PageObjects/PageObject_AboutYourAbsence.js');
var AddlInfoPage = require('./../../PageObjects/PageObject_Additional_InformationPage.js');
var ReviewPage = require('./../../PageObjects/PageObject_ER_ReviewPage.js');
var ConfirmationPage = require('./../../PageObjects/PageObject_ConfirmationPage.js');
var ViewSubmissionPage = require('./../../PageObjects/PageObject_ViewSubmissionPage.js');



describe ('New ER_CLI - End to End Validations', function() {

    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 900000;


    it('New CLI_ER_E2E_Intermittent_Bond with Child', function () {

        ResuableFunction.MLC_Login();
        ResuableFunction.EmployerCLI();
        Getting_StartedPage.clickStart("Employer");

        //AboutYouPage.UniqueID_EmpID_SSN('SSN');
        AboutYouPage.EnterEmployeeID('24440');
        AboutYouPage.EnterFirstName('Tester');
        AboutYouPage.EnterLastName('Test');
        AboutYouPage.SelectGender('Male');
        AboutYouPage.EnterDateofBirth('01011987');
        AboutYouPage.EnterResdentialAddress1('123 Test');
        AboutYouPage.EnterResdentialcity('Dover');
        AboutYouPage.EnterPostalCode('23345');
        AboutYouPage.SelectState('NH');
        AboutYouPage.EnterPersonalPhone('9997775550');
        AboutYouPage.EnterPersonalEmail('TESTemail@test.com');
        AboutYouPage.SelectEmploymentState('AK');
        AboutYouPage.ClickContinue_ViewAboutYourAbsence();

        AboutAbsencePage.SelectLeaveorClaimCategory('No');
        AboutAbsencePage.SelectLeaveorClaimtype('BondwithChild','Male');
        AboutAbsencePage.Select_List_1_Value('NP');
        AboutAbsencePage.Select_List_2_Value('CD');
        AboutAbsencePage.EnterDateQuestion_1('11/01/2017');
        AboutAbsencePage.EnterDateQuestion_2('11/03/2017');
        AboutAbsencePage.EnterDateQuestion_3('11/08/2017');
        AboutAbsencePage.ClickContinue();

        AddlInfoPage.EnternoValues_ClickContinue_ViewReviewPage();

        ReviewPage.ClickSubmit_ViewConfirmation();

        ConfirmationPage.VerifyPageHeader();
        ConfirmationPage.VerifySubmissionText_Date();
        ConfirmationPage.clickViewSubmission();

        ViewSubmissionPage.lbl_ER_Intermittent_Bondwithchild();
        ViewSubmissionPage.Click_CloseButton();

    }, 300000000);

});





