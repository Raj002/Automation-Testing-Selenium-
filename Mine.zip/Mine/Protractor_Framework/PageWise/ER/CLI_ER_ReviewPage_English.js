/**
 * Created by n0275896 on 7/12/2017.
 */
//Include the pageobjects created for Review Page
//var PORPER = require('./../PageObject_ER_ReviewPage.js');
//var POEER = require('./../PageObject_EEReviewPage.js');
//var POAYA = require('./../PageObject_AboutYourAbsence.js');
//var POAYP = require('./../PageObject_AboutYouPage.js');
//var POCommonFunctions = require('./../PageObject_Functions.js')
//var POAIP = require('./../PageObject_Additional_InformationPage.js');
POAYA
var TestDataAYE = require('./../../TestData/AboutYourEmployee.js');
var ConfirmationPage = require('./../../PageObjects/PageObject_ConfirmationPage.js');
var Getting_StartedPage = require('./../../PageObjects/PageObject_GettingStarted.js');
var ResuableFunction = require('./..//helpers/helpers.js');
var AboutYourEmployeePage = require('./../../PageObjects/PageObject_AboutYouPage.js');

//Take Screenshots
var fs = require('fs');
function writeScreenShot(data, filename) {
    var stream = fs.createWriteStream(filename);
    stream.write(new Buffer(data, 'base64'));
    stream.end();
}
describe ('Open URL in browser and validate ER Review page', function() {


    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;
    var lblempid = POEER.lblemployeeid.input;
    var lblfirstname = POEER.lblfirstname.input;
    var lblmiddle = POEER.lblmiddle.input;
    var lbllastname = POEER.lbllastname.input;
    var lblgender = POEER.lblgender1.input;
    var lbldob = POEER.lbldob.input;
    var lblpphone = POEER.lblpphone.input;
    var lblpemail = POEER.lblpemail.input;
    var lblpmethod = POEER.lblprefmethod.input;
    var lblres1 = POEER.lblresaddress1.input;
    var lblres2 = POEER.lblresaddress2.input;
    var lblrescity = POEER.lblrescity.input;
    var lblcountry = POEER.lblcountry.input;
    var lblpostalcode = POEER.lblpostalcode.input;
    var lblcountryofemploy = POEER.lblcounofemploy.input;
    var lblstateemploy  = POEER.lblstateofemploy.input;
    var lblresstate = POEER.lblstate.input;

    var txtempid1 = POEER.txtemployeeid.input;
    var txtfirstname = POEER.txtfirstname.input;
    var txtmiddlename = POEER.txtmiddle.input;
    var txtlastname = POEER.txtlastname.input;
    var txtgender = POEER.txtgender1.input;
    var txtdob = POEER.txtdob.input;
    var txtpphone = POEER.txtpphone.input;
    var txtpemail = POEER.txtpemail.input;
    var txtpmethod = POEER.txtprefmethod.input;
    var txtresaddr1 = POEER.txtresaddress1.input;
    var txtresaddr2 = POEER.txtresaddress2.input;
    var txtrescity = POEER.txtrescity.input;
    var txtcountry = POEER.txtcountry.input;
    var txtpostalcode = POEER.txtpostalcode.input;
    var txtecountry = POEER.txtcounofemploy.input;
    var txtfax1 = POEER.txtfax.input;
    var txtsemploy = POEER.txtstateofemploy.input;
    var txtstate = POEER.txtstate.input;





    var empid = POAYP.empidtbox.input;
    var ssntext = POAYP.ssntbox.input;
    var firstname = POAYP.fnametbox.input;
    var lastname = POAYP.lnametbox.input;
    var dob = POAYP.dobtbox.input;
    var preferedphone = POAYP.ppphonetbox.input;
    var prefmail = POAYP.ppemailtbox.input;
    var resaddr1 = POAYP.resaddrtbox1.input;
    var rescity = POAYP.rescitytbox.input;
    var statelist = POAYP.resstatelist.input;
    var postalcode = POAYP.postalcdetbox.input;
    var stateemploy = POAYP.stateofemploylist.input;
    var middlename = POAYP.mnametbox.input;
    var resaddr2 = POAYP.resaddrtbox2.input;

    //addl information page label declaration
    var lbldateofhire = PORPER.lbldateofhire.input;
    var lblempcontribution = PORPER.lblempcontribution.input;
    var lblclass = PORPER.lblclass.input;
    var lblemprcontribution = PORPER.lblemprcontribution.input;
    var lblbenefitpercent = PORPER.lblbenefitpercent.input;
    var lbldaysperweek = PORPER.lbldaysperweek.input;
    var lblhourdays = PORPER.lblhourdays.input;
    var lblschdays = PORPER.lblschdays.input;
    var lblcurrstatus = PORPER.lblcurrstatus.input;
    var lblempid1= PORPER.lbladdlempid.input;
    var lblworkstate = PORPER.lblworkstate.input;
    var lblsubsidiary = PORPER.lblsubsidiary.input;
    var lbllocbranch = PORPER.lbllocbranch.input;
    var lblemptype = PORPER.lblemptype.input;
    var lbljob = PORPER.lbljob.input;
    var lblphydemands = PORPER.lblphydemands.input;
    var lblpaytype = PORPER.lblpaytype.input;
    var lblearnings = PORPER.lblearnings.input;

    var lblincomeamt = PORPER.lblincomeamount.input;
    var lblincometype = PORPER.lblincometype.input;
    var lblbegindate = PORPER.lblbegindate.input;
    var lblenddate = PORPER.lblenddate.input;
    var lblapplieddate = PORPER.lblapplieddate.input;

    var txtdateofhire = PORPER.txtdateofhire.input;
    var txtempid = PORPER.txtempid.input;
    var txtworkstate = PORPER.txtworkstate.input;
    var txtsubsidiary = PORPER.txtsubsidiary.input;
    var txtlocbranch= PORPER.txtlocbranch.input;
    var txtemptype= PORPER.txtemptype.input;
    var txtjob= PORPER.txtjob.input;

    var txtphydem= PORPER.txtphydem.input;
    var txtpaytype= PORPER.txtpaytype.input;
    var txtearnings= PORPER.txtearnings.input;

    var txtincomeamt = PORPER.txtincomeamt.input;
    var txtclass1= PORPER.txtclass1.input;
    var txtemppremium= PORPER.txtemppremium.input;
    var txtemprpremium= PORPER.txtemprpremium.input;
    var txtbenefit= PORPER.txtbenefit.input;
    var txtdays= PORPER.txtdays.input;
    var txthours= PORPER.txthours.input;
    var txtschdays= PORPER.txtschdays.input;
    var txtcurworkstatus= PORPER.txtcurworkstatus.input;
   /* var txtincometype = PORPER.txtincometype.input;
    var txtbegindate = PORPER.txtbegindate.input;
    var txtenddate = PORPER.txtenddate.input;
    var txtappdate = PORPER.txtapplieddate.input;*/
    var pphone1 = POAYP.ppphonetbox1.input;

    var lblcirumcondition = POAYA.lblcircumcondition.input;
    var lblillness = POAYA.lblillness.input;
    var lbllastday = POAYA.lbllastday1.input;
    var lblresaccident = POAYA.lblaccidentresult.input;
    var lblmotor = POAYA.lblmotorvehaccident.input;
    var rbtnaccident = POAYA.rbtnaccidentyes.input;
    var rbtnmotoraccident = POAYA.rbtnmotoraccidentyes.input;
    var lblonjob = POAYA.lbloccurjob.input;
    var rbtnjobyes = POAYA.rbtnjobyes.input;
    var lblhosp = POAYA.lblgnghosp.input;
    var rbtnhosp = POAYA.rbtnhospyes.input;
    var lblsurgery = POAYA.lblsurgery.input;
    var rbtnsurgery = POAYA.rbtnsurgery.input;
    var lbldatehosp = POAYA.lbldatehosp.input;
    var lbldatesurgery = POAYA.lbldatesurgery.input;
    var lbldiag = POAYA.lbldiagnosis.input;
    var txtadmission = POAYA.admission.input;
    var txtsurgerydesc = POAYA.txtsurgerydesc.input;
    var txtsurgery = POAYA.txtsurgerydate.input;
    var absencequestions =  POAYA.aboutabsencequestions.input;
    var surdecreqmsg = POAYA.surdecreqmsg.input;
    var surdesques = POAYA.surdesques.input;
    var txtssn1 = POAYP.txtssn.input;

    var lblsurgeryno = POAYA.lblsurgeryno.input;
    var lblsurgryunknown = POAYA.lblsurgeryunknown.input;
    var lblsurgeryyes = POAYA.lblsurgeryyes.input;
    var rbtnsurgeryno = POAYA.rbtnsurgeryno.input;
    var rbtnsurgeryunknown = POAYA.rbtnsurgeryunknown.input;
    var username = POAYP.username.input;
    var password = POAYP.password.input;
    var txtillness = POAYA.txtillness.input;
    var txtlastday = POAYA.txtlastday.input;
    var dateillness = POAYA.dateillness.input;
    var datelastday = POAYA.datelastday.input;
    var leaveclaimlist = POAYA.leavetypelist.input;
    var circumstance = POAYA.circumstance.input;
    var aboutyousection = PORPER.aboutyousection.input;

    var fraudstmntheader = PORPER.fraudstmntheader.input;
    var flfraudstmt = 'Any person who knowingly or willfully presents a false or fraudulent claim for payment of a loss or benefit or who knowingly or willfully presents false information in an application for insurance is guilty of a crime and may be subject to fines and confinement in prison.'

    var lblcontinuous1  = POEER.lblcontinuous.input;
    var lblcircumstances = POEER.lblcircumstances.input;
    var lbldesccircumstances = POEER.lbldesccircumstances.input;
    var lblillnessreview = POEER.lblillnessreview.input;
    var lbllastdayreview = POEER.lbllastdayreview.input;
    var lblresultreview= POEER.lblresultreview.input;
    var lblmvaccident= POEER.lblmvaccident.input;
    var lblonjob= POEER.lblonjob.input;
    var lbltohospital= POEER.lbltohospital.input;
    var lbldatehospital= POEER.lbldatehospital.input;
    var lblsurgeryreview= POEER.lblsurgeryreview.input;
    var lbldescreview= POEER.lbldescreview.input;
    var lblcomplicationsreview= POEER.lblcomplicationsreview.input;


    var txtcontinuous1  = POEER.txtcontinuous.input;
    var txtcircumstances = POEER.txtcircumstances.input;
    var txtdesccircumstances = POEER.txtdesccircumstances.input;
    var txtillnessreview = POEER.txtillnessreview.input;
    var txtlastdayreview = POEER.txtlastdayreview.input;
    var txtresultreview= POEER.txtresultreview.input;
    var txtmvaccident= POEER.txtmvaccident.input;
    var txtonjob= POEER.txtonjob.input;
    var txttohospital= POEER.txttohospital.input;
    var txtdatehospital= POEER.txtdatehospital.input;
    var txtsurgeryreview= POEER.txtsurgeryreview.input;
    var txtdescreview= POEER.txtdescreview.input;
    var txtcomplicationsreview= POEER.txtcomplicationsreview.input;
    var txthospital = POAYA.txthospital.input;
    var txtsurgery1 = POAYA.txtsurgery1.input;
    var txtaddlninfeng = 'Please review the information below for accuracy before submitting your absence. To make any changes, select “Edit” to return to the appropriate section';





    /******************** Beginning of Test Case I - Verify Review page Links and Sections ******************************/

   it('New CI_Review Page Link and Sections for ER', function () {

            browser.ignoreSynchronization = true;
            browser.waitForAngularEnabled(false);
            POCommonFunctions.employerurl();
            POCommonFunctions.employeelogin();
            POCommonFunctions.callCLI();
            POCommonFunctions.enteraboutyouremppagefemale();
            POCommonFunctions.enterDetailsofabsencepage();
            element(by.buttonText('Continue')).click();
            browser.executeScript('window.scrollTo(40,200);');
            browser.executeScript('window.scrollTo(40,200);');
            POCommonFunctions.enteraddldetailspage();
           /* var txthiredate = POAIP.txthiredate.input;
            txthiredate.sendKeys('02/02/2017',protractor.Key.TAB);
            browser.executeScript('window.scrollTo(3300,2600);');
            element(by.buttonText('Continue')).click();*/

            //Identifying the current Date and Time

           var timestamp;
            var today = new Date();
            var month = today.getMonth() + 1;
            timestamp = today.getDate()+ "_" + month + "_" + today.getFullYear()+ "_"+today.getHours()+"_"+ today.getMinutes()+"_"+today.getSeconds();
            var screenshot;
            screenshot = "./Screenshots/6203/";

            //Verify the page header for review page
            var reviewheader = PORPER.reviewheader.input.getText();
            expect(reviewheader).toEqual('Review');


            //Instructional dynamic content
            var instructionaltextcontent = PORPER.instructionaltextcontent.input.getText();
            expect(instructionaltextcontent).toContain('with Instructional text (Text are still TBD)');
            browser.executeScript('window.scrollTo(40,200);');

            //Get Help - Label
            var gethelplabel = PORPER.gethlplabel.input.getText();
            expect(gethelplabel).toEqual('Get Help');

            //Verify GetHelp pop up is displayed
            PORPER.gethlplabel.input.click();
            expect(PORPER.popuphelp.input.isDisplayed()).toBe(true);

            //Take screenshot
            browser.takeScreenshot().then(function (png) {
                writeScreenShot(png, screenshot+"Testcase1_Screenshot1"+"_"+timestamp+".png");
            });
            element(by.buttonText('Close')).click();

            //About Your Employee section - Label
            var aboutyousection = PORPER.aboutyousection.input.getText();
            expect(PORPER.aboutyousection.input.isDisplayed()).toBe(true);
            expect(aboutyousection).toEqual('About Your Employee');

            //Verify accordian for About Your Employee is not expanded
            //expect(PORPER.aboutyouaccordiant.input.isPresent()).toBeTruthy();

            //About Your Employee’s Absence - Label
            var aboutyourabsencesection = PORPER.aboutyourabsencesection.input.getText();
            expect(PORPER.aboutyourabsencesection.input.isDisplayed()).toBe(true);
            expect(aboutyourabsencesection).toEqual('About Absence');

            //Verify accordian for About Your Employee Absence is not expanded
            expect(PORPER.aboutabsenceaccordiant.input.isPresent()).toBeFalsy();

            //Additional Information section - Label
            var addlinfosection = PORPER.addlinfosection.input.getText();
            expect(PORPER.addlinfosection.input.isDisplayed()).toBe(true);
            expect(addlinfosection).toEqual('Additional Information');

            //Verify accordian for Additional Information is not expanded
            expect(PORPER.addlinfoaccordiant.input.isPresent()).toBeFalsy();

            //About You section - Edit Label
            var aboutyousedit = PORPER.aboutyousedit.input.getText();
            expect(aboutyousedit).toEqual('Edit');

            //Take screenshot
           browser.takeScreenshot().then(function (png) {
                writeScreenShot(png, screenshot+"Testcase1_Screenshot2"+"_"+timestamp+".png");
            });


            //Verify About Your Employee page is dislayed when Edit is clicked
            aboutyousedit.click();
            expect(PORPER.abtyouremppage.input.isDisplayed()).toBe(true);
            browser.sleep(1000);
            browser.executeScript('window.scrollTo(600,1600);');
            browser.sleep(1000);
            POAYP.continuebutton.input.click();


            browser.sleep(1000);
            element(by.buttonText('Continue')).click();
            browser.sleep(1000);
            browser.executeScript('window.scrollTo(3300,2600);');
            browser.sleep(1000);
            element(by.buttonText('Continue')).click();
            browser.executeScript('window.scrollTo(80,400);');
            browser.sleep(1000);

            //Take screenshot
            browser.takeScreenshot().then(function (png) {
                writeScreenShot(png, screenshot+"Testcase1_Screenshot3"+"_"+timestamp+".png");
            });


            //About Your Absence - Edit Label
            var aboutyourabsenceedit = PORPER.aboutyourabsenceedit.input.getText();
            expect(aboutyourabsenceedit).toEqual('Edit');


            //Verify About Your Employee Absence page is dislayed when Edit is clicked
            aboutyourabsenceedit.click();
            expect(PORPER.abtyourabsemppage.input.isDisplayed()).toBe(true);
            browser.sleep(1000);
            browser.executeScript('window.scrollTo(3300,2600);');
            element(by.buttonText('Continue')).click();
            browser.sleep(1000);
            browser.executeScript('window.scrollTo(600,2600);');
            browser.sleep(1000);
            element(by.buttonText('Continue')).click();
            browser.executeScript('window.scrollTo(80,400);');
            browser.sleep(1000);

            //Take screenshot
            browser.takeScreenshot().then(function (png) {
                writeScreenShot(png, screenshot+"Testcase1_Screenshot4"+"_"+timestamp+".png");
            });


            //Additional Information - Edit Label
            var addlinfoedit = PORPER.addlinfoedit.input.getText();
            expect(addlinfoedit).toEqual('Edit');

            //Verify Additional Info page is dislayed when Edit is clicked
            addlinfoedit.click();
            expect(PORPER.addlinfopage.input.isDisplayed()).toBe(true);
            browser.sleep(1000);

            browser.executeScript('window.scrollTo(3300,2600);');
            browser.sleep(1000);
            element(by.buttonText('Continue')).click();
            browser.executeScript('window.scrollTo(80,400);');
            browser.sleep(1000);

            //Take screenshot
            browser.takeScreenshot().then(function (png) {
                writeScreenShot(png, screenshot+"Testcase1_Screenshot5"+"_"+timestamp+".png");
            });


            //Submit button -  Label
            var submitbutton = PORPER.submitbutton.input.getText();
            expect(submitbutton).toEqual('Submit');

            //Go back button -  Label
            var gobackbutton = PORPER.gobackbutton.input.getText();
            expect(gobackbutton).toEqual('Go Back');

            //Take screenshot
            browser.takeScreenshot().then(function (png) {
                writeScreenShot(png, screenshot+"Testcase1_Screenshot6"+"_"+timestamp+".png");
            });


            //Verify the accordian format when "About your Employee section is clicked
            aboutyousection.click();
            aboutyousection.click();
            expect(PORPER.aboutyouaccordiant.input.isPresent()).toBeTruthy();
            expect(PORPER.addlinfoaccordiant.input.isPresent()).toBeFalsy();
            expect(PORPER.aboutabsenceaccordiant.input.isPresent()).toBeFalsy();
            browser.sleep(1000);

            //Take screenshot
            browser.takeScreenshot().then(function (png) {
                writeScreenShot(png, screenshot+"Testcase1_Screenshot7"+"_"+timestamp+".png");
            });


            //Verify the accordian format when "About your Employee Absence section is clicked
            aboutyourabsencesection.click();
            expect(PORPER.aboutyouaccordianf.input.isPresent()).toBeTruthy();
            expect(PORPER.addlinfoaccordianf.input.isPresent()).toBeTruthy();
            expect(PORPER.aboutabsenceaccordiant.input.isPresent()).toBeTruthy();
            browser.sleep(1000);

            //Take screenshot
            browser.takeScreenshot().then(function (png) {
                writeScreenShot(png, screenshot+"Testcase1_Screenshot8"+"_"+timestamp+".png");
            });


            //Verify the accordian format when "Additional Information section is clicked
            browser.executeScript('window.scrollTo(400,600);');
            addlinfosection.click();
            expect(PORPER.aboutyouaccordiant.input.isPresent()).toBeFalsy();
            expect(PORPER.addlinfoaccordiant.input.isPresent()).toBeTruthy();
            expect(PORPER.aboutabsenceaccordiant.input.isPresent()).toBeFalsy();
            browser.sleep(1000);


            //Take screenshot
            browser.takeScreenshot().then(function (png) {
                writeScreenShot(png, screenshot+"Testcase1_Screenshot9"+"_"+timestamp+".png");
            });


    },300000000);


/******************** Beginning of Test Case 2 - Verify Medical contacts section is not displayed for the Employer******************************/
   it('New CI_Review Page Link and Sections for ER_Negative Scenario', function () {




         var cnt;

         var lists = element.all(by.className('accordion-toggle collapsed'));
         lists.count().then(function(c)
         {
             cnt = c;

             for(var i = 0; i<cnt ; i++)
             {

                 var section;
                 section = lists.get(i).getText();
                 expect(section).not.toContain('Medical Contacts');
             }
         });

         var lists1 = element.all(by.className('accordion-toggle'));
         lists.count().then(function(c)
         {
             cnt = c;

             for(var i = 0; i<cnt ; i++)
             {

                 var section;
                 section = lists.get(i).getText();
                 expect(section).not.toContain('Medical Contacts');
             }
         });

     });

    /******************** End of Test Case 2 - Verify Medical contacts section is not displayed for the Employer******************************/

        //Test Case 3 Verify label validations for About your Employee page

   it('New CLI_Review Page : Verify About Your Employee section when Employee ID is selected ', function() {




        browser.executeScript('window.scrollTo(40,200);');
        aboutyousection.click();
        expect(lblempid.getText()).toEqual('Employee ID');
        expect(lblfirstname.getText()).toEqual('First Name');
        expect(lblmiddle.getText()).toEqual('Middle Initial');
        expect(lbllastname.getText()).toEqual('Last Name');
        expect(lblgender.getText()).toEqual('Gender');
        expect(lbldob.getText()).toEqual('Date of Birth');
        expect(lblpphone.getText()).toEqual('Preferred Personal Phone');
        expect(lblpemail.getText()).toEqual('Preferred Personal Email');
        expect(lblpmethod.getText()).toEqual('Preferred method for non-confidential correspondence');
        expect(lblres1.getText()).toEqual('Residential Address 1');
        expect(lblres2.getText()).toEqual('Residential Address 2');
        expect(lblrescity.getText()).toEqual('Residential City');
        expect(lblcountry.getText()).toEqual('Country');
        expect(lblpostalcode.getText()).toEqual('Postal Code');
        expect(lblcountryofemploy.getText()).toEqual('Country of Employment');

       expect(txtempid1.getText()).toEqual('12345');
       expect(txtfirstname.getText()).toEqual('TestFirst');
       expect(txtmiddlename.getText()).toEqual('');
       expect(txtlastname.getText()).toEqual('TestLast');
       expect(txtgender.getText()).toEqual('f');
       expect(txtdob.getText()).toEqual('01/01/1987');
       expect(txtpphone.getText()).toEqual('(666) 644-4555');
       expect(txtpemail.getText()).toEqual('test@testmail.com');
       expect(txtpmethod.getText()).toEqual('Email');
       expect(txtresaddr1.getText()).toEqual('150 LibertyWay');
       expect(txtresaddr2.getText()).toEqual('');
       expect(txtrescity.getText()).toEqual('Dover');
       expect(txtcountry.getText()).toEqual('United States');
       expect(txtecountry.getText()).toEqual('United States');
       expect(txtpostalcode.getText()).toEqual('03820');

    });

   it('New CLI_Review Page  - About Your absence section validations for MOC flow ', function() {

            var aboutyourabsencesection = PORPER.aboutyourabsencesection.input.getText();
            browser.executeScript('window.scrollTo(200,500);');
            browser.sleep(20000);
            aboutyourabsencesection.click();

            expect(lblcontinuous1.getText()).toEqual('Will the Employee be out for a continuous period of time?');
            expect(lblcircumstances.getText()).toEqual('What best describes the circumstances for the absence?');
            expect(lbldesccircumstances.getText()).toEqual('Please select the condition that best describes the circumstances?');
            expect(lblillnessreview .getText()).toEqual('When did this illness begin?');
            expect(lbllastdayreview .getText()).toEqual('What was the last day worked or expected last day worked?');
            expect(lblresultreview.getText()).toEqual('Was this the result of an accident?');
            expect(lblmvaccident.getText()).toEqual('Was the Employee in a motor vehicle accident?');
            expect(lblonjob.getText()).toEqual('Did this occur while on the job?');
            expect(lbltohospital.getText()).toEqual('Did/Will the Employee be going to the hospital?');
            expect(lbldatehospital.getText()).toEqual('What date did/will the Employee go to the hospital?');
            expect(lblsurgeryreview.getText()).toEqual('Did/Will the Employee have surgery?');
            expect(lbldescreview.getText()).toEqual("What was, or is, the date of the Employee's surgery?");
            expect(lblcomplicationsreview.getText()).toEqual("Please provide the Employee's diagnosis or a description of the condition or symptoms.");

            expect(txtcontinuous1.getText()).toEqual('Yes');
            expect(txtcircumstances.getText()).toEqual('My own illness, injury, or medical treatment');
            expect(txtdesccircumstances.getText()).toEqual('Illness or related medical treatment');
            expect(txtillnessreview .getText()).toEqual('10/09/2017');
            expect(txtlastdayreview .getText()).toEqual('10/06/2017');
            expect(txtresultreview.getText()).toEqual('Yes');
            expect(txtmvaccident.getText()).toEqual('Yes');
            expect(txtonjob.getText()).toEqual('Yes');
            expect(txttohospital.getText()).toEqual('Yes');
            expect(txtdatehospital.getText()).toEqual('');
            expect(txtsurgeryreview.getText()).toEqual('Yes');
            expect(txtdescreview.getText()).toEqual("");
            expect(txtcomplicationsreview.getText()).toEqual("test");



        });

   it('New CLI_Review Page  - Additional Information section validations ', function() {


        var addlinfosection = PORPER.addlinfosection.input.getText();
        browser.executeScript('window.scrollTo(400,600);');
        addlinfosection.click();


        //Additional Information page label validations
        expect(lbldateofhire.getText()).toEqual('Date of Hire');
        expect(lblempcontribution.getText()).toEqual('Employee Premium Contribution');
        expect(lblclass.getText()).toEqual('Class');
        expect(lblemprcontribution.getText()).toEqual('Employer Premium Contribution');
        expect(lblbenefitpercent.getText()).toEqual('Benefit Percent');
        expect(lbldaysperweek.getText()).toEqual('Days per Week');
        expect(lblhourdays.getText()).toEqual('Hours per Day');
        expect(lblschdays.getText()).toEqual('Scheduled Work Days');
        expect(lblcurrstatus.getText()).toEqual('Current Work Status');
        expect(lblempid1.getText()).toEqual('Employee ID');
        expect(lblworkstate.getText()).toEqual('Work State');
        expect(lblsubsidiary.getText()).toEqual('Subsidiary');
        expect(lbllocbranch.getText()).toEqual('Location/Branch');

        expect(lblemptype.getText()).toEqual('Employee Type');
        expect(lbljob.getText()).toEqual('Job Requirements Description');
        expect(lblphydemands.getText()).toEqual('Physical Demands');
        expect(lblpaytype.getText()).toEqual('Pay Type');
        expect(lblearnings.getText()).toEqual('Earnings (excluding commissions and bonuses)');

        expect(lblincometype.getText()).toEqual('Income Type');
        expect(lblincomeamt.getText()).toEqual('Income Amount ($)');
        expect(lblbegindate.getText()).toEqual('Income Begin Date');
        expect(lblenddate.getText()).toEqual('Income End Date');
        expect(lblapplieddate.getText()).toEqual('Income Applied Date');
        browser.sleep(1000);

        expect(txtdateofhire.getText()).toEqual('02/02/2017');
        expect(txtempid.getText()).toContain('98980');
        expect(txtworkstate.getText()).toEqual('Alaska');
        expect(txtsubsidiary.getText()).toEqual('1000');
        expect(txtlocbranch.getText()).toEqual('NewYork');
        expect(txtemptype.getText()).toEqual('Full-Time');
        expect(txtjob.getText()).toEqual('Test job desc');
        expect(txtphydem.getText()).toEqual('Sedentary');
        expect(txtpaytype.getText()).toEqual('Salary');
        expect(txtearnings.getText()).toEqual('$4,500.00');

        // expect(txtincomeamt.getText()).toEqual('250');
        expect(txtclass1.getText()).toEqual('B1');
        expect(txtemppremium.getText()).toEqual('45%');
        expect(txtemprpremium.getText()).toEqual('55%');
        expect(txtbenefit.getText()).toEqual('20%');
        expect(txtdays.getText()).toEqual('6');
        expect(txthours.getText()).toEqual('8');
        expect(txtschdays.getText()).toEqual('Monday');
        expect(txtcurworkstatus.getText()).toEqual('Active');
        /* expect(txtincometype.getText()).toEqual('Vacation');
         expect(txtbegindate.getText()).toEqual('02/02/2017');
         expect(txtenddate.getText()).toEqual('02/02/2017');
         expect(txtappdate.getText()).toEqual('02/02/2017');*/


    });

  it('New CLI_Review Page  - About Your absence section validations for Bond flow ', function() {

        browser.executeScript('window.scrollTo(550,1600);');
        element(by.buttonText('Go Back')).click();
        browser.executeScript('window.scrollTo(3300,2600);');
        browser.sleep(1000);
        element(by.buttonText('Go Back')).click();

        browser.executeScript('window.scrollTo(40,100);');
        browser.sleep(10000);
        var leaveclaimlist = POAYA.leavetypelist1.input;


        leaveclaimlist.$('[value="BND"]').click();

        browser.sleep(10000);
        var claimantconditionlist = POAYA.claimantconditionlist.input;
        claimantconditionlist.$('[value="AD"]').click();

        txtillness.sendKeys('02/02/2017',protractor.Key.TAB);
        txtlastday.sendKeys('02/02/2017',protractor.Key.TAB);
        txthospital.sendKeys('02/02/2017',protractor.Key.TAB);
        txtsurgery1.sendKeys('02/02/2017',protractor.Key.TAB);
        element(by.buttonText('Continue')).click();
        browser.executeScript('window.scrollTo(3300,2600);');
        element(by.buttonText('Continue')).click();

        var aboutyourabsencesection = PORPER.aboutyourabsencesection.input.getText();
        browser.executeScript('window.scrollTo(200,500);');
        browser.sleep(20000);
        aboutyourabsencesection.click();

        expect(lblcontinuous1.getText()).toEqual('Will the Employee be out for a continuous period of time?');
        expect(lblcircumstances.getText()).toEqual('What best describes the circumstances for the absence?');
        expect(lbldesccircumstances.getText()).toEqual("What is the reason for the Employee's absence?");
        expect(lblillnessreview .getText()).toEqual('What is the first day, or expected first day, of the leave of absence?');
        expect(lbllastdayreview .getText()).toEqual("What is the date the child was placed in the Employee's care?");
        expect(lblresultreview.getText()).toEqual('What is the date of birth of the person the Employee is bonding with?');
        expect(lblmvaccident.getText()).toEqual("What is the last day, or estimated last day, of the Employee's leave of absence?");


        expect(txtcontinuous1.getText()).toEqual('Yes');
        expect(txtcircumstances.getText()).toEqual('Bond with child');
        expect(txtdesccircumstances.getText()).toEqual('Adoption');
        expect(txtillnessreview .getText()).toEqual('02/02/2017');
        expect(txtlastdayreview .getText()).toEqual('02/02/2017');
        expect(txtresultreview.getText()).toEqual('02/02/2017');
        expect(txtmvaccident.getText()).toEqual('02/02/2017');
        expect(txtonjob.getText()).toEqual('');
        expect(txttohospital.getText()).toEqual('');
        expect(txtdatehospital.getText()).toEqual('');
        expect(txtcomplicationsreview.getText()).toEqual("");



    });

   it('New CLI_Review Page  - About Your absence section validations for Materity flow ', function() {

        browser.executeScript('window.scrollTo(550,1600);');
        element(by.buttonText('Go Back')).click();
        browser.executeScript('window.scrollTo(3300,2600);');
        browser.sleep(1000);
        element(by.buttonText('Go Back')).click();

        browser.executeScript('window.scrollTo(40,100);');
        browser.sleep(10000);
        var leaveclaimlist = POAYA.leavetypelist1.input;
        POAYA.consecutivedaysradiobtnn.input.click();
        POAYA.consecutivedaysradiobtny.input.click();

        leaveclaimlist.$('[value = "MAT"]').click();
        browser.sleep(10000);
        var delivery = POAYA.delivered.input;
        delivery.$('[value = "Yes, C-Section"]').click();
        txtillness.sendKeys('02/02/2017',protractor.Key.TAB);
        txtlastday.sendKeys('02/02/2017',protractor.Key.TAB);
        txthospital.sendKeys('02/02/2017',protractor.Key.TAB);
        txtsurgery1.sendKeys('02/02/2017',protractor.Key.TAB);
        element(by.buttonText('Continue')).click();
        browser.executeScript('window.scrollTo(3300,2600);');
        element(by.buttonText('Continue')).click();

        var aboutyourabsencesection = PORPER.aboutyourabsencesection.input.getText();
        browser.executeScript('window.scrollTo(200,500);');
        browser.sleep(20000);
        aboutyourabsencesection.click();

        expect(lblcontinuous1.getText()).toEqual('Will the Employee be out for a continuous period of time?');
        expect(lblcircumstances.getText()).toEqual('What best describes the circumstances for the absence?');
        expect(lbldesccircumstances.getText()).toEqual('Has the Employee already delivered?');
        expect(lblillnessreview .getText()).toEqual('What date did the Employee deliver?');
        expect(lbllastdayreview .getText()).toEqual('What was the last day worked or expected last day worked?');
        expect(lblresultreview.getText()).toEqual('What date did the Employee arrive at the hospital?');
        expect(lblmvaccident.getText()).toEqual("What was, or is, the Employee's discharge date from the hospital?");
        expect(lblonjob.getText()).toEqual("Please provide details around the Employee's related complications, surgeries, injuries, or any additional details related to the absence.");


        expect(txtcontinuous1.getText()).toEqual('Yes');
        expect(txtcircumstances.getText()).toEqual('Maternity');
        expect(txtdesccircumstances.getText()).toEqual('Yes, C-Section');
        expect(txtillnessreview .getText()).toEqual('02/02/2017');
        expect(txtlastdayreview .getText()).toEqual('02/02/2017');
        expect(txtresultreview.getText()).toEqual('02/02/2017');
        expect(txtmvaccident.getText()).toEqual('02/02/2017');
        expect(txtonjob.getText()).toEqual('');
        expect(txttohospital.getText()).toEqual('');
        expect(txtdatehospital.getText()).toEqual('');
        expect(txtcomplicationsreview.getText()).toEqual("");



    });

   it('New CLI_Review Page  - About Your absence section validations for Care flow', function() {

        browser.executeScript('window.scrollTo(550,1600);');
        element(by.buttonText('Go Back')).click();
        browser.executeScript('window.scrollTo(3300,2600);');
        browser.sleep(1000);
        element(by.buttonText('Go Back')).click();

        browser.executeScript('window.scrollTo(40,100);');
        browser.sleep(10000);
        var leaveclaimlist = POAYA.leavetypelist1.input;
        POAYA.consecutivedaysradiobtnn.input.click();
        POAYA.consecutivedaysradiobtny.input.click();

        leaveclaimlist.$('[value = "FMC"]').click();
        browser.sleep(10000);
        var claimantconditionlist = POAYA.claimantconditionlist.input;
        claimantconditionlist.$('[value = "CH"]').click();

        var lstrelationship = POAYA.relationshiplist.input;
        lstrelationship.$('[value = "CP"]').click();

        txtillness.sendKeys('02/02/2017',protractor.Key.TAB);
        txtlastday.sendKeys('02/02/2017',protractor.Key.TAB);
        txthospital.sendKeys('02/02/2017',protractor.Key.TAB);

        browser.executeScript('window.scrollTo(650,1800);');

        element(by.buttonText('Continue')).click();
        browser.executeScript('window.scrollTo(3300,2600);');
        element(by.buttonText('Continue')).click();

        var aboutyourabsencesection = PORPER.aboutyourabsencesection.input.getText();
        browser.executeScript('window.scrollTo(200,500);');
        browser.sleep(20000);
        aboutyourabsencesection.click();

        expect(lblcontinuous1.getText()).toEqual('Will the Employee be out for a continuous period of time?');
        expect(lblcircumstances.getText()).toEqual('What best describes the circumstances for the absence?');
        expect(lbldesccircumstances.getText()).toEqual("What is the reason for the Employee's absence?");
        expect(lblillnessreview .getText()).toEqual("What is the person's relationship to the Employee?");
        expect(lbllastdayreview .getText()).toEqual("What is the first day, or expected first day, of the leave of absence?");
        expect(lblresultreview.getText()).toEqual('What is the date of birth of the person the Employee is caring for?');
        expect(lblmvaccident.getText()).toEqual("What is the last day, or estimated last day, of the Employee's leave of absence?");

        expect(txtcontinuous1.getText()).toEqual('Yes');
        expect(txtcircumstances.getText()).toEqual('Care for family member (including military)');
        expect(txtdesccircumstances.getText()).toEqual('Child');
        expect(txtillnessreview .getText()).toEqual('Child 18+');
        expect(txtlastdayreview .getText()).toEqual('02/02/2017');
        expect(txtresultreview.getText()).toEqual('02/02/2017');
        expect(txtmvaccident.getText()).toEqual('02/02/2017');
        expect(txtonjob.getText()).toEqual('');
        expect(txttohospital.getText()).toEqual('');
        expect(txtdatehospital.getText()).toEqual('');
        expect(txtcomplicationsreview.getText()).toEqual("");



    });

   it('New CLI_Review Page  - About Your absence section validations for Other flow', function() {

        browser.executeScript('window.scrollTo(550,1600);');
        element(by.buttonText('Go Back')).click();
        browser.executeScript('window.scrollTo(3300,2600);');
        browser.sleep(1000);
        element(by.buttonText('Go Back')).click();

        browser.executeScript('window.scrollTo(40,100);');
        browser.sleep(10000);
        var leaveclaimlist = POAYA.leavetypelist1.input;
        POAYA.consecutivedaysradiobtnn.input.click();
        POAYA.consecutivedaysradiobtny.input.click();

        leaveclaimlist.$('[value = "OTH"]').click();
        browser.sleep(10000);
        var claimantconditionlist = POAYA.claimantconditionlist.input;
        claimantconditionlist.$('[value = "AM"]').click();



        txtillness.sendKeys('02/02/2017',protractor.Key.TAB);
        txtlastday.sendKeys('02/02/2017',protractor.Key.TAB);


        browser.executeScript('window.scrollTo(650,1800);');

        element(by.buttonText('Continue')).click();
        browser.executeScript('window.scrollTo(3300,2600);');
        element(by.buttonText('Continue')).click();

        var aboutyourabsencesection = PORPER.aboutyourabsencesection.input.getText();
        browser.executeScript('window.scrollTo(200,500);');
        browser.sleep(20000);
        aboutyourabsencesection.click();

        expect(lblcontinuous1.getText()).toEqual('Will the Employee be out for a continuous period of time?');
        expect(lblcircumstances.getText()).toEqual('What best describes the circumstances for the absence?');
        expect(lbldesccircumstances.getText()).toEqual("What is the reason for the Employee's absence?");
        expect(lblillnessreview .getText()).toEqual("What is the first day, or expected first day, of the leave of absence?");
        expect(lbllastdayreview .getText()).toEqual("What is the last day, or estimated last day, of the Employee's leave of absence?");


        expect(txtcontinuous1.getText()).toEqual('Yes');
        expect(txtcircumstances.getText()).toEqual('Other leave type, not listed above');
        expect(txtdesccircumstances.getText()).toEqual('Administrative');
        expect(txtillnessreview .getText()).toEqual('02/02/2017');
        expect(txtlastdayreview .getText()).toEqual('02/02/2017');




    });

   it('New CLI_Employer Review Page: Story#6874 - Fraud statement validation in Review page for MD state', function() {


        expect(fraudstmntheader.getText()).not.toContain(flfraudstmt);

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/English/Testcase9_ii.png');
        });

    });

   it('Verification of the headers and the alignment in all the CLI Pages', function() {

        var dob1 = POAYP.dobtbox1.input;
        var pageheader = POAYP.pageheader.input;
        var AYPPageheader = POAYP.pageheaderAYP.input;
        var AYAPageheader = POAYP.pageheaderAYA.input;
        var reviewpageheader = POAYP.pageheaderreview.input;
        var pageheaderaddl = POAYP.pageheaderaddl.input;

        expect(pageheader.getText()).toEqual('Get Started');

        expect(AYPPageheader.getText()).toEqual('About Your Employee');

        expect(AYAPageheader.getText()).toEqual('About Absence');

        expect(pageheaderaddl.getText()).toEqual('Additional Information');

        expect(reviewpageheader.getText()).toEqual('Review');


    },300000000);

    it('New CLI_Review Page : Verify Label Validations when SSN is selected ', function() {

        browser.executeScript('window.scrollTo(550,1600);');
        element(by.buttonText('Go Back')).click();
        browser.executeScript('window.scrollTo(3300,2600);');
        browser.sleep(1000);
        element(by.buttonText('Go Back')).click();
        browser.executeScript('window.scrollTo(600,1600);');
        browser.sleep(1000);
        element(by.buttonText('Go Back')).click();
        browser.executeScript('window.scrollTo(40,200);');

        POAYP.ssnradio.input.click();

        txtssn1.sendKeys('234234234');

        browser.executeScript('window.scrollTo(750,1800);');
        browser.sleep(1000);

        POAYP.prefmethodrbtnmail.input.click();


        browser.executeScript('window.scrollTo(600,1600);');
        browser.sleep(1000);
        POAYP.continuebutton.input.click();


        browser.sleep(1000);
        element(by.buttonText('Continue')).click();
        browser.sleep(1000);
        browser.executeScript('window.scrollTo(3300,2600);');
        browser.sleep(1000);
        element(by.buttonText('Continue')).click();
        browser.executeScript('window.scrollTo(80,400);');
        browser.sleep(1000);





        //Validations for the story 6333

        //Verify the lables displayed are correct

        expect(lblempid.getText()).toEqual('Social Security Number');
        expect(lblfirstname.getText()).toEqual('First Name');
        expect(lblmiddle.getText()).toEqual('Middle Initial');
        expect(lbllastname.getText()).toEqual('Last Name');
        expect(lblgender.getText()).toEqual('Gender');
        expect(lbldob.getText()).toEqual('Date of Birth');
        expect(lblpphone.getText()).toEqual('Preferred Personal Phone');
        expect(lblpemail.getText()).toEqual('Preferred Personal Email');
        expect(lblpmethod.getText()).toEqual('Preferred method for non-confidential correspondence');
        expect(lblres1.getText()).toEqual('Residential Address 1');
        expect(lblres2.getText()).toEqual('Residential Address 2');
        expect(lblrescity.getText()).toEqual('Residential City');
        expect(lblcountry.getText()).toEqual('Country');
        expect(lblpostalcode.getText()).toEqual('Postal Code');
        expect(lblcountryofemploy.getText()).toEqual('Country of Employment');

        expect(txtempid1.getText()).toContain('4234');
        expect(txtfirstname.getText()).toEqual('TestFirst');
        expect(txtmiddlename.getText()).toEqual('');
        expect(txtlastname.getText()).toEqual('TestLast');
        expect(txtgender.getText()).toEqual('f');
        expect(txtdob.getText()).toEqual('01/01/1987');
        expect(txtpphone.getText()).toEqual('(666) 644-4555');
        expect(txtpemail.getText()).toEqual('test@testmail.com');
        expect(txtpmethod.getText()).toEqual('Mail');
        expect(txtresaddr1.getText()).toEqual('150 LibertyWay');
        expect(txtresaddr2.getText()).toEqual('');
        expect(txtrescity.getText()).toEqual('Dover');
        expect(txtcountry.getText()).toEqual('United States');
        expect(txtecountry.getText()).toEqual('United States');
        expect(txtpostalcode.getText()).toEqual('03820');



    });


    it('New CLI_Review Page  - About Your Employee section : Verify textbox entries when SSN and Fax selected for Pref Method - Country United States', function() {

        browser.executeScript('window.scrollTo(550,1600);');
        element(by.buttonText('Go Back')).click();
        browser.executeScript('window.scrollTo(3300,2600);');
        browser.sleep(1000);
        element(by.buttonText('Go Back')).click();
        browser.executeScript('window.scrollTo(600,1600);');
        browser.sleep(1000);
        element(by.buttonText('Go Back')).click();


        browser.executeScript('window.scrollTo(750,1800);');
        browser.sleep(1000);

        POAYP.prefmethodrbtnfax.input.click();
        browser.sleep(1000);
       // POAYP.faxtextbox.input.click();
        browser.sleep(1000);

        var txtfax = POAYP.txtfax.input;
        txtfax.sendKeys('8908977989');
        browser.sleep(1000);

        var valfax = txtfax.getAttribute('value');


        var lblfax = POEER.lblfax.input;

        browser.executeScript('window.scrollTo(850,2200);');
        browser.sleep(1000);
        POAYP.continuebutton.input.click();


        browser.sleep(1000);
        element(by.buttonText('Continue')).click();
        browser.sleep(1000);
        browser.executeScript('window.scrollTo(3300,2600);');
        browser.sleep(1000);
        element(by.buttonText('Continue')).click();
        browser.executeScript('window.scrollTo(80,400);');
        browser.sleep(1000);

        expect(txtempid1.getText()).toContain('4234');
        expect(txtfirstname.getText()).toEqual('TestFirst');
        expect(txtmiddlename.getText()).toEqual('');
        expect(txtlastname.getText()).toEqual('TestLast');
        expect(txtgender.getText()).toEqual('f');
        expect(txtdob.getText()).toEqual('01/01/1987');
        expect(txtpphone.getText()).toEqual('(666) 644-4555');
        expect(txtpemail.getText()).toEqual('test@testmail.com');
        expect(txtpmethod.getText()).toEqual('Fax');
        expect(txtresaddr1.getText()).toEqual('150 LibertyWay');
        expect(txtresaddr2.getText()).toEqual('');
        expect(txtrescity.getText()).toEqual('Dover');
        expect(txtcountry.getText()).toEqual('United States');
        expect(txtecountry.getText()).toEqual('United States');
        expect(txtpostalcode.getText()).toEqual('03820');
        expect(lblfax.getText()).toEqual('Preferred Fax');
        expect(txtfax1.getText()).toEqual(valfax);


    });

    it('New CLI_Review Page  - About Your Employee section : Verify textbox entries when SSN and Fax selected for Pref Method - Country Canada', function() {

        browser.executeScript('window.scrollTo(550,1600);');
        element(by.buttonText('Go Back')).click();
        browser.executeScript('window.scrollTo(3300,2600);');
        browser.sleep(1000);
        element(by.buttonText('Go Back')).click();
        browser.executeScript('window.scrollTo(600,1600);');
        browser.sleep(1000);
        element(by.buttonText('Go Back')).click();
        var lblfax = POEER.lblfax.input;


        browser.executeScript('window.scrollTo(850,2200);');
        browser.sleep(1000);

        var country = POAYP.empcountrylist1.input;
        country.$('[value = "CAN"]').click();

        statelist.$('[value = "AB"]').click();

        postalcode.sendKeys('a1a1a1');
        var vpostal = postalcode.getAttribute('value');
        var ecountry = POAYP.countryofemploylist.input;
        ecountry.$('[value = "CAN"]').click();

        stateemploy.$('[value = "BC"]').click();

        browser.executeScript('window.scrollTo(850,2200);');
        browser.sleep(1000);
        POAYP.continuebutton.input.click();


        browser.sleep(1000);
        element(by.buttonText('Continue')).click();
        browser.sleep(1000);
        browser.executeScript('window.scrollTo(3300,2600);');
        browser.sleep(1000);
        element(by.buttonText('Continue')).click();
        browser.executeScript('window.scrollTo(80,400);');
        browser.sleep(1000);

        expect(txtempid1.getText()).toContain('4234');
        expect(txtfirstname.getText()).toEqual('TestFirst');
        expect(txtmiddlename.getText()).toEqual('');
        expect(txtlastname.getText()).toEqual('TestLast');
        expect(txtgender.getText()).toEqual('f');
        expect(txtdob.getText()).toEqual('01/01/1987');
        expect(txtpphone.getText()).toEqual('(666) 644-4555');
        expect(txtpemail.getText()).toEqual('test@testmail.com');
        expect(txtpmethod.getText()).toEqual('Fax');
        expect(txtresaddr1.getText()).toEqual('150 LibertyWay');
        expect(txtresaddr2.getText()).toEqual('');
        expect(txtrescity.getText()).toEqual('Dover');
        expect(lblfax.getText()).toEqual('Preferred Fax');
        expect(txtfax1.getText()).toEqual('(890) 897-7989');

        expect(txtcountry.getText()).toEqual('Canada');
        expect(txtecountry.getText()).toEqual('Canada');
        expect(lblstateemploy.getText()).toEqual('Province of Employment');
        expect(txtsemploy.getText()).toEqual('British Columbia');

        expect(lblresstate.getText()).toEqual('Province');
        expect(txtstate.getText()).toEqual('Alberta');

        expect(txtpostalcode.getText()).toEqual(vpostal);




    });

    it('New CLI_Review Page  - About Your Employee section : Verify values when country is other than United States and Canada', function() {

        browser.executeScript('window.scrollTo(550,1600);');
        element(by.buttonText('Go Back')).click();
        browser.executeScript('window.scrollTo(3300,2600);');
        browser.sleep(1000);
        element(by.buttonText('Go Back')).click();
        browser.executeScript('window.scrollTo(600,1600);');
        browser.sleep(1000);
        element(by.buttonText('Go Back')).click();
        var lblfax = POEER.lblfax.input;



        var country = POAYP.empcountrylist1.input;
        country.$('[value = "BTN"]').click();



        postalcode.clear();
        postalcode.sendKeys('11001');
        var vpostal = postalcode.getAttribute('value');
        var ecountry = POAYP.countryofemploylist.input;
        ecountry.$('[value = "BTN"]').click();
        browser.executeScript('window.scrollTo(850,2200);');
        browser.sleep(1000);
        POAYP.continuebutton.input.click();


        browser.sleep(1000);
        element(by.buttonText('Continue')).click();
        browser.sleep(1000);
        browser.executeScript('window.scrollTo(3300,2600);');
        browser.sleep(1000);
        element(by.buttonText('Continue')).click();
        browser.executeScript('window.scrollTo(80,400);');
        browser.sleep(1000);

        expect(txtempid1.getText()).toContain('4234');
        expect(txtfirstname.getText()).toEqual('TestFirst');
        expect(txtmiddlename.getText()).toEqual('');
        expect(txtlastname.getText()).toEqual('TestLast');
        expect(txtgender.getText()).toEqual('f');
        expect(txtdob.getText()).toEqual('01/01/1987');
        expect(txtpphone.getText()).toEqual('(666) 644-4555');
        expect(txtpemail.getText()).toEqual('test@testmail.com');
        expect(txtpmethod.getText()).toEqual('(890) 897-7989');
        expect(txtresaddr1.getText()).toEqual('150 LibertyWay');
        expect(txtresaddr2.getText()).toEqual('');
        expect(txtrescity.getText()).toEqual('Dover');

        var ocountry = POEER.ocountry.input;
        expect(ocountry.getText()).toEqual('Bhutan');


        var opostal = POEER.opostalcode.input;
        expect(opostal.getText()).toEqual(vpostal);


        var oecountry = POEER.oecountry.input;
        expect(oecountry.getText()).toEqual('Bhutan');

    });
    it('NEW CLI - Review Page - Add Instructional Text to the page-7859', function() {

         ResuableFunction.MLC_Login();
         ResuableFunction.EmployerCLI();

         Getting_StartedPage.clickStart("Employer");

         AboutYourEmployeePage.EnterEmployeeID('23259');
         AboutYourEmployeePage.EnterFirstName('Test');
         AboutYourEmployeePage.EnterLastName('Test');
         AboutYourEmployeePage.EnterDateofBirth('01/01/1987');
         AboutYourEmployeePage.SelectGender('Female');
         AboutYourEmployeePage.EnterResdentialAddress1('123 Test');
         AboutYourEmployeePage.EnterResdentialcity('Dover');
         AboutYourEmployeePage.SelectState('AK');
         AboutYourEmployeePage.EnterPostalCode('23345');
         AboutYourEmployeePage.EnterPersonalPhone('1231231234');
         AboutYourEmployeePage.EnterPersonalEmail('test@test.com');
         AboutYourEmployeePage.SelectEmploymentState('AK');
         AboutYourEmployeePage.ClickContinue_ViewAboutYourAbsence();

         POAYA .SelectLeaveorClaimCategory('Yes');
         POAYA .SelectLeaveorClaimtype('Maternity');
         POAYA .SelectDeliveryType('Vaginal');
         POAYA .EnterDateQuestion_1('11/01/2017');
         POAYA .EnterDateQuestion_2('11/01/2017');
         POAYA .ClickContinue_ViewAdditionalInformation();

        POAIP .EnternoValues_ClickContinue_ViewReviewPage();

        expect(element(by.xpath("//h2[ text()='Review']").getText())).toEqual(txtaddlninfeng);

     },300000000);


});



