/**
 * Created by n0275896 on 7/3/2017.
 */

//Include the pageobjects for Getting Started Page

var ResuableFunction = require('./..//helpers/helpers.js');
var Getting_StartedPage = require('./../../PageObjects/PageObject_GettingStarted.js');
var AboutYouPage = require('./../../PageObjects/PageObject_AboutYouPage.js');
var ReviewPage = require('./../../PageObjects/PageObject_ER_ReviewPage.js')


describe ('New CLI_Getting Started Page Validations', function() {

    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;



    it('New_CLI:Getting Started Page : Circle color and Progress bar header validations', function() {

         ResuableFunction.MLC_Login();
         ResuableFunction.EmployerCLI();
         Getting_StartedPage.VerifyGettingStartedCircleColor();
         Getting_StartedPage.VerifyProgressBarHeader("Employer");
         Getting_StartedPage.VerifyTransparentCircle("Employer",3);

     },300000000);

    it('New_CLI:Getting Started Page : Header and static content validations', function() {

        Getting_StartedPage.VerifyCLIHeader();
        Getting_StartedPage.VerifyPageHeader("Employer");
        Getting_StartedPage.VerifyGettingStarted_StaticContent("Employer");

    });

    it('New_CLI:Getting Started Page : GetHelp Pop up validations', function() {

        Getting_StartedPage.VerifyGetHelp_Popup();

    });

    it('New_CLI:Getting Started Page : Start button Presence and when clicked navigates to About your employee page', function() {


        Getting_StartedPage.VerifyStartButtonText_Color("Employer");
        Getting_StartedPage.clickStart("Employer");

    },300000000);


    it('New_CLI: Button - Report an Employees New Claim or Leave - Story 8996', function() {

        ResuableFunction.MLC_Login();
        ResuableFunction.EmployerCLI();
        Getting_StartedPage.VerifyGettingStartedCircleColor();


    },300000000);


});