/**
 * Created by n0305595 on 6/20/2017.
 */

//Use the pageobjects defined for AboutYouPage

var Getting_StartedPage = require('./../../PageObjects/PageObject_GettingStarted.js');
var ResuableFunction = require('./..//helpers/helpers.js');
var AboutYourEmployeePage = require('./../../PageObjects/PageObject_AboutYouPage.js');
var AboutAbsencePage = require('./../../PageObjects/PageObject_AboutYourAbsence.js');
var AddlInfoPage = require('./../../PageObjects/PageObject_Additional_InformationPage.js');

//Function to take screenshot
var fs = require('fs');
function writeScreenShot(data, filename) {
 var stream = fs.createWriteStream(filename);
 stream.write(new Buffer(data, 'base64'));
 stream.end();
}


function DateValidation(Element) {
    Element.sendKeys('02/2/2012',protractor.Key.TAB);
    expect(Element.getAttribute('value')).toEqual('02/02/2012');
    browser.takeScreenshot().then(function (png) {
        writeScreenShot(png, './Screenshots/ER/Addl Info/Date1.png');
    });
    console.log("02/2/2012 format validated");

    Element.clear().sendKeys('8/12/2017',protractor.Key.TAB);
    expect(Element.getAttribute('value')).toEqual('08/12/2017');
    browser.takeScreenshot().then(function (png) {
        writeScreenShot(png, './Screenshots/ER/Addl Info/Date2.png');
    });
    console.log("8/12/2017 format validated");

    Element.clear().sendKeys('8/8/2017',protractor.Key.TAB);
    expect(Element.getAttribute('value')).toEqual('08/08/2017');
    browser.takeScreenshot().then(function (png) {
        writeScreenShot(png, './Screenshots/ER/Addl Info/Date3.png');
    });
    console.log("8/8/2017 format validated");

    Element.clear().sendKeys('8-8-2017',protractor.Key.TAB);
    expect(Element.getAttribute('value')).toEqual('');
    browser.takeScreenshot().then(function (png) {
        writeScreenShot(png, './Screenshots/ER/Addl Info/Date4.png');
    });
    console.log("8-8-2017 format validated");
}



describe ('New ER CLI_Confirmation Page - Validations', function() {

    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;




    it('New CLI_Employer_Additional Information Page - Validations', function () {

        ResuableFunction.MLC_Login();
        ResuableFunction.EmployerCLI();

        Getting_StartedPage.clickStart("Employer");

        AboutYourEmployeePage.EnterEmployeeID('23259');
        AboutYourEmployeePage.EnterFirstName('Test');
        AboutYourEmployeePage.EnterLastName('Test');
        AboutYourEmployeePage.EnterDateofBirth('01/01/1987');
        AboutYourEmployeePage.SelectGender('Female');
        AboutYourEmployeePage.EnterResdentialAddress1('123 Test');
        AboutYourEmployeePage.EnterResdentialcity('Dover');
        AboutYourEmployeePage.SelectState('AK');
        AboutYourEmployeePage.EnterPostalCode('23345');
        AboutYourEmployeePage.EnterPersonalPhone('1231231234');
        AboutYourEmployeePage.EnterPersonalEmail('test@test.com');
        AboutYourEmployeePage.SelectEmploymentState('AK');
        AboutYourEmployeePage.ClickContinue_ViewAboutYourAbsence();

        AboutAbsencePage.SelectLeaveorClaimCategory('Yes');
        AboutAbsencePage.SelectLeaveorClaimtype('Maternity');
        AboutAbsencePage.SelectDeliveryType('Vaginal');
        AboutAbsencePage.EnterDateQuestion_1('11/01/2017');
        AboutAbsencePage.EnterDateQuestion_2('11/01/2017');
        AboutAbsencePage.ClickContinue_ViewAdditionalInformation();


        AddlInfoPage.Labelvalidations();
        AddlInfoPage.SectionsHeadingValidations();
        AddlInfoPage.dateofhire('11/02/2017');
        AddlInfoPage.EnterTextBoxValue('118877');
        AddlInfoPage.Selectdropdown('NY');
        AddlInfoPage.EnterTextBoxValue('test');
        AddlInfoPage.EnterTextBoxValue('New York');
        AddlInfoPage.Selectdropdown('F');
        AddlInfoPage.EnterJobReqDesc('Sample text will display here');
        AddlInfoPage.Selectdropdown('L');
        AddlInfoPage.Selectdropdown('VA');
        AddlInfoPage.EnterTextBoxValue('23');
        AddlInfoPage.EnterTextBoxValue('50');
        AddlInfoPage.EnterTextBoxValue('50');
        AddlInfoPage.EnterEmpcontribution('50');
        AddlInfoPage.Selectdropdown('VA');
        AddlInfoPage.EnterOtherincomamount('340');
        AddlInfoPage.Otherincomebegandate('11/02/2017');
        AddlInfoPage.Otherincomeceaseddate('11/02/2017');
        AddlInfoPage.Otherincomeapplieddate('11/02/2017');
        AddlInfoPage.EnterTextBoxValue('5');
        AddlInfoPage.EnterTextBoxValue('8');
        AddlInfoPage.Selectdropdown('A');


        AddlInfoPage.EnternoValues_ClickContinue_ViewReviewPage();

    },300000000);

    it('New CLI_Employer_Additional Information Page - Date Field Error Message Validations', function () {

        ResuableFunction.MLC_Login();
        ResuableFunction.EmployerCLI();

        Getting_StartedPage.clickStart("Employer");

        AboutYourEmployeePage.EnterEmployeeID('23259');
        AboutYourEmployeePage.EnterFirstName('Test');
        AboutYourEmployeePage.EnterLastName('Test');
        AboutYourEmployeePage.EnterDateofBirth('01/01/1987');
        AboutYourEmployeePage.SelectGender('Female');
        AboutYourEmployeePage.EnterResdentialAddress1('123 Test');
        AboutYourEmployeePage.EnterResdentialcity('Dover');
        AboutYourEmployeePage.SelectState('AK');
        AboutYourEmployeePage.EnterPostalCode('23345');
        AboutYourEmployeePage.EnterPersonalPhone('5231231234');
        AboutYourEmployeePage.EnterPersonalEmail('test@test.com');
        AboutYourEmployeePage.SelectEmploymentState('AK');
        AboutYourEmployeePage.ClickContinue_ViewAboutYourAbsence();

        AboutAbsencePage.SelectLeaveorClaimCategory('Yes');
        AboutAbsencePage.SelectLeaveorClaimtype('Maternity');
        AboutAbsencePage.SelectDeliveryType('Vaginal');
        AboutAbsencePage.EnterDateQuestion_1('01/01/2018');
        AboutAbsencePage.EnterDateQuestion_2('01/01/2018');
        AboutAbsencePage.ClickContinue_ViewAdditionalInformation();


        AddlInfoPage.dateofhire('01011899');
        AddlInfoPage.Selectincomedropdown('WG');
        AddlInfoPage.Otherincomebegandate('01/11899');
        AddlInfoPage.Otherincomeceaseddate('0101899');
        AddlInfoPage.Otherincomeapplieddate('010118');
        AddlInfoPage.invalid_msg('HireDate');
        AddlInfoPage.invalid_msg('BeginDate');
        AddlInfoPage.invalid_msg('EndDate');
        AddlInfoPage.invalid_msg('ApplyDate');
        AddlInfoPage.dateofhire('02/02/2018');
        AddlInfoPage.future_msg();
        AddlInfoPage.Otherincomebegandate('01/02/2017');
        AddlInfoPage.Otherincomeceaseddate('01/02/2017');
        AddlInfoPage.Otherincomeapplieddate('01/02/2017');
        AddlInfoPage.outofwindow_msg('BeginDate');
        AddlInfoPage.outofwindow_msg('EndDate');
        AddlInfoPage.outofwindow_msg('ApplyDate');


    },300000000);

});













/*
describe ('Open CLI URL in Browser and Validate About You Page', function(){

    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;

    var hiredatetextbox = POAIP.hiredatetextbox.input;
    var username = POAYP.username.input;
    var password = POAYP.password.input;
    var begandate = POAIP.begandate.input;
    var ceaseddate = POAIP.ceaseddate.input;
    var applieddate = POAIP.applieddate.input;
    var txthiredate = POAIP.txthiredate.input;
    var txtbegandate = POAIP.txtbegandate.input;
    var txtapplieddate = POAIP.txtapplieddate.input;
    var txtceaseddate = POAIP.txtceasedate.input;




    it('New CLI_Additional Information values validation - Employment Details section', function() {


        browser.ignoreSynchronization = true;
        browser.waitForAngularEnabled(false);
        POCommonFunctions.employerurl();
        POCommonFunctions.employeelogin();
        POCommonFunctions.callCLI();
        POCommonFunctions.enteraboutyouremppagefemale();
        POCommonFunctions.enterDetailsofabsencepage();
        element(by.buttonText('Continue')).click();
        browser.executeScript('window.scrollTo(40,200);');


      //Verify Date Of Hire label
      var hiredatelabel = POAIP.hiredatelabel.input.getText();
      expect(hiredatelabel).toContain('Date of Hire (optional)');

      //Verify Employee ID label
      var empidlabel = POAIP.empidlabel.input.getText();
      expect(empidlabel).toEqual('Employee ID (optional)');

      //Verify Work Statelabel
      var workstatelabel = POAIP.workstatelabel.input.getText();
      expect(workstatelabel).toContain('Work State (optional)');

      //Verify Subsidiary label
      var subslbl = POAIP.subslbl.input.getText();
      expect(subslbl).toEqual('Subsidiary (optional)');

      //Verify Location/Branch label
      var locbranchlbl = POAIP.locbranchlbl.input.getText();
      expect(locbranchlbl).toEqual('Location/Branch (optional)');

      //Verify  Employee Type label
      var emptypelbl = POAIP.emptypelbl.input.getText();
      expect(emptypelbl).toContain('Employee Type (optional)');

      //Verify Job Requirements Description label
      var jobreqdesclbl = POAIP.jobreqdesclbl.input.getText();
      expect(jobreqdesclbl).toContain('Job Requirements Description (optional)');

      //Verify  Physical Demands label
      var phydemandsclbl = POAIP.phydemandsclbl.input.getText();
      expect(phydemandsclbl).toContain('Physical Demands (optional)');

      //Verify Pay Type label
      var paytypelbl = POAIP.paytypelbl.input.getText();
      expect(paytypelbl).toContain('Pay Type (optional)');

      //Verify Earnings (excluding commissions and bonuses) label
      var earningslbl = POAIP.earningslbl.input.getText();
      expect(earningslbl).toContain('Earnings (excluding commissions and bonuses) (optional)');


  },300000000);

    it('New CLI_Additional Information values validation - Other Income section', function() {

      //Has or will this employee receive another source of income for the entire portion of the absence covered by this claim?
      //Please select from the following
      var sourceofincomelbl = POAIP.sourceofincomelbl.input.getText();

      //var source = 'Has or will this employee receive another source of income for the entire portion of the absence covered by this claim?'+ '/n' + 'Please select from the following'
      //expect(sourceofincomelbl).toContain(source);

      var source = 'Has or will this employee receive another source of income for the entire portion of the absence covered by this claim?'+ '/n' + 'Please select from the following'
      expect(sourceofincomelbl).toContain('source');

      var source = 'Has or will this employee receive another source of income for the entire portion of the absence covered by this claim?'+ '/n' + 'Please select from the following (optional)'
      expect(sourceofincomelbl).toContain('source');


      //Has or will this employee receive another source of income for the entire portion of the absence covered by this claim?
      //Please select from the following
      var sourceofincomelist = POAIP.sourceofincomelist.input;
      sourceofincomelist.$('[value = "Vacation"]').click();



      //Has or will this employee receive another source of income for the entire portion of the absence covered by this claim?
      //Please select from the following
      var sourceofincomelist = POAIP.sourceofincomelist.input;
      sourceofincomelist.$('[value = "Vacation"]').click();


      //Verify Other Income Amount (Please indicate per Week/per Month)label
     var otherincomeamtlbl = POAIP.otherincomeamtlbl.input.getText();
      expect(otherincomeamtlbl).toContain('Other Income Amount (Please indicate per Week/per Month) (optional)');

      //Verify Date employee began receiving other incomelabel
      var begandatelbl = POAIP.begandatelbl.input.getText();
      expect(begandatelbl).toContain('Date employee began receiving other income (optional)');

      //Verify Date employee ceased receiving other income label
      var ceaseddatelbl = POAIP.ceaseddatelbl.input.getText();
      expect(ceaseddatelbl).toContain('Date employee ceased receiving other income (optional)');

      //Verify Date employee applied for other income label
      var applieddatelbl = POAIP.applieddatelbl.input.getText();
      expect(applieddatelbl).toContain('Date employee applied for other income (optional)');

      //Verify Class label
      var classlbl = POAIP.classlbl.input.getText();
      expect(classlbl).toContain('Class (optional)');

        //Verify Employee Premium Contribution label
        var eecontributionlbl = POAIP.eecontributionlbl.input.getText();
        expect(eecontributionlbl).toContain('Employee Premium Contribution (optional)');

        //Verify Employer Premium Contribution label
        var ercontributionlbl = POAIP.ercontributionlbl.input.getText();
        expect(ercontributionlbl).toContain('Employer Premium Contribution (optional)');

        //Verify Benefit Percent label
        var benefitpercentlbl = POAIP.benefitpercentlbl.input.getText();
        expect(benefitpercentlbl).toContain('Benefit Percent (optional)');


    },300000000);

    it('New CLI_Additional Information values validation - Work Schedule (At Time Last Worked) section', function() {

        //Verify Days per Week label
        var daysperweeklbl = POAIP.daysperweeklbl.input.getText();
        expect(daysperweeklbl).toContain('Days per Week (optional)');

      //Verify Hours per Day label
      var hrsperdaylbl = POAIP.hrsperdaylbl.input.getText();
      expect(hrsperdaylbl).toContain('Hours per Day (optional)');

        //Verify Scheduled Work Days label
        var scheduledwrkdayslbl = POAIP.scheduledwrkdayslbl.input.getText();
        expect(scheduledwrkdayslbl).toContain('Scheduled Work Days (optional)');

        //Verify  Current Work Status label
        var curwrkstatuslbl = POAIP.curwrkstatuslbl.input.getText();
        expect(curwrkstatuslbl).toContain('Current Work Status (optional)');



    },300000000);



  it('New CLI_Additional Information validation - Entering all values', function() {

        //Enter date in Date of Hire

        browser.executeScript('window.scrollTo(40,200);');

        DateValidation(txthiredate);
        txthiredate.sendKeys('02/02/2017',protractor.Key.TAB);

        //Enter Employee ID
        var empidtxt = POAIP.empidtxt.input;
        empidtxt.sendKeys('98980');

        //Enter Work State in drop down
        var workstatelist = POAIP.workstatelist.input;
        workstatelist.$('[value = "AK"]').click();

        //Enter Subsidiary text box
        var substext = POAIP.substext.input;
        substext.sendKeys('1000');

        //Enter Location/Branch text box
        var locbranchtxt = POAIP.locbranchtxt.input;
        locbranchtxt.sendKeys('NewYork');

        //Enter Employee Type in drop down
        var emptypelist = POAIP.emptypelist.input;
        emptypelist.$('[value = "F"]').click();

        //Enter Job Requirements Description text box
        var jobreqdesctxt = POAIP.jobreqdesctxt.input;
        jobreqdesctxt.sendKeys('Test job desc');

        //Enter Physical Demands in drop down
        var phydemandsclist = POAIP.phydemandsclist.input;
        phydemandsclist.$('[value = "S"]').click();

        //Enter Pay Type in drop down
        var paytypelist = POAIP.paytypelist.input;
        paytypelist.$('[value = "Salary"]').click();

        //Enter Earnings (excluding commissions and bonuses) text box
        var earningstxt = POAIP.earningstxt.input;
        earningstxt.sendKeys('4500');


        //Has or will this employee receive another source of income for the entire portion of the absence covered by this claim?
        //Please select from the following
        var sourceofincomelist = POAIP.sourceofincomelist.input;
        sourceofincomelist.$('[value = "Separation Pay"]').click();

        //Enter Other Income Amount (Please indicate per Week/per Month) text box
        var otherincomeamttxt = POAIP.otherincomeamttxt.input;
        otherincomeamttxt.sendKeys('250');

        DateValidation(txtbegandate);
        txtbegandate.sendKeys('02/02/2017',protractor.Key.TAB);

        DateValidation(txtceaseddate);
        txtceaseddate.sendKeys('02/02/2017',protractor.Key.TAB);

        DateValidation(txtapplieddate);
        txtapplieddate.sendKeys('02/02/2017',protractor.Key.TAB);

        //Enter Class text box
        var classtext = POAIP.classtext.input;
        classtext.sendKeys('test');

        //Enter Employee Premium Contribution text box
        var eecontributiontext = POAIP.eecontributiontext.input;
        eecontributiontext.sendKeys('45');

        //Enter Employer Premium Contribution text box
         var ercontributiontext = POAIP.ercontributiontext.input;
         ercontributiontext.sendKeys('55');

        //Enter Benefit Percent text box
        var benefitpercenttxt = POAIP.benefitpercenttxt.input;
        benefitpercenttxt.sendKeys('20');
        browser.executeScript('window.scrollTo(2000,2000);');

        //Enter Days per Week text box
        var daysperweektxt = POAIP.daysperweektxt.input;
        daysperweektxt.sendKeys('6');

        //Enter Hours per Day text box
        var hrsperdaytxt = POAIP.hrsperdaytxt.input;
        hrsperdaytxt.sendKeys('8');

        //Click Scheduled Work Days check box (Monday)
        POAIP.mondaycheckbox.input.click();

        //Enter Current Work Status in drop down
        var curwrkstatuslist = POAIP.curwrkstatuslist.input;
        curwrkstatuslist.$('[value = "A"]').click();


    });




   /* it('New CLI_Additional Information validation - Date fields formatting', function() {


        browser.executeScript('window.scrollTo(40,200);');

        DateValidation(txthiredate);
        browser.executeScript('window.scrollTo(1300,1500);');
        DateValidation(txtbegandate);
        browser.executeScript('window.scrollTo(1400,1500);');
        DateValidation(txtceaseddate);
        browser.executeScript('window.scrollTo(1500,1600);');
        DateValidation(txtapplieddate);

    },300000000);

 it('New CLI_Additional Information values validation - To validate whether system navigates to Review page when click on "Continue" button without entering any values', function() {

        browser.executeScript('window.scrollTo(2500,2600);');
        //Click Continue button
        POAIP.continuebutton.input.click();


        //Verify review header label
        var reviewheader = PORPER.reviewheader.input.getText();
        expect(reviewheader).toContain('Review');


        //Click Additional Info page link
       // element(by.buttonText('Continue')).click();


    });


    });
*/