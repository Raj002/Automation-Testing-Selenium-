/**
 * Created by n0313914 on 8/22/2017.
 */

//Use the pageobjects, reusable functions and test data defined for AboutYouPage
var POAYP = require('./../../PageObjects/PageObject_AboutYouPage.js');
var ReuseFunc = require('./../../FunctionUtilities/Reusable.js');
var TestDataAYE = require('./../../TestData/AboutYourEmployee.js');
var Region = require('./../../FunctionUtilities/Environments.js');
var fs = require('fs');

describe ('Open CLI URL in Browser and Validate About You Page', function(){

    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;

// **********BEGINNING OF TESTCASE I************************************************************************************************************************* //
    it('New CLI_About Your Employee: Validate Date of birth field if blank', function() {

        //Open NEW CLI in browser and go to About You Page
        browser.get(Region.Env);

        //Click About Your Employee
        element(by.css('[href="/employer/cli/claimant"]')).click();

        //Enter valid value for Employee ID
        ReuseFunc.SendElement(POAYP.empidtbox.input,TestDataAYE.EmpID);

        //To enter values in SSN text box
        ReuseFunc.clickElement(POAYP.ssnradio.input);

        //Enter valid value for SSN
        ReuseFunc.SendElement(POAYP.ssntbox.input,TestDataAYE.SSN);

        //Enter valid value for FirstName
        ReuseFunc.SendElement(POAYP.fnametbox.input,TestDataAYE.FirstName);

        //Enter valid value for Last Name
        ReuseFunc.SendElement(POAYP.lnametbox.input,TestDataAYE.LastName);

        //Select Gender
        ReuseFunc.clickElement(POAYP.rbtnfemale.input);

        //Enter Valid value for Date of Birth
        ReuseFunc.SendElement(POAYP.dobtbox.input,TestDataAYE.DOB);

        //Enter Valid value for  Preferred phone number
        ReuseFunc.SendElement(POAYP.ppphonetbox.input,TestDataAYE.PrefPersonalPhone);

        //Enter Valid value for  Preferred email
        ReuseFunc.SendElement(POAYP.ppemailtbox.input,TestDataAYE.PrefPersemail);

        //Enter Valid value for  Residential Address1
        ReuseFunc.SendElement(POAYP.resaddrtbox1.input,TestDataAYE.Addr1);

        //Enter Valid value for  Residential City
        ReuseFunc.SendElement(POAYP.rescitytbox.input,TestDataAYE.City);

        //Select any Residential State
        var statelist = POAYP.resstatelist.input;
        statelist.$('[value = "AK"]').click();

        //Enter Valid value for  Postal Code
        ReuseFunc.SendElement(POAYP.postalcdetbox.input,TestDataAYE.postalCode);

        //Select any value for State of Employment
        var stateemploy = POAYP.stateofemploylist.input;
        stateemploy.$('[value = "AK"]').click();

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            ReuseFunc.writeScreenShot(png, './Screenshots/ER/About Your Employee/Testcase4_i.png');
        });

        //Click Summary Page
        element(by.css('[href="/employer/cli/summary"]')).click();

        var Summary = element(by.xpath('//div[@id="collapse1"]/div/pre'));
        expect(Summary.getText()).toContain(TestDataAYE.ExpectedResult.DOBBlank);
        console.log(Summary);


        browser.takeScreenshot().then(function (png) {
            ReuseFunc.writeScreenShot(png, './Screenshots/ER/About Your Employee/Testcase4_ii.png');
        });

    });
// **********END OF TESTCASE VI*************************************************************************************************************************//

});
