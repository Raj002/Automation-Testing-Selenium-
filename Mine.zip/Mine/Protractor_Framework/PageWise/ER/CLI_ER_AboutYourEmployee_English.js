/**
 * Created by n0305595 on 6/20/2017.
 */

//Use the pageobjects defined for AboutYouPage

var ResuableFunction = require('./..//helpers/helpers.js');
var Getting_StartedPage = require('./../../PageObjects/PageObject_GettingStarted.js');
var AboutYourEmployeePage = require('./../../PageObjects/PageObject_AboutYouPage.js');
var AboutAbsencePage = require('./../../PageObjects/PageObject_AboutYourAbsence.js');
var ReviewPage = require('./../../PageObjects/PageObject_ER_ReviewPage.js');
var AddlInfoPage = require('./../../PageObjects/PageObject_Additional_InformationPage.js');


describe ('New_CLI: About your Employee Page Validations', function(){

    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;
/*
    it('New CLI_About You Page: Header and Label Name Validations', function() {

        ResuableFunction.MLC_Login();
        ResuableFunction.EmployerCLI();
        Getting_StartedPage.clickStart("Employer");
        AboutYourEmployeePage.Validate_AboutYouPageHeader("Employer");
        AboutYourEmployeePage.Validate_AboutYouPage_LabelName("Employer");
        //AboutYourEmployeePage.Validate_ButtonText_Color("Employer");

    },300000000);


    it('New CLI_About You Page: Placeholder Text Validation', function() {

        AboutYourEmployeePage.Validate_PlaceHolderText();

    },300000000);

    it('New CLI_About You Page: Error Message Validation when Mandatory Values are not entered', function() {

        AboutYourEmployeePage.Validate_ErrorMessage_MandatoryFields_NotEntered("Employer");

    },300000000);

    it('New CLI_About You Page: Prepop Validation', function() {
        //AboutYourEmployeePage.Validate_Prepop_Valid_EmpID_LastName('23259','vega');
        //AboutYourEmployeePage.Validate_Prepop_Valid_SSN_LastName('840101955','MOHAMMAD');
        //AboutYourEmployeePage.Validate_Prepop_Valid_SSN_InvalidLastName('840101955','Test');

    });

*/
    it('New CLI_Employer:  Story 9581 - Clicking out of the CLI interview does not display pop-up message that you will lose your progress', function() {


        ResuableFunction.MLC_Login();
        ResuableFunction.EmployerCLI();
        Getting_StartedPage.clickStart("Employer");

        AboutYourEmployeePage.ERheaderlink('Home');
        AboutYourEmployeePage.popupvalidation();
        AboutYourEmployeePage.ERheaderlink('Service Team');
        AboutYourEmployeePage.popupvalidation();
        AboutYourEmployeePage.ERheaderlink('Learning Center');
        AboutYourEmployeePage.popupvalidation();
        AboutYourEmployeePage.ERheaderlink('Employee Home');
        AboutYourEmployeePage.popupvalidation();


    },300000000);
/*
    it('New CLI_About You Page:  Verify when page is refreshed, Getting started page is displayed with no values retained', function() {


        AboutYourEmployeePage.EnterEmployeeID('23259');
        AboutYourEmployeePage.EnterFirstName('Test');
        AboutYourEmployeePage.EnterLastName('Test');
        AboutYourEmployeePage.Display_GettingStartedPage_OnRefresh("Employer");

    },300000000);

    it('New CLI_About You Page:  Validate Date of Birth fields if Invalid values are entered', function() {

        var Dateofbirth_value =  AboutYourEmployeePage.EnterDateofBirth('01011987');
        expect(Dateofbirth_value).toEqual('01/01/1987');

        Dateofbirth_value =   AboutYourEmployeePage.EnterDateofBirth('/-');
        expect(Dateofbirth_value).toEqual('');

        Dateofbirth_value =  AboutYourEmployeePage.EnterDateofBirth('mmddyyyy');
        expect(Dateofbirth_value).toEqual('');


    });

    it('New CLI_About You Page:  Verify About Your Absence Page is displayed when Mandatory values are entered', function() {


        AboutYourEmployeePage.EnterEmployeeID('23259');
        AboutYourEmployeePage.EnterFirstName('Test');
        AboutYourEmployeePage.EnterLastName('Test');
        AboutYourEmployeePage.SelectGender('Female');
        AboutYourEmployeePage.EnterResdentialAddress1('123 Test');
        AboutYourEmployeePage.EnterResdentialcity('Dover');
        AboutYourEmployeePage.EnterPostalCode('23345');
        AboutYourEmployeePage.SelectState('AK');
        AboutYourEmployeePage.EnterPersonalEmail('TESTEMAIL@EMAIL.COM');
        AboutYourEmployeePage.EnterPersonalPhone('1231231234');
        AboutYourEmployeePage.SelectEmploymentState('AK');
        AboutYourEmployeePage.ClickContinue_ViewAboutYourAbsence();


    });


    it('New CLI_About You Page:  Verify Date of Birth is "01/01/1900" in Review Page when no value is passed in About You Page', function() {

        AboutAbsencePage.SelectLeaveorClaimCategory('Yes');
        AboutAbsencePage.SelectLeaveorClaimtype('Maternity');
        AboutAbsencePage.SelectDeliveryType('Vaginal');
        AboutAbsencePage.EnterDateQuestion_1('11/01/2017');
        AboutAbsencePage.EnterDateQuestion_2('11/01/2017');
        AboutAbsencePage.ClickContinue_ViewAdditionalInformation();
        AddlInfoPage.EnternoValues_ClickContinue_ViewReviewPage();
        ReviewPage.VerifyDateofBirth();
    });


*/
});
