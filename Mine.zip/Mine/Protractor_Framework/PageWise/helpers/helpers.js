
var TestData = require('./../../TestData/AboutYourEmployee.js');

var helpers = function() {

    var logo_text = '/html/body/sd-app/mlc-header/header/div/div[1]/div[1]/div/p';


    this.MLC_Login = function(){

        browser.ignoreSynchronization = true;
        browser.waitForAngularEnabled(false);
        browser.manage().deleteAllCookies();

        browser.get('https://www-test.mylibertyconnection.com/public/index.html');
        browser.sleep(10000);
        element(by.id('username')).sendKeys(TestData.username);
        element(by.id('password')).sendKeys(TestData.password);
        element(by.buttonText('Login')).click();
        browser.sleep(20000);

    };

    this.SelectCustomer = function(value1){

        var customer;

        switch(value1){
            case "Catholic Health":
                customer = element(by.xpath('/html/body/div/div[3]/div/div/div/div/div[2]/div/ul/li[57]/a'));
                browser.executeScript("arguments[0].scrollIntoView()",customer.getWebElement());
                customer.click();
                browser.sleep(10000);
                break;
            case "Baird":
                customer = element(by.xpath('/html/body/div/div[3]/div/div/div/div/div[2]/div/ul/li[31]/a'));
                browser.executeScript("arguments[0].scrollIntoView()",customer.getWebElement());
                customer.click();
                browser.sleep(10000);
                break;
            case "Commercial Metal - Group Benefit":
                customer = element(by.xpath('/html/body/div/div[3]/div/div/div/div/div[2]/div/ul/li[73]/a'));
                browser.executeScript("arguments[0].scrollIntoView()",customer.getWebElement());
                customer.click();
                browser.sleep(10000);
                break;
            case "Tetra Pak":
                customer = element(by.xpath('/html/body/div/div[3]/div/div/div/div/div[2]/div/ul/li[354]/a'));
                browser.executeScript("arguments[0].scrollIntoView()",customer.getWebElement());
                customer.click();
                browser.sleep(10000);
                break;
            case "Healthways Inc":
                customer = element(by.xpath('/html/body/div/div[3]/div/div/div/div/div[2]/div/ul/li[167]/a'));
                browser.executeScript("arguments[0].scrollIntoView()",customer.getWebElement());
                customer.click();
                browser.sleep(10000);
                break;

            case "Brown Shoe":
                customer = element(by.xpath('/html/body/div/div[3]/div/div/div/div/div[2]/div/ul/li[49]/a'));
                browser.executeScript("arguments[0].scrollIntoView()",customer.getWebElement());
                customer.click();
                browser.sleep(10000);
                break;

            case "2012 Disc Customer":
                customer = element(by.xpath(' /html/body/div/div[3]/div/div/div/div/div[2]/div/ul/li[1]/a'));
                browser.executeScript("arguments[0].scrollIntoView()",customer.getWebElement());
                customer.click();
                browser.sleep(10000);
                break;



        }

    };

    this.EmployerCLI = function(){

        var CLIbutton = element(by.buttonText("Report an Employee's New Claim or Leave"));
        browser.executeScript("arguments[0].scrollIntoView()",CLIbutton.getWebElement());
        browser.sleep(500);
        CLIbutton.click();
        browser.sleep(20000);
    };

    this.EmployerCLI_Claimonly = function(){

        var CLIbutton = element(by.buttonText("Report an Employee's New Claim"));
        browser.executeScript("arguments[0].scrollIntoView()",CLIbutton.getWebElement());
        browser.sleep(500);
        CLIbutton.click();
        browser.sleep(20000);
    };

    this.Click_CLI_Leaveonly = function(){
        var CLIButton = element.all(by.className('btn btn-primary'));
        browser.executeScript("arguments[0].scrollIntoView()",CLIButton.get(0).getWebElement());
        browser.sleep(500);
        CLIButton.get(0).click();
        browser.sleep(20000);
    };

    this.Click_CLI_Leaveonly_EE = function(){
        var CLIButton = element.all(by.className('btn btnhome'));
        browser.executeScript("arguments[0].scrollIntoView()",CLIButton.get(0).getWebElement());
        browser.sleep(500);
        CLIButton.get(0).click();
        browser.sleep(20000);
    };


    this.EmployeeCLI_Claimonly = function(){

        var CLIbutton = element.all(by.className('btn btnhome'));
        browser.executeScript("arguments[0].scrollIntoView()",CLIbutton.get(0).getWebElement());
        browser.sleep(500);
        CLIbutton.get(0).click();
        browser.sleep(20000);
    };

    this.SelectUSAA = function(){


        browser.get('https://secure-test.mylibertyconnection.com/sites/customers/SSOTest/SSOSAMLCustomClientSimulator.aspx');
        browser.sleep(10000);
        element(by.id('rdoButtonListCustomer_1')).click();
        browser.sleep(1000);

    };

    this.EnterEmployeeID_USAA = function(value1){

        var txtemployeeID = element(by.id('txtEmployeeId'));
        browser.executeScript("arguments[0].scrollIntoView()",txtemployeeID.getWebElement());
        txtemployeeID.clear();
        txtemployeeID.sendKeys(value1);
        browser.sleep(5000);
    };

    this.EnterEmployeeIDUnique_USAA = function(value1){

        var txtemployeeID = element(by.id('txtEmployeeIdUnique'));
        browser.executeScript("arguments[0].scrollIntoView()",txtemployeeID.getWebElement());
        txtemployeeID.clear();
        txtemployeeID.sendKeys(value1);
        browser.sleep(5000);
    };

    this.ClickSubmit_USAA = function(){

        var submit = element(by.id('btnSubmit'));
        browser.executeScript("arguments[0].scrollIntoView()",submit.getWebElement());
        submit.click();
        browser.sleep(20000);
    };

    this.SelectCLI = function(value1){

        if (value1 =="Employer") {
            browser.get('https://tst-benefits.mylibertyconnection.com/cli/employer?lang=EN');
            browser.sleep(20000);
        }
        else
        {
            browser.get('https://tst-benefits.mylibertyconnection.com/cli/employee?lang=EN');
            browser.sleep(20000);
        }


    };


    this.EmployeeCLI = function(){

        var CLIbutton = element.all(by.className('btn btnhome')).get(0);
        var CLIbuttontext = CLIbutton.getText();
        browser.executeScript("arguments[0].scrollIntoView()",CLIbutton.getWebElement());
        browser.sleep(500);
        CLIbutton.click();
        browser.sleep(20000);
        return CLIbuttontext;

    };
    this.EmployeefromEmployerLogin = function(){

        var employeehome = element(by.xpath('//*[@id="navbarNavDropdown"]/ul[5]/li/a'));

        browser.executeScript("arguments[0].scrollIntoView()",employeehome.getWebElement());
        employeehome.click();
        browser.sleep(10000);

    };

    this.Spanish_Link = function(){

        var spanishlink = element(by.className('link'))
        spanishlink.click();
        browser.sleep(25000);

    };


    this.Employee_PageHeader  = function(){

        var navlink = element.all(by.className('nav-link'));
        expect(navlink.get(0).getText()).toEqual('Home');
        expect(navlink.get(1).getText()).toEqual('Forms');
        expect(navlink.get(2).getText()).toEqual('Learn More');


    };

    this.Employee_PageHeader_Spanish  = function(){

        var navlink = element.all(by.className('nav-link'));
        expect(navlink.get(0).getText()).toEqual('Inicio');
        expect(navlink.get(1).getText()).toEqual('Formularios');
        expect(navlink.get(2).getText()).toEqual('Más Información');


    };

    this.Employee_PageLinks = function(){

        var pagelinks = element.all(by.className('link linkSeparator'));
        expect(pagelinks.get(0).getText()).toEqual('Profile');
        expect(pagelinks.get(1).getText()).toEqual('Logout');

    };

    this.Employee_PageLinks_Spanish = function(){

        var pagelinks = element.all(by.className('link linkSeparator'));
        expect(pagelinks.get(0).getText()).toEqual('Perfil');
        expect(pagelinks.get(1).getText()).toEqual('Salir');

    };

    this.Change_to_Spanish = function(){

        element.all(by.className('link')).get(0).click();

    };

    this.Employee_LogoText = function(){

        var logoText = element(by.xpath(logo_text)).getText();

        expect(logoText.getText()).toContain('MyLibertyConnection®' );

    };

    this.TodayDate = function() {
        var timestamp;

        var today = new Date();
        var tdate = today.getDate();
        var thours = today.getHours();
        var tminutes = today.getMinutes();
        var tsec = today.getSeconds();
        var month = today.getMonth() + 1;
        if (month <10)
        {
            month = "0" +  month;

        }
        if (today.getDate() < 10)
        {
            tdate = "0" + tdate;
        }

        if (thours < 10 )
        {
            thours = "0" + thours;
        }
        if (tminutes < 10)
        {
            tminutes = "0" + tminutes;
        }

        timestamp =  month + "/" + tdate + "/"  + today.getFullYear();

        return timestamp;
    };


    //Function to take screenshot
    var fs = require('fs');
    this.writeScreenshot = function (data, filename) {
        var stream = fs.createWriteStream(filename);
        stream.write(new Buffer(data, 'base64'));
        stream.end();
    }

};

module.exports = new helpers();