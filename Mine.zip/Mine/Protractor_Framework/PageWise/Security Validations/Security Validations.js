
var Getting_StartedPage = require('./../PageObject_GettingStarted.js');
var ResuableFunction = require('./..//helpers/helpers.js');
var AboutYourEmployeePage = require('./../PageObject_AboutYouPage.js');

describe ('New_CLI: CLI Authentication', function(){

    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;

    beforeEach(function() {
        ResuableFunction.MLC_Login();
    },300000000);

   it('New CLI_Getting Started Header validations for Leave and Claim only customer', function() {


        ResuableFunction.SelectCustomer("Catholic Health");
        ResuableFunction.SelectCLI("Employer");
        Getting_StartedPage.VerifyCLIPermission("Catholic Health");

    },300000000);

    it('New CLI_Getting Started Header validations for Leave only customer', function() {


        ResuableFunction.SelectCustomer("Brown Shoe");
        ResuableFunction.SelectCLI("Employer");
        Getting_StartedPage.VerifyCLIPermission("Brown Shoe");

    },300000000);

    it('New CLI_Getting Started Header validations for Claim only customer', function() {


        ResuableFunction.SelectCustomer("2012 Disc Customer");
        ResuableFunction.SelectCLI("Employer");
        Getting_StartedPage.VerifyCLIPermission("2012 Disc Customer");

    },300000000);

    it('New CLI_Getting Started Header validations for Not Authorized Customer', function() {


        ResuableFunction.SelectCustomer("Commercial Metal - Group Benefit");
        ResuableFunction.SelectCLI("Employer");
        Getting_StartedPage.VerifyCLIPermission("Commercial Metal - Group Benefit");

    },300000000);

    it('New CLI_Getting Started Header validations for Not Authorized Customer', function() {


        ResuableFunction.SelectCustomer("Baird");
        ResuableFunction.SelectCLI("Employer");
        Getting_StartedPage.VerifyCLIPermission("Baird");

    },300000000);

    it('New CLI_About You Page: SSO Assertion', function() {

        ResuableFunction.SelectUSAA();
        ResuableFunction.EnterEmployeeID_USAA('65627');
        ResuableFunction.EnterEmployeeIDUnique_USAA('65627');
        ResuableFunction.ClickSubmit_USAA();
        ResuableFunction.SelectCustomer("Catholic Health");
        ResuableFunction.EmployerCLI();
        Getting_StartedPage.clickStart("Employer");
        AboutYourEmployeePage.VerifyEmployeeID("Employer","");

        ResuableFunction.EmployeefromEmployerLogin();
        ResuableFunction.EmployeeCLI();
        Getting_StartedPage.clickStart("Employee-English");
        AboutYourEmployeePage.VerifyEmployeeID("Employee","65627");




    },300000000);






});
