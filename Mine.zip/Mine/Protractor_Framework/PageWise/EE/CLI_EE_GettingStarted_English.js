/**
 * Created by n0275896 on 7/3/2017.
 */

var ResuableFunction = require('./..//helpers/helpers.js');
var Getting_StartedPage = require('./../../PageObjects/PageObject_GettingStarted.js');
var AboutYouPage = require('./../../PageObjects/PageObject_AboutYouPage.js');

describe ('New CLI_Getting Started Page Validation', function() {

    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;

    it('New_CLI:Getting Started Page : Circle color and Progress bar header validations', function () {

        ResuableFunction.MLC_Login();
        ResuableFunction.EmployeeCLI();
        ResuableFunction.Employee_PageHeader();
        ResuableFunction.Employee_PageLinks();
        ResuableFunction.Employee_LogoText();
        Getting_StartedPage.VerifyGettingStartedCircleColor();
        Getting_StartedPage.VerifyProgressBarHeader("Employee- English");
        Getting_StartedPage.VerifyTransparentCircle("Employee-English", 2);

    }, 300000000);

    it('New_CLI:Getting Started Page : Header and static content validations', function() {

        Getting_StartedPage.VerifyCLIHeader();
        Getting_StartedPage.VerifyPageHeader("Employee- English");
        Getting_StartedPage.VerifyGettingStarted_StaticContent("Employee- English");

    });

    it('New_CLI:Getting Started Page : GetHelp Pop up validations', function() {

        Getting_StartedPage.VerifyGetHelp_Popup();

    });

    it('New_CLI:Getting Started Page : Start button Presence and when clicked navigates to About You page', function() {


        Getting_StartedPage.VerifyStartButtonText_Color("Employee-English");
        Getting_StartedPage.clickStart("Employee-English");

    },300000000);


    it('New_CLI:Getting Started Page : Open Your Saved Application is displayed when application is Saved', function() {

        AboutYouPage.EnterEmployeeID('12345');
        AboutYouPage.EnterFirstName('Test');
        AboutYouPage.EnterLastName('Test');
        AboutYouPage.ClickSaveforLater();
        Getting_StartedPage.VerifyOpenSavedApplication();


    },300000000);

});