

var POEER = require('./../PageObject_EEReviewPage.js');
var POAYA = require('./../PageObject_AboutYourAbsence.js');
var POAYP = require('./../PageObject_AboutYouPage.js');
var POAYC = require('./../PageObject_ContactsPage.js');
var PORPER = require('./../PageObject_ER_ReviewPage.js');
var POCommonFunctions = require('./../PageObject_Functions.js');
var Getting_StartedPage = require('./../../PageObjects/PageObject_GettingStarted.js');
var ResuableFunction = require('./..//helpers/helpers.js');

//Take Screenshots
var fs = require('fs');
function writeScreenShot(data, filename) {
    var stream = fs.createWriteStream(filename);
    stream.write(new Buffer(data, 'base64'));
    stream.end();
}

describe ('Open URL in browser and validate EE Review Page', function() {

//Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;

    //Variables Declaration

    var lblempid = POEER.lblemployeeid.input;
    var lblfirstname = POEER.lblfirstname.input;
    var lblmiddle = POEER.lblmiddle.input;
    var lbllastname = POEER.lbllastname.input;
    var lblgender = POEER.lblgender1.input;
    var lbldob = POEER.lbldob.input;
    var lblpphone = POEER.lblpphone.input;
    var lblpemail = POEER.lblpemail.input;
    var lblpmethod = POEER.lblprefmethod.input;
    var lblres1 = POEER.lblresaddress1.input;
    var lblres2 = POEER.lblresaddress2.input;
    var lblrescity = POEER.lblrescity.input;
    var lblcountry = POEER.lblcountry.input;
    var lblpostalcode = POEER.lblpostalcode.input;
    var lblcountryofemploy = POEER.lblcounofemploy.input;
    var lblstateemploy = POEER.lblstateofemploy.input;
    var lblresstate = POEER.lblstate.input;

    var txtempid = POEER.txtemployeeid.input;
    var txtfirstname = POEER.txtfirstname.input;
    var txtmiddlename = POEER.txtmiddle.input;
    var txtlastname = POEER.txtlastname.input;
    var txtgender = POEER.txtgender1.input;
    var txtdob = POEER.txtdob.input;
    var txtpphone = POEER.txtpphone.input;
    var txtpemail = POEER.txtpemail.input;
    var txtpmethod = POEER.txtprefmethod.input;
    var txtresaddr1 = POEER.txtresaddress1.input;
    var txtresaddr2 = POEER.txtresaddress2.input;
    var txtrescity = POEER.txtrescity.input;
    var txtcountry = POEER.txtcountry.input;
    var txtpostalcode = POEER.txtpostalcode.input;
    var txtecountry = POEER.txtcounofemploy.input;
    var txtfax1 = POEER.txtfax.input;
    var txtsemploy = POEER.txtstateofemploy.input;
    var txtstate = POEER.txtstate.input;

    var dob1 = POAYP.dobtbox1.input;
    var pphone1 = POAYP.ppphonetbox1.input;


    var empid = POAYP.empidtbox.input;
    var ssntext = POAYP.txtssn.input;
    var firstname = POAYP.fnametbox.input;
    var lastname = POAYP.lnametbox.input;
    var dob = POAYP.dobtbox.input;
    var preferedphone = POAYP.ppphonetbox.input;
    var prefmail = POAYP.ppemailtbox.input;
    var resaddr1 = POAYP.resaddrtbox1.input;
    var rescity = POAYP.rescitytbox.input;
    var statelist = POAYP.resstatelist.input;
    var postalcode = POAYP.postalcdetbox.input;
    var stateemploy = POAYP.stateofemploylist.input;
    var middlename = POAYP.mnametbox.input;
    var resaddr2 = POAYP.resaddrtbox2.input;
    var txtfax1 = POAYP.txtfax.input;
    var illness = POAYA.illness.input;

    var leaveclaimlist = POAYA.leavetypelist.input;
    var circumstance = POAYA.circumstance.input;
    var delivery = POAYA.delivered.input;
    var deliverydate = POAYA.deliverydate.input;
    var lastworkingdate = POAYA.lastdate.input;
    var medicalcontactpage = POAYA.medicalcontactspage.input;
    var medicalheader = POAYA.medicalheader.input;
    var lblhavedelivered = POAYA.lbldelivered.input;

    var physicianfnametbox = POAYC.physicianfnametbox.input;
    var physicianlnametbox = POAYC.physicianlnametbox.input;
    var physicianpnumtbox = POAYC.physicianpnumtbox.input;
    var physicianhnametbox = POAYC.physicianhnametbox.input;
    var physicianhpnumtbox = POAYC.physicianhpnumtbox.input;

    var lblphyfirstname = POEER.lblphyfirstname.input;
    var lblhosphyname = POEER.lblhosphyfirstname.input;
    var lblphylastname = POEER.lblphylastname.input;
    var lblhosphyphone = POEER.lblhosphyphonenumber.input;
    var lblphyphone = POEER.lblphyphonenumber.input;

    var txtphyfirstname = POEER.txtphyfirstname.input;
    var txthosphyname = POEER.txthosphyfirstname.input;
    var txtphylastname = POEER.txtphylastname.input;
    var txthosphyphone = POEER.txthosphyphonenumber.input;
    var txtphyphone = POEER.txtphyphonenumber.input;
    var txtfax = POEER.txtfax.input;

    var surdecreqmsg = POAYA.surdecreqmsg.input;
    var surdesques = POAYA.surdesques.input;
    var fraudstmntheader = POEER.fraudstmntheader.input;
    var flfraudstmt = 'Any person who includes any false or misleading information on an application for an insurance policy is subject to criminal and civil penalties.'

    var lblcontinuous1  = POEER.lblcontinuous.input;
    var lblcircumstances = POEER.lblcircumstances.input;
    var lbldesccircumstances = POEER.lbldesccircumstances.input;
    var lblillnessreview = POEER.lblillnessreview.input;
    var lbllastdayreview = POEER.lbllastdayreview.input;
    var lblresultreview= POEER.lblresultreview.input;
    var lblmvaccident= POEER.lblmvaccident.input;
    var lblonjob= POEER.lblonjob.input;
    var lbltohospital= POEER.lbltohospital.input;
    var lbldatehospital= POEER.lbldatehospital.input;
    var lblsurgeryreview= POEER.lblsurgeryreview.input;
    var lbldescreview= POEER.lbldescreview.input;
    var lblcomplicationsreview= POEER.lblcomplicationsreview.input;


    var txtcontinuous1  = POEER.txtcontinuous.input;
    var txtcircumstances = POEER.txtcircumstances.input;
    var txtdesccircumstances = POEER.txtdesccircumstances.input;
    var txtillnessreview = POEER.txtillnessreview.input;
    var txtlastdayreview = POEER.txtlastdayreview.input;
    var txtresultreview= POEER.txtresultreview.input;
    var txtmvaccident= POEER.txtmvaccident.input;
    var txtonjob= POEER.txtonjob.input;
    var txttohospital= POEER.txttohospital.input;
    var txtdatehospital= POEER.txtdatehospital.input;
    var txtsurgeryreview= POEER.txtsurgeryreview.input;
    var txtdescreview= POEER.txtdescreview.input;
    var txtcomplicationsreview= POEER.txtcomplicationsreview.input;
    var txthospital = POAYA.txthospital.input;
    var txtsurgery1 = POAYA.txtsurgery1.input;
    var txtillness = POAYA.txtillness.input;
    var txtlastday = POAYA.txtlastday.input;
    var txtaddlninfeng = 'Please review the information below for accuracy before submitting your absence. To make any changes, select “Edit” to return to the appropriate section';


    /******************** Beginning of Test Case I - Verify Review page Links and Sections ******************************/

    it('New CLI_Review Page Link and Sections for EE', function () {

        browser.ignoreSynchronization = true;
        browser.waitForAngularEnabled(false);
        POCommonFunctions.employeeurl();
        POCommonFunctions.employeelogin();
        POCommonFunctions.callCLIemployee();
        POCommonFunctions.enteraboutyouremppagefemale();
        POCommonFunctions.enterDetailsofabsencepage();
        element(by.buttonText('Continue')).click();
        element(by.buttonText('Continue')).click();

        //Identifying the current Date and Time

        var timestamp;
        var today = new Date();
        var month = today.getMonth() + 1;
        timestamp = today.getDate() + "_" + month + "_" + today.getFullYear() + "_" + today.getHours() + "_" + today.getMinutes() + "_" + today.getSeconds();
        var screenshot;
        screenshot = "./Screenshots/EE/ReviewPage/English/";


        //Validate Review Page header label
        var reviewheader = POEER.reviewheader.input.getText();
        expect(reviewheader).toEqual('Review');

        //Validate the Instructional dynamic text
        var instext = POEER.instext.input.getText();
        expect(instext).toContain('with Instructional text (Text are still TBD)');

        browser.executeScript('window.scrollTo(40,200);');

        //Get Help - Label
        var gethelplabel = PORPER.gethlplabel.input.getText();
        expect(gethelplabel).toEqual('Get Help');

        //Verify GetHelp pop up is displayed
        PORPER.gethlplabel.input.click();
        expect(PORPER.popuphelp.input.isDisplayed()).toBe(true);

       // var helppopup = element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/review/div[1]/div[2]/div/get-help/a'));
       // helppopup.click();
       // expect(PORPER.popuphelp.input.isDisplayed()).toBe(true);
        browser.sleep(1000);

        element(by.buttonText('Close')).click();

        //Validate the About You label
        var abtyoulbl = POEER.abtyoulbl.input.getText();
        expect(abtyoulbl).toEqual('About You');

        //Validate the About Your Absence label
        var abtyouabsencelbl = POEER.abtyouabsencelbl.input.getText();
        expect(abtyouabsencelbl).toEqual('About Your Absence');

        //Verify accordion for About Your Absence is not expanded
        expect(POEER.abtyouacct.input.isPresent()).toBeFalsy();

        //Validate the Medical Contacts label
        var medicalconlbl = POEER.medicalconlbl.input.getText();
        expect(medicalconlbl).toEqual('Medical Contacts');

        //Verify accordion for Medical Contacts is not expanded
        expect(POEER.medcont.input.isPresent()).toBeFalsy();




        //Click the About You Edit label
       var abtyoueditlnk = POEER.abtyoueditlnk.input.getText();
        expect(abtyoueditlnk).toEqual('Edit');


        //Verify About You page is displayed when About You Edit link is clicked
        abtyoueditlnk.click();
       /* expect(POEER.abtyouhdr.input.isDisplayed()).toBe(true);
        expect(POEER.abtyouhdr.input.getText()).toEqual('Retrieve Your Information');
        browser.sleep(1000);

        browser.executeScript('window.scrollTo(600,1600);');
        browser.sleep(1000);
        POAYP.continuebutton.input.click();


        browser.sleep(1000);
        element(by.buttonText('Continue')).click();
        browser.sleep(1000);
        browser.executeScript('window.scrollTo(3300,2600);');
        browser.sleep(1000);
        element(by.buttonText('Continue')).click();
        browser.executeScript('window.scrollTo(80,400);');
        browser.sleep(1000);




        //Click the About Your Absence Edit label
        var abtyouabseditlnk = POEER.abtyouabseditlnk.input.getText();
        expect(abtyouabseditlnk).toEqual('Edit');

        //Verify About Your Absence page is displayed when About Your Absence Edit link is clicked
        abtyouabseditlnk.click();
        expect(POEER.abtyourabshdr.input.isDisplayed()).toBe(true);
        expect(POEER.abtyourabshdr.input.getText()).toEqual('About Absence');
        browser.sleep(1000);

        browser.sleep(1000);
        browser.executeScript('window.scrollTo(3300,2600);');
        element(by.buttonText('Continue')).click();
        browser.sleep(1000);
        browser.executeScript('window.scrollTo(600,2600);');
        browser.sleep(1000);
        element(by.buttonText('Continue')).click();
        browser.executeScript('window.scrollTo(80,400);');
        browser.sleep(1000);
;

        //Click the Medical Contacts Edit label
        var medconeditlnk = POEER.medconeditlnk.input.getText();
        expect(medconeditlnk).toEqual('Edit');

        //Verify Medical Contacts page is displayed when Medical Contacts Edit link is clicked
        medconeditlnk.click();
        expect(POEER.medconhdr.input.isDisplayed()).toBe(true);
        expect(POEER.medconhdr.input.getText()).toEqual('Medical Contacts');


        browser.sleep(1000);
        element(by.buttonText('Continue')).click();
        browser.executeScript('window.scrollTo(80,400);');
        browser.sleep(1000);*/



        //Validate the Submit button is displayed
        var submitbutton = POEER.submitbutton.input.getText();
        expect(submitbutton).toEqual('Submit');

        //Validate the go Back button is displayed
        var gobackbtn = POEER.gobackbtn.input.getText();
        expect(gobackbtn).toEqual('Go Back');




        //Verify the accordian format when "About your Employee Absence section is clicked
        browser.executeScript('window.scrollTo(80,400);');
        abtyouabsencelbl.click();
        expect(POEER.abtyouaccf.input.isPresent()).toBeTruthy();
        expect(POEER.medconaccf.input.isPresent()).toBeTruthy();
        expect(POEER.abtyourabsacct.input.isPresent()).toBeTruthy();
        browser.sleep(200);



        //Verify the accordion format when Medical Information section is clicked
        browser.executeScript('window.scrollTo(400,600);');
        medicalconlbl.click();
        expect(POEER.abtyouacct.input.isPresent()).toBeFalsy();
        expect(POEER.medcont.input.isPresent()).toBeTruthy();
        expect(POEER.abtyourabsacct.input.isPresent()).toBeFalsy();
        browser.sleep(100);



        browser.sleep(100);
        browser.executeScript('window.scrollTo(80,400);');

        abtyoulbl.click();
        //Verify the accordian format when About You section
        expect(POEER.abtyouacct.input.isPresent()).toBeTruthy();
        expect(POEER.abtyourabsacct.input.isPresent()).toBeFalsy();
        expect(POEER.medcont.input.isPresent()).toBeFalsy();
        browser.sleep(100);


    },300000000);

    //Test Case 2 Verify label validations for About you page

    it('New CLI_Review Page : Verify Label Validations when Employee ID is selected ', function () {

        browser.executeScript('window.scrollTo(40,200);');

        expect(lblempid.getText()).toEqual('Employee ID');
        expect(lblfirstname.getText()).toEqual('First Name');
        expect(lblmiddle.getText()).toEqual('Middle Initial');
        expect(lbllastname.getText()).toEqual('Last Name');
        expect(lblgender.getText()).toEqual('Gender');
        expect(lbldob.getText()).toEqual('Date of Birth');
        expect(lblpphone.getText()).toEqual('Preferred Personal Phone');
        expect(lblpemail.getText()).toEqual('Preferred Personal Email');
        expect(lblpmethod.getText()).toEqual('Preferred method for non-confidential correspondence');
        expect(lblres1.getText()).toEqual('Residential Address 1');
        expect(lblres2.getText()).toEqual('Residential Address 2');
        expect(lblrescity.getText()).toEqual('Residential City');
        expect(lblcountry.getText()).toEqual('Country');
        expect(lblpostalcode.getText()).toEqual('Postal Code');
        expect(lblcountryofemploy.getText()).toEqual('Country of Employment');


    });

    //Validate Bug - 7520

    it('New CLI_Review Page : Residential State or Employment State fields', function () {



        expect(lblstateemploy.getText()).toEqual('State of Employment');
        expect(lblresstate.getText()).toEqual('Residential State');

        browser.sleep(100);


    });

    it('New CLI_Review Page  - About Your absence section validations for MOC flow ', function() {

        var aboutyourabsencesection = PORPER.aboutyourabsencesection.input.getText();
        browser.executeScript('window.scrollTo(200,500);');
        browser.sleep(20000);
        aboutyourabsencesection.click();

        expect(lblcontinuous1.getText()).toEqual('Will you be out for at least 3 consecutive days?');
        expect(lblcircumstances.getText()).toEqual('What best describes the circumstances for your absence?');
        expect(lbldesccircumstances.getText()).toEqual('Please select the condition that best describes your circumstances?');
        expect(lblillnessreview .getText()).toEqual('When did this illness begin?');
        expect(lbllastdayreview .getText()).toEqual('What was the last day worked or expected last day worked?');
        expect(lblresultreview.getText()).toEqual('Was this the result of an accident?');
        expect(lblmvaccident.getText()).toEqual('Were you in a motor vehicle accident?');
        expect(lblonjob.getText()).toEqual('Did this occur while on the job?');
        expect(lbltohospital.getText()).toEqual('Did you, or will you be, going to the hospital?');
        expect(lbldatehospital.getText()).toEqual('What date did you, or will you, go to the hospital?');
        expect(lblsurgeryreview.getText()).toEqual('Did you, or will you, have surgery?');
        expect(lbldescreview.getText()).toEqual("What was, or is, the date of your surgery?");
        expect(lblcomplicationsreview.getText()).toEqual("Please provide your diagnosis or a description of your condition or symptoms.");

        expect(txtcontinuous1.getText()).toEqual('Yes');
        expect(txtcircumstances.getText()).toEqual('My own illness, injury, or medical treatment');
        expect(txtdesccircumstances.getText()).toEqual('Illness or related medical treatment');
        expect(txtillnessreview .getText()).toEqual('10/09/2017');
        expect(txtlastdayreview .getText()).toEqual('10/06/2017');
        expect(txtresultreview.getText()).toEqual('Yes');
        expect(txtmvaccident.getText()).toEqual('Yes');
        expect(txtonjob.getText()).toEqual('Yes');
        expect(txttohospital.getText()).toEqual('Yes');
        expect(txtdatehospital.getText()).toEqual('');
        expect(txtsurgeryreview.getText()).toEqual('Yes');
        expect(txtdescreview.getText()).toEqual("");
        expect(txtcomplicationsreview.getText()).toEqual("test");



    });

    it('New CLI_Review Page  - About Your absence section validations for Materity flow ', function() {

        browser.executeScript('window.scrollTo(550,1600);');
        element(by.buttonText('Go Back')).click();

        browser.sleep(1000);
        element(by.buttonText('Go Back')).click();

        browser.executeScript('window.scrollTo(40,100);');
        browser.sleep(10000);
        var leaveclaimlist = POAYA.leavetypelist1.input;
        POAYA.consecutivedaysradiobtnn.input.click();
        POAYA.consecutivedaysradiobtny.input.click();

        leaveclaimlist.$('[value = "MAT"]').click();
        browser.sleep(10000);
        var delivery = POAYA.delivered.input;
        delivery.$('[value = "Yes, C-Section"]').click();
        txtillness.sendKeys('02/02/2017',protractor.Key.TAB);
        txtlastday.sendKeys('02/02/2017',protractor.Key.TAB);
        txthospital.sendKeys('02/02/2017',protractor.Key.TAB);
        txtsurgery1.sendKeys('02/02/2017',protractor.Key.TAB);
        element(by.buttonText('Continue')).click();

        element(by.buttonText('Continue')).click();

        var aboutyourabsencesection = PORPER.aboutyourabsencesection.input.getText();
        browser.executeScript('window.scrollTo(200,500);');
        browser.sleep(20000);
        aboutyourabsencesection.click();

        expect(lblcontinuous1.getText()).toEqual('Will you be out for at least 3 consecutive days?');
        expect(lblcircumstances.getText()).toEqual('What best describes the circumstances for your absence?');
        expect(lbldesccircumstances.getText()).toEqual('Have you already delivered?');
        expect(lblillnessreview .getText()).toEqual('What date did you deliver?');
        expect(lbllastdayreview .getText()).toEqual('What was the last day worked or expected last day worked?');
        expect(lblresultreview.getText()).toEqual('What date did you arrive at the hospital?');
        expect(lblmvaccident.getText()).toEqual("What was, or is, your discharge date from the hospital?");
        expect(lblonjob.getText()).toEqual("Please provide details around your related complications, surgeries, injuries, or any additional details related to your absence.");


        expect(txtcontinuous1.getText()).toEqual('Yes');
        expect(txtcircumstances.getText()).toEqual('Maternity');
        expect(txtdesccircumstances.getText()).toEqual('Yes, C-Section');
        expect(txtillnessreview .getText()).toEqual('02/02/2017');
        expect(txtlastdayreview .getText()).toEqual('02/02/2017');
        expect(txtresultreview.getText()).toEqual('02/02/2017');
        expect(txtmvaccident.getText()).toEqual('02/02/2017');
        expect(txtonjob.getText()).toEqual('');
        expect(txttohospital.getText()).toEqual('');
        expect(txtdatehospital.getText()).toEqual('');
        expect(txtcomplicationsreview.getText()).toEqual("");



    });

    it('New CLI_Employee Review Page: Story#6874 - Fraud statement validation in Review page for NJ state', function () {


        expect(fraudstmntheader.getText()).toContain(flfraudstmt);

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/English/Testcase9_ii.png');
        });
    });


    it('New CLI_Review Page  - About Your absence section validations for Other flow', function() {

        browser.executeScript('window.scrollTo(550,1600);');
        element(by.buttonText('Go Back')).click();

        browser.sleep(1000);
        element(by.buttonText('Go Back')).click();

        browser.executeScript('window.scrollTo(40,100);');
        browser.sleep(10000);
        var leaveclaimlist = POAYA.leavetypelist1.input;
        POAYA.consecutivedaysradiobtnn.input.click();
        POAYA.consecutivedaysradiobtny.input.click();

        leaveclaimlist.$('[value = "OTH"]').click();
        browser.sleep(10000);
        var claimantconditionlist = POAYA.claimantconditionlist.input;
        claimantconditionlist.$('[value = "AM"]').click();



        txtillness.sendKeys('02/02/2017',protractor.Key.TAB);
        txtlastday.sendKeys('02/02/2017',protractor.Key.TAB);


        browser.executeScript('window.scrollTo(650,1800);');

        element(by.buttonText('Continue')).click();

        element(by.buttonText('Continue')).click();

        var aboutyourabsencesection = PORPER.aboutyourabsencesection.input.getText();
        browser.executeScript('window.scrollTo(200,500);');
        browser.sleep(20000);
        aboutyourabsencesection.click();

        expect(lblcontinuous1.getText()).toEqual('Will you be out for at least 3 consecutive days?');
        expect(lblcircumstances.getText()).toEqual('What best describes the circumstances for your absence?');
        expect(lbldesccircumstances.getText()).toEqual("What is the reason for your absence?");
        expect(lblillnessreview .getText()).toEqual("What is the first day, or expected first day, of your leave of absence?");
        expect(lbllastdayreview .getText()).toEqual("What is the last day, or estimated last day, of your leave of absence?");


        expect(txtcontinuous1.getText()).toEqual('Yes');
        expect(txtcircumstances.getText()).toEqual('Other leave type, not listed above');
        expect(txtdesccircumstances.getText()).toEqual('Administrative');
        expect(txtillnessreview .getText()).toEqual('02/02/2017');
        expect(txtlastdayreview .getText()).toEqual('02/02/2017');




    });



    it('New CLI_Review Page  - About Your absence section validations for Bond flow ', function() {

        browser.executeScript('window.scrollTo(550,1600);');
        element(by.buttonText('Go Back')).click();
        element(by.buttonText('Go Back')).click();

        browser.executeScript('window.scrollTo(40,100);');
        browser.sleep(10000);
        var leaveclaimlist = POAYA.leavetypelist1.input;


        leaveclaimlist.$('[value="BND"]').click();

        browser.sleep(10000);
        var claimantconditionlist = POAYA.claimantconditionlist.input;
        claimantconditionlist.$('[value="AD"]').click();

        txtillness.sendKeys('02/02/2017',protractor.Key.TAB);
        txtlastday.sendKeys('02/02/2017',protractor.Key.TAB);
        txthospital.sendKeys('02/02/2017',protractor.Key.TAB);
        txtsurgery1.sendKeys('02/02/2017',protractor.Key.TAB);
        element(by.buttonText('Continue')).click();


        var aboutyourabsencesection = PORPER.aboutyourabsencesection.input.getText();
        browser.executeScript('window.scrollTo(200,500);');
        browser.sleep(20000);
        aboutyourabsencesection.click();

        expect(lblcontinuous1.getText()).toEqual('Will you be out for at least 3 consecutive days?');
        expect(lblcircumstances.getText()).toEqual('What best describes the circumstances for your absence?');
        expect(lbldesccircumstances.getText()).toEqual("What is the reason for your absence?");
        expect(lblillnessreview .getText()).toEqual('What is the first day, or expected first day, of your leave of absence?');
        expect(lbllastdayreview .getText()).toEqual("What is the date the child was placed in your care?");
        expect(lblresultreview.getText()).toEqual('What is the date of birth of the person you are bonding with?');
        expect(lblmvaccident.getText()).toEqual("What is the last day, or estimated last day, of your leave of absence?");


        expect(txtcontinuous1.getText()).toEqual('Yes');
        expect(txtcircumstances.getText()).toEqual('Bond with child');
        expect(txtdesccircumstances.getText()).toEqual('Adoption');
        expect(txtillnessreview .getText()).toEqual('02/02/2017');
        expect(txtlastdayreview .getText()).toEqual('02/02/2017');
        expect(txtresultreview.getText()).toEqual('02/02/2017');
        expect(txtmvaccident.getText()).toEqual('02/02/2017');
       /* expect(txtonjob.getText()).toEqual('');
        expect(txttohospital.getText()).toEqual('');
        expect(txtdatehospital.getText()).toEqual('');
        expect(txtcomplicationsreview.getText()).toEqual("");*/



    });



    it('New CLI_Review Page  - About Your absence section validations for Care flow', function() {

        browser.executeScript('window.scrollTo(550,1600);');
        element(by.buttonText('Go Back')).click();

        browser.sleep(1000);


        browser.executeScript('window.scrollTo(40,100);');
        browser.sleep(10000);
        var leaveclaimlist = POAYA.leavetypelist1.input;
        POAYA.consecutivedaysradiobtnn.input.click();
        POAYA.consecutivedaysradiobtny.input.click();

        leaveclaimlist.$('[value = "FMC"]').click();
        browser.sleep(10000);
        var claimantconditionlist = POAYA.claimantconditionlist.input;
        claimantconditionlist.$('[value = "CH"]').click();

        var lstrelationship = POAYA.relationshiplist.input;
        lstrelationship.$('[value = "CP"]').click();

        txtillness.sendKeys('02/02/2017',protractor.Key.TAB);
        txtlastday.sendKeys('02/02/2017',protractor.Key.TAB);
        txthospital.sendKeys('02/02/2017',protractor.Key.TAB);

        browser.executeScript('window.scrollTo(650,1800);');

        element(by.buttonText('Continue')).click();


        var aboutyourabsencesection = PORPER.aboutyourabsencesection.input.getText();
        browser.executeScript('window.scrollTo(200,500);');
        browser.sleep(20000);
        aboutyourabsencesection.click();

        expect(lblcontinuous1.getText()).toEqual('Will you be out for at least 3 consecutive days?');
        expect(lblcircumstances.getText()).toEqual('What best describes the circumstances for your absence?');
        expect(lbldesccircumstances.getText()).toEqual("What is the reason for your absence?");
        expect(lblillnessreview .getText()).toEqual("What is the person’s relationship to you?");
        expect(lbllastdayreview .getText()).toEqual("What is the first day, or expected first day, of your leave of absence?");
        expect(lblresultreview.getText()).toEqual('What is the date of birth of the person you are caring for?');
        expect(lblmvaccident.getText()).toEqual("What is the last day, or estimated last day, of your leave of absence?");

        expect(txtcontinuous1.getText()).toEqual('Yes');
        expect(txtcircumstances.getText()).toEqual('Care for family member (including military)');
        expect(txtdesccircumstances.getText()).toEqual('Child');
        expect(txtillnessreview .getText()).toEqual('Child 18+');
        expect(txtlastdayreview .getText()).toEqual('02/02/2017');
        expect(txtresultreview.getText()).toEqual('02/02/2017');
        expect(txtmvaccident.getText()).toEqual('02/02/2017');
        /*expect(txtonjob.getText()).toEqual('');
        expect(txttohospital.getText()).toEqual('');
        expect(txtdatehospital.getText()).toEqual('');
        expect(txtcomplicationsreview.getText()).toEqual("");*/



    });

    it('NEW CLI - Review Page - Add Instructional Text to the page-7859', function() {

        ResuableFunction.MLC_Login();
        ResuableFunction.EmployeeCLI();

        Getting_StartedPage.clickStart("Employee-English");

        POAYP.EnterEmployeeID('23259');
        POAYP.EnterFirstName('Test');
        POAYP.EnterLastName('Test');
        POAYP.EnterDateofBirth('01/01/1987');
        POAYP.SelectGender('Female');
        POAYP.EnterResdentialAddress1('123 Test');
        POAYP.EnterResdentialcity('Dover');
        POAYP.EnterPostalCode('23345');
        POAYP.SelectState('AK');
        POAYP.EnterPersonalEmail('test@test.com');
        POAYP.EnterPersonalPhone('1231231234');
        POAYP.SelectEmploymentState('AK');
        POAYP.ClickContinue_ViewAboutYourAbsence();

        POAYA.SelectLeaveorClaimCategory('Yes');
        POAYA.SelectLeaveorClaimtype('Maternity');
        POAYA.SelectDeliveryType('Vaginal');
        POAYA.EnterDateQuestion_1('11/01/2017');
        POAYA.EnterDateQuestion_2('11/01/2017');
        POAYA.ClickContinue_ViewMedicalContacts("Employee-English");

        POAYC.EnternoValues_ClickContinue_ViewReviewPage("Employee-English");

        expect(element(by.xpath("//h2[ text()='Review']").getText())).toEqual(txtaddlninfeng);

    },300000000);



    //Test Case  3 when SSN is selected in Aboout you page

   /* it('New CLI_Review Page : Verify Label Validations when SSN is selected ', function () {

        //Open NEW CLI in browser and go to Review Page
        POCommonFunctions.employeeurl();

        //Click About You Page
        element(by.css('[href="/cli/claimant"]')).click();

        POAYP.ssnradio.input.click();

        ssntext.sendKeys('984575674');

        element(by.css('[href="/cli/review"]')).click();

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/English/Testcase2_i.png');
        });

        //Validations for the story 6333

        //Verify the lables displayed are correct

        expect(lblempid.getText()).toEqual('Social Security Number');
        expect(lblfirstname.getText()).toEqual('First Name');
        expect(lblmiddle.getText()).toEqual('Middle Initial');
        expect(lbllastname.getText()).toEqual('Last Name');
        expect(lblgender.getText()).toEqual('Gender');
        expect(lbldob.getText()).toEqual('Date of Birth');
        expect(lblpphone.getText()).toEqual('Preferred Personal Phone');
        expect(lblpemail.getText()).toEqual('Preferred Personal Email');
        expect(lblpmethod.getText()).toEqual('Preferred method for non-confidential correspondence');
        expect(lblres1.getText()).toEqual('Residential Address 1');
        expect(lblres2.getText()).toEqual('Residential Address 2');
        expect(lblrescity.getText()).toEqual('Residential City');
        expect(lblcountry.getText()).toEqual('Country');
        expect(lblpostalcode.getText()).toEqual('Postal Code');
        expect(lblcountryofemploy.getText()).toEqual('Country of Employment');


    });

    //Test Case  4 verify the values entered are correct when Employee ID is selected

    it('New CLI_Review Page : About You Section, Medical contacts section - Validation of Labels & Textbox entries when Gender is Female with Employee ID - Maternity flow ', function () {


        //Open NEW CLI in browser and go to About You Page
        POCommonFunctions.employeeurl();

        //Select About You Page
        element(by.css('[href="/cli/claimant"]')).click();
        POAYP.empidradio.input.click();

        //Enter valid value for Employee ID
        empid.sendKeys('12345');
        firstname.sendKeys('TestFirstname');
        lastname.sendKeys('TestLastName');
        middlename.sendKeys('M');

        dob.click();
        dob1.sendKeys('11/12/1975');
        POAYP.rbtnfemale.input.click();

        //Enter Valid value for  Residential Address1
        resaddr1.sendKeys('Testaddress1');
        resaddr2.sendKeys('testAddress2');

        //Enter Valid value for  Residential City
        rescity.sendKeys('Testcity');

        //Select any Residential State
        statelist.$('[value = "AK"]').click();

        //Enter Valid value for  Postal Code
        postalcode.sendKeys('78901');


        //Enter Valid value for  Preferred phone number
        preferedphone.click();
        pphone1.sendKeys('9089089098')

        //Enter Valid value for  Preferred email
        prefmail.sendKeys('test@tst.com');

        //Select any value for State of Employment
        stateemploy.$('[value = "AK"]').click();

        var eid = empid.getAttribute('value');
        var fname = firstname.getAttribute('value');
        var lname = lastname.getAttribute('value');
        var vdob = dob1.getAttribute('value');
        var vphone = pphone1.getAttribute('value');
        var vmail = prefmail.getAttribute('value');
        var vresaddr1 = resaddr1.getAttribute('value');
        var vresaddr2 = resaddr2.getAttribute('value');
        var vrescity = rescity.getAttribute('value');
        var vpostal = postalcode.getAttribute('value');


        //Click Continue button
        POAYP.continuebutton.input.click();
        //element(by.css('[href="/cli/absence"]')).click();

        //Verify About your Absence is displayed
        var aboutyourabsencehdr = POAYA.absenceheader.input.getText();
        expect(aboutyourabsencehdr).toEqual('About Your Absence');


        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/English/Testcase4_i.png');
        });

        browser.sleep(100);


        //Select the Continous radio button
        POAYA.consecutivedaysradiobtny.input.click();

        leaveclaimlist.$('[value = "MAT"]').click();
        browser.sleep(100);

        //Verify next question displayed after Maternity is selected is "have you delivered"
        expect(lblhavedelivered.getText()).toEqual('Have you already delivered?');

        //  circumstance.$('[value = "P"]').click();
        // browser.sleep(100);
        delivery.$('[value = "Yes, C-Section"]').click();
        browser.sleep(100);


        deliverydate.sendKeys('08/10/2017');
        browser.sleep(100);

        lastworkingdate.sendKeys('08/09/2017');
        browser.sleep(100);

        element(by.buttonText('Continue')).click();
        browser.sleep(100);

        //Enter values for Contacts page
        physicianfnametbox.sendKeys("Phyfirstname");
        var pfname = physicianfnametbox.getAttribute('value');

        physicianlnametbox.sendKeys("PhyLastName");
        var plname = physicianlnametbox.getAttribute('value');

        physicianpnumtbox.sendKeys("1234567890");
        var ppnum = physicianpnumtbox.getAttribute('value');

        physicianhnametbox.sendKeys("PhysicianhospName");
        var phname = physicianhnametbox.getAttribute('value');

        physicianhpnumtbox.sendKeys("1980899999");
        var phnum = physicianhpnumtbox.getAttribute('value');

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/English/Testcase4_ii.png');
        });
        element(by.buttonText('Continue')).click();
        browser.sleep(100);

        //Verify the Review page values for About You Section 6333

        expect(txtempid.getText()).toEqual(eid);
        expect(txtfirstname.getText()).toEqual(fname);
        expect(txtmiddlename.getText()).toEqual('M');
        expect(txtlastname.getText()).toEqual(lname);
        expect(txtgender.getText()).toEqual('female');
        expect(txtdob.getText()).toEqual(vdob);
        expect(txtpphone.getText()).toEqual(vphone);
        expect(txtpemail.getText()).toEqual(vmail);
        expect(txtpmethod.getText()).toEqual('Email');
        expect(txtresaddr1.getText()).toEqual(vresaddr1);
        expect(txtresaddr2.getText()).toEqual(vresaddr2);
        expect(txtrescity.getText()).toEqual(vrescity);
        expect(txtcountry.getText()).toEqual('United States');
        expect(txtecountry.getText()).toEqual('United States');
        expect(txtpostalcode.getText()).toEqual(vpostal);


        var medicalconlbl = POEER.medicalconlbl.input.getText();
        medicalconlbl.click();

        //Medical contacts section validation as a part of story 6335

        expect(lblphyfirstname.getText()).toEqual("Physician's First Name");
        expect(lblhosphyname.getText()).toEqual("Hospital Name or Physicians Practice Name");
        expect(lblphylastname.getText()).toEqual("Physician's Last Name");
        expect(lblhosphyphone.getText()).toEqual("Hospital or Physicians Practice Phone Number");
        expect(lblphyphone.getText()).toEqual("Physician's Phone Number");

        expect(txtphyfirstname.getText()).toEqual(pfname);
        expect(txthosphyname.getText()).toEqual(phname);
        expect(txtphylastname.getText()).toEqual(plname);
        expect(txthosphyphone.getText()).toEqual(phnum);
        expect(txtphyphone.getText()).toEqual(ppnum);


    });


    //Test Case  5 verify the values entered are correct when SSN is selected

    it('New CLI_Review Page About You Section, Medical contacts section - Validation of Labels & Textbox entries when Gender is Male,SSN,Mail selected for Pref Method - MOC flow', function () {

        //Open NEW CLI in browser and go to Review Page
        POCommonFunctions.employeeurl();

        //Click About You Page
        element(by.css('[href="/cli/claimant"]')).click();

        POAYP.ssnradio.input.click();

        ssntext.sendKeys('984575674');
        var ssn = ssntext.getAttribute('value');

        firstname.sendKeys('TestFirstname');
        var fname = firstname.getAttribute('value');

        middlename.sendKeys('M');


        lastname.sendKeys('TestLastName');
        var lname = lastname.getAttribute('value');


        //Select Gender
        POAYP.rbtnmale.input.click();
        dob.click();
        dob1.sendKeys('11/12/1975');
        var vdob = dob1.getAttribute('value');

        preferedphone.click();
        pphone1.sendKeys('9089089098')
        var vphone = pphone1.getAttribute('value');

        prefmail.sendKeys('test@tst.com');
        var vmail = prefmail.getAttribute('value');

        POAYP.prefmethodrbtnmail.input.click();

        resaddr1.sendKeys('Testaddress1');
        var vresaddr1 = resaddr1.getAttribute('value');

        resaddr2.sendKeys('testAddress2');
        var vresaddr2 = resaddr2.getAttribute('value');

        rescity.sendKeys('Testcity');
        var vrescity = rescity.getAttribute('value');

        statelist.$('[value = "AK"]').click();

        postalcode.sendKeys('78901');
        var vpostal = postalcode.getAttribute('value');

        stateemploy.$('[value = "AK"]').click();

        //Click Continue button
        POAYP.continuebutton.input.click();

        //Verify About your Absence is displayed
        var aboutyourabsencehdr = POAYA.absenceheader.input.getText();
        expect(aboutyourabsencehdr).toEqual('About Your Absence');

        //Select the Continous radio button
        POAYA.consecutivedaysradiobtny.input.click();

        leaveclaimlist.$('[value = "OWN"]').click();
        browser.sleep(100);
        circumstance.$('[value = "S"]').click();
        browser.sleep(100);

        lastworkingdate.sendKeys('07/09/2017');
        browser.sleep(100);

        illness.sendKeys('07/09/2017');
        browser.sleep(100);

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/AboutYourAbsencePage/MOC/English/Testcase3_i.png');
        });


        browser.sleep(100);

        element(by.buttonText('Continue')).click();
        browser.sleep(100);

        //Enter values for Contacts page
        physicianfnametbox.sendKeys("Phyfirstname");
        var pfname = physicianfnametbox.getAttribute('value');

        physicianlnametbox.sendKeys("PhyLastName");
        var plname = physicianlnametbox.getAttribute('value');

        physicianpnumtbox.sendKeys("1234567890");
        var ppnum = physicianpnumtbox.getAttribute('value');

        physicianhnametbox.sendKeys("PhysicianhospName");
        var phname = physicianhnametbox.getAttribute('value');

        physicianhpnumtbox.sendKeys("1980899999");
        var phnum = physicianhpnumtbox.getAttribute('value');

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/English/Testcase4_ii.png');
        });
        element(by.buttonText('Continue')).click();
        browser.sleep(100);

        //Verify the Review page values for the story 6333

        expect(txtempid.getText()).toContain('5674');
        expect(txtfirstname.getText()).toEqual(fname);
        expect(txtmiddlename.getText()).toEqual('M');
        expect(txtlastname.getText()).toEqual(lname);
        expect(txtgender.getText()).toEqual('male');
        expect(txtdob.getText()).toEqual(vdob);
        expect(txtpphone.getText()).toEqual(vphone);
        expect(txtpemail.getText()).toEqual(vmail);
        expect(txtpmethod.getText()).toEqual('Mail');
        expect(txtresaddr1.getText()).toEqual(vresaddr1);
        expect(txtresaddr2.getText()).toEqual(vresaddr2);
        expect(txtrescity.getText()).toEqual(vrescity);
        expect(txtcountry.getText()).toEqual('United States');
        expect(txtecountry.getText()).toEqual('United States');
        expect(txtpostalcode.getText()).toEqual(vpostal);


        var medicalconlbl = POEER.medicalconlbl.input.getText();
        medicalconlbl.click();

        //Medical contacts section validation as a part of story 6335

        expect(lblphyfirstname.getText()).toEqual("Physician's First Name");
        expect(lblhosphyname.getText()).toEqual("Hospital Name or Physicians Practice Name");
        expect(lblphylastname.getText()).toEqual("Physician's Last Name");
        expect(lblhosphyphone.getText()).toEqual("Hospital or Physicians Practice Phone Number");
        expect(lblphyphone.getText()).toEqual("Physician's Phone Number");

        expect(txtphyfirstname.getText()).toEqual(pfname);
        expect(txthosphyname.getText()).toEqual(phname);
        expect(txtphylastname.getText()).toEqual(plname);
        expect(txthosphyphone.getText()).toEqual(phnum);
        expect(txtphyphone.getText()).toEqual(ppnum);


    });

    //Test Case  6 verify the values entered are correct when Fax is selected

    it('New CLI_Review Page : Verify textbox entries when SSN and Fax selected for Pref Method - Country United States', function () {

        //Open NEW CLI in browser and go to Review Page
        POCommonFunctions.employeeurl();

        //Click About You Page
        element(by.css('[href="/cli/claimant"]')).click();

        POAYP.ssnradio.input.click();

        ssntext.sendKeys('984575674');
        var ssn = ssntext.getAttribute('value');

        firstname.sendKeys('TestFirstname');
        var fname = firstname.getAttribute('value');

        middlename.sendKeys('M');


        lastname.sendKeys('TestLastName');
        var lname = lastname.getAttribute('value');


        //Select Gender
        POAYP.rbtnmale.input.click();
        dob.click();
        dob1.sendKeys('11/12/1975');
        var vdob = dob1.getAttribute('value');

        preferedphone.click();
        pphone1.sendKeys('9089089098')
        var vphone = pphone1.getAttribute('value');

        prefmail.sendKeys('test@tst.com');
        var vmail = prefmail.getAttribute('value');

        POAYP.prefmethodrbtnfax.input.click();

        POAYP.faxtextbox.input.click();
        txtfax1.sendKeys('8908977896');
        var valfax = txtfax1.getAttribute('value');


        resaddr1.sendKeys('Testaddress1');
        var vresaddr1 = resaddr1.getAttribute('value');

        resaddr2.sendKeys('testAddress2');
        var vresaddr2 = resaddr2.getAttribute('value');

        rescity.sendKeys('Testcity');
        var vrescity = rescity.getAttribute('value');

        statelist.$('[value = "OH"]').click();

        postalcode.sendKeys('78901');
        var vpostal = postalcode.getAttribute('value');

        stateemploy.$('[value = "AK"]').click();

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/English/Testcase4_i.png');
        });

        browser.sleep(100);

        element(by.css('[href="/cli/review"]')).click();

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/English/Testcase4_ii.png');
        });
        var lblfax = POEER.lblfax.input;
        //Verify the Review page values
        expect(txtempid.getText()).toContain('5674');
        expect(txtfirstname.getText()).toEqual(fname);
        expect(txtmiddlename.getText()).toEqual('M');
        expect(txtlastname.getText()).toEqual(lname);
        expect(txtgender.getText()).toEqual('male');
        expect(txtdob.getText()).toEqual(vdob);
        expect(txtpphone.getText()).toEqual(vphone);
        expect(txtpemail.getText()).toEqual(vmail);
        expect(txtpmethod.getText()).toEqual('Fax');
        expect(lblfax.getText()).toEqual('Preferred Fax');
        expect(txtfax.getText()).toEqual(valfax);
        expect(txtresaddr1.getText()).toEqual(vresaddr1);
        expect(txtresaddr2.getText()).toEqual(vresaddr2);
        expect(txtrescity.getText()).toEqual(vrescity);
        expect(txtcountry.getText()).toEqual('United States');
        expect(txtecountry.getText()).toEqual('United States');
        expect(lblstateemploy.getText()).toEqual('State of Employment');
        expect(txtsemploy.getText()).toEqual('Alaska');

        expect(lblresstate.getText()).toEqual('Residential State');
        expect(txtstate.getText()).toEqual('Ohio');

        expect(txtpostalcode.getText()).toEqual(vpostal);


    });

//Test Case  8 verify the values entered are correct when Fax is selected

    it('New CLI_Review Page : Verify textbox entries when SSN and Fax selected for Pref Method - Country Canada', function () {

        POCommonFunctions.employeeurl();
        element(by.css('[href="/cli/claimant"]')).click();

        POAYP.ssnradio.input.click();

        ssntext.sendKeys('984575674');
        var ssn = ssntext.getAttribute('value');

        firstname.sendKeys('TestFirstname');
        var fname = firstname.getAttribute('value');

        middlename.sendKeys('M');


        lastname.sendKeys('TestLastName');
        var lname = lastname.getAttribute('value');


        //Select Gender
        POAYP.rbtnmale.input.click();
        dob.click();
        dob1.sendKeys('11/12/1975');
        var vdob = dob1.getAttribute('value');

        preferedphone.click();
        pphone1.sendKeys('9089089098')
        var vphone = pphone1.getAttribute('value');

        prefmail.sendKeys('test@tst.com');
        var vmail = prefmail.getAttribute('value');

        POAYP.prefmethodrbtnfax.input.click();


        POAYP.faxtextbox.input.click();
        txtfax1.sendKeys('8908977896');
        var valfax = txtfax1.getAttribute('value');


        var lblfax = POEER.lblfax.input;

        resaddr1.sendKeys('Testaddress1');
        var vresaddr1 = resaddr1.getAttribute('value');

        resaddr2.sendKeys('testAddress2');
        var vresaddr2 = resaddr2.getAttribute('value');

        rescity.sendKeys('Testcity');
        var vrescity = rescity.getAttribute('value');
        var country = POAYP.empcountrylist1.input;
        country.$('[value = "CAN"]').click();

        statelist.$('[value = "AB"]').click();

        postalcode.sendKeys('a1a1a1');
        var vpostal = postalcode.getAttribute('value');
        var ecountry = POAYP.empstatecountrylist1.input;
        ecountry.$('[value = "CAN"]').click();


        stateemploy.$('[value = "BC"]').click();

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/English/Testcase8_i.png');
        });

        browser.sleep(100);

        element(by.css('[href="/cli/review"]')).click();

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/English/Testcase8_ii.png');
        });

        //Verify the Review page values
        expect(txtempid.getText()).toContain('5674');
        expect(txtfirstname.getText()).toEqual(fname);
        expect(txtmiddlename.getText()).toEqual('M');
        expect(txtlastname.getText()).toEqual(lname);
        expect(txtgender.getText()).toEqual('male');
        expect(txtdob.getText()).toEqual(vdob);
        expect(txtpphone.getText()).toEqual(vphone);
        expect(txtpemail.getText()).toEqual(vmail);
        expect(txtpmethod.getText()).toEqual('Fax');
        expect(lblfax.getText()).toEqual('Preferred Fax');
        expect(txtfax.getText()).toEqual(valfax);
        expect(txtresaddr1.getText()).toEqual(vresaddr1);
        expect(txtresaddr2.getText()).toEqual(vresaddr2);
        expect(txtrescity.getText()).toEqual(vrescity);
        expect(txtcountry.getText()).toEqual('Canada');
        expect(txtecountry.getText()).toEqual('Canada');
        expect(lblstateemploy.getText()).toEqual('Province of Employment');
        expect(txtsemploy.getText()).toEqual('British Columbia');

        expect(lblresstate.getText()).toEqual('Province');
        expect(txtstate.getText()).toEqual('Alberta');

        expect(txtpostalcode.getText()).toEqual(vpostal);


    });

    //Test Case  9 verify the values entered are correct when country is other than US and Canada

    it('New CLI_Review Page : Verify values when country is other than United States and Canada', function () {

        POCommonFunctions.employeeurl();
        element(by.css('[href="/cli/claimant"]')).click();

        POAYP.ssnradio.input.click();

        ssntext.sendKeys('984575674');
        var ssn = ssntext.getAttribute('value');

        firstname.sendKeys('TestFirstname');
        var fname = firstname.getAttribute('value');

        middlename.sendKeys('M');


        lastname.sendKeys('TestLastName');
        var lname = lastname.getAttribute('value');


        //Select Gender
        POAYP.rbtnmale.input.click();
        dob.click();
        dob1.sendKeys('11/12/1975');
        var vdob = dob1.getAttribute('value');

        preferedphone.click();
        pphone1.sendKeys('9089089098')
        var vphone = pphone1.getAttribute('value');

        prefmail.sendKeys('test@tst.com');
        var vmail = prefmail.getAttribute('value');


        resaddr1.sendKeys('Testaddress1');
        var vresaddr1 = resaddr1.getAttribute('value');

        resaddr2.sendKeys('testAddress2');
        var vresaddr2 = resaddr2.getAttribute('value');

        rescity.sendKeys('Testcity');
        var vrescity = rescity.getAttribute('value');
        var country = POAYP.empcountrylist1.input;
        country.$('[value = "BTN"]').click();


        postalcode.sendKeys('78901');
        var vpostal = postalcode.getAttribute('value');
        var ecountry = POAYP.empstatecountrylist1.input;
        ecountry.$('[value = "BTN"]').click();


        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/English/Testcase9_i.png');
        });

        browser.sleep(100);

        element(by.css('[href="/cli/review"]')).click();

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/English/Testcase9_ii.png');
        });


        //Verify the Review page values
        expect(txtempid.getText()).toContain('5674');
        expect(txtfirstname.getText()).toEqual(fname);
        expect(txtresaddr1.getText()).toEqual(vresaddr1);
        expect(txtmiddlename.getText()).toEqual('M');
        expect(txtresaddr2.getText()).toEqual(vresaddr2);
        expect(txtlastname.getText()).toEqual(lname);
        expect(txtrescity.getText()).toEqual(vrescity);
        expect(txtgender.getText()).toEqual('male');

        var odob = POEER.otxtdob.input;
        expect(odob.getText()).toEqual(vdob);

        var ocountry = POEER.ocountry.input;
        expect(ocountry.getText()).toEqual('Bhutan');

        var ophone = POEER.ophone.input;
        expect(ophone.getText()).toEqual(vphone);

        var opostal = POEER.opostalcode.input;
        expect(opostal.getText()).toEqual(vpostal);

        var oemail = POEER.opemail.input;
        expect(oemail.getText()).toEqual(vmail);

        var oecountry = POEER.oecountry.input;
        expect(oecountry.getText()).toEqual('Bhutan');


    });*/






   /*     it('New CLI_Contacts Page: Story#6674 - EE- English - Medical contacts page displays dynamically', function () {

            POCommonFunctions.enteraboutyoupage();

            POAYA.consecutivedaysradiobtny.input.click();

            //Select Bond with child option in drop down
            var leavetypelist = POAYA.leavetypelist1.input;
            leavetypelist.$('[value="OWN"]').click();
            browser.sleep(3000);

            element(by.css('[href="/cli/employee/contacts"]')).click();
            var medheader = POAYC.medheader.input.getText();
            expect(medheader).toEqual('Medical Contacts');

            POAYP.continuebutton.input.click();
            expect(POEER.medicalconlbl.input.isDisplayed()).toBe(true);
            browser.sleep(500);

            POEER.gobackbtn.input.click();
            browser.sleep(500);
            POEER.gobackbtn.input.click();

            //Select Bond with child option in drop down
            var leavetypelist = POAYA.leavetypelist1.input;
            leavetypelist.$('[value="OTH"]').click();
            browser.sleep(3000);

            element(by.css('[href="/cli/employee/contacts"]')).click();
            var medheader = POAYC.medheader.input.getText();
            expect(medheader).toEqual('Medical Contacts');
            browser.sleep(500);

            POAYP.continuebutton.input.click();
            browser.sleep(500);
            expect(POEER.medicalconlbl.input.isDisplayed()).toBe(true);
            browser.sleep(500);

            POEER.gobackbtn.input.click();
            browser.sleep(500);
            POEER.gobackbtn.input.click();

            //Select Bond with child option in drop down
            var leavetypelist = POAYA.leavetypelist1.input;
            leavetypelist.$('[value="MAT"]').click();
            browser.sleep(3000);

            element(by.css('[href="/cli/employee/contacts"]')).click();
            var medheader = POAYC.medheader.input.getText();
            expect(medheader).toEqual('Medical Contacts');
            browser.sleep(500);

            POAYP.continuebutton.input.click();
            browser.sleep(500);
            expect(POEER.medicalconlbl.input.isDisplayed()).toBe(true);
            browser.sleep(500);

            //Take screenshot
            browser.takeScreenshot().then(function (png) {
                writeScreenShot(png, './Screenshots/AboutYourAbsencePage/Testcase1.png');
            });

        });


    });*/
});

