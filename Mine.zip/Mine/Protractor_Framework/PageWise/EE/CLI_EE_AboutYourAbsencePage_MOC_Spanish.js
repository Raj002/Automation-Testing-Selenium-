


var Getting_StartedPage = require('./../../PageObjects/PageObject_GettingStarted.js');
var ResuableFunction = require('./..//helpers/helpers.js');
var AboutYouPage = require('./../../PageObjects/PageObject_AboutYouPage.js');
var AboutAbsencePage = require('./../../PageObjects/PageObject_AboutYourAbsence.js');
var AddlInfoPage = require('./../../PageObjects/PageObject_Additional_InformationPage.js');
var ReviewPage = require('./../../PageObjects/PageObject_ER_ReviewPage.js');



describe ('AboutYourAbsence Page: MOC Flow - Validations', function() {

    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;



    it('New CLI_Employee_About Absence Page: New York Paid Family Leave validation ', function () {

        ResuableFunction.MLC_Login();
        ResuableFunction.EmployeeCLI();
        ResuableFunction.Spanish_Link();
        Getting_StartedPage.clickStart("Employee-Spanish");

        AboutYouPage.EnterEmployeeID('23259');
        AboutYouPage.EnterFirstName('Test');
        AboutYouPage.EnterLastName('Test');
        AboutYouPage.EnterDateofBirth('01/01/1987');
        AboutYouPage.SelectGender('Female');
        AboutYouPage.EnterResdentialAddress1('123 Test');
        AboutYouPage.EnterResdentialcity('Dover');
        AboutYouPage.EnterPostalCode('23345');
        AboutYouPage.SelectState('AK');
        AboutYouPage.EnterPersonalPhone('1231231234');
        AboutYouPage.EnterPersonalEmail('test@test.com');
        AboutYouPage.SelectEmploymentState('AK');
        AboutYouPage.ClickContinue_ViewAboutYourAbsence();

        AboutAbsencePage.SelectLeaveorClaimCategory('Yes');
        AboutAbsencePage.SelectLeaveorClaimtype('MOC','Female');
        AboutAbsencePage.SelectClaimantCondition('PaidLeave');
        AboutAbsencePage.CustomMessage_PaidLeave();
        AboutAbsencePage.Continuebuttondisabled_validation();

    },300000000);

    it('New CLI_Employee_About Absence Page - Verify options for Leave of Absence - Intermittent ', function () {

        AboutAbsencePage.ClickGoBack();
        AboutYouPage.EnterEmployeeID('23259');
        AboutYouPage.SelectGender('Male');
        AboutYouPage.ClickContinue_ViewAboutYourAbsence();
        AboutAbsencePage.SelectLeaveorClaimCategory('No');
        AboutAbsencePage.SelectLeaveorClaimtype('MOC','Male');
        AboutAbsencePage.Dropdown_1_Options("MOC-Spanish");



    },300000000);


    it('New CLI_Employee_About Absence Page - Verify options for Leave of Absence - Intermittent ', function () {

        AboutAbsencePage.ClickGoBack();
        AboutYouPage.EnterEmployeeID('23259');
        AboutYouPage.SelectGender('Female');
        AboutYouPage.ClickContinue_ViewAboutYourAbsence();
        AboutAbsencePage.SelectLeaveorClaimCategory('No');
        AboutAbsencePage.SelectLeaveorClaimtype('MOC','Female-No');
        AboutAbsencePage.Dropdown_1_Options("MOC-Spanish");



    },300000000);

    it('New CLI_Employee_About Absence Page - Page Header, Questions Label Validations - Illness ', function () {

        AboutAbsencePage.SelectLeaveorClaimCategory('Yes');
        AboutAbsencePage.SelectLeaveorClaimtype('MOC','Female');
        AboutAbsencePage.SelectClaimantCondition('Illness');
        AboutAbsencePage.ClickContinue();
        AboutAbsencePage.Verify_RequiredErrorMessage('Spanish');
        AboutAbsencePage.SelectAccidentResult('Yes');
        AboutAbsencePage.SelectMotorAccident('Yes');
        AboutAbsencePage.SelectOnJob('Yes');
        AboutAbsencePage.SelectGoingHospital('Yes');
        AboutAbsencePage.SelectSurgery('Yes');
        AboutAbsencePage.QuestionsLabelValidations('Employee-Spanish-MOC-Illness');
        AboutAbsencePage.LastQuestion_Validation("Employee-Spanish-MOC");
        AboutAbsencePage.SurgeryOptions_Spanish();



    },300000000);

    it('New CLI_Employee_About Absence Page - Auto Format Validations for Date fields', function () {


        var datevalue;

        datevalue =  AboutAbsencePage.VerifyFormat_DateQuestion_1('02/2/2012');
        expect(datevalue).toEqual('02/02/2012');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_1('8/12/2017');
        expect(datevalue).toEqual('08/12/2017');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_1('8-8-2017');
        expect(datevalue).toEqual('');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_1('8/8/2017');
        expect(datevalue).toEqual('08/08/2017');


        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_2('02/2/2012');
        expect(datevalue).toEqual('02/02/2012');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_2('8/12/2017');
        expect(datevalue).toEqual('08/12/2017');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_1('8-8-2017');
        expect(datevalue).toEqual('');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_2('8/8/2017');
        expect(datevalue).toEqual('08/08/2017');


        datevalue =  AboutAbsencePage.VerifyFormat_DateQuestion_3('02/2/2012');
        expect(datevalue).toEqual('02/02/2012');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_3('8/12/2017');
        expect(datevalue).toEqual('08/12/2017');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_3('8-8-2017');
        expect(datevalue).toEqual('');
        datevalue =  AboutAbsencePage.VerifyFormat_DateQuestion_3('8/8/2017');
        expect(datevalue).toEqual('08/08/2017');

        datevalue =  AboutAbsencePage.VerifyFormat_DateQuestion_4('02/2/2012');
        expect(datevalue).toEqual('02/02/2012');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_4('8/12/2017');
        expect(datevalue).toEqual('08/12/2017');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_4('8-8-2017');
        expect(datevalue).toEqual('');
        datevalue =  AboutAbsencePage.VerifyFormat_DateQuestion_4('8/8/2017');
        expect(datevalue).toEqual('08/08/2017');


    },300000000);

    it('New CLI_Employee_About Absence Page - Page Header, Questions Label Validations - Injury ', function () {

        AboutAbsencePage.SelectClaimantCondition('Injury');
        AboutAbsencePage.ClickContinue();
        AboutAbsencePage.Verify_RequiredErrorMessage('Spanish');
        AboutAbsencePage.SelectAccidentResult('Yes');
        AboutAbsencePage.SelectMotorAccident('Yes');
        AboutAbsencePage.SelectOnJob('Yes');
        AboutAbsencePage.SelectGoingHospital('Yes');
        AboutAbsencePage.SelectSurgery('Yes');
        AboutAbsencePage.QuestionsLabelValidations('Employee-Spanish-MOC-Injury');
        AboutAbsencePage.LastQuestion_Validation("Employee-Spanish-MOC");
        AboutAbsencePage.SurgeryOptions_Spanish();
        AboutAbsencePage.EnterDateQuestion_1('11/01/2017');
        AboutAbsencePage.EnterDateQuestion_2('11/01/2017');

        AboutAbsencePage.ClickContinue_ViewMedicalContacts('Employee-Spanish');


    },300000000);


    it('New CLI_Employee - Were you in a motor vehicle accident? - Spanish question validation - Story 7946', function () {

        AboutAbsencePage.SelectLeaveorClaimCategory('Yes');
        AboutAbsencePage.SelectLeaveorClaimtype('MOC','Female');
        AboutAbsencePage.SelectClaimantCondition('Illness');
        AboutAbsencePage.SelectAccidentResult('Yes');
        AboutAbsencePage.lblmotorquestion('Yes');
        AboutAbsencePage.SelectAccidentResult('No');
        AboutAbsencePage.lblmotorquestion('No');

    },300000000);

});

