var Getting_StartedPage = require('./../../PageObjects/PageObject_GettingStarted.js');
var ResuableFunction = require('./..//helpers/helpers.js');
var AboutYouPage = require('./../../PageObjects/PageObject_AboutYouPage.js');
var AboutAbsencePage = require('./../../PageObjects/PageObject_AboutYourAbsence.js');
var AddlInfoPage = require('./../../PageObjects/PageObject_Additional_InformationPage.js');
var ReviewPage = require('./../../PageObjects/PageObject_ER_ReviewPage.js');

describe ('New CLI_Employee- About Absence: Care Flow Validations', function() {


    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;

/*

    it('New CLI_Employee_About Absence Page - Page Header, Questions Label Validations - Continuous - Male', function () {

        ResuableFunction.MLC_Login();
        ResuableFunction.EmployeeCLI();
        Getting_StartedPage.clickStart("Employee-English");
        AboutYouPage.EnterEmployeeID('23259');
        AboutYouPage.EnterFirstName('Test');
        AboutYouPage.EnterLastName('Test');
        AboutYouPage.EnterDateofBirth('01/01/1987');
        AboutYouPage.SelectGender('Male');
        AboutYouPage.EnterResdentialAddress1('123 Test');
        AboutYouPage.EnterResdentialcity('Dover');
        AboutYouPage.EnterPostalCode('23345');
        AboutYouPage.SelectState('AK');
        AboutYouPage.EnterPersonalPhone('1231231234');
        AboutYouPage.EnterPersonalEmail('test@test.com');
        AboutYouPage.SelectEmploymentState('AK');
        AboutYouPage.ClickContinue_ViewAboutYourAbsence();
        AboutAbsencePage.SelectLeaveorClaimCategory('Yes');
        AboutAbsencePage.SelectLeaveorClaimtype('CareFlow','Male');
        AboutAbsencePage.Select_List_1_Value('CH');
        AboutAbsencePage.Select_List_2_Value('CH');
        AboutAbsencePage.QuestionsLabelValidations('Employee-CareFlow');
        AboutAbsencePage.Dropdown_1_Options('CareFlow');

    },300000000);

    it('New CLI_Employee_About Absence Page - Auto Format Validations for Date fields', function () {


        var datevalue;

        datevalue =  AboutAbsencePage.VerifyFormat_DateQuestion_1('02/2/2012');
        expect(datevalue).toEqual('02/02/2012');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_1('8/12/2017');
        expect(datevalue).toEqual('08/12/2017');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_1('8/8/2017');
        expect(datevalue).toEqual('08/08/2017');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_1('8-8-2017');
        expect(datevalue).toEqual('');

        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_2('02/2/2012');
        expect(datevalue).toEqual('02/02/2012');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_2('8/12/2017');
        expect(datevalue).toEqual('08/12/2017');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_2('8/8/2017');
        expect(datevalue).toEqual('08/08/2017');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_2('8-8-2017');
        expect(datevalue).toEqual('');



        datevalue =  AboutAbsencePage.VerifyFormat_DateQuestion_3('02/2/2012');
        expect(datevalue).toEqual('02/02/2012');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_3('8/12/2017');
        expect(datevalue).toEqual('08/12/2017');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_3('8-8-2017');
        expect(datevalue).toEqual('');
        datevalue =  AboutAbsencePage.VerifyFormat_DateQuestion_3('8/8/2017');
        expect(datevalue).toEqual('08/08/2017');


    },300000000);



    it('New CLI_Employee_About Absence Page - Page Header, Questions Label Validations - Intermittent - Female', function () {

        AboutAbsencePage.ClickGoBack();
        AboutYouPage.EnterEmployeeID('23259');
        AboutYouPage.SelectGender('Female');
        AboutYouPage.ClickContinue_ViewAboutYourAbsence();
        AboutAbsencePage.SelectLeaveorClaimCategory('No');
        AboutAbsencePage.SelectLeaveorClaimtype('CareFlow','Female-No');
        AboutAbsencePage.ClickContinue();
        AboutAbsencePage.Verify_ErrorMessage();
        AboutAbsencePage.Select_List_1_Value('CH');
        AboutAbsencePage.Select_List_2_Value('CH');
        AboutAbsencePage.QuestionsLabelValidations('Employee-CareFlow');
        AboutAbsencePage.Dropdown_1_Options('CareFlow');

    },300000000);

    it('New CLI_Employee_About Absence Page - Page Header, Questions Label Validations - Continuous - Female', function () {


        AboutAbsencePage.SelectLeaveorClaimCategory('Yes');
        AboutAbsencePage.SelectLeaveorClaimtype('CareFlow','Female');
        AboutAbsencePage.ClickContinue();
        AboutAbsencePage.Verify_ErrorMessage();
        AboutAbsencePage.Select_List_1_Value('CH');
        AboutAbsencePage.Select_List_2_Value('CH');
        AboutAbsencePage.QuestionsLabelValidations('Employee-CareFlow');
        AboutAbsencePage.Dropdown_1_Options('CareFlow');

    },300000000);

    it('New CLI_Employee_About Absence Page - Page Header, Other Relationship', function () {
        AboutAbsencePage.Select_List_1_Value('OT');
        AboutAbsencePage.Select_List_2_Value('OT');
        AboutAbsencePage.Verify_OtherRelationshipLabel();

    },300000000);


    it('New CLI_Employee_About Absence Page - In loco Parentis (In place of parent) option', function () {

        AboutAbsencePage.Select_List_1_Value('PA');//Parent
        AboutAbsencePage.VerifyInlocoParentisoption();
        AboutAbsencePage.Select_List_2_Value('IP');

        AboutAbsencePage.Select_List_1_Value('DV');//Domestic Violence
        AboutAbsencePage.VerifyInlocoParentisoption();
        AboutAbsencePage.Select_List_2_Value('IP');

        AboutAbsencePage.Select_List_1_Value('ML');//Parent
        AboutAbsencePage.VerifyInlocoParentisoption();
        AboutAbsencePage.Select_List_2_Value('IP');

    },300000000);

*/
    it('Story 7682 - NEW CLI - About Your Employees Absence - Validate and disable date fields and date pickers based on valid date range', function () {

        var date_1;
        var date_2;
        var date_3;
        var date_4;
        var date_5;
        var date_6;
        ResuableFunction.MLC_Login();
        ResuableFunction.EmployeeCLI();
        Getting_StartedPage.clickStart("Employee-English");

        //AboutYouPage.UniqueID_EmpID_SSN('EmpID');
        AboutYouPage.EnterSSN('112224440');
        AboutYouPage.ValidateFirstNameEE();
        AboutYouPage.ValidateLastNameEE();
        AboutYouPage.SelectGender('Female');
        AboutYouPage.EnterDateofBirth('01011987');
        AboutYouPage.EnterResdentialAddress1('123 Test');
        AboutYouPage.EnterResdentialcity('Dover');
        AboutYouPage.EnterPostalCode('23345');
        AboutYouPage.SelectState('NH');
        AboutYouPage.EnterPersonalPhone('9997775550');
        AboutYouPage.EnterPersonalEmail('TESTemail@test.com');
        AboutYouPage.SelectEmploymentState('AK');
        AboutYouPage.ClickContinue_ViewAboutYourAbsence();

        date_1 = AboutAbsencePage.DateEntry('greater than 1 year');
        date_2 = AboutAbsencePage.DateEntry('greater than 2 year');
        date_3 = AboutAbsencePage.DateEntry('lesser than 1 year');
        date_4 = AboutAbsencePage.DateEntry('invalid date');
        date_5 = AboutAbsencePage.DateEntry('today');
        date_6 = AboutAbsencePage.DateEntry('future date');
        AboutAbsencePage.SelectLeaveorClaimCategory('Yes');
        AboutAbsencePage.SelectLeaveorClaimtype('CareFlow','Female');
        AboutAbsencePage.Select_List_1_Value('CH');
        AboutAbsencePage.Select_List_2_Value('CP');
        AboutAbsencePage.EnterDateQuestion_1(date_1);
        AboutAbsencePage.EnterDateQuestion_2(date_1);
        AboutAbsencePage.EnterDateQuestion_3(date_2);
        AboutAbsencePage.Verify_ErrorMessage_datefeilds_Careflow('Err_Msg_Outside valid window_Greater');
        AboutAbsencePage.EnterDateQuestion_1(date_3);
        AboutAbsencePage.EnterDateQuestion_2(date_3);
        AboutAbsencePage.EnterDateQuestion_3(date_3);
        AboutAbsencePage.Verify_ErrorMessage_datefeilds_Careflow('Err_Msg_Outside valid window_lesser');
        AboutAbsencePage.EnterDateQuestion_1(date_4);
        AboutAbsencePage.EnterDateQuestion_2(date_4);
        AboutAbsencePage.EnterDateQuestion_3(date_4);
        AboutAbsencePage.Verify_ErrorMessage_datefeilds_Careflow('Err_Msg_Invalid format');

    },300000000);




});


