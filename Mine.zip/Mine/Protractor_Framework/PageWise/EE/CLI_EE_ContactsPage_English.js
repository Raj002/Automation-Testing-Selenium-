/**
 * Created by n0238696 on 7/11/2017.
 */

var Getting_StartedPage = require('./../../PageObjects/PageObject_GettingStarted.js');
var ResuableFunction = require('./..//helpers/helpers.js');
var AboutYouPage = require('./../../PageObjects/PageObject_AboutYouPage.js');
var AboutAbsencePage = require('./../../PageObjects/PageObject_AboutYourAbsence.js');
var MedicalContactsPage = require('./../../PageObjects/PageObject_ContactsPage.js');
var ReviewPage = require('./../../PageObjects/PageObject_ER_ReviewPage.js');
//var ConfirmationPage = require('./../../PageObjects/PageObject_ConfirmationPage.js');



describe ('New ER CLI_Medical Contacts Page - Validations', function() {

    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;


    it('New CLI_Employee_Medical contacts Page - Validations - English', function () {

        ResuableFunction.MLC_Login();
        ResuableFunction.EmployeeCLI();
        Getting_StartedPage.clickStart("Employee-English");

        AboutYouPage.EnterEmployeeID('23259');
        AboutYouPage.EnterFirstName('Test');
        AboutYouPage.EnterLastName('Test');
        AboutYouPage.SelectGender('Female');
        AboutYouPage.EnterDateofBirth('01011987');
        AboutYouPage.EnterResdentialAddress1('123 Test');
        AboutYouPage.EnterResdentialcity('Dover');
        AboutYouPage.EnterPostalCode('23345');
        AboutYouPage.SelectState('AK');
        AboutYouPage.EnterPersonalEmail('TESTemail@test.com');
        AboutYouPage.EnterPersonalPhone('1231231234');
        AboutYouPage.SelectEmploymentState('AK');
        AboutYouPage.ClickContinue_ViewAboutYourAbsence();

        AboutAbsencePage.SelectLeaveorClaimCategory('Yes');
        AboutAbsencePage.SelectLeaveorClaimtype('Maternity');
        AboutAbsencePage.SelectDeliveryType('Vaginal');
        AboutAbsencePage.EnterDateQuestion_1('11/01/2017');
        AboutAbsencePage.EnterDateQuestion_2('11/01/2017');
        AboutAbsencePage.ClickContinue_ViewMedicalContacts("Employee-English");
        MedicalContactsPage.instructtext_med("Employee-English")


    }, 300000000);

});





//Import Page objects

//var cppageobj = require('./VSPageObjects.js');

/*var POAYC = require('./PageObject_ContactsPage.js');

//Take Screenshots
var fs = require('fs');
function writeScreenShot(data, filename) {
    var stream = fs.createWriteStream(filename);
    stream.write(new Buffer(data, 'base64'));
    stream.end();
}
describe ('Open URL in browser and validate contacts page labels', function() {


    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;


    //TestCase - 1 Contacts Page English -------------------------------------------------------------------------------
   it('New CLI_Contacts Page: Label/Header Validations', function () {

        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/');
        //element(by.css('[href="/cli/contacts"]')).click();

        //Verify Medical contacts header
        var medheader = POAYC.medheader.input.getText();
        expect(medheader).toEqual('Medical Contacts');

        //Verify static content below Medical contacts header
        var statictext = POAYC.statictext.input.getText();
        expect(statictext).toEqual('Please provide us with one of the contacts below to help expedite the processing of your absence request.');

        //Verify Treating Physician Information header
        var physicianinfoheader = POAYC.physicianinfoheader.input.getText();
        expect(physicianinfoheader).toEqual('Treating Physician Information');

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/Contactspage/English/Testcase1.png');
        });

    });

    //End of test case 1 ----------------------------------------------------------------------------------------------

   //TestCase - 2 ----------------------------------------------------------------------------------------------------
    it('New CLI_Contacts Page: Physician First name label', function () {


        //Verify Physician First name label
        var physicianfnamelabel = POAYC.physicianfnamelabel.input.getText();
        expect(physicianfnamelabel).toEqual("Physician's First Name");

        //Verify Physician First name- Optional  label
        var physicianfnameoplabel = POAYC.physicianfnameoplabel.input.getText();
        expect(physicianfnameoplabel).toEqual('(optional)');

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/Contactspage/English/Testcase2.png');
        });

    });

    //End of test case 2 ----------------------------------------------------------------------------------------------

    //TestCase - 3 ----------------------------------------------------------------------------------------------------
   it('New CLI_Contacts Page: Physician Last name label', function () {


        //Verify Physician Last name label
        var physicianlnamelabel = POAYC.physicianlnamelabel.input.getText();
        expect(physicianlnamelabel).toEqual("Physician's Last Name");

        //Verify Physician Last name- Optional  label
        var physicianlnameoplabel = POAYC.physicianlnameoplabel.input.getText();
        expect(physicianlnameoplabel).toEqual('(optional)');

    //Take screenshot
    browser.takeScreenshot().then(function (png) {
        writeScreenShot(png, './Screenshots/Contactspage/English/Testcase3.png');
    });

});
    //End of test case 3 ----------------------------------------------------------------------------------------------


    //TestCase - 4 ----------------------------------------------------------------------------------------------------
    it('New CLI_Contacts Page: Physician phone number label', function () {


        //Verify Physician phone number label
        var physicianpnumlabel = POAYC.physicianpnumlabel.input.getText();
        expect(physicianpnumlabel).toEqual("Physician's Phone Num");

        //Verify Physician phone number optional label
        var physicianpnumoplabel = POAYC.physicianpnumoplabel.input.getText();
        expect(physicianpnumoplabel).toEqual('(optional)');

        //Verify Physician phone number format lable
        var physicianpnumformatlabel = POAYC.physicianpnumformatlabel.input.getText();
        expect(physicianpnumformatlabel).toEqual('(###) ### - ####');

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/Contactspage/English/Testcase4.png');
        });

    });
    //End of test case 4 ----------------------------------------------------------------------------------------------

        //TestCase - 5 ----------------------------------------------------------------------------------------------------
        it('New CLI_Contacts Page: Hospital Name or Physicians Practice Name label', function () {

        //Verify Hospital Name or Physicians Practice Name label
        var physicianhnamelabel = POAYC.physicianhnamelabel.input.getText();
        expect(physicianhnamelabel).toEqual("Hospital Name or Physicians Practice Name");

        //Verify Hospital Name or Physicians Practice Name optional label
        var physicianhnameoplabel = POAYC.physicianhnameoplabel.input.getText();
        expect(physicianhnameoplabel).toEqual('(optional)');


        //Take screenshot
        browser.takeScreenshot().then(function (png) {
        writeScreenShot(png, './Screenshots/Contactspage/English/Testcase5.png');
        });

    });
    //End of test case 5 ----------------------------------------------------------------------------------------------


    //TestCase - 6 ----------------------------------------------------------------------------------------------------
         it('New CLI_Contacts Page: Hospital or Physicians Practice Phone Number labell', function () {

        //Verify Hospital or Physicians Practice Phone Number label
        var physicianhpnumlabel = POAYC.physicianhpnumlabel.input.getText();
        expect(physicianhpnumlabel).toEqual("Hospital or Physicians Practice Phone Number");

        //Verify Hospital or Physicians Practice Phone Number optional label
        var physicianhpnumoplabel = POAYC.physicianhpnumoplabel.input.getText();
        expect(physicianhpnumoplabel).toEqual('(optional)');

        //Verify Hospital or Physicians Practice Phone Number format label
        var physicianhpnumformatlabel = POAYC.physicianhpnumformatlabel.input.getText();
        expect(physicianhpnumformatlabel).toEqual("(###) ### - ####");


             //Take screenshot
             browser.takeScreenshot().then(function (png) {
                 writeScreenShot(png, './Screenshots/Contactspage/English/Testcase6.png');
             });

         });
    //End of test case 6 ----------------------------------------------------------------------------------------------

    //TestCase - 7 ----------------------------------------------------------------------------------------------------
         it('New CLI_Contacts Page: Button label validations', function () {

        //Verify Continue button label
        var continuebutton = POAYC.continuebutton.input.getText();
        expect(continuebutton).toEqual('Continue');

        //Verify Go back button label
        var gobackbutton = POAYC.gobackbutton.input.getText();
        expect(gobackbutton).toEqual('Go Back');

        //Verify Save for Later button label
        var saveforlaterbutton = POAYC.saveforlaterbutton.input.getText();
        expect(saveforlaterbutton).toEqual('Save for Later');

        //Verify Delete Application button label
        var deleteapplicationbutton = POAYC.deleteapplicationbutton.input.getText();
        expect(deleteapplicationbutton).toEqual('Delete Application');

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/Contactspage/English/Testcase7.png');
        });
         });
        //End of test case 7 -------------------------------------------------------------------------------------------

    //TestCase - 8 ----------------------------------------------------------------------------------------------------
    it("New CLI_Contacts Page: Data entry - Physician's First Name", function () {

            //Validate Physician's First Name - valid and invalid formats
        var physicianfnametbox = POAYC.physicianfnametbox.input;

            physicianfnametbox.sendKeys("FirstName-");
            expect(physicianfnametbox.getAttribute('value')).toEqual("FirstName-");
            physicianfnametbox.clear();
            physicianfnametbox.sendKeys("1234567890");
            expect(physicianfnametbox.getAttribute('value')).toEqual("");
            physicianfnametbox.clear();
            physicianfnametbox.sendKeys("!@#$%^&*()_+=<>?,./:");
            expect(physicianfnametbox.getAttribute('value')).toEqual("");
            physicianfnametbox.clear();
            physicianfnametbox.sendKeys(";'{}[]'");
            expect(physicianfnametbox.getAttribute('value')).toEqual("''");
            physicianfnametbox.clear();

    //Take screenshot
    browser.takeScreenshot().then(function (png) {
        writeScreenShot(png, './Screenshots/Contactspage/English/Testcase8.png');
    });
});
//End of test case 8 -------------------------------------------------------------------------------------------


    //TestCase - 9 ----------------------------------------------------------------------------------------------------
    it("New CLI_Contacts Page: Data entry - Physician's Last Name", function () {

            //Validate Physician's Last Name - valid and invalid formats
        var physicianlnametbox = POAYC.physicianlnametbox.input;

            physicianlnametbox.sendKeys("LastName-");
            expect(physicianlnametbox.getAttribute('value')).toEqual("LastName-");
            physicianlnametbox.clear();
            physicianlnametbox.sendKeys("1234567890");
            expect(physicianlnametbox.getAttribute('value')).toEqual("");
            physicianlnametbox.clear();
            physicianlnametbox.sendKeys("!@#$%^&*()_+=<>?,./:");
            expect(physicianlnametbox.getAttribute('value')).toEqual("");
            physicianlnametbox.clear();
            physicianlnametbox.sendKeys(";'{}[]'");
            expect(physicianlnametbox.getAttribute('value')).toEqual("''");
            physicianlnametbox.clear();

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/Contactspage/English/Testcase9.png');
        });
    });
//End of test case 9 -------------------------------------------------------------------------------------------


    //TestCase - 10 ----------------------------------------------------------------------------------------------------
        it("New CLI_Contacts Page: Data entry - Physician's Phone number", function () {

        //Validate Physician's Phone number - valid and invalid formats
        var physicianpnumtbox = POAYC.physicianpnumtbox.input;

            physicianpnumtbox.sendKeys("1234567890");
            expect(physicianpnumtbox.getAttribute('value')).toEqual("(123) 456-7890");
            physicianpnumtbox.clear();
            physicianpnumtbox.sendKeys("!@#$%^&*()");
            expect(physicianpnumtbox.getAttribute('value')).toEqual("(");
            physicianpnumtbox.clear();
            physicianpnumtbox.sendKeys("QWERTY{}|:<>?");
            expect(physicianpnumtbox.getAttribute('value')).toEqual("(");
            physicianpnumtbox.clear();

            //Take screenshot
            browser.takeScreenshot().then(function (png) {
                writeScreenShot(png, './Screenshots/Contactspage/English/Testcase10.png');
            });
        });
//End of test case 10 -------------------------------------------------------------------------------------------

    //TestCase - 11 ----------------------------------------------------------------------------------------------------
            it('New CLI_Contacts Page: Data entry - Hospital Name or Physicians Practice Name', function () {


        //Validate Hospital Name or Physicians Practice Name - valid and invalid formats
        var physicianhnametbox = POAYC.physicianhnametbox.input;

            physicianhnametbox.sendKeys("PhysicianName-");
            expect(physicianhnametbox.getAttribute('value')).toEqual("PhysicianName-");
            physicianhnametbox.clear();
            physicianhnametbox.sendKeys("1234567890");
            expect(physicianhnametbox.getAttribute('value')).toEqual("");
            physicianhnametbox.clear();
            physicianhnametbox.sendKeys("!@#$%^&*()_+=<>?,./:");
            expect(physicianhnametbox.getAttribute('value')).toEqual("");
            physicianhnametbox.clear();
            physicianhnametbox.sendKeys(";'{}[]'");
            expect(physicianhnametbox.getAttribute('value')).toEqual("''");
            physicianhnametbox.clear();

                //Take screenshot
                browser.takeScreenshot().then(function (png) {
                    writeScreenShot(png, './Screenshots/Contactspage/English/Testcase11.png');
                });
            });
//End of test case 11 -------------------------------------------------------------------------------------------

    //TestCase - 12 ----------------------------------------------------------------------------------------------------
            it('New CLI_Contacts Page: Data entry - Validate Hospital or Physicians Practice Phone Number', function () {



        //Validate Hospital or Physicians Practice Phone Number - valid and invalid formats
        var physicianhpnumtbox = POAYC.physicianhpnumtbox.input;
            physicianhpnumtbox.sendKeys("1234567890");
            expect(physicianhpnumtbox.getAttribute('value')).toEqual("(123) 456-7890");
            physicianhpnumtbox.clear();
            physicianhpnumtbox.sendKeys("!@#$%^&*()");
            expect(physicianhpnumtbox.getAttribute('value')).toEqual("(");
            physicianhpnumtbox.clear();
            physicianhpnumtbox.sendKeys("QWERTY{}|:<>?");
            expect(physicianhpnumtbox.getAttribute('value')).toEqual("(");
            physicianhpnumtbox.clear();

                //Take screenshot
                browser.takeScreenshot().then(function (png) {
                    writeScreenShot(png, './Screenshots/Contactspage/English/Testcase12.png');
                });
                browser.sleep(1000);
            });
//End of test case 12 -------------------------------------------------------------------------------------------


         //TestCase - 13 ----------------------------------------------------------------------------------------------------
        it('New CLI_Contacts Page: Data entry - valid value and continue ', function () {

        var physicianfnametbox = POAYC.physicianfnametbox.input;
        physicianfnametbox.sendKeys("Firstname");
        var physicianlnametbox = POAYC.physicianlnametbox.input;
        physicianlnametbox.sendKeys("Lastname");
        var physicianhpnumtbox = POAYC.physicianhpnumtbox.input;
        physicianhpnumtbox.sendKeys("1234567890");
        var physicianhnametbox = POAYC.physicianhnametbox.input;
        physicianhnametbox.sendKeys("PhysicianName");
        var physicianpnumtbox = POAYC.physicianpnumtbox.input;
        physicianpnumtbox.sendKeys("1234567890");
            //Click on Continue button
            element(by.buttonText('Continue')).click();
            //browser.sleep(1000);

        browser.sleep(1000);


    //Take screenshot
    browser.takeScreenshot().then(function (png) {
        writeScreenShot(png, './Screenshots/Contactspage/English/Testcase13.png');
    });
       });

    //End of test case 13 -------------------------------------------------------------------------------------------



    //TestCase - 14 ----------------------------------------------------------------------------------------------------
    it('New CLI_Contacts Page: Delete Button Validations ', function () {

        //Open NEW CLI in browser and go to About You Page
        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/');

        //Select About You Page
        element(by.css('[href="/cli/contacts"]')).click();

        //Verify the label name for Delete Button
        var deletebutton = POAYC.deleteapplicationbutton.input.getText();
        expect(deletebutton).toEqual('Delete Application');

        //Click Delete button
        deletebutton.click();

        //Verify pop up is displayed when Delete application is clicked
        expect(element(by.className('modal-content')).isDisplayed()).toBe(true);

        //Take screenshot
      /*  browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/Contactspage/English/Testcase14.png');
        });*/


 //   });

    //End of test case 14 -------------------------------------------------------------------------------------------

    //Beginning of test case 15 -------------------------------------------------------------------------------------------
    //To validate pop up when Delete button is clicked

   /* it('New CLI_Contacts Page: Pop up When Delete button is clicked', function() {

        //Verify Ok Button Label
        var okbutton = POAYC.okbutton.input.getText();
        expect(okbutton).toEqual('Ok');

        //Verify Cancel Button Label
        var cancelbutton = POAYC.cancelbutton.input.getText();
        expect(cancelbutton).toEqual('Cancel');

        var headermessage = POAYC.deletepopupheader.input.getText();
        expect(headermessage).toEqual('Delete Application');

        var deletemsg = POAYC.deletepopupmsg.input.getText();
        expect(deletemsg).toEqual('If you continue, all information you have entered will be removed. Would you like to continue?');

        //Take screenshot
        /*browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/Contactspage/English/Testcase15.png');
        });

    });

    //End of test case 15 -------------------------------------------------------------------------------------------

    it('New CLI_Contacts Page: Story#6674 - EE- English - Medical contacts page displays dynamically', function () {

      /*  browser.ignoreSynchronization = true;
        browser.waitForAngularEnabled(false);
        browser.get('https://dev1-lmbc-empr-mlc-gateway.pdc.np.paas.lmig.com/cli/employees');
        browser.sleep(15000);
        username.sendKeys('mcfarlandc');
        password.sendKeys('Test1234');
        element(by.buttonText('Login')).click();
        browser.sleep(90000);
        POCommonFunctions.enteraboutyouremppagefemale();

        POAYA.consecutivedaysradiobtny.input.click();

        //Select Bond with child option in drop down
        var leavetypelist = POAYA.leavetypelist1.input;
        leavetypelist.$('[value="OWN"]').click();
        browser.sleep(5000);

        element(by.css('[href="/cli/employee/contacts"]')).click();
        var medheader = POAYC.medheader.input.getText();
       /* expect(medheader).toEqual('Medical Contacts');

        POAYP.continuebutton.input.click();
        expect(POEER.medicalconlbl.input.isDisplayed()).toBe(true);
        browser.sleep(500);

        POEER.gobackbtn.input.click();
        browser.sleep(500);
        POEER.gobackbtn.input.click();

        //Select Bond with child option in drop down
        var leavetypelist = POAYA.leavetypelist1.input;
        leavetypelist.$('[value="OTH"]').click();
        browser.sleep(5000);

        element(by.css('[href="/cli/employee/contacts"]')).click();
        var medheader = POAYC.medheader.input.getText();
        expect(medheader).toEqual('Medical Contacts');
        browser.sleep(500);

        POAYP.continuebutton.input.click();
        browser.sleep(500);
        expect(POEER.medicalconlbl.input.isDisplayed()).toBe(true);
        browser.sleep(500);

        POEER.gobackbtn.input.click();
        browser.sleep(500);
        POEER.gobackbtn.input.click();

        //Select Bond with child option in drop down
        var leavetypelist = POAYA.leavetypelist1.input;
        leavetypelist.$('[value="MAT"]').click();
        browser.sleep(5000);

        element(by.css('[href="/cli/employee/contacts"]')).click();
        var medheader = POAYC.medheader.input.getText();
        expect(medheader).toEqual('Medical Contacts');
        browser.sleep(500);

        POAYP.continuebutton.input.click();
        browser.sleep(500);
        expect(POEER.medicalconlbl.input.isDisplayed()).toBe(true);
        browser.sleep(500);

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/AboutYourAbsencePage/Testcase1.png');
        });

});
});*/


