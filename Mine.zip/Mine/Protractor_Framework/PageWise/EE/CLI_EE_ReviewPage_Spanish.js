

//var POEER = require('./../PageObject_EEReviewPage.js');
//var POAYA = require('./../PageObject_AboutYourAbsence.js');
//var POAYP = require('./../PageObject_AboutYouPage.js');
//var POAYC = require('./../PageObject_ContactsPage.js');
//var POCommonFunctions = require('./../PageObject_Functions.js');
var Getting_StartedPage = require('./../../PageObjects/PageObject_GettingStarted.js');
var ResuableFunction = require('./..//helpers/helpers.js');
var AboutYouPage = require('./../../PageObjects/PageObject_AboutYouPage.js');
var AboutAbsencePage = require('./../../PageObjects/PageObject_AboutYourAbsence.js');
var MedicalContactsPage = require('./../../PageObjects/PageObject_ContactsPage.js');
var ReviewPage = require('./../../PageObjects/PageObject_ER_ReviewPage.js');

//Take Screenshots
var fs = require('fs');
function writeScreenShot(data, filename) {
    var stream = fs.createWriteStream(filename);
    stream.write(new Buffer(data, 'base64'));
    stream.end();
}

describe ('Open URL in browser and validate EE Review Page', function(){

//Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;
/*
    var lblempid = POEER.lblemployeeid.input;
    var lblfirstname = POEER.lblfirstname.input;
    var lblmiddle = POEER.lblmiddle.input;
    var lbllastname = POEER.lbllastname.input;
    var lblgender = POEER.lblgender1.input;
    var lbldob = POEER.lbldob.input;
    var lblpphone = POEER.lblpphone.input;
    var lblpemail = POEER.lblpemail.input;
    var lblpmethod = POEER.lblprefmethod.input;
    var lblres1 = POEER.lblresaddress1.input;
    var lblres2 = POEER.lblresaddress2.input;
    var lblrescity = POEER.lblrescity.input;
    var lblcountry = POEER.lblcountry.input;
    var lblpostalcode = POEER.lblpostalcode.input;
    var lblcountryofemploy = POEER.lblcounofemploy.input;
    var lblstateemploy  = POEER.lblstateofemploy.input;
    var lblresstate = POEER.lblstate.input;

    var txtempid = POEER.txtemployeeid.input;
    var txtfirstname = POEER.txtfirstname.input;
    var txtmiddlename = POEER.txtmiddle.input;
    var txtlastname = POEER.txtlastname.input;
    var txtgender = POEER.txtgender1.input;
    var txtdob = POEER.txtdob.input;
    var txtpphone = POEER.txtpphone.input;
    var txtpemail = POEER.txtpemail.input;
    var txtpmethod = POEER.txtprefmethod.input;
    var txtresaddr1 = POEER.txtresaddress1.input;
    var txtresaddr2 = POEER.txtresaddress2.input;
    var txtrescity = POEER.txtrescity.input;
    var txtcountry = POEER.txtcountry.input;
    var txtpostalcode = POEER.txtpostalcode.input;
    var txtecountry = POEER.txtcounofemploy.input;
    var txtfax1 = POEER.txtfax.input;
    var txtsemploy = POEER.txtstateofemploy.input;
    var txtstate = POEER.txtstate.input;

    var dob1 = POAYP.dobtbox1.input;
    var pphone1 = POAYP.ppphonetbox1.input;



    var empid = POAYP.empidtbox.input;
    var ssntext = POAYP.txtssn.input;
    var firstname = POAYP.fnametbox.input;
    var lastname = POAYP.lnametbox.input;
    var dob = POAYP.dobtbox.input;
    var preferedphone = POAYP.ppphonetbox.input;
    var prefmail = POAYP.ppemailtbox.input;
    var resaddr1 = POAYP.resaddrtbox1.input;
    var rescity = POAYP.rescitytbox.input;
    var statelist = POAYP.resstatelist.input;
    var postalcode = POAYP.postalcdetbox.input;
    var stateemploy = POAYP.stateofemploylist.input;
    var middlename = POAYP.mnametbox.input;
    var resaddr2 = POAYP.resaddrtbox2.input;
    var txtfax1 = POAYP.txtfax.input;
    var illness = POAYA.illness.input;

    var leaveclaimlist = POAYA.leavetypelist.input;
    var circumstance = POAYA.circumstance.input;
    var delivery = POAYA.delivered.input;
    var deliverydate = POAYA.deliverydate.input;
    var lastworkingdate = POAYA.lastdate.input;
    var medicalcontactpage = POAYA.medicalcontactspage.input;
    var medicalheader = POAYA.medicalheader.input;
    var lblhavedelivered = POAYA.lbldelivered.input;

    var physicianfnametbox = POAYC.physicianfnametbox.input;
    var physicianlnametbox = POAYC.physicianlnametbox.input;
    var physicianpnumtbox = POAYC.physicianpnumtbox.input;
    var physicianhnametbox = POAYC.physicianhnametbox.input;
    var physicianhpnumtbox = POAYC.physicianhpnumtbox.input;

    var lblphyfirstname = POEER.lblphyfirstname.input;
    var lblhosphyname = POEER.lblhosphyfirstname.input;
    var lblphylastname = POEER.lblphylastname.input;
    var lblhosphyphone = POEER.lblhosphyphonenumber.input;
    var lblphyphone = POEER.lblphyphonenumber.input;

    var txtphyfirstname = POEER.txtphyfirstname.input;
    var txthosphyname = POEER.txthosphyfirstname.input;
    var txtphylastname = POEER.txtphylastname.input;
    var txthosphyphone = POEER.txthosphyphonenumber.input;
    var txtphyphone = POEER.txtphyphonenumber.input;
    var txtfax = POEER.txtfax.input;
    var fraudstmntheader = POEER.fraudstmntheader.input;

    */
    var flfraudstmt = 'Toda aquella persona que deliberadamente y con el fin de defraudar a una compañía de seguros o a otra persona, presente una solicitud de seguro o una declaración de reclamo que contenga información falsa u oculte información concerniente a hechos fundamentales con el objeto de engañar, cometerá un acto fraudulento contra el seguro, lo cual es un crimen, y quedará sujeta a sanciones penales y civiles.'
    var txtaddlninfspn  = 'Por favor revise la información de abajo antes de presentar su ausencia. Para realizar cualquier cambio, seleccione "Editar" para volver a la sección correspondiente.';



    /******************** Beginning of Test Case I - Verify Review page Links and Sections ******************************/

    /*it('New CLI_Review Page Link and Sections for EE', function() {

        //Open NEW CLI in browser and go to Review Page
        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/cli');

        element(by.className('link')).click();
        element(by.css('[href="/cli/absence"]')).click();
        browser.sleep(100);

        var leaveclaimlist = POAYA.leavetypelist.input;
        leaveclaimlist.$('[value = "OWN"]').click();

        element(by.css('[href="/cli/review"]')).click();
        browser.sleep(5000);

        //Identifying the current Date and Time

        var timestamp;
        var today = new Date();
        var month = today.getMonth() + 1;
        timestamp = today.getDate()+ "_" + month + "_" + today.getFullYear()+ "_"+today.getHours()+"_"+ today.getMinutes()+"_"+today.getSeconds();
        var screenshot;
        screenshot = "./Screenshots/EE/ReviewPage/English/";


        //Validate Review Page header label
       var reviewheader = POEER.reviewheader.input.getText();
        expect(reviewheader).toEqual('Revisión');

        //Validate the Instructional dynamic text
        var instext = POEER.instext.input.getText();
       expect(instext).toContain('Con el texto instructivo (el texto todavía está por determinar)');

        //Validate the Get Help link is displayed
        var gethelplnk = POEER.gethelplnk.input.getText();
        expect(gethelplnk).toEqual('!!Get Help!!');

        //Verify GetHelp pop up is displayed
        POEER.gethelplnk.input.click();
        expect(POEER.gethelplnk.input.isDisplayed()).toBe(true);

        element(by.buttonText('Cerrar')).click();

        //Validate the About You label
        var abtyoulbl = POEER.abtyoulbl.input.getText();
        expect(abtyoulbl).toEqual('Acerca de usted');

        //Validate the About Your Absence label
        var abtyouabsencelbl = POEER.abtyouabsencelbl.input.getText();
        expect(abtyouabsencelbl).toEqual('Acerca de su ausencia');

        //Verify accordion for About Your Absence is not expanded
        expect(POEER.abtyouacct.input.isPresent()).toBeFalsy();

        //Validate the Medical Contacts label
        var medicalconlbl = POEER.medicalconlbl.input.getText();
        expect(medicalconlbl).toEqual('Contactos Médicos');

        //Verify accordion for Medical Contacts is not expanded
        expect(POEER.medcont.input.isPresent()).toBeFalsy();



        //Click the About You Edit label
        var abtyoueditlnk = POEER.abtyoueditlnk.input.getText();
        expect(abtyoueditlnk).toEqual('Editar');


        //Verify About You page is displayed when About You Edit link is clicked
        abtyoueditlnk.click();
        expect(POEER.abtyouhdr.input.isDisplayed()).toBe(true);
        expect(POEER.abtyouhdr.input.getText()).toEqual('Retrieve Your Information');
        browser.sleep(1000);

        element(by.css('[href="/cli/review"]')).click();



        //Click the About Your Absence Edit label
        var abtyouabseditlnk = POEER.abtyouabseditlnk.input.getText();
        expect(abtyouabseditlnk).toEqual('Editar');

        //Verify About Your Absence page is displayed when About Your Absence Edit link is clicked
        abtyouabseditlnk.click();
        expect(POEER.abtyourabshdr.input.isDisplayed()).toBe(true);
        expect(POEER.abtyourabshdr.input.getText()).toEqual('Acerca de su ausencia');
        browser.sleep(1000);

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, screenshot+"Testcase1_Screenshot4"+"_"+timestamp+".png");
        });

        element(by.css('[href="/cli/review"]')).click();
        browser.sleep(5000);

        //Click the Medical Contacts Edit label
        var medconeditlnk = POEER.medconeditlnk.input.getText();
        expect(medconeditlnk).toEqual('Editar');

        medconeditlnk.click();
        expect(POEER.medconhdr.input.isDisplayed()).toBe(true);
        expect(POEER.medconhdr.input.getText()).toEqual('Contactos medicos');


        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, screenshot+"Testcase1_Screenshot5"+"_"+timestamp+".png");
        });


        element(by.css('[href="/cli/review"]')).click();
        browser.sleep(100);

        //Validate the Submit button is displayed
        var submitbutton = POEER.submitspanbutton.input.getText();
        expect(submitbutton).toEqual('Enviar');

        //Validate the go Back button is displayed
        var gobackbtn = element(by.buttonText('Volver'));
        expect(gobackbtn.getText()).toEqual('Volver');

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, screenshot+"Testcase1_Screenshot6"+"_"+timestamp+".png");
        });




        //Verify the accordian format when "About your Employee Absence section is clicked
        abtyouabsencelbl.click();
        expect(POEER.abtyouaccf.input.isPresent()).toBeTruthy();
        expect(POEER.medconaccf.input.isPresent()).toBeTruthy();
        expect(POEER.abtyourabsacct.input.isPresent()).toBeTruthy();
        browser.sleep(100);

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, screenshot+"Testcase1_Screenshot8"+"_"+timestamp+".png");
        });


        //Verify the accordion format when Medical Information section is clicked
        medicalconlbl.click();
        expect(POEER.abtyouacct.input.isPresent()).toBeFalsy();
        expect(POEER.medcont.input.isPresent()).toBeTruthy();
        expect(POEER.abtyourabsacct.input.isPresent()).toBeFalsy();
        browser.sleep(100);

        abtyoulbl.click();
        //Verify the accordian format when About You section
        expect(POEER.abtyouacct.input.isPresent()).toBeTruthy();
        expect(POEER.abtyourabsacct.input.isPresent()).toBeFalsy();
        expect(POEER.medcont.input.isPresent()).toBeFalsy();
        browser.sleep(100);


        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, screenshot+"Testcase1_Screenshot9"+"_"+timestamp+".png");
        });






    });


    //Test Case 2 Verify label validations for About you page

   it('New CLI_Review Page : Verify Label Validations when Employee ID is selected ', function() {

        //Open NEW CLI in browser and go to Review Page
        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/cli');
        //Click the 'En Espanol' link

        //Click About You Page
        element(by.css('[href="/cli/claimant"]')).click();

        empid.sendKeys('12345');

        element(by.css('[href="/cli/review"]')).click();

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/Spanish/Testcase3_i.png');
        });

        //Validations for the story 6333

        //Verify the lables displayed are correct

        expect(lblempid.getText()).toEqual('Identificación del Empleado');
        expect(lblfirstname.getText()).toEqual('Primer Nombre');
        expect(lblmiddle.getText()).toEqual('Inicial del Segundo Nombre');
        expect(lbllastname.getText()).toEqual('Apellido');
        expect(lblgender.getText()).toEqual('Sexo');
        expect(lbldob.getText()).toEqual('Fecha de Nacimiento');
        expect(lblpphone.getText()).toEqual('Teléfono Personal Preferido'  );
        expect(lblpemail.getText()).toEqual('Correo electrónico personal preferido'  );
        expect(lblpmethod.getText()).toEqual('Método preferido para correspondencia de carácter no confidencial' );
        expect(lblres1.getText()).toEqual('Dirección Residencial 1' );
        expect(lblres2.getText()).toEqual('Dirección Residencial 2' );
        expect(lblrescity.getText()).toEqual('Ciudad' );
        expect(lblcountry.getText()).toEqual('Pais');
        expect(lblpostalcode.getText()).toEqual('Código Posta' );
        expect(lblcountryofemploy.getText()).toEqual('País de Empleo' );







    });

    //Test Case  3 when SSN is selected in Aboout you page

    it('New CLI_Review Page : Verify Label Validations when SSN is selected ', function() {

        //Open NEW CLI in browser and go to Review Page
        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/cli');

        //Click About You Page
        element(by.css('[href="/cli/claimant"]')).click();

        POAYP.ssnradio.input.click();

        ssntext.sendKeys('984575674');

        element(by.css('[href="/cli/review"]')).click();

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/English/Testcase2_i.png');
        });

        //Validations for the story 6333

        //Verify the lables displayed are correct

        expect(lblempid.getText()).toEqual('Número de Seguro Social');
        expect(lblfirstname.getText()).toEqual('Primer Nombre');
        expect(lblmiddle.getText()).toEqual('Inicial del Segundo Nombre');
        expect(lbllastname.getText()).toEqual('Apellido');
        expect(lblgender.getText()).toEqual('Sexo');
        expect(lbldob.getText()).toEqual('Fecha de Nacimiento');
        expect(lblpphone.getText()).toEqual('Teléfono Personal Preferido'  );
        expect(lblpemail.getText()).toEqual('Correo electrónico personal preferido'  );
        expect(lblpmethod.getText()).toEqual('Método preferido para correspondencia de carácter no confidencial' );
        expect(lblres1.getText()).toEqual('Dirección Residencial 1' );
        expect(lblres2.getText()).toEqual('Dirección Residencial 2' );
        expect(lblrescity.getText()).toEqual('Ciudad' );
        expect(lblcountry.getText()).toEqual('Pais');
        expect(lblpostalcode.getText()).toEqual('Código Posta' );
        expect(lblcountryofemploy.getText()).toEqual('País de Empleo' );



    });

    //Test Case  4 verify the values entered are correct when Employee ID is selected

   it('New CLI_Review Page : About You Section, Medical contacts section - Validation of Labels & Textbox entries when Gender is Female with Employee ID - Maternity flow ', function() {

        //Open NEW CLI in browser and go to Review Page
        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/cli');

        element(by.css('[href="/cli/claimant"]')).click();

        POAYP.empidradio.input.click();

        //Enter valid value for Employee ID
        empid.sendKeys('12345');
        firstname.sendKeys('TestFirstname');
        lastname.sendKeys('TestLastName');
        middlename.sendKeys('M');

        dob.click();
        dob1.sendKeys('11/12/1975');
        POAYP.rbtnfemale.input.click();

        //Enter Valid value for  Residential Address1
        resaddr1.sendKeys('Testaddress1');
        resaddr2.sendKeys('testAddress2');

        //Enter Valid value for  Residential City
        rescity.sendKeys('Testcity');

        //Select any Residential State
        statelist.$('[value = "AK"]').click();

        //Enter Valid value for  Postal Code
        postalcode.sendKeys('78901');


        //Enter Valid value for  Preferred phone number
        preferedphone.click();
        pphone1.sendKeys('9089089098')

        //Enter Valid value for  Preferred email
        prefmail.sendKeys('test@tst.com');

        //Select any value for State of Employment
        stateemploy.$('[value = "AK"]').click();

        var eid = empid.getAttribute('value');
        var fname = firstname.getAttribute('value');
        var lname = lastname.getAttribute('value');
        var vdob = dob1.getAttribute('value');
        var vphone = pphone1.getAttribute('value');
        var vmail = prefmail.getAttribute('value');
        var vresaddr1 = resaddr1.getAttribute('value');
        var vresaddr2 = resaddr2.getAttribute('value');
        var vrescity = rescity.getAttribute('value');
        var vpostal = postalcode.getAttribute('value');



        //Click Continue button
        POAYP.continuebuttonspanish.input.click();

        //Verify About your Absence is displayed
        var aboutyourabsencehdr = POAYA.absenceheader.input.getText();
        expect(aboutyourabsencehdr).toEqual('Acerca de su ausencia');

        //Select the Continous radio button
        POAYA.consecutivedaysradiobtny.input.click();

        leaveclaimlist.$('[value = "MAT"]').click();
        browser.sleep(100);

        //Verify next question displayed after Maternity is selected is "have you delivered"
        expect(lblhavedelivered.getText()).toEqual('¿Ya dio a luz?');

        //  circumstance.$('[value = "P"]').click();
        // browser.sleep(100);
        delivery.$('[value = "Yes, C-Section"]').click();
        browser.sleep(100);


        deliverydate.sendKeys('07/10/2017');
        browser.sleep(100);
        lastworkingdate.sendKeys('07/09/2017');
        browser.sleep(100);

        element(by.buttonText('Continuar')).click();
        browser.sleep(100);

        //Enter values for Contacts page
        physicianfnametbox.sendKeys("Phyfirstname");
        var pfname = physicianfnametbox.getAttribute('value');

        physicianlnametbox.sendKeys("PhyLastName");
        var plname = physicianlnametbox.getAttribute('value');

        physicianpnumtbox.sendKeys("1234567890");
        var ppnum = physicianpnumtbox.getAttribute('value');

        physicianhnametbox.sendKeys("PhysicianhospName");
        var phname = physicianhnametbox.getAttribute('value');

        physicianhpnumtbox.sendKeys("1980899999");
        var phnum = physicianhpnumtbox.getAttribute('value');

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/English/Testcase4_ii.png');
        });
        element(by.buttonText('Continuar')).click();
        browser.sleep(100);

        //Verify the Review page values
        expect(txtempid.getText()).toEqual(eid);
        expect(txtfirstname.getText()).toEqual(fname);
        expect(txtmiddlename.getText()).toEqual('M');
        expect(txtlastname.getText()).toEqual(lname);
        expect(txtgender.getText()).toEqual('female');
        expect(txtdob.getText()).toEqual(vdob);
        expect(txtpphone.getText()).toEqual(vphone);
        expect(txtpemail.getText()).toEqual(vmail);
        expect(txtpmethod.getText()).toEqual('Email');
        expect(txtresaddr1.getText()).toEqual(vresaddr1);
        expect(txtresaddr2.getText()).toEqual(vresaddr2);
        expect(txtrescity.getText()).toEqual(vrescity);
        expect(txtcountry.getText()).toEqual('United States');
        expect(txtecountry.getText()).toEqual('United States');
        expect(txtpostalcode.getText()).toEqual(vpostal);


        var medicalconlbl = POEER.medicalconlbl.input.getText();
        medicalconlbl.click();

        expect(lblphyfirstname.getText()).toEqual("Nombre del Médico");
        expect(lblhosphyname.getText()).toEqual("Nombre del hospital o nombre de la práctica de los médicos");
        expect(lblphylastname.getText()).toEqual("Apellido del Médico");
        expect(lblhosphyphone.getText()).toEqual("Número de teléfono de la práctica del hospital o de los médicos");
        expect(lblphyphone.getText()).toEqual("Número de teléfono del médico");

        expect(txtphyfirstname.getText()).toEqual(pfname);
        expect(txthosphyname.getText()).toEqual(phname);
        expect(txtphylastname.getText()).toEqual(plname);
        expect(txthosphyphone.getText()).toEqual(phnum);
        expect(txtphyphone.getText()).toEqual(ppnum);



    });
    //Test Case  5 verify the values entered are correct when SSN is selected

   it('New CLI_Review Page About You Section, Medical contacts section - Validation of Labels & Textbox entries when Gender is Male,SSN,Mail selected for Pref Method - MOC flow', function() {


        //Open NEW CLI in browser and go to Review Page
        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/cli');

        //Click About You Page
        element(by.css('[href="/cli/claimant"]')).click();

       POAYP.ssnradio.input.click();

       ssntext.sendKeys('984575674');
       var ssn = ssntext.getAttribute('value');

       firstname.sendKeys('TestFirstname');
       var fname = firstname.getAttribute('value');

       middlename.sendKeys('M');


       lastname.sendKeys('TestLastName');
       var lname = lastname.getAttribute('value');



       //Select Gender
       POAYP.rbtnmale.input.click();
       dob.click();
       dob1.sendKeys('11/12/1975');
       var vdob = dob1.getAttribute('value');

       preferedphone.click();
       pphone1.sendKeys('9089089098')
       var vphone = pphone1.getAttribute('value');

       prefmail.sendKeys('test@tst.com');
       var vmail = prefmail.getAttribute('value');

       POAYP.prefmethodrbtnmail.input.click();

       resaddr1.sendKeys('Testaddress1');
       var vresaddr1 = resaddr1.getAttribute('value');

       resaddr2.sendKeys('testAddress2');
       var vresaddr2 = resaddr2.getAttribute('value');

       rescity.sendKeys('Testcity');
       var vrescity = rescity.getAttribute('value');

       statelist.$('[value = "AK"]').click();

       postalcode.sendKeys('78901');
       var vpostal = postalcode.getAttribute('value');

       stateemploy.$('[value = "AK"]').click();

        //Click Continue button
        POAYP.continuebuttonspanish.input.click();

        //Verify About your Absence is displayed
        var aboutyourabsencehdr = POAYA.absenceheader.input.getText();
        expect(aboutyourabsencehdr).toEqual('Acerca de su ausencia');

        //Select the Continous radio button
        POAYA.consecutivedaysradiobtny.input.click();

        leaveclaimlist.$('[value = "OWN"]').click();
        browser.sleep(100);
        circumstance.$('[value = "S"]').click();
        browser.sleep(100);

        lastworkingdate.sendKeys('07/09/2017');
        browser.sleep(100);

        illness.sendKeys('07/09/2017');
        browser.sleep(100);


        element(by.buttonText('Continuar')).click();
        browser.sleep(100);

        //Enter values for Contacts page
        physicianfnametbox.sendKeys("Phyfirstname");
        var pfname = physicianfnametbox.getAttribute('value');

        physicianlnametbox.sendKeys("PhyLastName");
        var plname = physicianlnametbox.getAttribute('value');

        physicianpnumtbox.sendKeys("1234567890");
        var ppnum = physicianpnumtbox.getAttribute('value');

        physicianhnametbox.sendKeys("PhysicianhospName");
        var phname = physicianhnametbox.getAttribute('value');

        physicianhpnumtbox.sendKeys("1980899999");
        var phnum = physicianhpnumtbox.getAttribute('value');

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/English/Testcase4_ii.png');
        });
        element(by.buttonText('Continuar')).click();
        browser.sleep(100);


        //Verify the Review page values
        expect(txtempid.getText()).toContain('5674');
        expect(txtfirstname.getText()).toEqual(fname);
        expect(txtmiddlename.getText()).toEqual('M');
        expect(txtlastname.getText()).toEqual(lname);
        expect(txtgender.getText()).toEqual('male');
        expect(txtdob.getText()).toEqual(vdob);
        expect(txtpphone.getText()).toEqual(vphone);
        expect(txtpemail.getText()).toEqual(vmail);
        expect(txtpmethod.getText()).toEqual('Mail');
        expect(txtresaddr1.getText()).toEqual(vresaddr1);
        expect(txtresaddr2.getText()).toEqual(vresaddr2);
        expect(txtrescity.getText()).toEqual(vrescity);
        expect(txtcountry.getText()).toEqual('United States');
        expect(txtecountry.getText()).toEqual('United States');
        expect(txtpostalcode.getText()).toEqual(vpostal);

        var medicalconlbl = POEER.medicalconlbl.input.getText();
        medicalconlbl.click();

        //Medical contacts section validation as a part of story 6335

        expect(lblphyfirstname.getText()).toEqual("Nombre del Médico");
        expect(lblhosphyname.getText()).toEqual("Nombre del hospital o nombre de la práctica de los médicos");
        expect(lblphylastname.getText()).toEqual("Apellido del Médico");
        expect(lblhosphyphone.getText()).toEqual("Número de teléfono de la práctica del hospital o de los médicos");
        expect(lblphyphone.getText()).toEqual("Número de teléfono del médico");

        expect(txtphyfirstname.getText()).toEqual(pfname);
        expect(txthosphyname.getText()).toEqual(phname);
        expect(txtphylastname.getText()).toEqual(plname);
        expect(txthosphyphone.getText()).toEqual(phnum);
        expect(txtphyphone.getText()).toEqual(ppnum);




    });

    //Test Case  6 verify the values entered are correct when Fax is selected

   it('New CLI_Review Page - About you section : Verify textbox entries when SSN and Fax selected for Pref Method - Country United States', function() {

            //Open NEW CLI in browser and go to Review Page
            browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/cli');


               //Click About You Page
               element(by.css('[href="/cli/claimant"]')).click();

               POAYP.ssnradio.input.click();

               ssntext.sendKeys('984575674');
               var ssn = ssntext.getAttribute('value');

               firstname.sendKeys('TestFirstname');
               var fname = firstname.getAttribute('value');

               middlename.sendKeys('M');


               lastname.sendKeys('TestLastName');
               var lname = lastname.getAttribute('value');



               //Select Gender
               POAYP.rbtnmale.input.click();
               dob.click();
               dob1.sendKeys('11/12/1975');
               var vdob = dob1.getAttribute('value');

               preferedphone.click();
               pphone1.sendKeys('9089089098')
               var vphone = pphone1.getAttribute('value');

               prefmail.sendKeys('test@tst.com');
               var vmail = prefmail.getAttribute('value');

               POAYP.prefmethodrbtnfax.input.click();

               POAYP.faxtextbox.input.click();
               txtfax1.sendKeys('8908977896');
               var valfax = txtfax1.getAttribute('value');




               resaddr1.sendKeys('Testaddress1');
               var vresaddr1 = resaddr1.getAttribute('value');

               resaddr2.sendKeys('testAddress2');
               var vresaddr2 = resaddr2.getAttribute('value');

               rescity.sendKeys('Testcity');
               var vrescity = rescity.getAttribute('value');

               statelist.$('[value = "OH"]').click();

               postalcode.sendKeys('78901');
               var vpostal = postalcode.getAttribute('value');

               stateemploy.$('[value = "AK"]').click();

               //Take screenshot
               browser.takeScreenshot().then(function (png) {
                   writeScreenShot(png, './Screenshots/EE/ReviewPage/English/Testcase4_i.png');
               });

               browser.sleep(100);

               element(by.css('[href="/cli/review"]')).click();

               //Take screenshot
               browser.takeScreenshot().then(function (png) {
                   writeScreenShot(png, './Screenshots/EE/ReviewPage/English/Testcase4_ii.png');
               });
               var lblfax = POEER.lblfax.input;
               //Verify the Review page values
               expect(txtempid.getText()).toContain('5674');
               expect(txtfirstname.getText()).toEqual(fname);
               expect(txtmiddlename.getText()).toEqual('M');
               expect(txtlastname.getText()).toEqual(lname);
               expect(txtgender.getText()).toEqual('male');
               expect(txtdob.getText()).toEqual(vdob);
               expect(txtpphone.getText()).toEqual(vphone);
               expect(txtpemail.getText()).toEqual(vmail);
               expect(txtpmethod.getText()).toEqual('Fax');
               expect(lblfax.getText()).toEqual('Número de Fax');
               expect(txtfax.getText()).toEqual(valfax);
               expect(txtresaddr1.getText()).toEqual(vresaddr1);
               expect(txtresaddr2.getText()).toEqual(vresaddr2);
               expect(txtrescity.getText()).toEqual(vrescity);
               expect(txtcountry.getText()).toEqual('United States');
               expect(txtecountry.getText()).toEqual('United States');
               expect(lblstateemploy.getText()).toEqual('Estado de Empleo');
               expect(txtsemploy.getText()).toEqual('Alaska');

               expect(lblresstate.getText()).toEqual('Estado de Residencia');
               expect(txtstate.getText()).toEqual('Ohio');

               expect(txtpostalcode.getText()).toEqual(vpostal);


    });

//Test Case  8 verify the values entered are correct when Fax is selected

   it('New CLI_Review Page - About you section : Verify textbox entries when SSN and Fax selected for Pref Method - Country Canada', function() {

        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/cli');
        element(by.css('[href="/cli/claimant"]')).click();

       POAYP.ssnradio.input.click();

       ssntext.sendKeys('984575674');
       var ssn = ssntext.getAttribute('value');

       firstname.sendKeys('TestFirstname');
       var fname = firstname.getAttribute('value');

       middlename.sendKeys('M');


       lastname.sendKeys('TestLastName');
       var lname = lastname.getAttribute('value');



       //Select Gender
       POAYP.rbtnmale.input.click();
       dob.click();
       dob1.sendKeys('11/12/1975');
       var vdob = dob1.getAttribute('value');

       preferedphone.click();
       pphone1.sendKeys('9089089098')
       var vphone = pphone1.getAttribute('value');

       prefmail.sendKeys('test@tst.com');
       var vmail = prefmail.getAttribute('value');

       POAYP.prefmethodrbtnfax.input.click();


       POAYP.faxtextbox.input.click();
       txtfax1.sendKeys('8908977896');
       var valfax = txtfax1.getAttribute('value');


       var lblfax = POEER.lblfax.input;

       resaddr1.sendKeys('Testaddress1');
       var vresaddr1 = resaddr1.getAttribute('value');

       resaddr2.sendKeys('testAddress2');
       var vresaddr2 = resaddr2.getAttribute('value');

       rescity.sendKeys('Testcity');
       var vrescity = rescity.getAttribute('value');
       var country = POAYP.empcountrylist1.input;
       country.$('[value = "CAN"]').click();

       statelist.$('[value = "AB"]').click();

       postalcode.sendKeys('a1a1a1');
       var vpostal = postalcode.getAttribute('value');
       var ecountry = POAYP.empstatecountrylist1.input;
       ecountry.$('[value = "CAN"]').click();


       stateemploy.$('[value = "BC"]').click();


       //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/Spanish/Testcase8_i.png');
        });

        browser.sleep(100);

        element(by.css('[href="/cli/review"]')).click();

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/Spanish/Testcase8_ii.png');
        });

        //Verify the Review page values
        expect(txtempid.getText()).toContain('5674');
        expect(txtfirstname.getText()).toEqual(fname);
        expect(txtmiddlename.getText()).toEqual('M');
        expect(txtlastname.getText()).toEqual(lname);
        expect(txtgender.getText()).toEqual('male');
        expect(txtdob.getText()).toEqual(vdob);
        expect(txtpphone.getText()).toEqual(vphone);
        expect(txtpemail.getText()).toEqual(vmail);
        expect(txtpmethod.getText()).toEqual('Fax');
        expect(lblfax.getText()).toEqual('Número de Fax');
        expect(txtfax1.getText()).toEqual(valfax);
        expect(txtresaddr1.getText()).toEqual(vresaddr1);
        expect(txtresaddr2.getText()).toEqual(vresaddr2);
        expect(txtrescity.getText()).toEqual(vrescity);
        expect(txtcountry.getText()).toEqual('Canada');
        expect(txtecountry.getText()).toEqual('Canada');
        expect(lblstateemploy.getText()).toEqual('Provincia de Empleo' );
        expect(txtsemploy.getText()).toEqual('British Columbia');

        expect(lblresstate.getText()).toEqual('Provincia de Residencia' );
        expect(txtstate.getText()).toEqual('Alberta');

        expect(txtpostalcode.getText()).toEqual(vpostal);




    });

    //Test Case  9 verify the values entered are correct when country is other than US and Canada

   it('New CLI_Review Page - About you section: Verify values when country is other than United States and Canada', function() {

        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/cli');
        element(by.css('[href="/cli/claimant"]')).click();

            POAYP.ssnradio.input.click();

            ssntext.sendKeys('984575674');
            var ssn = ssntext.getAttribute('value');

            firstname.sendKeys('TestFirstname');
            var fname = firstname.getAttribute('value');

            middlename.sendKeys('M');


            lastname.sendKeys('TestLastName');
            var lname = lastname.getAttribute('value');



            //Select Gender
            POAYP.rbtnmale.input.click();
            dob.click();
            dob1.sendKeys('11/12/1975');
            var vdob = dob1.getAttribute('value');

            preferedphone.click();
            pphone1.sendKeys('9089089098')
            var vphone = pphone1.getAttribute('value');

            prefmail.sendKeys('test@tst.com');
            var vmail = prefmail.getAttribute('value');



            resaddr1.sendKeys('Testaddress1');
            var vresaddr1 = resaddr1.getAttribute('value');

            resaddr2.sendKeys('testAddress2');
            var vresaddr2 = resaddr2.getAttribute('value');

            rescity.sendKeys('Testcity');
            var vrescity = rescity.getAttribute('value');
            var country = POAYP.empcountrylist1.input;
            country.$('[value = "BTN"]').click();



            postalcode.sendKeys('78901');
            var vpostal = postalcode.getAttribute('value');
            var ecountry = POAYP.empstatecountrylist1.input;
            ecountry.$('[value = "BTN"]').click();



    //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/Spanish/Testcase9_i.png');
        });

        browser.sleep(100);

        element(by.css('[href="/cli/review"]')).click();

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/Spanish/Testcase9_ii.png');
        });



        //Verify the Review page values
        expect(txtempid.getText()).toContain('5674');
        expect(txtfirstname.getText()).toEqual(fname);
        expect(txtresaddr1.getText()).toEqual(vresaddr1);
        expect(txtmiddlename.getText()).toEqual('M');
        expect(txtresaddr2.getText()).toEqual(vresaddr2);
        expect(txtlastname.getText()).toEqual(lname);
        expect(txtrescity.getText()).toEqual(vrescity);
        expect(txtgender.getText()).toEqual('male');

        var odob = POEER.otxtdob.input;
        expect(odob.getText()).toEqual(vdob);

        var ocountry = POEER.ocountry.input;
        expect(ocountry.getText()).toEqual('Bhutan');

        var ophone = POEER.ophone.input;
        expect(ophone.getText()).toEqual(vphone);

        var opostal = POEER.opostalcode.input;
        expect(opostal.getText()).toEqual(vpostal);

        var oemail = POEER.opemail.input;
        expect(oemail.getText()).toEqual(vmail);

        var oecountry = POEER.oecountry.input;
        expect(oecountry.getText()).toEqual('Bhutan');

    });
    it('New CLI_Employee Review Page_Spanish: Story#6874 - Fraud statement validation in Review page for PA state', function() {

        //Open NEW CLI in browser and go to Review Page
        browser.get('	https://dev1-lmbc-empr-mlc-gateway.pdc.np.paas.lmig.com/cli/employee');

        browser.sleep(3000);

        element(by.className('link')).click();

        //Select About You Page
        element(by.css('[href="/cli/employee/claimant"]')).click();

        //Enter valid value for Employee ID
        empid.sendKeys('12345');

        //Enter valid value for FirstName
        firstname.sendKeys('TestFirstname');

        //Enter valid value for Last Name
        lastname.sendKeys('TestLastName');

        dob.click();
        dob1.sendKeys('11/12/1975');

        //Select Gender
        POAYP.rbtnmale.input.click();

        //Enter Valid value for  Preferred email
        prefmail.sendKeys('test@tst.com');
        pphone1.sendKeys('9089089098')

        //Enter Valid value for  Residential Address1
        resaddr1.sendKeys('Testaddress1');

        //Enter Valid value for  Residential City
        rescity.sendKeys('Testcity');

        //Select any Residential State
        statelist.$('[value = "PA"]').click();

        //Enter Valid value for  Postal Code
        postalcode.sendKeys('78901');

        //Select any value for State of Employment
        stateemploy.$('[value = "TN"]').click();



        //Click Continue button
        POAYP.continuebuttonspanish.input.click();

        browser.sleep(100);
        //fillaboutyoupage_female();
//Select the Continous radio button
        POAYA.consecutivedaysradiobtny.input.click();

        leaveclaimlist.$('[value = "OWN"]').click();
        browser.sleep(100);
        circumstance.$('[value = "S"]').click();
        browser.sleep(100);

        browser.executeScript('window.scrollTo(80,500);');



        rbtnaccident.click();
        rbtnmotoraccident.click();
        rbtnjobyes.click();
        browser.executeScript('window.scrollTo(100,600);');

        rbtnhosp.click();
        browser.executeScript('window.scrollTo(140,1000);');
        rbtnsurgery.click();
        txtsurgerydesc.sendKeys('test');

        lastworkingdate.sendKeys('07/09/2017');
        browser.sleep(100);

        illness.sendKeys('07/09/2017');
        browser.sleep(100);

        element(by.buttonText('Continuar')).click();
        browser.sleep(100);

        element(by.buttonText('Continuar')).click();
        browser.sleep(100);

        expect(fraudstmntheader.getText()).toContain(flfraudstmt);

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/ReviewPage/English/Testcase9_ii.png');
        });

    });*/
    it('NEW CLI - Review Page - Add Instructional Text to the page-7859', function() {

        ResuableFunction.MLC_Login();
        ResuableFunction.EmployeeCLI();
        ResuableFunction.Change_to_Spanish();

        Getting_StartedPage.clickStart("Employee-Spanish");

        AboutYouPage.EnterEmployeeID('23259');
        AboutYouPage.EnterFirstName('');
        AboutYouPage.EnterLastName('Test');
        AboutYouPage.SelectGender('Female');
        AboutYouPage.EnterDateofBirth('01011987');
        AboutYouPage.EnterResdentialAddress1('123 Test');
        AboutYouPage.EnterResdentialcity('Dover');
        AboutYouPage.EnterPostalCode('23345');
        AboutYouPage.SelectState('AK');
        AboutYouPage.EnterPersonalEmail('TESTemail@test.com');
        AboutYouPage.EnterPersonalPhone('1231231234');
        AboutYouPage.SelectEmploymentState('AK');
        AboutYouPage.ClickContinue_ViewAboutYourAbsence();

        AboutAbsencePage.SelectLeaveorClaimCategory('Yes');
        AboutAbsencePage.SelectLeaveorClaimtype('Maternity');
        AboutAbsencePage.SelectDeliveryType('Vaginal');
        AboutAbsencePage.EnterDateQuestion_1('11/01/2017');
        AboutAbsencePage.EnterDateQuestion_2('11/01/2017');
        AboutAbsencePage.ClickContinue_ViewMedicalContacts("Employee-Spanish");

        MedicalContactsPage.EnternoValues_ClickContinue_ViewReviewPage("Employee-Spanish");
        expect(element(by.xpath("//h2[ text()='Review']")).getText()).toEqual(txtaddlninfspn);
        ReviewPage.ClickSubmit_ViewConfirmation("Employee-Spanish");
/*
        POAYA.SelectLeaveorClaimCategory('Yes');
        POAYA.SelectLeaveorClaimtype('Maternity');
        POAYA.SelectDeliveryType('Vaginal');
        POAYA.EnterDateQuestion_1('11/01/2017');
        POAYA.EnterDateQuestion_2('11/01/2017');
        POAYA.ClickContinue_ViewMedicalContacts("Employee-Spanish");

        POAYC.EnternoValues_ClickContinue_ViewReviewPage("Employee-Spanish");


*/
    },300000000);




});

