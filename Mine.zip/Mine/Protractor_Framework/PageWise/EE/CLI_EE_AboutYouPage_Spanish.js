
var ResuableFunction = require('./..//helpers/helpers.js');
var Getting_StartedPage = require('./../../PageObjects/PageObject_GettingStarted.js');
var AboutYouPage = require('./../../PageObjects/PageObject_AboutYouPage.js');


describe ('New CLI - About You Page Validations', function(){

    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;


    it('New CLI_About You Page: Header and Label Name Validations', function() {

        ResuableFunction.MLC_Login();
        ResuableFunction.EmployeeCLI();
        ResuableFunction.Change_to_Spanish();

        Getting_StartedPage.clickStart("Employee-Spanish");
        AboutYouPage.Validate_AboutYouPageHeader("Employee-Spanish");
        AboutYouPage.Validate_AboutYouPage_LabelName("Employee-Spanish");
        AboutYouPage.Validate_ButtonText_Color("Employee-Spanish");

    },300000000);

    it('New CLI_About You Page: Placeholder Text Validation', function() {

        AboutYouPage.Validate_PlaceHolderText();

    });

    it('New CLI_About You Page: Error Message Validation when Mandatory Values are not entered', function() {

        AboutYouPage.Validate_ErrorMessage_MandatoryFields_NotEntered("Employee-Spanish");

    });

    it('New CLI_About You Page: Prepop Validation', function() {
        //AboutYouPage.Validate_Prepop_Valid_EmpID_LastName('23259','vega');
        //AboutYouPage.Validate_Prepop_Valid_SSN_LastName('840101955','MOHAMMAD');
        //AboutYouPage.Validate_Prepop_Valid_SSN_InvalidLastName('840101955','Test');

    });

    it('New CLI_About You Page:  Verify when page is refreshed, Getting started page is displayed with no values retained', function() {

        AboutYouPage.EnterEmployeeID('23259');
        AboutYouPage.EnterFirstName('Test');
        AboutYouPage.EnterLastName('Test');
        AboutYouPage.Display_GettingStartedPage_OnRefresh("Employee-Spanish");

    });


    it('New CLI_About You Page:  Validate Date of Birth fields if Invalid values are entered', function() {

        var Dateofbirth_value =  AboutYouPage.EnterDateofBirth('01011987');
        expect(Dateofbirth_value).toEqual('01/01/1987');

        Dateofbirth_value =   AboutYouPage.EnterDateofBirth('/-');
        expect(Dateofbirth_value).toEqual('');

        Dateofbirth_value =  AboutYouPage.EnterDateofBirth('mmddyyyy');
        expect(Dateofbirth_value).toEqual('');

        var invaliderrormessage = AboutYouPage.InvalidErrorMessage_DateofBirth('12/13/2056');
        expect(invaliderrormessage).toEqual('Ingrese una fecha de nacimiento válida');


    });

    it('New CLI_About You Page:  Verify Deletebutton pop up', function() {

        AboutYouPage.ClickDeleteApplication_ViewDeletePopup();
        AboutYouPage.Validate_DeletePopup_ButtonText_Header_Body("Employee-Spanish");
        AboutYouPage.Validate_DeletePopup_ClickCancel();
        AboutYouPage.Validate_AboutYouPageHeader("Employee-Spanish");
        AboutYouPage.Validate_DeletePopup_ClickOk();
        Getting_StartedPage.VerifyPageHeader();
        Getting_StartedPage.clickStart("Employee-Spanish");

    });


    it('New CLI_About You Page:  Verify About Your Absence Page is displayed when Mandatory values are entered', function() {


        AboutYouPage.EnterEmployeeID('23259');
        AboutYouPage.EnterFirstName('Test');
        AboutYouPage.EnterLastName('Test');
        AboutYouPage.SelectGender('Female');
        AboutYouPage.EnterDateofBirth('01011987');
        AboutYouPage.EnterResdentialAddress1('123 Test');
        AboutYouPage.EnterResdentialcity('Dover');
        AboutYouPage.EnterPostalCode('23345');
        AboutYouPage.SelectState('AK');
        AboutYouPage.EnterPersonalEmail('TESTEMAIL@TEST.COM');
        AboutYouPage.EnterPersonalPhone('1231231234');
        AboutYouPage.SelectEmploymentState('AK');
        AboutYouPage.ClickContinue_ViewAboutYourAbsence();

    });

});