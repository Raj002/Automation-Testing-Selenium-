

var Getting_StartedPage = require('./../../PageObjects/PageObject_GettingStarted.js');
var ResuableFunction = require('./..//helpers/helpers.js');
var AboutYouPage = require('./../../PageObjects/PageObject_AboutYouPage.js');
var AboutAbsencePage = require('./../../PageObjects/PageObject_AboutYourAbsence.js');
var MedicalContactsPage = require('./../../PageObjects/PageObject_ContactsPage.js');
var ReviewPage = require('./../../PageObjects/PageObject_ER_ReviewPage.js');
var ConfirmationPage = require('./../../PageObjects/PageObject_ConfirmationPage.js');



describe ('New ER CLI_Confirmation Page - Validations', function() {

    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;




    it('New CLI_Employee_Confirmation Page - Page_Header and static content Validations - Spanish', function () {

        ResuableFunction.MLC_Login();
        ResuableFunction.EmployeeCLI();

        Getting_StartedPage.clickStart("Employee-English");

        AboutYouPage.EnterSSN('232593232');
        AboutYouPage.EnterDateofBirth('01/01/1987');
        AboutYouPage.SelectGender('Female');
        AboutYouPage.EnterResdentialAddress1('123 Test');
        AboutYouPage.EnterResdentialcity('Dover');
        AboutYouPage.EnterPostalCode('23345');
        AboutYouPage.SelectState('AK');
        AboutYouPage.EnterPersonalEmail('test@test.com');
        AboutYouPage.EnterPersonalPhone('5231231234');
        AboutYouPage.SelectEmploymentState('AK');
        AboutYouPage.ClickContinue_ViewAboutYourAbsence();

        AboutAbsencePage.SelectLeaveorClaimCategory('Yes');
        AboutAbsencePage.SelectLeaveorClaimtype('Maternity');
        AboutAbsencePage.SelectDeliveryType('Vaginal');
        AboutAbsencePage.EnterDateQuestion_1('11/01/2017');
        AboutAbsencePage.EnterDateQuestion_2('11/01/2017');
        AboutAbsencePage.ClickContinue_ViewMedicalContacts("Employee-English");

        MedicalContactsPage.EnternoValues_ClickContinue_ViewReviewPage("Employee-English");
        ReviewPage.ClickSubmit_ViewConfirmation();

        ConfirmationPage.VerifyPageHeader();
        ConfirmationPage.VerifySuccessMessage();
        ConfirmationPage.VerifySubmissionText_Date();
        ConfirmationPage.VerifyHeaders("Employee-English");
        ConfirmationPage.VerifyStaticContent("Employee-English");
        ConfirmationPage.VerifyMediAuthBtn('English');



    },300000000);

    it('New CLI_Employee_Confirmation Page - View Submission Validations - English', function () {


        var Leave_ClaimNumber = ConfirmationPage.GetClaimNumber();

        ConfirmationPage.clickViewSubmission();
        ConfirmationPage.ViewSubmission_PageHeaders("Employee-English");
        ConfirmationPage.ViewSubmission_ProgressbarHeader_NotDisplayed();
        ConfirmationPage.ViewSubmission_ProgressbarCircles_NotDisplayed();
        ConfirmationPage.ViewSubmission_GetHelpLink_NotDisplayed();
        ConfirmationPage.ViewSubmission_InstructionalText_FraudStatement_NotDisplayed();
        ConfirmationPage.ViewSubmission_VerifyLeave_ClaimNumber(Leave_ClaimNumber);
        ConfirmationPage.ViewSubmission_EditLinks_NotDisplayed();
        ConfirmationPage.ViewSubmission_VerifyPrintIcon_Displayed();
        ConfirmationPage.ViewSubmission_ClickClose_ViewConfirmationPage();
        ConfirmationPage.VerifyPageHeader();

    },300000000);

});


