
var Getting_StartedPage = require('./../../PageObjects/PageObject_GettingStarted.js');
var ResuableFunction = require('./..//helpers/helpers.js');
var AboutYourEmployeePage = require('./../../PageObjects/PageObject_AboutYouPage.js');
var AboutAbsencePage = require('./../../PageObjects/PageObject_AboutYourAbsence.js');
var MedicalContactsPage = require('./../../PageObjects/PageObject_ContactsPage.js');
var ReviewPage = require('./../../PageObjects/PageObject_ER_ReviewPage.js');

describe ('New CLI_Employee- About Absence: Maternity Flow Validations - English', function() {

    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;

/*
    it('New CLI_Employee_About Absence Page - Verify Maternity Option is not available for Male', function () {

        ResuableFunction.MLC_Login();
        ResuableFunction.EmployeeCLI();

        Getting_StartedPage.clickStart("Employee-English");

        AboutYourEmployeePage.EnterEmployeeID('23259');
        AboutYourEmployeePage.EnterFirstName('Test');
        AboutYourEmployeePage.EnterLastName('Test');
        AboutYourEmployeePage.EnterDateofBirth('01/01/1987');
        AboutYourEmployeePage.SelectGender('Male');
        AboutYourEmployeePage.EnterResdentialAddress1('123 Test');
        AboutYourEmployeePage.EnterResdentialcity('Dover');
        AboutYourEmployeePage.EnterPostalCode('23345');
        AboutYourEmployeePage.SelectState('AK');
        AboutYourEmployeePage.EnterPersonalPhone('1231231234');
        AboutYourEmployeePage.EnterPersonalEmail('test@test.com');
        AboutYourEmployeePage.SelectEmploymentState('AK');
        AboutYourEmployeePage.ClickContinue_ViewAboutYourAbsence();

    },300000000);

    it('New CLI_Employer_About Absence Page - Verify Maternity Option is not available for Leave flow', function () {

        AboutAbsencePage.ClickGoBack();
        AboutYourEmployeePage.EnterEmployeeID('23259');
        AboutYourEmployeePage.SelectGender('Female');
        AboutYourEmployeePage.ClickContinue_ViewAboutYourAbsence();
        AboutAbsencePage.SelectLeaveorClaimCategory('No');
        AboutAbsencePage.VerifyMaternityNotAvailableforLeaveFlow();

    },300000000);

    it('New CLI_Employer_About Absence Page - Page Header, Questions Label Validations', function () {


        AboutAbsencePage.SelectLeaveorClaimCategory('Yes');
        AboutAbsencePage.SelectLeaveorClaimtype('Maternity');
        AboutAbsencePage.SelectDeliveryType('Vaginal');
        AboutAbsencePage.QuestionsLabelValidations('Employee-Maternity-Vaginal');
        AboutAbsencePage.LastQuestion_Validation('Employee-Maternity-Vaginal');


    },300000000);

    it('New CLI_Employer_About Absence Page - Auto Format Validations for Date fields', function () {

        var datevalue;

        datevalue =  AboutAbsencePage.VerifyFormat_DateQuestion_1('02/2/2012');
        expect(datevalue).toEqual('02/02/2012');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_1('8/12/2017');
        expect(datevalue).toEqual('08/12/2017');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_1('8/8/2017');
        expect(datevalue).toEqual('08/08/2017');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_1('8-8-2017');
        expect(datevalue).toEqual('');

        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_2('02/2/2012');
        expect(datevalue).toEqual('02/02/2012');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_2('8/12/2017');
        expect(datevalue).toEqual('08/12/2017');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_2('8/8/2017');
        expect(datevalue).toEqual('08/08/2017');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_2('8-8-2017');
        expect(datevalue).toEqual('');



        datevalue =  AboutAbsencePage.VerifyFormat_DateQuestion_3('02/2/2012');
        expect(datevalue).toEqual('02/02/2012');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_3('8/12/2017');
        expect(datevalue).toEqual('08/12/2017');
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_3('8-8-2017');
        expect(datevalue).toEqual('');
        datevalue =  AboutAbsencePage.VerifyFormat_DateQuestion_3('8/8/2017');
        expect(datevalue).toEqual('08/08/2017');


        datevalue =  AboutAbsencePage.VerifyFormat_DateQuestion_4('02/2/2012');
        expect(datevalue).toEqual('02/02/2012');
        datevalue =  AboutAbsencePage.VerifyFormat_DateQuestion_4('8/12/2017');
        expect(datevalue).toEqual('08/12/2017');
        datevalue =  AboutAbsencePage.VerifyFormat_DateQuestion_4('8-8-2017');
        expect(datevalue).toEqual('');
        datevalue =  AboutAbsencePage.VerifyFormat_DateQuestion_4('8/8/2017');
        expect(datevalue).toEqual('08/08/2017');

    },300000000);

    it('New CLI_Employer_About Absence Page - Verify Options for Delivery Complication', function () {

        AboutAbsencePage.SelectDeliveryType('No_NotYet');
        AboutAbsencePage.QuestionsLabelValidations('Employee-No Not Yet');
        AboutAbsencePage.EnterDateQuestion_1('11/01/2017');
        AboutAbsencePage.EnterDateQuestion_2('11/01/2017');
        AboutAbsencePage.DeliveryComplicationOptions_Employee_English('No-NotYet');
        AboutAbsencePage.SelectComplicationIndicator('Yes');
        AboutAbsencePage.ClickContinue_ViewMedicalContacts("Employee-English");
        MedicalContactsPage.EnternoValues_ClickContinue_ViewReviewPage("Employee-English");
        ReviewPage.VerifyMedicalContactsSection();

    });
*/

    it('Story 7682 - NEW CLI - About Your Absence/About Your Employees Absence - Validate and disable date fields and date pickers based on valid date range', function () {

        var date_1;
        var date_2;
        var date_3;
        var date_4;
        var date_5;
        var date_6;
        ResuableFunction.MLC_Login();
        ResuableFunction.EmployeeCLI();
        Getting_StartedPage.clickStart("Employee-English");

        //AboutYouPage.UniqueID_EmpID_SSN('EmpID');
        AboutYourEmployeePage.EnterSSN('112224440');
        AboutYourEmployeePage.ValidateFirstNameEE();
        AboutYourEmployeePage.ValidateLastNameEE();
        AboutYourEmployeePage.SelectGender('Female');
        AboutYourEmployeePage.EnterDateofBirth('01011987');
        AboutYourEmployeePage.EnterResdentialAddress1('123 Test');
        AboutYourEmployeePage.EnterResdentialcity('Dover');
        AboutYourEmployeePage.EnterPostalCode('23345');
        AboutYourEmployeePage.SelectState('NH');
        AboutYourEmployeePage.EnterPersonalPhone('9997775550');
        AboutYourEmployeePage.EnterPersonalEmail('TESTemail@test.com');
        AboutYourEmployeePage.SelectEmploymentState('AK');
        AboutYourEmployeePage.ClickContinue_ViewAboutYourAbsence();

        date_1 = AboutAbsencePage.DateEntry('greater than 1 year');
        date_2 = AboutAbsencePage.DateEntry('greater than 2 year');
        date_3 = AboutAbsencePage.DateEntry('lesser than 1 year');
        date_4 = AboutAbsencePage.DateEntry('invalid date');
        date_5 = AboutAbsencePage.DateEntry('today');
        date_6 = AboutAbsencePage.DateEntry('future date');
        AboutAbsencePage.SelectLeaveorClaimCategory('Yes');
         AboutAbsencePage.SelectLeaveorClaimtype('Maternity');
         AboutAbsencePage.SelectDeliveryType('Vaginal');
         AboutAbsencePage.EnterDateQuestion_1(date_1);
         AboutAbsencePage.EnterDateQuestion_2(date_1);
         AboutAbsencePage.EnterDateQuestion_3(date_1);
         AboutAbsencePage.EnterDateQuestion_4(date_1);
         AboutAbsencePage.Verify_ErrorMessage_datefeilds_Maternityflow('Err_Msg_Outside valid window_Greater');
         AboutAbsencePage.EnterDateQuestion_1(date_5);
         AboutAbsencePage.EnterDateQuestion_2(date_3);
         AboutAbsencePage.EnterDateQuestion_3(date_3);
         AboutAbsencePage.EnterDateQuestion_4(date_3);
         AboutAbsencePage.Verify_ErrorMessage_datefeilds_Maternityflow('Err_Msg_Outside valid window_lesser');
         AboutAbsencePage.EnterDateQuestion_1(date_4);
         AboutAbsencePage.EnterDateQuestion_2(date_4);
         AboutAbsencePage.EnterDateQuestion_3(date_4);
         AboutAbsencePage.EnterDateQuestion_4(date_4);
         AboutAbsencePage.Verify_ErrorMessage_datefeilds_Maternityflow('Err_Msg_Invalid format');

    },300000000);


});

