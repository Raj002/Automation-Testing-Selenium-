
var Getting_StartedPage = require('./../../PageObjects/PageObject_GettingStarted.js');
var ResuableFunction = require('./..//helpers/helpers.js');
var AboutYourEmployeePage = require('./../../PageObjects/PageObject_AboutYouPage.js');
var AboutAbsencePage = require('./../../PageObjects/PageObject_AboutYourAbsence.js');
var AddlInfoPage = require('./../../PageObjects/PageObject_Additional_InformationPage.js');
var ReviewPage = require('./../../PageObjects/PageObject_ER_ReviewPage.js');

describe ('New CLI_Employer- About Absence: Other Leave Flow Validations', function() {

    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;


    it('New CLI_Employee_About Absence Page - Page Header, Questions Label Validations', function () {

        ResuableFunction.MLC_Login();
        ResuableFunction.EmployeeCLI();
        ResuableFunction.Spanish_Link();
        Getting_StartedPage.clickStart("Employee-Spanish");

        AboutYourEmployeePage.EnterEmployeeID('23259');
        AboutYourEmployeePage.EnterFirstName('Test');
        AboutYourEmployeePage.EnterLastName('Test');
        AboutYourEmployeePage.EnterDateofBirth('01/01/1987');
        AboutYourEmployeePage.SelectGender('Male');
        AboutYourEmployeePage.EnterResdentialAddress1('123 Test');
        AboutYourEmployeePage.EnterResdentialcity('Dover');
        AboutYourEmployeePage.EnterPostalCode('23345');
        AboutYourEmployeePage.SelectState('AK');
        AboutYourEmployeePage.EnterPersonalPhone('1231231234');
        AboutYourEmployeePage.EnterPersonalEmail('test@test.com');
        AboutYourEmployeePage.SelectEmploymentState('AK');
        AboutYourEmployeePage.ClickContinue_ViewAboutYourAbsence();
        AboutAbsencePage.SelectLeaveorClaimCategory('Yes');
        AboutAbsencePage.SelectLeaveorClaimtype('Other-Leave','Male');
        AboutAbsencePage.Select_List_1_Value('AM');
        AboutAbsencePage.QuestionsLabelValidations('Employee-Spanish-OtherLeaveFlow');

    },300000000);



    it('New CLI_Employee_About Absence Page - Auto Format Validations for Date fields', function () {

        var datevalue;
        datevalue =  AboutAbsencePage.VerifyFormat_DateQuestion_1('02/2/2012');
        expect(datevalue).toEqual('02/02/2012');

        datevalue = '';
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_1('8/12/2017');
        expect(datevalue).toEqual('08/12/2017');

        datevalue = '';
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_1('8/8/2017');
        expect(datevalue).toEqual('08/08/2017');

        datevalue = '';
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_1('8-8-2017');
        expect(datevalue).toEqual('');

        datevalue = '';
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_2('02/2/2012');
        expect(datevalue).toEqual('02/02/2012');

        datevalue = '';
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_2('8/12/2017');
        expect(datevalue).toEqual('08/12/2017');

        datevalue = '';
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_2('8/8/2017');
        expect(datevalue).toEqual('08/08/2017');

        datevalue = '';
        datevalue = AboutAbsencePage.VerifyFormat_DateQuestion_2('8-8-2017');
        expect(datevalue).toEqual('');



    },300000000);

    it('New CLI_Employee_About Absence Page - Display Additional Info page when Mandatory values entered', function () {


        AboutAbsencePage.EnterDateQuestion_1('11/01/2017');
        AboutAbsencePage.EnterDateQuestion_2('11/01/2017');
        AboutAbsencePage.ClickContinue_ViewMedicalContacts("Employee-Spanish");


    });



});

