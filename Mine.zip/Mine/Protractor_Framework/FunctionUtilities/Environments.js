/**
 * Created by n0313914 on 8/22/2017.
 */

var Region = function() {
    this.Env = 'https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/employer/cli/'
}
module.exports = new Region();