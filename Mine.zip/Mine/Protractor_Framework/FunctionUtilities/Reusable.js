var fs = require('fs');
var ReuseFunc = function() {
    this.SendElement = function (element,text) {
        element.sendKeys(text);
    },
    this.clickElement = function(element){
        element.click();
    },
    this.getElement = function(element){
        element.getText();
    },
    this.writeScreenShot = function(data, filename) {
        var stream = fs.createWriteStream(filename);
        stream.write(new Buffer(data, 'base64'));
        stream.end();
    },
    //this.Environment = function(region){
    //    this.Test = 'https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/employer/cli/'};
    //    this.Test = 'https://test1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/employer/cli/';
    //    this.Perf = 'https://perf1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/employer/cli/';
    //},
    /*this.listClick = function(element,Val){
        element.$('[value="'Val'"]').click();
    }, */
    this.expectToEqual = function(Actual,Expected) {
        expect(Actual).toEqual(Expected);
    },
    this.expectToContain = function(Actual,Expected) {
        expect(Actual).toContain(Expected);
    }
};

module.exports = new ReuseFunc();