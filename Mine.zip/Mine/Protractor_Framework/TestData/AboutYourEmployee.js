/**
 * Created by n0313914 on 8/21/2017.
 */
module.exports = {
    URL: '',

    username: 'Dukeenergy01',
    password: 'Test1234',
    FirstName: 'TestFirst',
    MiddleName: 'A',
    LastName: 'last',
    DOB: '09/09/2001',
    PrefPersonalPhone: '6666444555',
    PrefPersemail: 'test@testmail.com',
    Country: 'USA',
    Addr1: '150 LibertyWay',
    Addr2: 'Liberty',
    City: 'Dover',
    State: 'New Hampshire',
    postalCode: '03820',
    PrefMeth: 'Email',
    EmpID: '12345',
    SSN: '984575674',
    ResState: 'DC',
    EmpState:'AK',
    WorkLocation: {
        Country: 'United States',
        state: 'NH'
    },
    ExpectedResult:{
        DOBBlank:'02/02/1990'
    }
};

