exports.config = {

    //seleniumAddress: 'http://localhost:4444/wd/hub',
    //directConnect: true,


    specs: ['./End to End/ER/CLI_ER_E2E_Continuous_CareFlow.js'],

   // specs: ['./End to End/EE/CLI_EE_E2E_English_Continuous_CareFlow.js'],

   // specs: ['./Page Wise/EE/CLI_EE_AboutYourAbsencePage_MOC_English.js'],

    specs: ['./Page Wise/EE/CLI_EE_AboutYourAbsencePage_MOC_English.js'],

    specs: ['./End to End/EE/CLI_EE_E2E_English_Continuous_Maternity_Vaginal.js'],

    specs: ['./End to End/EE/CLI_EE_E2E_English_Continuous_Maternity_Vaginal.js'],

    specs: ['./End to End/EE/CLI_EE_E2E_Spanish_Continuous_CareFlow.js'],

    specs: ['./End to End/EE/CLI_EE_E2E_Spanish_Continuous_CareFlow.js'],

    specs: ['./EndtoEnd/ER/CLI_ER_E2E_Intermittent_BondwithChild.js'],

    async: false,
    capabilities: {
       'browserName': 'chrome'

    },

    framework: 'jasmine',

    onPrepare: function () {
        // Add Jasmine Spec Reporter
        var specReporter = require('jasmine-spec-reporter');
        jasmine.getEnv().addReporter(new specReporter({displayStacktrace: 'all'}));
        //browser.driver.manage().window().maximize();

        var Jasmine2HtmlReporter = require('protractor-jasmine2-html-reporter');
        jasmine.getEnv().addReporter(
            new Jasmine2HtmlReporter({
                savePath: 'Report/screenshots',
                //takeScreenshots: true,
                //takeScreenShotsOnlyOnFailures: true,
                fileName: 'Protractor Automation Report'
            }));

    }

        }


