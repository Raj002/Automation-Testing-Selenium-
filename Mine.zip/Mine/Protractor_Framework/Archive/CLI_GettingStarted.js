/**
 * Created by n0275896 on 7/3/2017.
 */
var POGSP = require('./PageObject_GettingStarted.js');

//Function to take screenshot
var fs = require('fs');
function writeScreenShot(data, filename) {
    var stream = fs.createWriteStream(filename);
    stream.write(new Buffer(data, 'base64'));
    stream.end();
}

describe ('New CLI_Getting Started Page Validation', function() {
    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;

    //Sample Test
    it('New_CLI:Getting Started Page Validations', function() {

        //Open NEW CLI in browser and go to Getting Started Page
        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/cli');
        browser.sleep(5000);

        //Verify whether the Get Help Link opens "Get Help" pop up
        POGSP.gethlplabel.input.click();
        expect(POGSP.popuphelp.input.isDisplayed()).toBe(true);
        element(by.buttonText('Close')).click();



        //Verify the header A message from Employer
        var header1 = POGSP.headermessage1.input.getText();
        expect(header1).toEqual('EE A Message From Your Employer');


        //Welcome header
        var headermessage2 = POGSP.headermessage3.input.getText();
        expect(headermessage2).toEqual('Welcome. To continue, please make sure you have the following information:');

        //Static content line 1
        var staticcontent1 = POGSP.staticcontent1.input.getText();
        expect(staticcontent1).toEqual('1. Information to identify yourself (may include your social security number or other ID as required by your employer)');

        //Static content line 2
        var staticcontent2 = POGSP.staticcontent2.input.getText();
        expect(staticcontent2).toEqual('2. Claim or leave information, including reason and dates of medical or other authorized events');

        //Static content line 3
        var staticcontent3 = POGSP.staticcontent3.input.getText();
        expect(staticcontent3).toEqual('3. Physician or hospital contact information (if available)');

        //Static content line 4
        var staticcontent4 = POGSP.staticcontent4.input.getText();
        expect(staticcontent4).toEqual('NOTE:');

        //Static content line 5
        var staticcontent5 = POGSP.staticcontent5.input.getText();
        expect(staticcontent5).toEqual('For added security, your session will automatically time-out following 15 minutes of inactivity to protect your personal information.');

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/GettingStartedPage/Testcase.png');
        });

        //Click start to continue with About You Page
        element(by.buttonText('Start')).click();



    });

});