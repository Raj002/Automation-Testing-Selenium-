
var POAYC = require('./PageObject_ContactsPage.js');

describe ('Open URL in browser and validate contacts page labels', function() {

//Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;


   // describe('angularjs homepage', function () {
        it('should greet the named user', function () {
            browser.get
            ('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/cli');
            element(by.css('[href="/cli/contacts"]')).click();


            var medheader = POAYC.medheader.input.getText();
            expect(medheader).toEqual('Medical Contacts');

        });
   // });
});



//console.log test1


        //Store Page elements
        //var hlink  = element(by.className('progressactive')).getText();
        //var mtitle = element(by.id('header1')).getText();
        //var ttitle  = element(by.id('header2')).getText();
        //var fname  = element(by.xpath('//div/ui-view/contacts/div/div[2]/div/section/div[1]/fieldset/label')).getText();
        //var lname   = element(by.xpath('//div/ui-view/contacts/div/div[2]/div/section/div[2]/fieldset/label')).getText();
        //var pnum = element(by.xpath('//div/ui-view/contacts/div/div[2]/div/section/div[3]/fieldset/label')).getText();
        //var pnumformat = element(by.xpath('//div/ui-view/contacts/div/div[2]/div/section/div[3]/fieldset/span[1]')).getText();
        //var conbutton = element(by.xpath('//div/ui-view/contacts/button[2]')).getText();
        //var gobackbutton = element(by.xpath('//div/ui-view/contacts/button[1]')).getText();
        //var fnametbox = element(by.id('physicianFirstName'));
        //var lnametbox = element(by.id('physicianLastName'));
        //var pnumtbox = element(by.id('physicianphone'));
        //var pnumerr1 = element(by.xpath('//div/ui-view/contacts/div/div[2]/div/section/div[3]/fieldset/span[2]'));
        //
        //
        ////Valdiate Page elements
        //expect(hlink).toEqual('About Your Contacts');
        //expect(mtitle).toEqual('Medical Contacts');
        //expect(ttitle).toEqual('Treating Physician Information');
        //expect(fname).toEqual("Physician's First Name");
        //expect(lname).toEqual("Physician's Last Name");
        //expect(pnum).toEqual("Physician's Phone Number");
        //expect(pnumformat).toEqual("(###) ### - ####");
        //expect(conbutton).toEqual("Continue");
        //expect(gobackbutton).toEqual("Go Back");
        //expect((fnametbox).isDisplayed()).toBe(true);
        //expect((lnametbox).isDisplayed()).toBe(true);
        //expect((pnumtbox).isDisplayed()).toBe(true);
        //
        ////Validate for Data Entry - Physician's First Name
        //fnametbox.sendKeys("Testing-");
        //expect(fnametbox.getAttribute('value')).toEqual("Testing-");
        //fnametbox.clear();
        //fnametbox.sendKeys("1234567890");
        //expect(fnametbox.getAttribute('value')).toEqual("");
        //fnametbox.clear();
        //fnametbox.sendKeys("!@#$%^&*()_+=<>?,./:");
        //expect(fnametbox.getAttribute('value')).toEqual("");
        //fnametbox.clear();
        //fnametbox.sendKeys(";'{}[]'");
        //expect(fnametbox.getAttribute('value')).toEqual("''");
        //fnametbox.clear();
        //
        ////Validate for Data Entry - Physician's Last Name
        //lnametbox.sendKeys("Testing-'");
        //expect(lnametbox.getAttribute('value')).toEqual("Testing-'");
        //lnametbox.clear();
        //lnametbox.sendKeys("1234567890");
        //expect(lnametbox.getAttribute('value')).toEqual("");
        //lnametbox.clear();
        //lnametbox.sendKeys("!@#$%^&*()_+=<>?,./:");
        //expect(lnametbox.getAttribute('value')).toEqual("");
        //lnametbox.clear();
        //lnametbox.sendKeys(";'{}[]'");
        //expect(lnametbox.getAttribute('value')).toEqual("''");
        //lnametbox.clear();
        //
        ////Validate for Data Entry - Physician's Phone Number
        //pnumtbox.sendKeys("1234567890");
        //expect(pnumtbox.getAttribute('value')).toEqual("(123) 456-7890");
        //expect(pnumerr1.isDisplayed()).toBe(false);
        //pnumtbox.clear();
        //pnumtbox.sendKeys("12345678");
        //conbutton.click();
        //expect(pnumerr1.isDisplayed()).toBe(true);
        //
        //browser.takeScreenshot().then(function (png) {
        //    writeScreenShot(png, 'exception.png');
    //    });
    //
    //});


    //-------------------------------------------------------***********************************---------------------------------------------------------//
    //-------------------------------------------------------***********************************---------------------------------------------------------//

    ////TestCase - 2 Contacts Page Spanish
    //it('Spanish - enter value', function() {
    //
    //  browser.ignoreSynchronization = false
    //  browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/');
    //  var langtoggle = element(by.className('link'));
    //  var contacts = element(by.css('[uisref="contacts"]'));
    //
    //  //Toggle to Spanish and Navigate to Contacts Page
    //  langtoggle.click();
    //  contacts.click();
    //
    //  //Store Page elements
    //  var hlink  = element(by.className('progressactive')).getText();
    //  var mtitle = element(by.id('header1')).getText();
    //  var ttitle  = element(by.id('header2')).getText();
    //  var fname  = element(by.xpath('//div/ui-view/contacts/div/div[2]/div/section/div[1]/fieldset/label')).getText();
    //  var lname   = element(by.xpath('//div/ui-view/contacts/div/div[2]/div/section/div[2]/fieldset/label')).getText();
    //  var pnum = element(by.xpath('//div/ui-view/contacts/div/div[2]/div/section/div[3]/fieldset/label')).getText();
    //  var pnumformat = element(by.xpath('//div/ui-view/contacts/div/div[2]/div/section/div[3]/fieldset/span[1]')).getText();
    //  var conbutton = element(by.xpath('//div/ui-view/contacts/button[2]')).getText();
    //  var gobackbutton = element(by.xpath('//div/ui-view/contacts/button[1]')).getText();
    //  var fnametbox = element(by.id('physicianFirstName'));
    //  var lnametbox = element(by.id('physicianLastName'));
    //  var pnumtbox = element(by.id('physicianphone'));
    //
    //  //Valdiate Page elements
    //  expect(hlink).toEqual('Otros contactos');
    //  expect(mtitle).toEqual('Medical Contacts');
    //  expect(ttitle).toEqual('Treating Physician Information');
    //  expect(fname).toEqual("Nombre del M"+ '\u00E9' +"dico");
    //  expect(lname).toEqual("Apellido del M"+ '\u00E9' +"dico");
    //  expect(pnum).toEqual("Nombre del hospital o nombre de la pr"+ '\u00E1' + "ctica de los m"+ '\u00E9' +"dicos");
    //  expect(pnumformat).toEqual("(###) ### - ####");
    //  expect(conbutton).toEqual("Continuar");
    //  expect(gobackbutton).toEqual("Volver");
    //  expect((fnametbox).isDisplayed()).toBe(true);
    //  expect((lnametbox).isDisplayed()).toBe(true);
    //  expect((pnumtbox).isDisplayed()).toBe(true);
    //
    //});
//});