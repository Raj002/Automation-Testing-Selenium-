/**
 * Created by n0238696 on 7/11/2017.
 */


//Import Page objects

//var cppageobj = require('./VSPageObjects.js');

var POAYC = require('./PageObject_ContactsPage.js');

//Take Screenshots
var fs = require('fs');
function writeScreenShot(data, filename) {
    var stream = fs.createWriteStream(filename);
    stream.write(new Buffer(data, 'base64'));
    stream.end();
}
describe ('Open URL in browser and validate contacts page labels', function() {


    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;


    //TestCase - 1 Contacts Page English
    it('New CLI_Contacts Page: Label/Header Validations', function () {

        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/');
        element(by.css('[href="/cli/contacts"]')).click();

        //===============*** Field label Validations ***================//

        //Verify Medical contacts header
        var medheader = POAYC.medheader.input.getText();
        expect(medheader).toEqual('Medical Contacts');

        //Verify static content below Medical contacts header
        var statictext = POAYC.statictext.input.getText();
        expect(statictext).toEqual('Please provide us with one of the contacts below to help expedite the processing of your absence request.');

        //Verify Treating Physician Information header
        var physicianinfoheader = POAYC.physicianinfoheader.input.getText();
        expect(physicianinfoheader).toEqual('Treating Physician Information');

        //Verify Physician First name label
        var physicianfnamelabel = POAYC.physicianfnamelabel.input.getText();
        expect(physicianfnamelabel).toEqual("Physician's First Name");

        //Verify Physician First name- Optional  label
        var physicianfnameoplabel = POAYC.physicianfnameoplabel.input.getText();
        expect(physicianfnameoplabel).toEqual('(optional)');

        //Verify Physician Last name label
        var physicianlnamelabel = POAYC.physicianlnamelabel.input.getText();
        expect(physicianlnamelabel).toEqual("Physician's Last Name");

        //Verify Physician Last name- Optional  label
        var physicianlnameoplabel = POAYC.physicianlnameoplabel.input.getText();
        expect(physicianlnameoplabel).toEqual('(optional)');

        //Verify Physician phone number label
        var physicianpnumlabel = POAYC.physicianpnumlabel.input.getText();
        expect(physicianpnumlabel).toEqual("Physician's Phone Number");

        //Verify Physician phone number optional label
        var physicianpnumoplabel = POAYC.physicianpnumoplabel.input.getText();
        expect(physicianpnumoplabel).toEqual('(optional)');

        //Verify Physician phone number format lable
        var physicianpnumformatlabel = POAYC.physicianpnumformatlabel.input.getText();
        expect(physicianpnumformatlabel).toEqual('(###) ### - ####');

        //Verify Hospital Name or Physicians Practice Name label
        var physicianhnamelabel = POAYC.physicianhnamelabel.input.getText();
        expect(physicianhnamelabel).toEqual("Hospital Name or Physicians Practice Name");

        //Verify Hospital Name or Physicians Practice Name optional label
        var physicianhnameoplabel = POAYC.physicianhnameoplabel.input.getText();
        expect(physicianhnameoplabel).toEqual('(optional)');

        //Verify Hospital or Physicians Practice Phone Number label
        var physicianhpnumlabel = POAYC.physicianhpnumlabel.input.getText();
        expect(physicianhpnumlabel).toEqual("Hospital or Physicians Practice Phone Number");

        //Verify Hospital or Physicians Practice Phone Number optional label
        var physicianhpnumoplabel = POAYC.physicianhpnumoplabel.input.getText();
        expect(physicianhpnumoplabel).toEqual('(optional)');

        //Verify Hospital or Physicians Practice Phone Number format label
        var physicianhpnumformatlabel = POAYC.physicianhpnumformatlabel.input.getText();
        expect(physicianhpnumformatlabel).toEqual("(###) ### - ####");

        //Verify Continue button label
        var continuebutton = POAYC.continuebutton.input.getText();
        expect(continuebutton).toEqual('Continue');

        //Verify Go back button label
        var gobackbutton = POAYC.gobackbutton.input.getText();
        expect(gobackbutton).toEqual('Go Back');

        //Verify Save for Later button label
        var saveforlaterbutton = POAYC.saveforlaterbutton.input.getText();
        expect(saveforlaterbutton).toEqual('Save for Later');

        //Verify Delete Application button label
        var deleteapplicationbutton = POAYC.deleteapplicationbutton.input.getText();
        expect(deleteapplicationbutton).toEqual('Delete Application');

//Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/ContactsPage');
        });



        //===============*** Data Entry Validations ***================//

        //Validate Physician's First Name - valid and invalid formats
        var physicianfnametbox = POAYC.physicianfnametbox.input;

            physicianfnametbox.sendKeys("FirstName-");
            expect(physicianfnametbox.getAttribute('value')).toEqual("FirstName-");
            physicianfnametbox.clear();
            physicianfnametbox.sendKeys("1234567890");
            expect(physicianfnametbox.getAttribute('value')).toEqual("");
            physicianfnametbox.clear();
            physicianfnametbox.sendKeys("!@#$%^&*()_+=<>?,./:");
            expect(physicianfnametbox.getAttribute('value')).toEqual("");
            physicianfnametbox.clear();
            physicianfnametbox.sendKeys(";'{}[]'");
            expect(physicianfnametbox.getAttribute('value')).toEqual("''");
            physicianfnametbox.clear();



        //Validate Physician's Last Name - valid and invalid formats
        var physicianlnametbox = POAYC.physicianlnametbox.input;

            physicianlnametbox.sendKeys("LastName-");
            expect(physicianlnametbox.getAttribute('value')).toEqual("LastName-");
            physicianlnametbox.clear();
            physicianlnametbox.sendKeys("1234567890");
            expect(physicianlnametbox.getAttribute('value')).toEqual("");
            physicianlnametbox.clear();
            physicianlnametbox.sendKeys("!@#$%^&*()_+=<>?,./:");
            expect(physicianlnametbox.getAttribute('value')).toEqual("");
            physicianlnametbox.clear();
            physicianlnametbox.sendKeys(";'{}[]'");
            expect(physicianlnametbox.getAttribute('value')).toEqual("''");
            physicianlnametbox.clear();


        //Validate Physician's Phone number - valid and invalid formats
        var physicianpnumtbox = POAYC.physicianpnumtbox.input;

            physicianpnumtbox.sendKeys("1234567890");
            expect(physicianpnumtbox.getAttribute('value')).toEqual("(123) 456-7890");
            physicianpnumtbox.clear();
            physicianpnumtbox.sendKeys("!@#$%^&*()");
            expect(physicianpnumtbox.getAttribute('value')).toEqual("(");
            physicianpnumtbox.clear();
            physicianpnumtbox.sendKeys("QWERTY{}|:<>?");
            expect(physicianpnumtbox.getAttribute('value')).toEqual("(");
            physicianpnumtbox.clear();


        //Validate Hospital Name or Physicians Practice Name - valid and invalid formats
        var physicianhnametbox = POAYC.physicianhnametbox.input;

            physicianhnametbox.sendKeys("PhysicianName-");
            expect(physicianhnametbox.getAttribute('value')).toEqual("PhysicianName-");
            physicianhnametbox.clear();
            physicianhnametbox.sendKeys("1234567890");
            expect(physicianhnametbox.getAttribute('value')).toEqual("");
            physicianhnametbox.clear();
            physicianhnametbox.sendKeys("!@#$%^&*()_+=<>?,./:");
            expect(physicianhnametbox.getAttribute('value')).toEqual("");
            physicianhnametbox.clear();
            physicianhnametbox.sendKeys(";'{}[]'");
            expect(physicianhnametbox.getAttribute('value')).toEqual("''");
            physicianhnametbox.clear();


        //Validate Hospital or Physicians Practice Phone Number - valid and invalid formats
        var physicianhpnumtbox = POAYC.physicianhpnumtbox.input;
            physicianhpnumtbox.sendKeys("1234567890");
            expect(physicianhpnumtbox.getAttribute('value')).toEqual("(123) 456-7890");
            physicianhpnumtbox.clear();
            physicianhpnumtbox.sendKeys("!@#$%^&*()");
            expect(physicianhpnumtbox.getAttribute('value')).toEqual("(");
            physicianhpnumtbox.clear();
            physicianhpnumtbox.sendKeys("QWERTY{}|:<>?");
            expect(physicianhpnumtbox.getAttribute('value')).toEqual("(");
            physicianhpnumtbox.clear();

        browser.sleep(1000);

        physicianhpnumtbox.sendKeys("1234567890");
        physicianhnametbox.sendKeys("PhysicianName");
        physicianpnumtbox.sendKeys("1234567890");

        //Click on Continue button
       element(by.buttonText('Continue')).click();

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/ContactsPage/');
        });

        browser.sleep(1000);
    });
});