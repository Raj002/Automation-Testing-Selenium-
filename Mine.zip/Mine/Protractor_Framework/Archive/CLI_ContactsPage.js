/**
 * Created by n0305595 on 05/19/2017.
 */

//Import Page objects

//var cppageobj = require('./VSPageObjects.js');


describe ('Open URL in browser and validate contacts page labels', function(){


  //Take Screenshots
  var fs = require('fs');
  function writeScreenShot(data, filename) {
    var stream = fs.createWriteStream(filename);
    stream.write(new Buffer(data, 'base64'));
    stream.end();
  }

  //Increase TimeOut_Interval
  originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
  jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;


  //TestCase - 1 Contacts Page English
  it('Engish - enter value', function() {
    browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/');
    element(by.css('[href="/cli/contacts"]')).click();

    //Store Page elements
    //var hlink  = element(by.className('progressactive')).getText();
    var mtitle = element(by.id('header1')).getText();
    var ttitle  = element(by.id('header2')).getText();
    var fname  = element(by.xpath('//div/ui-view/contacts/div/div[2]/div/section/div[1]/fieldset/label')).getText();
    var lname   = element(by.xpath('//div/ui-view/contacts/div/div[2]/div/section/div[2]/fieldset/label')).getText();
    var pnum = element(by.xpath('//div/ui-view/contacts/div/div[2]/div/section/div[3]/fieldset/label')).getText();
    var pnumformat = element(by.xpath('//div/ui-view/contacts/div/div[2]/div/section/div[3]/fieldset/span[1]')).getText();
    var conbutton = element(by.xpath('//div/ui-view/contacts/button[2]')).getText();
    var gobackbutton = element(by.xpath('//div/ui-view/contacts/button[1]')).getText();
    var fnametbox = element(by.id('physicianFirstName'));
    var lnametbox = element(by.id('physicianLastName'));
    var pnumtbox = element(by.id('physicianphone'));
    var pnumerr1 = element(by.xpath('//div/ui-view/contacts/div/div[2]/div/section/div[3]/fieldset/span[2]'));


    //Valdiate Page elements
    //expect(hlink).toEqual('About Your Contacts');
    expect(mtitle).toEqual('Medical Contacts');
    expect(ttitle).toEqual('Treating Physician Information');
    expect(fname).toEqual("Physician's First Name");
    expect(lname).toEqual("Physician's Last Name");
    expect(pnum).toEqual("Physician's Phone Number");
    expect(pnumformat).toEqual("(###) ### - ####");
    expect(conbutton).toEqual("Continue");
    expect(gobackbutton).toEqual("Go Back");
    expect((fnametbox).isDisplayed()).toBe(true);
    expect((lnametbox).isDisplayed()).toBe(true);
    expect((pnumtbox).isDisplayed()).toBe(true);

    //Validate for Data Entry - Physician's First Name
    fnametbox.sendKeys("Testing-");
    expect(fnametbox.getAttribute('value')).toEqual("Testing-");
    fnametbox.clear();
    fnametbox.sendKeys("1234567890");
    expect(fnametbox.getAttribute('value')).toEqual("");
    fnametbox.clear();
    fnametbox.sendKeys("!@#$%^&*()_+=<>?,./:");
    expect(fnametbox.getAttribute('value')).toEqual("");
    fnametbox.clear();
    fnametbox.sendKeys(";'{}[]'");
    expect(fnametbox.getAttribute('value')).toEqual("''");
    fnametbox.clear();

    //Validate for Data Entry - Physician's Last Name
    lnametbox.sendKeys("Testing-'");
    expect(lnametbox.getAttribute('value')).toEqual("Testing-'");
    lnametbox.clear();
    lnametbox.sendKeys("1234567890");
    expect(lnametbox.getAttribute('value')).toEqual("");
    lnametbox.clear();
    lnametbox.sendKeys("!@#$%^&*()_+=<>?,./:");
    expect(lnametbox.getAttribute('value')).toEqual("");
    lnametbox.clear();
    lnametbox.sendKeys(";'{}[]'");
    expect(lnametbox.getAttribute('value')).toEqual("''");
    lnametbox.clear();

    //Validate for Data Entry - Physician's Phone Number
    pnumtbox.sendKeys("1234567890");
    expect(pnumtbox.getAttribute('value')).toEqual("(123) 456-7890");
    expect(pnumerr1.isDisplayed()).toBe(false);
    pnumtbox.clear();
    pnumtbox.sendKeys("12345678");
    conbutton.click();
    expect(pnumerr1.isDisplayed()).toBe(true);

    browser.takeScreenshot().then(function (png) {
      writeScreenShot(png, 'exception.png');
    });

  });


  //-------------------------------------------------------***********************************---------------------------------------------------------//
  //-------------------------------------------------------***********************************---------------------------------------------------------//

  ////TestCase - 2 Contacts Page Spanish
  //it('Spanish - enter value', function() {
  //
  //  browser.ignoreSynchronization = false
  //  browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/');
  //  var langtoggle = element(by.className('link'));
  //  var contacts = element(by.css('[uisref="contacts"]'));
  //
  //  //Toggle to Spanish and Navigate to Contacts Page
  //  langtoggle.click();
  //  contacts.click();
  //
  //  //Store Page elements
  //  var hlink  = element(by.className('progressactive')).getText();
  //  var mtitle = element(by.id('header1')).getText();
  //  var ttitle  = element(by.id('header2')).getText();
  //  var fname  = element(by.xpath('//div/ui-view/contacts/div/div[2]/div/section/div[1]/fieldset/label')).getText();
  //  var lname   = element(by.xpath('//div/ui-view/contacts/div/div[2]/div/section/div[2]/fieldset/label')).getText();
  //  var pnum = element(by.xpath('//div/ui-view/contacts/div/div[2]/div/section/div[3]/fieldset/label')).getText();
  //  var pnumformat = element(by.xpath('//div/ui-view/contacts/div/div[2]/div/section/div[3]/fieldset/span[1]')).getText();
  //  var conbutton = element(by.xpath('//div/ui-view/contacts/button[2]')).getText();
  //  var gobackbutton = element(by.xpath('//div/ui-view/contacts/button[1]')).getText();
  //  var fnametbox = element(by.id('physicianFirstName'));
  //  var lnametbox = element(by.id('physicianLastName'));
  //  var pnumtbox = element(by.id('physicianphone'));
  //
  //  //Valdiate Page elements
  //  expect(hlink).toEqual('Otros contactos');
  //  expect(mtitle).toEqual('Medical Contacts');
  //  expect(ttitle).toEqual('Treating Physician Information');
  //  expect(fname).toEqual("Nombre del M"+ '\u00E9' +"dico");
  //  expect(lname).toEqual("Apellido del M"+ '\u00E9' +"dico");
  //  expect(pnum).toEqual("Nombre del hospital o nombre de la pr"+ '\u00E1' + "ctica de los m"+ '\u00E9' +"dicos");
  //  expect(pnumformat).toEqual("(###) ### - ####");
  //  expect(conbutton).toEqual("Continuar");
  //  expect(gobackbutton).toEqual("Volver");
  //  expect((fnametbox).isDisplayed()).toBe(true);
  //  expect((lnametbox).isDisplayed()).toBe(true);
  //  expect((pnumtbox).isDisplayed()).toBe(true);
  //
  //});
});

================================================================

/**
 * Created by n0305595 on 6/19/2017.
 */


var POAYC = function(){

  //About Your Contacts - Progress Bar
  this.contactspbar = {
    element(by.css('[href="/cli/contacts"]'))
  };
  //Medical Contacts - Header
  this.medheader = {
    input: element(by.id('header1'))
  };
  //"Please provide us with one of the contacts below to help expedite the processing of your absence request." - Static Text
  this.statictext = {
    input: element(by.id('header2'))
  };
  //"Treating Physician Information" - Header
  this.physicianinfoheader = {
    input: element(by.id('header3'))
  };
  //Physician's First Name - Label
  this.physicianfnamelabel = {
    input: element.all(by.className('fieldset__label_optional')).get(0)
  };
  //Physician's First Name (optional) - Label
  this.physicianfnameoplabel = {
    input: element.all(by.className('fieldset__optional')).get(0)
  };
  //Physician's First Name  - Textbox
  this.physicianfnametbox = {
    input: element(by.id('physicianFirstName'))
  };
  //Physician's Last Name - Label
  this.physicianlnamelabel = {
    input: element.all(by.className('fieldset__label_optional')).get(1)
  };
  //Physician's Last Name (optional) - Label
  this.physicianlnameoplabel = {
    input: element.all(by.className('fieldset__optional')).get(1)
  };
  //Physician's Last Name  - Textbox
  this.physicianlnametbox = {
    input: element(by.id('physicianLastName'))
  };
  //Physician's Phone Number - Label
  this.physicianpnumlabel = {
    input: element.all(by.className('fieldset__label_optional')).get(2)
  };
  //Physician's Phone Number (optional) - Label
  this.physicianpnumoplabel = {
    input: element.all(by.className('fieldset__optional')).get(2)
  };
  //Physician's Phone Number  - Textbox
  this.physicianpnumtbox = {
    input: element(by.id('physicianphone'))
  };
  //Physician's Phone Number format - Label
  this.physicianpnumformatlabel = {
    input: element.all(by.className('fieldset__help-text')).get(0)
  };
  //Hospital Name or Physicians Practice Name - Label
  this.physicianhnamelabel = {
    input: element.all(by.className('fieldset__label_optional')).get(3)
  };
  //Hospital Name or Physicians Practice Name (optional) - Label
  this.physicianhnameoplabel = {
    input: element.all(by.className('fieldset__optional')).get(3)
  };
  //Hospital Name or Physicians Practice Name   - Textbox
  this.physicianhnametbox = {
    input: element(by.id('hospitalName'))
  };
  //Hospital or Physicians Practice Phone Number - Label
  this.physicianhpnumlabel = {
    input: element.all(by.className('fieldset__label_optional')).get(4)
  };
  //Hospital or Physicians Practice Phone Number (optional) - Label
  this.physicianhpnumoplabel = {
    input: element.all(by.className('fieldset__optional')).get(4)
  };
  //Hospital or Physicians Practice Phone Number format - Label
  this.physicianhpnumformatlabel = {
    input: element.all(by.className('fieldset__help-text')).get(1)
  };
  //Hospital or Physicians Practice Phone Number format - Textbox
  this.physicianhpnumtbox = {
    input: element(by.id('hospitalNumber'))
  };
  //Continue Button
  this.continuebutton = {
    input: element(by.buttonText('Continue'))
  };
  //Go Back Button
  this.gobackbutton = {
    input: element(by.buttonText('Go Back'))
  };
  //Validation message
  this.validationmessage = {
    input: element.all(by.className('fieldset__feedback fieldset__feedback--invalid'))
  };

};



module.exports = new POAYC();