/**
 * Created by n0275896 on 7/12/2017.
 */
var PORPER = require('./PageObject_ER_ReviewPage.js');

//Take Screenshots
var fs = require('fs');
function writeScreenShot(data, filename) {
    var stream = fs.createWriteStream(filename);
    stream.write(new Buffer(data, 'base64'));
    stream.end();
}
describe ('Open URL in browser and validate ER Review page', function() {


    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;


/******************** Beginning of Test Case I - Verify Review page Links and Sections ******************************/

    it('New CI_Review Page Link and Sections for ER', function () {

        //Open the ER link in the browser and click Review link
        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/employer/cli');
        element(by.css('[href="/employer/cli/review"]')).click();

        var timestamp;
        var today = new Date();
        var month = today.getMonth() + 1;
        timestamp = today.getDate()+ "_" + month + "_" + today.getFullYear()+ "_"+today.getHours()+"_"+ today.getMinutes()+"_"+today.getSeconds();
        var screenshot;
        screenshot = "./Screenshots/6203/";

        //Verify the page header for review page
        var reviewheader = PORPER.reviewheader.input.getText();
        expect(reviewheader).toEqual('Review');


        //Instructional dynamic content
        var instructionaltextcontent = PORPER.instructionaltextcontent.input.getText();
        expect(instructionaltextcontent).toContain('with Instructional text (Text are still TBD)');

        //Get Help - Label
        var gethelplabel = PORPER.gethlplabel.input.getText();
        expect(gethelplabel).toEqual('Get Help');

        //Verify GetHelp pop up is displayed
        PORPER.gethlplabel.input.click();
        expect(PORPER.popuphelp.input.isDisplayed()).toBe(true);

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, screenshot+"Testcase1_Screenshot1"+"_"+timestamp+".png");
        });
        element(by.buttonText('Close')).click();

        //About Your Employee section - Label
        var aboutyousection = PORPER.aboutyousection.input.getText();
        expect(PORPER.aboutyousection.input.isDisplayed()).toBe(true);
        expect(aboutyousection).toEqual('About Your Employee');

        //Verify accordian for About Your Employee is not expanded
        //expect(PORPER.aboutyouaccordiant.input.isPresent()).toBeTruthy();

        //About Your Employee’s Absence - Label
        var aboutyourabsencesection = PORPER.aboutyourabsencesection.input.getText();
        expect(PORPER.aboutyourabsencesection.input.isDisplayed()).toBe(true);
        expect(aboutyourabsencesection).toEqual('About Your Employee’s Absence');

        //Verify accordian for About Your Employee Absence is not expanded
        expect(PORPER.aboutabsenceaccordiant.input.isPresent()).toBeFalsy();

        //Additional Information section - Label
        var addlinfosection = PORPER.addlinfosection.input.getText();
        expect(PORPER.addlinfosection.input.isDisplayed()).toBe(true);
        expect(addlinfosection).toEqual('Additional Information');

        //Verify accordian for Additional Information is not expanded
        expect(PORPER.addlinfoaccordiant.input.isPresent()).toBeFalsy();

        //About You section - Edit Label
        var aboutyousedit = PORPER.aboutyousedit.input.getText();
        expect(aboutyousedit).toEqual('Edit');

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, screenshot+"Testcase1_Screenshot2"+"_"+timestamp+".png");
        });


        //Verify About Your Employee page is dislayed when Edit is clicked
        aboutyousedit.click();
        expect(PORPER.abtyouremppage.input.isDisplayed()).toBe(true);
        browser.sleep(1000);

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, screenshot+"Testcase1_Screenshot3"+"_"+timestamp+".png");
        });

        element(by.css('[href="/employer/cli/review"]')).click();


        //About Your Absence - Edit Label
        var aboutyourabsenceedit = PORPER.aboutyourabsenceedit.input.getText();
        expect(aboutyourabsenceedit).toEqual('Edit');


        //Verify About Your Employee Absence page is dislayed when Edit is clicked
        aboutyourabsenceedit.click();
        expect(PORPER.abtyourabsemppage.input.isDisplayed()).toBe(true);
        browser.sleep(1000);

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, screenshot+"Testcase1_Screenshot4"+"_"+timestamp+".png");
        });

        element(by.css('[href="/employer/cli/review"]')).click();


        //Additional Information - Edit Label
        var addlinfoedit = PORPER.addlinfoedit.input.getText();
        expect(addlinfoedit).toEqual('Edit');

        //Verify Additional Info page is dislayed when Edit is clicked
        addlinfoedit.click();
        expect(PORPER.addlinfopage.input.isDisplayed()).toBe(true);
        browser.sleep(1000);

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, screenshot+"Testcase1_Screenshot5"+"_"+timestamp+".png");
        });

        element(by.css('[href="/employer/cli/review"]')).click();


        //Submit button -  Label
        var submitbutton = PORPER.submitbutton.input.getText();
        expect(submitbutton).toEqual('Submit');

        //Go back button -  Label
        var gobackbutton = PORPER.gobackbutton.input.getText();
        expect(gobackbutton).toEqual('Go Back');

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, screenshot+"Testcase1_Screenshot6"+"_"+timestamp+".png");
        });


        //Verify the accordian format when "About your Employee section is clicked
        aboutyousection.click();
        aboutyousection.click();
        expect(PORPER.aboutyouaccordiant.input.isPresent()).toBeTruthy();
        expect(PORPER.addlinfoaccordiant.input.isPresent()).toBeFalsy();
        expect(PORPER.aboutabsenceaccordiant.input.isPresent()).toBeFalsy();
        browser.sleep(1000);

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, screenshot+"Testcase1_Screenshot7"+"_"+timestamp+".png");
        });


        //Verify the accordian format when "About your Employee Absence section is clicked
        aboutyourabsencesection.click();
        expect(PORPER.aboutyouaccordianf.input.isPresent()).toBeTruthy();
        expect(PORPER.addlinfoaccordianf.input.isPresent()).toBeTruthy();
        expect(PORPER.aboutabsenceaccordiant.input.isPresent()).toBeTruthy();
        browser.sleep(1000);

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, screenshot+"Testcase1_Screenshot8"+"_"+timestamp+".png");
        });


        //Verify the accordian format when "Additional Information section is clicked
        addlinfosection.click();
        expect(PORPER.aboutyouaccordiant.input.isPresent()).toBeFalsy();
        expect(PORPER.addlinfoaccordiant.input.isPresent()).toBeTruthy();
        expect(PORPER.aboutabsenceaccordiant.input.isPresent()).toBeFalsy();
        browser.sleep(1000);


        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, screenshot+"Testcase1_Screenshot9"+"_"+timestamp+".png");
        });


    });


/******************** Beginning of Test Case 2 - Verify Medical contacts section is not displayed for the Employer******************************/
     it('New CI_Review Page Link and Sections for ER_Negative Scenario', function () {

         //Open the ER link in the browser and click Review link
         browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/employer/cli');
         element(by.css('[href="/employer/cli/review"]')).click();


         var cnt;

         var lists = element.all(by.className('accordion-toggle collapsed'));
         lists.count().then(function(c)
         {
             cnt = c;

             for(var i = 0; i<cnt ; i++)
             {

                 var section;
                 section = lists.get(i).getText();
                 expect(section).not.toContain('Medical Contacts');
             }
         });

         var lists1 = element.all(by.className('accordion-toggle'));
         lists.count().then(function(c)
         {
             cnt = c;

             for(var i = 0; i<cnt ; i++)
             {

                 var section;
                 section = lists.get(i).getText();
                 expect(section).not.toContain('Medical Contacts');
             }
         });

     });

    /******************** End of Test Case 2 - Verify Medical contacts section is not displayed for the Employer******************************/
});



