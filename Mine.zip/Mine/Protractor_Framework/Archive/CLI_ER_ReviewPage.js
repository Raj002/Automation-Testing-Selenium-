/**
 * Created by n0238696 on 7/11/2017.
 */

var PORPER = require('./PageObject_ER_ReviewPage.js');

//Take Screenshots
var fs = require('fs');
function writeScreenShot(data, filename) {
    var stream = fs.createWriteStream(filename);
    stream.write(new Buffer(data, 'base64'));
    stream.end();
}
describe ('Open URL in browser and validate ER Review page', function() {


    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;


    //TestCase - 1 Contacts Page English
    it('CLI_ER_ReviewPage: Label/Header Validations', function () {

         browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/employer/cli');
         element(by.css('[href="/employer/cli/review"]')).click();

        //Review - Progress bar label
        var reviewpbar = PORPER.reviewpbar.input.getText();
        expect(reviewpbar).toEqual('Review');

        //Review - Header Label
        var reviewheader = PORPER.reviewheader.input.getText();
        expect(reviewheader).toEqual('Review');

        //Instructional dynamic content
        var instructionaltextcontent = PORPER.instructionaltextcontent.input.getText();
        expect(instructionaltextcontent).toEqual('with Instructional text (Text are still TBD)');

        //Get Help - Label
        var gethelplabel = PORPER.gethelplabel.input.getText();
        expect(gethelplabel).toEqual('Get Help');

        //About You section - Label
        var aboutyousection = PORPER.aboutyousection.input.getText();
        expect(aboutyousection).toEqual('About You');

        //About Your Absence - Label
        var aboutyourabsencesection = PORPER.aboutyourabsencesection.input.getText();
        expect(aboutyourabsencesection).toEqual('About Your Absence');

        //About You section - Edit Label
        var aboutyousedit = PORPER.aboutyousedit.input.getText();
        expect(aboutyousedit).toEqual('Edit');

        //About Your Absence - Edit Label
        var aboutyourabsenceedit = PORPER.aboutyourabsenceedit.input.getText();
        expect(aboutyourabsenceedit).toEqual('Edit');

        //Submit button -  Label
        var submitbutton = PORPER.submitbutton.input.getText();
        expect(submitbutton).toEqual('Submit');

        //Go back button -  Label
        var gobackbutton = PORPER.gobackbutton.input.getText();
        expect(gobackbutton).toEqual('Go Back');
    });
});




