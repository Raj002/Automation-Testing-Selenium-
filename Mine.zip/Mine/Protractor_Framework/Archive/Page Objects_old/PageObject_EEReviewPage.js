/**
 * Created by n0258375 on 7/11/2017.
 */


var POEER = function() {

    //En Espanol link
    this.spanlink = {
        input: (element.all(by.tagName('//a')).get(1))
    };

    //Review - Header
    this.reviewheader = {
        input: (element.all(by.tagName('h1')).get(1))
    };

    //Instruction text under Review page header
    this.instext = {
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/review/div[1]/div[1]'))
    };

    //Get Help link
    this.gethelplnk =  {
        input: element(by.css('.linkBold a'))
    };

    //About You page label
    this.abtyoulbl = {
        input: element(by.css('[href="#collapse1"]'))
    };

    //About You Accordion
    this.abtyouaccf = {
        input: element(by.css('[href="#collapse1"][aria-expanded="false"]'))
    };

    this.abtyouacct = {
        input: element(by.css('[href="#collapse1"][aria-expanded="true"]'))
    };

    //About Your Absence label
    this.abtyouabsencelbl = {
        input: element(by.css('[href="#collapse2"]'))
    };

    //About Your Absence Accordion
    this.abtyourabsaccf = {
        input: element(by.css('[href="#collapse2"][aria-expanded="false"]'))
    };

    this.abtyourabsacct = {
        input: element(by.css('[href="#collapse2"][aria-expanded="true"]'))
    };

    //Medical Contacts label
    this.medicalconlbl = {
        input: element(by.css('[href="#collapse4"]'))
    };

    //Medical Contacts Accordion
    this.medconaccf = {
        input: element(by.css('[href="#collapse4"][aria-expanded="false"]'))
    };

    this.medcont = {
        input: element(by.css('[href="#collapse4"][aria-expanded="true"]'))
    };

    //About You page Edit link
    this.abtyoueditlnk = {
        input: (element.all(by.className('editLink')).get(0))
    };

    //About Your Absence page Edit link
    this.abtyouabseditlnk = {
     input: (element.all(by.className('editLink')).get(1))
    };

    //Medical Contacts page Edit link
   this.medconeditlnk = {
        input: (element.all(by.className('editLink')).get(2))
    };

    //Submit Button
    this.submitbutton = {
        input: element(by.buttonText('Submit'))
    };

    //Submit Button - Spanish
    this.submitspanbutton = {
        input: element(by.buttonText('Enviar'))
    };

    //Go Back Button
    this.gobackbtn = {
        input: element(by.buttonText('Go Back'))
    };

    //Review header Progress bar
   /* this.reviewprgressbar = {
        input: element(by.xpath("//*[@id='progressbar']/div/div/ol/li[5]/a"))
    };*/

    //About You page
    this.abtyouhdr = {
        input: (element.all(by.tagName('h1')).get(1))
    };

    //About Your Absence page
    this.abtyourabshdr = {
    input: (element.all(by.tagName('h1')).get(1))
    };

    //Medical Contacts page
    this.medconhdr = {
    input: (element.all(by.tagName('h1')).get(1))
    };

    //Save for Later button
    this.saveforlaterbutton = {
        input: element(by.buttonText('Save for Later'))
    };

    //Save for Later - Popup
    this.savepopup = {
        input: element(by.className('modal-title'))
    };

    //Exit Application button - Save for Later Popup
    this.exitappbtn = {
        input: element(by.buttonText('Exit Application'))
    };

    //Return to Application button - Save for Later Popup
    this.rettoappbtn = {
        input: element(by.buttonText('Return to Application'))
    };

    //About you label - Employee ID

    this.lblemployeeid = {
        input:  element.all(by.className('fieldset__label')).get(0)

    };

    this.txtemployeeid = {
        input:  element.all(by.className('fieldset__label')).get(1)

    };

    this.lblfirstname = {
        input:  element.all(by.className('fieldset__label')).get(2)

    };

    this.txtfirstname = {
        input:  element.all(by.className('fieldset__label')).get(3)

    };

    this.lblmiddle = {
        input:  element.all(by.className('fieldset__label')).get(6)

    };

    this.txtmiddle = {
        input:  element.all(by.className('fieldset__label')).get(7)

    };


    this.lbllastname = {
        input:  element.all(by.className('fieldset__label')).get(10)

    };

    this.txtlastname = {
        input:  element.all(by.className('fieldset__label')).get(11)

    };

    this.lblgender1 = {
        input:  element.all(by.className('fieldset__label')).get(14)

    };

    this.txtgender1 = {
        input:  element.all(by.className('fieldset__label')).get(15)

    };

    this.lblstate = {
        input:  element.all(by.className('fieldset__label')).get(16)

    };

    this.txtstate = {
        input:  element.all(by.className('fieldset__label')).get(17)

    };

    this.lbldob = {
        input:  element.all(by.className('fieldset__label')).get(16)

    };

    this.txtdob = {
        input:  element.all(by.className('fieldset__label')).get(19)

    };

    this.otxtdob ={
        input:  element.all(by.className('fieldset__label')).get(17)
    };


    this.ocountry ={
        input:  element.all(by.className('fieldset__label')).get(19)
    };


    this.ophone ={
        input:  element.all(by.className('fieldset__label')).get(21)
    };

    this.opostalcode ={
        input:  element.all(by.className('fieldset__label')).get(23)
    };

    this.opemail ={
        input:  element.all(by.className('fieldset__label')).get(25)
    };

    this.oecountry ={
        input:  element.all(by.className('fieldset__label')).get(27)
    };

    this.lblpphone = {
        input:  element.all(by.className('fieldset__label')).get(20)

    };

    this.txtpphone = {
        input:  element.all(by.className('fieldset__label')).get(23)

    };

    this.lblpemail = {
        input:  element.all(by.className('fieldset__label')).get(24)

    };


    this.txtpemail = {
        input:  element.all(by.className('fieldset__label')).get(27)

    };

    this.lblprefmethod = {
        input:  element.all(by.className('fieldset__label')).get(28)

    };

    this.txtprefmethod = {
        input:  element.all(by.className('fieldset__label')).get(31)

    };

    this.lblresaddress1 = {
        input:  element.all(by.className('fieldset__label')).get(4)

    };

    this.txtresaddress1 = {
        input:  element.all(by.className('fieldset__label')).get(5)

    };

    this.lblresaddress2 = {
        input:  element.all(by.className('fieldset__label')).get(8)

    };

    this.txtresaddress2 = {
        input:  element.all(by.className('fieldset__label')).get(9)

    };

    this.lblrescity = {
        input:  element.all(by.className('fieldset__label')).get(12)

    };

    this.txtrescity = {
        input:  element.all(by.className('fieldset__label')).get(13)

    };

    this.lblcountry = {
        input:  element.all(by.className('fieldset__label')).get(18)

    };

    this.txtcountry = {
        input:  element.all(by.className('fieldset__label')).get(21)

    };

    this.lblpostalcode = {
        input:  element.all(by.className('fieldset__label')).get(22)

    };

    this.txtpostalcode = {
        input:  element.all(by.className('fieldset__label')).get(25)

    };

    this.lblcounofemploy = {
        input:  element.all(by.className('fieldset__label')).get(26)

    };

    this.txtcounofemploy = {
        input:  element.all(by.className('fieldset__label')).get(29)

    };

    this.lblfax = {
        input:  element.all(by.className('fieldset__label')).get(34)

    };


    this.txtfax = {
        input:  element.all(by.className('fieldset__label')).get(35)

    };

    this.lblstateofemploy = {
        input:  element.all(by.className('fieldset__label')).get(32)

    };

    this.txtstateofemploy = {
        input:  element.all(by.className('fieldset__label')).get(33)

    };

    this.lblphyfirstname = {
        input:  element.all(by.className('fieldset__label')).get(34)

    };

    this.txtphyfirstname = {
        input:  element.all(by.className('fieldset__label')).get(35)

    };

    this.lblhosphyfirstname = {
        input:  element.all(by.className('fieldset__label')).get(36)

    };

    this.txthosphyfirstname = {
        input:  element.all(by.className('fieldset__label')).get(37)

    };

    this.lblphylastname = {
        input:  element.all(by.className('fieldset__label')).get(38)

    };

    this.txtphylastname = {
        input:  element.all(by.className('fieldset__label')).get(39)

    };

    this.lblhosphyphonenumber = {
        input:  element.all(by.className('fieldset__label')).get(40)

    };

    this.txthosphyphonenumber = {
        input:  element.all(by.className('fieldset__label')).get(41)

    };

    this.lblphyphonenumber = {
        input:  element.all(by.className('fieldset__label')).get(42)

    };

    this.txtphyphonenumber = {
        input:  element.all(by.className('fieldset__label')).get(43)

    };







    };

    module.exports = new POEER();