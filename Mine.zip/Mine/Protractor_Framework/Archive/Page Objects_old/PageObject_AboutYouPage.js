/**
 * Created by n0305595 on 6/20/2017.
 */

var POAYP = function() {

    //About you page header
    this.aboutyouheader = {
        input: (element.all(by.tagName('h1')).get(1))
    };

    //Header - "Please enter Either Your Employee ID or Your SSN"
    this.searchMessage = {
        input: element(by.id('esfieldsetSearchMessage'))
    };

    this.Englishspanishlink = {
        input: element(by.className('link'))
    };

    //EmployeeID - Radio Button
    this.empidradio = {
        input: element(by.id('empID'))
    };
    //EmployeeID -Radio Button Field Label
    this.empidtext = {
        input: element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).first()
    };
    //SSN - Radio Button
    this.ssnradio = {
        input: element(by.id('SSN'))
    };
    //SSN - Radio Button Text
    this.ssntext = {
        input: element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(1)
    };
    //Employee ID - TextBox Label
    this.empidlabel = {
        input: element(by.id('esfieldsetEmpID')).element(by.className('fieldset__label'))
    };
    //Employee ID - TextBox
    this.empidtbox = {
        input: element(by.name('empId'))
    };
    //Employee ID - Validation Message
    this.empidemsg = {
        input: (element(by.id('esfieldsetEmpID')).element(by.className('fieldset__feedback fieldset__feedback--invalid')))
    };
    //SSN - TextBox Label
    this.ssnlabel = {
        input: element(by.id('esfieldsetSSN')).element(by.className('fieldset__label'))
    };
    //SSN - TextBox
    this.ssntbox = {
        input: element(by.name('SSN'))
    };
    //SSN - Validation Message
    this.ssnemsg = {
        input: (element(by.id('esfieldsetSSN')).element(by.className('fieldset__feedback fieldset__feedback--invalid')))
    };
    //SSN - Format
    this.ssnformat = {
        input: (element(by.id('esfieldsetSSN')).element(by.className('fieldset__help-text')))
    };
    //Employee ID - Get Help - Link
    this.gethelplink1 = {
        input: (element(by.id('esfieldsetEmpIDheader')).element(by.className('link linkSeparator')))
    };
    //SSN - Get Help - Link
    this.gethelplink2 = {
        input: (element.all(by.className('link linkSeparator')).get(3))
    };

    //Search Button Name Validation
    this.searchbtnname = {
        input: (element(by.buttonText('Search')))
    };

    //Personal Information Header - Validation
    this.personalinfoheader = {
        input: element.all(by.className('heading--beta')).get(0)
    };

    //FirstName Label
    this.fnamelabel = {
        input: (element(by.id('esfieldsetFirstName')).element(by.className('fieldset__label')))
    };
    //FirstName - TextBox
    this.fnametbox = {
        input: element(by.name('firstname'))
    };
    //FirstName - Validation Message
    this.fnameemsg = {
        input: (element(by.id('esfieldsetFirstName')).element(by.className('fieldset__feedback fieldset__feedback--invalid')))
    };

    //MiddleName Label
    this.mnamelabel = {
        input: (element(by.id('fieldsetMiddleName')).element(by.className('fieldset__label')))
    };

    //MiddleName - TextBox
    this.mnametbox = {
        input: (element(by.id('fieldsetMiddleName')).element(by.className('fieldset__input percentagewidth50 ng-untouched ng-pristine ng-invalid')))
    };
    //MiddleName - Validation Message - No error message will be displayed for Middle Name

    //LastName Label
    this.lnamelabel = {
        input: (element(by.id('esfieldsetLastName')).element(by.className('fieldset__label')))
    };
    //LastName - TextBox
    this.lnametbox = {
        input: element(by.name('lastName'))
    };
    //LastName - Validation Message
    this.lnameemsg = {
        input: (element(by.id('esfieldsetLastName')).element(by.className('fieldset__feedback fieldset__feedback--invalid')))
    };

    //Gender - Label Validation
    this.genderlabel = {
        input: element(by.id('Gender'))
    };

    //Radio button Male  - Label Validation
    this.malelabel = {
        input: element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(2)
    };

    //Radio button Female  - Label Validation
    this.femalelabel = {
        input: element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(3)
    };

    //Radio Button Male - Validation
    this.rbtnmale = {
        input: element(by.id('male'))
    };

    //Radio Button Female - Validation
    this.rbtnfemale = {
        input: element(by.id('female'))
    };

    //Gender - Validation Message
    this.genderemsg = {
        input: (element(by.id('esfieldsetgender')).element(by.className('fieldset__feedback fieldset__feedback--invalid')))
    };

    //Date of Birth Label
    this.doblabel = {
        input: (element(by.id('esfieldsetDob')).element(by.className('fieldset__label_optional')))
    };
    //Date of Birth format
    this.dobformatlabel = {
        input: (element(by.id('esfieldsetDob')).element(by.className('fieldset__help-text')))
    };
    //Date of Birth - TextBox
    this.dobtbox = {
        input: (element(by.name('dob')))
    };
    //Preferred Personal Phone Label
    this.ppphonelabel = {
        input: (element(by.id('esfieldsetPhone')).element(by.className('fieldset__label')))
    };
    //Preferred Personal Phone format
    this.ppphoneformatlabel = {
        input: (element(by.id('esfieldsetPhone')).element(by.className('fieldset__help-text')))
    };
    //Preferred Personal Phone - TextBox
    this.ppphonetbox = {
        input: (element(by.name('phone')))
    };
    //Preferred Personal Phone - Validation Message
    this.ppphoneemsg = {
        input: (element(by.id('esfieldsetPhone')).element(by.className('fieldset__feedback fieldset__feedback--invalid')))
    };
    //Preferred Personal Email Label
    this.ppemaillabel = {
        input: (element(by.id('esfieldsetEmail')).element(by.className('fieldset__label')))
    };
    //Preferred Personal Email format
    this.ppemailformatlabel = {
        input: (element(by.id('esfieldsetEmail')).element(by.className('fieldset__help-text')))
    };
    //Preferred Personal Email - TextBox
    this.ppemailtbox = {
        input: (element(by.name('email')))
    };
    //Preferred Personal Email - Validation Message
    this.ppemailemsg = {
        input: (element(by.id('esfieldsetEmail')).element(by.className('fieldset__feedback fieldset__feedback--invalid')))
    };
    //Emp Country - Label
    this.empcountrylabel = {
        input: (element(by.id('esfieldsetCountry')).element(by.className('fieldset__label')))
    };
    //Emp Country - Drop down
    this.empcountrylist = {
        input: (element(by.name('country')))
    };

    //Residential Adresss1  - Label
    this.resaddr1label = {
        input: (element(by.id('esfieldsetAdd1')).element(by.className('fieldset__label')))
    };
    //Residential Adresss1  - text box
    this.resaddrtbox1 = {
        input: element(by.name('res1'))
    };

    //Residential Adresss1  - validation message
    this.resaddr1emsg = {
        input: (element(by.id('esfieldsetAdd1')).element(by.className('fieldset__feedback fieldset__feedback--invalid')))
    };
    //Residential Address 2- Label
    this.resaddr2label = {
        input: (element(by.id('esfieldsetAdd2')).element(by.className('fieldset__label_optional')))
    };

    //Residential Adresss2  - text box
    this.resaddrtbox2 = {
        input: element(by.name('res2'))
    };


    //Residential City  - Label
    this.rescitylabel = {
        input: (element(by.id('esfieldsetAdd3')).element(by.className('fieldset__label')))
    };

    //Residential City  - text box
    this.rescitytbox = {
        input: element(by.name('rescity'))
    };

    this.rescityemsg = {
        input: (element(by.id('esfieldsetAdd3')).element(by.className('fieldset__feedback fieldset__feedback--invalid')))
    };

    //Residential State  - Label
    this.resstatelabel = {
        input: (element(by.id('esfieldsetState')).element(by.className('fieldset__label')))
    };

    //Residential State  - Dropdown
    this.resstatelist = {
        input: element(by.name('state'))
    };


    //Residential State  - Error
    this.resstateemsg = {
        input: (element(by.id('esfieldsetState')).element(by.className('fieldset__feedback fieldset__feedback--invalid')))
    };

    //Residential Postal Code  - Label
    this.postalcodelabel = {
        input: (element(by.id('esfieldsetPostalcode')).element(by.className('fieldset__label')))
    };

    //Residential Postal Code  - text box
    this.postalcdetbox = {
        input: element(by.name('postalCode'))
    };

    //Postal Code Required validation message
    this.postalmsg = {
        input: element(by.id('esfieldsetPostalcode')).element(by.className('fieldset__feedback fieldset__feedback--invalid'))
    };

    //Preferred Method - Label
    this.prefmethodlabel = {
        input: (element(by.id('esfieldsetPreferredMethod')).element(by.className('fieldset__label')))
    };

    //Preferred Method - Email
    this.prefmethodemail = {
        input: (element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(4))
    };

    //Preferred Method - Fax
    this.prefmethodfax = {
        input: (element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(5))
    };

    //Preferred Method - Mail
    this.prefmethodmail = {
        input: (element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(6))
    };

    //Preferred Method - Email -  Radio Button
    this.prefmethodrbtnemail = {
        input: (element(by.id('email')))
    };
    //Preferred Method - Fax -  Radio Button
    this.prefmethodrbtnfax = {
        input: (element(by.id('fax')))
    };
    //Preferred Method - Mail -  Radio Button
    this.prefmethodrbtnmail = {
        input: (element(by.id('Mail')))
    };

    //Primary Work  Location  Header - Validation
    this.primaryworkheader = {
        input: element.all(by.className('heading--beta')).get(1)
    };


    //Preferred Method - Mail -  Radio Button
    this.prefmethodfax = {
        input: (element(by.name('fax')))
    };
    //CountryofEmploy - Label
    this.countryofemploylabel = {
        input: (element(by.id('empCountry')).element(by.className('fieldset__label')))
    };

    //CountryofEmploy - Dropdown
    this.countryofemploylist = {
        input: (element(by.name('empcountry')))

    };

    //StateofEmployment - label
    this.stateofemploylabel = {
        input: (element(by.id('esfieldsetEmpState')).element(by.className('fieldset__label')))

    };
    //StateofEmployment - dropdown
    this.stateofemploylist = {
        input: (element(by.name('empstate')))

    };

    //StateofEmployment - Validation Message
    this.stateofemployemsg = {
        input: (element(by.id('esfieldsetEmpState')).element(by.className('fieldset__feedback fieldset__feedback--invalid')))

    };
    //GoBack Button Name
    this.gobackbutton = {
        input: element(by.buttonText('Go Back'))
    };

    //Continue Button Name
    this.continuebutton = {
        input: element(by.buttonText('Continue'))
    };

    //Continue Button Name - Spanish
    this.continuebuttonspanish = {
        input: element(by.buttonText('Continuar'))
    };

    //Delete Button Name
    this.deletebutton = {
        input: element(by.buttonText('Delete Application'))
    };

    //Delete Button Name
    this.deletebuttonspanish = {
        input: element(by.buttonText('Eliminar solicitud'))
    };

    //ok Button Name in the Delete Application Popup
    this.okbutton = {
        input: element(by.buttonText('Ok'))
    };

    //ok Button Name in the Delete Application Popup -Spanish
    this.okbuttonspanish = {
        input: element(by.buttonText('Aceptar'))
    };


    // Cancel Button Name in the Delete Application Popup
    this.cancelbutton = {
        input: element(by.buttonText('Cancel'))
    };


    // Cancel Button Name in the Delete Application Popup - Spanish
    this.cancelbuttonspanish = {
        input: element(by.buttonText('Cancelar'))
    };



    //Delete application pop up header

    this.deletepopupheader = {
        input: (element.all(by.tagName('h4')).get(0))
    };

    //Delete button pop up message
    this.deletepopupmsg = {
        input: element(by.className('modal-body'))
    };

    //About Your Absence Page
    this.aboutyourabsence = {
        input: element(by.className('lds-main'))
    };

    // Getting Started Page header
    this.headermessage1 = {
        input: (element.all(by.tagName('h2')).get(0))
    };

    //Save for Later button
    this.saveforlaterbtn = {
        input: element(by.buttonText('Save for Later'))
    };

    //Save for Later button Spanish
    this.saveforlaterbtnspan = {
        input: element(by.buttonText('Guardar para más tarde'))
    };

    //Save for Later - Popup
    this.savepopup = {
        input: element(by.className('modal-title'))
    };

    //Exit Application button - Save for Later Popup
    this.exitappbtn = {
        input: element(by.buttonText('Exit Application'))
    };

    //Exit Application button - Spanish
    this.exitappbtnspan = {
        input: element(by.buttonText('Salir de la solicitud'))
    };

    //Return to Application button - Save for Later Popup
    this.rettoappbtn = {
        input: element(by.buttonText('Return to Application'))
    };

    //Return to Application button - Spanish
    this.rettoappbtnspan = {
        input: element(by.buttonText('Volver a la solicitud'))
    };

};

    module.exports = new POAYP();
