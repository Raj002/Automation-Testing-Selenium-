/**
 * Created by n0275896 on 8/17/2017.
 */
var POAYA = require('./PageObject_AboutYourAbsence.js');
var POAYP = require('./PageObject_AboutYouPage.js');

var POCommonFunctions = function(){

    var empid = POAYP.empidtbox.input;
    var firstname = POAYP.fnametbox.input;
    var lastname = POAYP.lnametbox.input;
    var dob = POAYP.dobtbox.input;
    var preferedphone = POAYP.ppphonetbox.input;
    var prefmail = POAYP.ppemailtbox.input;
    var resaddr1 = POAYP.resaddrtbox1.input;
    var rescity = POAYP.rescitytbox.input;
    var statelist = POAYP.resstatelist.input;
    var postalcode = POAYP.postalcdetbox.input;
    var stateemploy = POAYP.stateofemploylist.input;
    var engsplink = POAYP.Englishspanishlink.input;

   this.enteraboutyouremployeepagemale = function fillaboutyouremppage_male(){

        //Fill all the details in About You page and click continue for About Your Absence page

       browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/employer/cli/');

       //Select About You Page
       element(by.css('[href="/employer/cli/claimant"]')).click();

        //Enter valid value for Employee ID
        empid.sendKeys('12345');

        //Enter valid value for FirstName
        firstname.sendKeys('TestFirstname');

        //Enter valid value for Last Name
        lastname.sendKeys('TestLastName');

        //Select Gender
        POAYP.rbtnmale.input.click();

        //Enter Valid value for Date of Birth
        dob.sendKeys('11/12/1975');

        //Enter Valid value for  Preferred phone number
        preferedphone.sendKeys('9887821111');

        //Enter Valid value for  Preferred email
        prefmail.sendKeys('test@tst.com');

        //Enter Valid value for  Residential Address1
        resaddr1.sendKeys('Testaddress1');

        //Enter Valid value for  Residential City
        rescity.sendKeys('Testcity');

        //Select any Residential State
        statelist.$('[value = "AK"]').click();

        //Enter Valid value for  Postal Code
        postalcode.sendKeys('78901');

        //Select any value for State of Employment
        stateemploy.$('[value = "AK"]').click();



       POAYP.continuebutton.input.click();


       //Verify About your Absence is displayed
       var aboutyourabsencehdr = POAYA.absenceheader.input.getText();
       expect(aboutyourabsencehdr).toEqual('Details of Employee absence');

    };

    this.enteraboutyouremppagefemale = function fillaboutyouremppage_female(){

        //Fill all the details in About You page and click continue for About Your Absence page

        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/employer/cli/');

        //Select About You Page
        element(by.css('[href="/employer/cli/claimant"]')).click();

        //Enter valid value for Employee ID
        empid.sendKeys('12345');

        //Enter valid value for FirstName
        firstname.sendKeys('TestFirstname');

        //Enter valid value for Last Name
        lastname.sendKeys('TestLastName');

        //Select Gender
        POAYP.rbtnfemale.input.click();

        //Enter Valid value for Date of Birth
        dob.sendKeys('11/12/1975');

        //Enter Valid value for  Preferred phone number
        preferedphone.sendKeys('9887821111');

        //Enter Valid value for  Preferred email
        prefmail.sendKeys('test@tst.com');

        //Enter Valid value for  Residential Address1
        resaddr1.sendKeys('Testaddress1');

        //Enter Valid value for  Residential City
        rescity.sendKeys('Testcity');

        //Select any Residential State
        statelist.$('[value = "AK"]').click();

        //Enter Valid value for  Postal Code
        postalcode.sendKeys('78901');

        //Select any value for State of Employment
        stateemploy.$('[value = "AK"]').click();


        //Click Continue button
        POAYP.continuebutton.input.click();

        //Verify About your Absence is displayed
        var aboutyourabsencehdr = POAYA.absenceheader.input.getText();
        expect(aboutyourabsencehdr).toEqual('Details of Employee absence');

    };

    this.enteraboutyoupagespanishfemale = function fillaboutyoupage_female_Spanish(){

        //Fill all the details in About You page and click continue for About Your Absence page

        //Open NEW CLI in browser and go to About You Page
        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/');

        //Select About You Page
        element(by.css('[href="/cli/claimant"]')).click();

        //Enter valid value for Employee ID
        empid.sendKeys('12345');

        //Enter valid value for FirstName
        firstname.sendKeys('TestFirstname');

        //Enter valid value for Last Name
        lastname.sendKeys('TestLastName');

        //Select Gender
        POAYP.rbtnfemale.input.click();

        //Enter Valid value for Date of Birth
        dob.sendKeys('11/12/1975');

        //Enter Valid value for  Preferred phone number
        preferedphone.sendKeys('9887821111');

        //Enter Valid value for  Preferred email
        prefmail.sendKeys('test@tst.com');

        //Enter Valid value for  Residential Address1
        resaddr1.sendKeys('Testaddress1');

        //Enter Valid value for  Residential City
        rescity.sendKeys('Testcity');

        //Select any Residential State
        statelist.$('[value = "AK"]').click();

        //Enter Valid value for  Postal Code
        postalcode.sendKeys('78901');

        //Select any value for State of Employment
        stateemploy.$('[value = "AK"]').click();


        //Click Continue button
        POAYP.continuebuttonspanish.input.click();

        //Verify About your Absence is displayed
        var aboutyourabsencehdr = POAYA.absenceheader.input.getText();
        expect(aboutyourabsencehdr).toEqual('Acerca de su ausencia');

    };
    this.enteraboutyoupagespanishmale = function fillaboutyoupage_male_Spanish(){

        //Fill all the details in About You page and click continue for About Your Absence page

        //Open NEW CLI in browser and go to About You Page
        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/');

        //Select About You Page
        element(by.css('[href="/cli/claimant"]')).click();

        //Enter valid value for Employee ID
        empid.sendKeys('12345');

        //Enter valid value for FirstName
        firstname.sendKeys('TestFirstname');

        //Enter valid value for Last Name
        lastname.sendKeys('TestLastName');

        //Select Gender
        POAYP.rbtnmale.input.click();

        //Enter Valid value for Date of Birth
        dob.sendKeys('11/12/1975');

        //Enter Valid value for  Preferred phone number
        preferedphone.sendKeys('9887821111');

        //Enter Valid value for  Preferred email
        prefmail.sendKeys('test@tst.com');

        //Enter Valid value for  Residential Address1
        resaddr1.sendKeys('Testaddress1');

        //Enter Valid value for  Residential City
        rescity.sendKeys('Testcity');

        //Select any Residential State
        statelist.$('[value = "AK"]').click();

        //Enter Valid value for  Postal Code
        postalcode.sendKeys('78901');

        //Select any value for State of Employment
        stateemploy.$('[value = "AK"]').click();


        //Click Continue button
        POAYP.continuebuttonspanish.input.click();

        //Verify About your Absence is displayed
        var aboutyourabsencehdr = POAYA.absenceheader.input.getText();
        expect(aboutyourabsencehdr).toEqual('Acerca de su ausencia');

    };
    this.enteraboutyoupagemale = function fillaboutyoupage_male(){

        //Fill all the details in About You page and click continue for About Your Absence page

        //Open NEW CLI in browser and go to About You Page
        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/');

        //Select About You Page
        element(by.css('[href="/cli/claimant"]')).click();

        //Enter valid value for Employee ID
        empid.sendKeys('12345');

        //Enter valid value for FirstName
        firstname.sendKeys('TestFirstname');

        //Enter valid value for Last Name
        lastname.sendKeys('TestLastName');

        //Select Gender
        POAYP.rbtnmale.input.click();

        //Enter Valid value for Date of Birth
        dob.sendKeys('11/12/1975');

        //Enter Valid value for  Preferred phone number
        preferedphone.sendKeys('9887821111');

        //Enter Valid value for  Preferred email
        prefmail.sendKeys('test@tst.com');

        //Enter Valid value for  Residential Address1
        resaddr1.sendKeys('Testaddress1');

        //Enter Valid value for  Residential City
        rescity.sendKeys('Testcity');

        //Select any Residential State
        statelist.$('[value = "AK"]').click();

        //Enter Valid value for  Postal Code
        postalcode.sendKeys('78901');

        //Select any value for State of Employment
        stateemploy.$('[value = "AK"]').click();



        POAYP.continuebutton.input.click();

        //Verify About your Absence is displayed
        var aboutyourabsencehdr = POAYA.absenceheader.input.getText();
        expect(aboutyourabsencehdr).toEqual('About Your Absence');

    };

    this.enteraboutyoupage = function fillaboutyoupage_female(){

        //Fill all the details in About You page and click continue for About Your Absence page

        //Open NEW CLI in browser and go to About You Page
        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/');

        //Select About You Page
        element(by.css('[href="/cli/claimant"]')).click();

        //Enter valid value for Employee ID
        empid.sendKeys('12345');

        //Enter valid value for FirstName
        firstname.sendKeys('TestFirstname');

        //Enter valid value for Last Name
        lastname.sendKeys('TestLastName');

        //Select Gender
        POAYP.rbtnfemale.input.click();

        //Enter Valid value for Date of Birth
        dob.sendKeys('11/12/1975');

        //Enter Valid value for  Preferred phone number
        preferedphone.sendKeys('9887821111');

        //Enter Valid value for  Preferred email
        prefmail.sendKeys('test@tst.com');

        //Enter Valid value for  Residential Address1
        resaddr1.sendKeys('Testaddress1');

        //Enter Valid value for  Residential City
        rescity.sendKeys('Testcity');

        //Select any Residential State
        statelist.$('[value = "AK"]').click();

        //Enter Valid value for  Postal Code
        postalcode.sendKeys('78901');

        //Select any value for State of Employment
        stateemploy.$('[value = "AK"]').click();


        //Click Continue button
        POAYP.continuebutton.input.click();

        //Verify About your Absence is displayed
        var aboutyourabsencehdr = POAYA.absenceheader.input.getText();
        expect(aboutyourabsencehdr).toEqual('About Your Absence');

    };


};
module.exports = new POCommonFunctions();