/**
 * Created by n0275896 on 6/28/2017.
 */
var POGSP = function() {

    //Start Button Name
    this.startbutton = {
        input: element(by.buttonText('Start'))
    };

    //Start Button Spanish
    this.startbtnspan = {
        input: element(by.buttonText('Comienzo'))
    };

    //Get Help Link label
    this.gethlplabel = {
        input: element(by.css('.linkBold a'))
    };

    // Header - EE A Message From Your Employer - content validation
    this.headermessage1 = {
        input: (element.all(by.tagName('h2')).get(0))
    };

    //Dynamic content1 below Header1 - Validation
    this.dynamiccontent1 = {
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[3]/div/start/div/div[1]/div[2]/span'))
    };

    // Header - Welcome. To continue, please make sure you have the following information: - Validation
    this.headermessage2 = {
        input: (element.all(by.tagName('h2')).get(1))
    };

    // Header - Welcome. To continue, please make sure you have the following information: - Validation
    this.headermessage3 = {
        input: (element.all(by.tagName('h2')).get(2))
    };

    //Static content1 - 1. Information to identify yourself (may include your social security number or other ID as required by your employer) - Validation
    this.staticcontent1 = {
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/start/div[2]/div/div[1]'))

    };

    //Static content2 - 2. Claim or leave information, including reason and dates of medical or other authorized events - Validation
    this.staticcontent2 = {
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/start/div[2]/div/div[2]'))
    };

    //Static content3 - 3. Physician or hospital contact information (if available) - Validation
    this.staticcontent3 = {
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/start/div[2]/div/div[3]'))
    };

    //Static content4 - NOTE:  - Validation
    this.staticcontent4 = {
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/start/div[2]/div/span[1]'))
    };

    //Static content5 - For added security, your session will automatically time-out following 15 minutes of inactivity to protect your personal information.  - Validation
    this.staticcontent5 = {
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/start/div[2]/div/span[2]'))
    };

    //pop up window validation
    this.popuphelp = {
        input: element(by.className('modal-dialog'))
    };

    //About You Page
    this.aboutyou = {
        input: element(by.className('lds-main'))
    };

    //Open Your Saved Application button
    this.opensaveappbtn = {
        input: element(by.buttonText('Open Your Saved Application'))
    };

    //Open Your Saved Application button Spanish
    this.opensaveappspan = {
        input: element(by.buttonText('Abra su aplicación guardada'))
    };

    //Text below Open Saved application - English
    this.opentext ={
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/start/div[3]/div/div/div/span'))

    };

};

module.exports = new POGSP();

