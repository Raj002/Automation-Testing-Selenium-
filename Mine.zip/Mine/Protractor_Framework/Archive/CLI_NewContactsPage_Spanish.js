/**
 * Created by n0238696 on 7/17/2017.
 */
/**
 * Created by n0238696 on 7/11/2017.
 */


//Import Page objects

//var cppageobj = require('./VSPageObjects.js');

var POAYC = require('./PageObject_ContactsPage.js');

//Take Screenshots
var fs = require('fs');
function writeScreenShot(data, filename) {
    var stream = fs.createWriteStream(filename);
    stream.write(new Buffer(data, 'base64'));
    stream.end();
}
describe ('Open URL in browser and validate contacts page labels', function() {


    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 900000;


    //TestCase - 1 Contacts Page English
    it('New CLI_Contacts Page: Label/Header Validations', function () {

        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/');
        element(by.css('[href="/cli/contacts"]')).click();

        //Click the 'En Espanol' link
        element(by.className('link')).click();

        browser.sleep(3000);

        //===============*** Field label Validations ***================//

        //Verify Medical contacts header
        var medheader = POAYC.medheader.input.getText();
        expect(medheader).toEqual('Contactos medicos');

        //Verify static content below Medical contacts header
        var statictext = POAYC.statictext.input.getText();
        expect(statictext).toEqual('Sírvase proporcionarnos uno de los contactos a continuación para ayudar a acelerar el procesamiento de su solicitud de ausencia.');

        //Verify Treating Physician Information header
        var physicianinfoheader = POAYC.physicianinfoheader.input.getText();
        expect(physicianinfoheader).toEqual('Tratamiento de la información del médico');

        //Verify Physician First name label
        var physicianfnamelabel = POAYC.physicianfnamelabel.input.getText();
        expect(physicianfnamelabel).toEqual("Nombre del Médico");

        //Verify Physician First name- Optional  label
        var physicianfnameoplabel = POAYC.physicianfnameoplabel.input.getText();
        expect(physicianfnameoplabel).toEqual('(opcional)');

        //Verify Physician Last name label
        var physicianlnamelabel = POAYC.physicianlnamelabel.input.getText();
        expect(physicianlnamelabel).toEqual("Apellido del Médico");

        //Verify Physician Last name- Optional  label
        var physicianlnameoplabel = POAYC.physicianlnameoplabel.input.getText();
        expect(physicianlnameoplabel).toEqual('(opcional)');

        //Verify Physician phone number label
        var physicianpnumlabel = POAYC.physicianpnumlabel.input.getText();
        expect(physicianpnumlabel).toEqual("Número de teléfono del médico");

        //Verify Physician phone number optional label
        var physicianpnumoplabel = POAYC.physicianpnumoplabel.input.getText();
        expect(physicianpnumoplabel).toEqual('(opcional)');

        //Verify Physician phone number format lable
        var physicianpnumformatlabel = POAYC.physicianpnumformatlabel.input.getText();
        expect(physicianpnumformatlabel).toEqual('(###) ### - ####');

        //Verify Hospital Name or Physicians Practice Name label
        var physicianhnamelabel = POAYC.physicianhnamelabel.input.getText();
        expect(physicianhnamelabel).toEqual("Nombre del hospital o nombre de la práctica de los médicos");

        //Verify Hospital Name or Physicians Practice Name optional label
        var physicianhnameoplabel = POAYC.physicianhnameoplabel.input.getText();
        expect(physicianhnameoplabel).toEqual('(opcional)');

        //Verify Hospital or Physicians Practice Phone Number label
        var physicianhpnumlabel = POAYC.physicianhpnumlabel.input.getText();
        expect(physicianhpnumlabel).toEqual("Número de teléfono de la práctica del hospital o de los médicos");

        //Verify Hospital or Physicians Practice Phone Number optional label
        var physicianhpnumoplabel = POAYC.physicianhpnumoplabel.input.getText();
        expect(physicianhpnumoplabel).toEqual('(opcional)');

        //Verify Hospital or Physicians Practice Phone Number format label
        var physicianhpnumformatlabel = POAYC.physicianhpnumformatlabel.input.getText();
        expect(physicianhpnumformatlabel).toEqual("(###) ### - ####");

        //Verify Continue button label
        var continuebutton = POAYC.continuebutton.input.getText();
        expect(continuebutton).toEqual('Continuar');

        //Verify Go back button label
        var gobackbutton = POAYC.gobackbutton.input.getText();
        expect(gobackbutton).toEqual('Volver');

        //Verify Save for Later button label
        var saveforlaterbutton = POAYC.saveforlaterbutton.input.getText();
        expect(saveforlaterbutton).toEqual('Guardar para más tarde');

        //Verify Delete Application button label
        var deleteapplicationbutton = POAYC.deleteapplicationbutton.input.getText();
        expect(deleteapplicationbutton).toEqual('Eliminar solicitud');


//Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/ContactsPage');
        });



        //===============*** Data Entry Validations ***================//

        //Validate Physician's First Name - valid and invalid formats
        var physicianfnametbox = POAYC.physicianfnametbox.input;

        physicianfnametbox.sendKeys("FirstName-");
        expect(physicianfnametbox.getAttribute('value')).toEqual("FirstName-");
        physicianfnametbox.clear();
        physicianfnametbox.sendKeys("1234567890");
        expect(physicianfnametbox.getAttribute('value')).toEqual("");
        physicianfnametbox.clear();
        physicianfnametbox.sendKeys("!@#$%^&*()_+=<>?,./:");
        expect(physicianfnametbox.getAttribute('value')).toEqual("");
        physicianfnametbox.clear();
        physicianfnametbox.sendKeys(";'{}[]'");
        expect(physicianfnametbox.getAttribute('value')).toEqual("''");
        physicianfnametbox.clear();



        //Validate Physician's Last Name - valid and invalid formats
        var physicianlnametbox = POAYC.physicianlnametbox.input;

        physicianlnametbox.sendKeys("LastName-");
        expect(physicianlnametbox.getAttribute('value')).toEqual("LastName-");
        physicianlnametbox.clear();
        physicianlnametbox.sendKeys("1234567890");
        expect(physicianlnametbox.getAttribute('value')).toEqual("");
        physicianlnametbox.clear();
        physicianlnametbox.sendKeys("!@#$%^&*()_+=<>?,./:");
        expect(physicianlnametbox.getAttribute('value')).toEqual("");
        physicianlnametbox.clear();
        physicianlnametbox.sendKeys(";'{}[]'");
        expect(physicianlnametbox.getAttribute('value')).toEqual("''");
        physicianlnametbox.clear();


        //Validate Physician's Phone number - valid and invalid formats
        var physicianpnumtbox = POAYC.physicianpnumtbox.input;

        physicianpnumtbox.sendKeys("1234567890");
        expect(physicianpnumtbox.getAttribute('value')).toEqual("(123) 456-7890");
        physicianpnumtbox.clear();
        physicianpnumtbox.sendKeys("!@#$%^&*()");
        expect(physicianpnumtbox.getAttribute('value')).toEqual("(");
        physicianpnumtbox.clear();
        physicianpnumtbox.sendKeys("QWERTY{}|:<>?");
        expect(physicianpnumtbox.getAttribute('value')).toEqual("(");
        physicianpnumtbox.clear();


        //Validate Hospital Name or Physicians Practice Name - valid and invalid formats
        var physicianhnametbox = POAYC.physicianhnametbox.input;

        physicianhnametbox.sendKeys("PhysicianName-");
        expect(physicianhnametbox.getAttribute('value')).toEqual("PhysicianName-");
        physicianhnametbox.clear();
        physicianhnametbox.sendKeys("1234567890");
        expect(physicianhnametbox.getAttribute('value')).toEqual("");
        physicianhnametbox.clear();
        physicianhnametbox.sendKeys("!@#$%^&*()_+=<>?,./:");
        expect(physicianhnametbox.getAttribute('value')).toEqual("");
        physicianhnametbox.clear();
        physicianhnametbox.sendKeys(";'{}[]'");
        expect(physicianhnametbox.getAttribute('value')).toEqual("''");
        physicianhnametbox.clear();


        //Validate Hospital or Physicians Practice Phone Number - valid and invalid formats
        var physicianhpnumtbox = POAYC.physicianhpnumtbox.input;
        physicianhpnumtbox.sendKeys("1234567890");
        expect(physicianhpnumtbox.getAttribute('value')).toEqual("(123) 456-7890");
        physicianhpnumtbox.clear();
        physicianhpnumtbox.sendKeys("!@#$%^&*()");
        expect(physicianhpnumtbox.getAttribute('value')).toEqual("(");
        physicianhpnumtbox.clear();
        physicianhpnumtbox.sendKeys("QWERTY{}|:<>?");
        expect(physicianhpnumtbox.getAttribute('value')).toEqual("(");
        physicianhpnumtbox.clear();

        browser.sleep(1000);

        physicianhpnumtbox.sendKeys("1234567890");
        physicianhnametbox.sendKeys("PhysicianName");
        physicianpnumtbox.sendKeys("1234567890");

        //Click on Continue button
        element(by.buttonText('Continuar')).click();

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/ContactsPage');
        });

        browser.sleep(1000);
    });
});
