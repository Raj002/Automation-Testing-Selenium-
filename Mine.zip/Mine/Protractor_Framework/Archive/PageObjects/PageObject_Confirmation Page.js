/**
 * Created by n0305595 on 6/20/2017.
 */

var Confirmation_Page = function() {



    var headers = element.all(by.tagName('h2'));
    var questionslist = ['If you have questions about the claims or leave process or next steps, please review','You can access up-to-date information about your claim or leave via:']
    var Employer_pageheaders = ['About Your Employee','About Absence','Additional Information'];
    var Employee_pageheaders = ['About You','About Your Absence','Medical Contacts'];
    var Employee_Pageheaders_Spanish = ['Acerca de usted','Acerca de su ausencia','Contactos Médicos'];
    var primarybutton = element.all(by.className('lds-button lds-button--primary'));

    this.VerifyPageHeader = function () {

        var pageheader = element(by.className('heading--alpha'));
        expect(pageheader.getText()).toEqual('Confirmation');


    };

    this.VerifySuccessMessage = function () {

        expect(headers.get(1).getText()).toEqual('Thank You! You have successfully submitted a claim, and a coordinated leave has been requested. If you have not already done so, please contact your supervisor to inform them you will be out of work.')

    };

    this.VerifyHeaders = function (value1,value2) {

        if (value1 == 'Employer') {
            expect(headers.get(2).getText()).toEqual('ER-Message from your Employer');
            expect(headers.get(3).getText()).toEqual('Liberty Mutual Insurance Next Steps');
            expect(headers.get(4).getText()).toEqual('Questions');
        }
        else if (value2 == 'English')
        {
            expect(headers.get(2).getText()).toEqual('EE-Message from your Employer');
            expect(headers.get(3).getText()).toEqual('Your Next Step');
            expect(headers.get(4).getText()).toEqual('Liberty Mutual Insurance Next Steps');
        }
        else if (value2 == "Spanish"){
            expect(headers.get(2).getText()).toEqual('ER-Message from your Employer- In spanish');
            expect(headers.get(3).getText()).toEqual('Su siguiente paso');
            expect(headers.get(4).getText()).toEqual('Siguientes pasos de Liberty Mutual Insurance');
        }
    };

    this.VerifyStaticContent = function (value1, value2) {

        var Confirmation_text = element(by.id('confirmationText'));
        var LibertyNextStep = element(by.id('libertynextstep'));

        if (value1 == 'Employer') {
            expect(Confirmation_text.getText()).toEqual('ER-This is a Custom Content message from your Employer that is displaying on the Confirmation page and Confirmation Report.');
            expect(LibertyNextStep.getText()).toEqual('Liberty Mutual will contact you within 3 business days from the date your disability begins to review and collect any needed information.');

            for (var i = 1; i <= 2; i++) {

                var questions = '/html/body/sd-app/section/cli-home-component/div/div/div/confirmation/form/div/div[8]/div/ul/li[' + i + ']/';
                var questionstext = element(by.xpath(questions+ 'span'));
                expect(questionstext.getText()).toEqual(questionslist[i-1]);

                if (i != 1) {
                    questionstext = element(by.xpath(questions + 'ul/li/span'));
                    expect(questionstext.getText()).toEqual('Phone: Call the Liberty Mutual Insurance Claim Services Office directly at 1-000-000-0CLM or Leave Services Office directly at 1-000-000-LEAV. Remember we will contact you after your disability begins so you’ll have an opportunity to ask questions and receive information at that time.');
                }

            }
        }
        else if (value2 == 'English')
        {
            expect(Confirmation_text.getText()).toEqual('EE-This is a Custom Content message from your Employer that is displaying on the Confirmation page and Confirmation Report.');
            expect(LibertyNextStep.getText()).toEqual('Liberty Mutual will contact you within 3 business days from the date your disability begins to review and collect any needed information.');

            for (var i = 1; i <= 2; i++) {

                var questions = '/html/body/sd-app/section/cli-home-component/div/div/div/confirmation/form/div/div[9]/div/ul/li[' + i + ']/';
                var questionstext = element(by.xpath(questions+ 'span'));
                expect(questionstext.getText()).toEqual(questionslist[i-1]);

                if (i != 1) {
                    questionstext = element(by.xpath(questions + 'ul/li[1]/span'));
                    expect(questionstext.getText()).toEqual('Online: Access the "View an Existing Claim or Leave" button in your MyLibertyConnection employee experience. Please allow 24-48 hours before checking on your claim or leave status.');

                    questionstext = element(by.xpath(questions + 'ul/li[2]/span'));
                    expect(questionstext.getText()).toEqual('Mobile: Visit www.mylibertyconnection.com on your mobile device and access the "View Status" button. Please allow 24-48 hours from the time reported before checking on your claim or leave status.');

                    questionstext = element(by.xpath(questions + 'ul/li[3]/span'));
                    expect(questionstext.getText()).toEqual('Phone: Call the Liberty Mutual Insurance Claim Services Office directly at 1-000-000-0CLM or Leave Services Office directly at 1-000-000-LEAV. Remember we will contact you after your disability begins so you’ll have an opportunity to ask questions and receive information at that time.');

                }

            }

        }

        else if (value2 == 'Spanish')
        {
            expect(Confirmation_text.getText()).toEqual('ER-This is a Custom Content message from your Employer that is displaying on the Confirmation page and Confirmation Report- In spanish');
            expect(LibertyNextStep.getText()).toEqual('Liberty Mutual se comunicará con usted en un plazo de 3 días hábiles desde la fecha en la que comience su incapacidad para revisar y recopilar cualquier información necesaria.');

            for (var i = 1; i <= 2; i++) {

                var questions = '/html/body/sd-app/section/cli-home-component/div/div/div/confirmation/form/div/div[9]/div/ul/li[' + i + ']/';
                var questionstext = element(by.xpath(questions+ 'span'));
                expect(questionstext.getText()).toEqual(questionslist[i-1]);

                if (i != 1) {
                    questionstext = element(by.xpath(questions + 'ul/li[1]/span'));
                    expect(questionstext.getText()).toEqual('En línea: Acceda al botón "View an Existing Claim or Leave" (Ver un reclamo o permiso existente) en su experiencia de empleado de MyLibertyConnection. Espere de 24 a 48 horas antes de comprobar el estado de su reclamo.');
                    questionstext = element(by.xpath(questions + 'ul/li[2]/span'));
                    expect(questionstext.getText()).toEqual('Por celular: Visite www.mylibertyconnection.com desde su dispositivo celular y acceda al botón “Ver estado”. Espere de 24 a 48 horas desde la hora del reporte antes de comprobar el estado de su reclamo o permiso.');
                    questionstext = element(by.xpath(questions + 'ul/li[3]/span'));
                    expect(questionstext.getText()).toEqual('Por teléfono: Llame a la Oficina de servicios de reclamos de Liberty Mutual Insurance directamente al 1-000-000-0CLM o a la Oficina de servicios de permisos directamente al 1-000-000-LEAV. Recuerde que nos comunicaremos con usted después de que su incapacidad comience por lo que tendrá la oportunidad de hacer preguntas y recibir información en ese momento.');
                }

            }

        }





    };

    this.VerifySubmissionText_Date = function () {

        var SubmissionText = element(by.id('submitText'));
        expect(SubmissionText.getText()).toContain('Your request was submitted on')

    };

    this.clickViewSubmission = function () {

        var ViewSubmission = element.all(by.className('lds-button lds-button--primary'));
        browser.executeScript("arguments[0].scrollIntoView()",ViewSubmission.get(0).getWebElement());
        browser.sleep(1000);
        ViewSubmission.get(0).click();
        var ViewSubmissionPage = element(by.className('heading--beta--top'));
        expect(ViewSubmissionPage.getText()).toEqual('View Submission');


    };
    this.GetClaimNumber = function(){
        var Leave_ClaimNumber = element(by.xpath('//*[@id="claimLeaveIDtext"]/b'));
        return Leave_ClaimNumber.getText();

    };

    this.ViewSubmission_VerifyLeave_ClaimNumber = function(value1){
        var Leave_ClaimNumber = element(by.xpath('//*[@id="claimLeaveIDtext"]/b'));
        expect(Leave_ClaimNumber.getText()).toEqual(value1);

    };



    this.ViewSubmission_PageHeaders = function (value1,value2) {

        var page_header = element.all(by.className('panel-title'));

        if (value1 == 'Employer'){

            for (var i = 0; i <= 2; i++)
            {
                expect(page_header.get(i).getText()).toEqual(Employer_pageheaders[i]);
            }

        }
        else if (value2 == 'English'){
            for (var i = 0; i <= 2; i++)
            {
                expect(page_header.get(i).getText()).toEqual(Employee_pageheaders[i]);
            }

        }
        else if (value2 =='Spanish'){

            for (var i = 0; i <= 2; i++)
            {
                expect(page_header.get(i).getText()).toEqual(Employee_Pageheaders_Spanish[i]);
            }

        }




    };

    this.ViewSubmission_ProgressbarHeader_NotDisplayed = function () {

        for (var i = 1; i <= 5; i++) {
            var progress_barmenu = '//*[@id="progressbar"]/div/ul[2]/li[' + i + ']/circle-lable/figure';
            var options = element(by.xpath(progress_barmenu));
            expect(options.isPresent()).toBe(false);
        }
    };

    this.ViewSubmission_ProgressbarCircles_NotDisplayed = function () {
        var firstcircle = element(by.className('fa fa-circle'));
        expect(firstcircle.isPresent()).toBe(false);

        for (var i = 0; i <= 3; i++) {
            var circle = element.all(by.className('fa fa-circle-thin')).get(i);
            expect(circle.isPresent()).toBe(false);
        }

    };

    this.ViewSubmission_GetHelpLink_NotDisplayed = function () {

        var gethelp = element(by.css('.linkBold a'));
        expect(gethelp.isPresent()).toBe(false);
    };

    this.ViewSubmission_InstructionalText_FraudStatement_NotDisplayed = function () {

        var instructionaltext = element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/review/div[1]/div[1]/text()'));
        expect(instructionaltext.isPresent()).toBe(false);

        var fraudstmntheader = element.all(by.className('col-xs-12')).get(5)
        expect(fraudstmntheader.isPresent()).toBe(false);
    };

    this.ViewSubmission_EditLinks_NotDisplayed = function () {

        var editlinks = element.all(by.className('editLink'));
        expect(editlinks.isPresent()).toBe(false);

    };

    this.ViewSubmission_ClickClose_ViewConfirmationPage = function() {

        browser.executeScript("arguments[0].scrollIntoView()",primarybutton.get(0).getWebElement());
        browser.sleep(1000);
        primarybutton.get(0).click();


    };

    this.ViewSubmission_VerifyPrintIcon_Displayed = function() {

        var print = element(by.className('fa fa-print fa-2x right-aligh'));
        expect(print.isDisplayed()).toBe(true);
    };

};

    module.exports = new Confirmation_Page();
