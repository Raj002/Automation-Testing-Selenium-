/**
 * Created by n0275896 on 6/28/2017.
 */
var Getting_StartedPage = function() {

    var progress_bar = ['Get Started','About Your Employee','About Absence','Additional Information','Review'];
    var header1 = element(by.tagName('h1'));
    var pageheading = element(by.id('start-page-heading'));
    var header2 = element.all(by.tagName('h2'));
    var static_content = ['1. Information to identify your employee (may include social security number or other ID as required by your employer)','2. Claim or leave information, including reason and dates of medical or other authorized events','NOTE:','For added security, your session will automatically time-out following 15 minutes of inactivity to protect your personal information.'];



    this.VerifyGettingStartedCircleColor = function () {
        var firstcircle = element(by.className('fa fa-circle'));
        expect(firstcircle.getCssValue("color")).toEqual("rgba(0, 38, 99, 1)");

    };

    this.VerifyProgressBarHeader = function () {

        for (var i = 1; i <= 5; i++) {
            var progress_barmenu = '//*[@id="progressbar"]/div/ul[2]/li[' + i + ']/circle-lable/figure';
            var options = element(by.xpath(progress_barmenu));

            expect(options.getText()).toEqual(progress_bar[i - 1]);
        }

    };

    this.VerifyTransparentCircle = function () {

        for (var i = 0; i <= 3; i++) {
            var circle = element.all(by.className('fa fa-circle-thin')).get(i);
            expect(circle.getCssValue("color")).toEqual("rgba(193, 192, 193, 1)");
        }

    };

    this.VerifyCLIHeader = function () {

        expect(header1.getText()).toEqual('Report a Claim or Leave of Absence');

    };

    this.VerifyPageHeader = function () {

        expect(pageheading.getText()).toEqual('ER A Message From Your Employer');
        expect(header2.get(2).getText()).toEqual('Welcome. To continue, please make sure you have the following information:');

    };

    this.VerifyGettingStarted_StaticContent = function () {

        var staticcontent = '/html/body/sd-app/section/cli-home-component/div/div/div[2]/start/div/div/div[2]/div/';


        for (var i = 1; i <= 2; i++)
        {

            content = element(by.xpath(staticcontent+ 'div[' + i + ']'));
            expect(content.getText()).toEqual(static_content[i-1]);
            var j = i + 2;
            content =  element(by.xpath(staticcontent + 'div[3]' + '/span[' + i + ']'));
            expect(content.getText()).toEqual(static_content[i+1]);

        }

    };

    this.VerifyGetHelp_Popup = function () {

        var gethelp = element(by.css('.linkBold a'));
        expect(gethelp.getText()).toEqual('Get Help');
        gethelp.click();

        var popuphelp = element(by.className('modal-dialog'));
        expect(popuphelp.isDisplayed()).toBe(true);
        element(by.buttonText('Close')).click();

    };

    this.VerifyStartButtonText_Color = function () {

        var btnstart = element(by.className('lds-button lds-button--primary'));
        expect(btnstart.getText()).toEqual('Start');
        expect(btnstart.getCssValue("color")).toEqual("rgba(255, 255, 255, 1)");

    };

    this.clickStart = function (value1, value2) {

        var btnstart = element(by.className('lds-button lds-button--primary'));


        if (value2 =="Spanish"){

            var spanish = element(by.className('link'));
            browser.executeScript("arguments[0].scrollIntoView()",spanish.getWebElement());
            spanish.click();
            browser.sleep(3000);
            browser.executeScript("arguments[0].scrollIntoView()",btnstart.getWebElement());
            btnstart.click();
            browser.sleep(1000);
            expect(header2.get(1).getText()).toEqual('Recuperar su información');

        }


        if (value1 == 'Employer') {

            browser.executeScript("arguments[0].scrollIntoView()",btnstart.getWebElement());
            btnstart.click();
            browser.sleep(1000);
            expect(header2.get(1).getText()).toEqual('Retrieve your information');

        } else if (value2 == "English"){

            browser.executeScript("arguments[0].scrollIntoView()",btnstart.getWebElement());
            btnstart.click();
            browser.sleep(1000);

        }


    };






    //Start Button Name
    this.startbutton = {
        input: element(by.className('lds-button lds-button--primary'))
    };

    //Start Button Spanish
    this.startbtnspan = {
        input: element(by.buttonText('Comienzo'))
    };

    //Get Help Link label
    this.gethlplabel = {
        input: element(by.css('.linkBold a'))
    };

    // Header - EE A Message From Your Employer - content validation
    this.headermessage1 = {
        input: (element.all(by.tagName('h2')).get(1))
    };

    //Dynamic content1 below Header1 - Validation
    this.dynamiccontent1 = {
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[3]/div/start/div/div[1]/div[2]/span'))
    };

    // Header - Welcome. To continue, please make sure you have the following information: - Validation
    this.headermessage2 = {
        input: (element.all(by.tagName('h2')).get(1))
    };

    // Header - Welcome. To continue, please make sure you have the following information: - Validation
    this.headermessage3 = {
        input: (element.all(by.tagName('h2')).get(2))
    };

    //Static content1 - 1. Information to identify yourself (may include your social security number or other ID as required by your employer) - Validation
    this.staticcontent1 = {
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/start/div/div/div[2]/div/div[1]'))

    };

    //Static content2 - 2. Claim or leave information, including reason and dates of medical or other authorized events - Validation
    this.staticcontent2 = {
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/start/div/div/div[2]/div/div[2]'))
    };

    //Static content3 - 3. Physician or hospital contact information (if available) - Validation
    this.staticcontent3 = {
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/start/div[2]/div/div[3]'))
    };

    //Static content4 - NOTE:  - Validation
    this.staticcontent4 = {
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/start/div/div/div[2]/div/span[1]'))
    };

    //Static content5 - For added security, your session will automatically time-out following 15 minutes of inactivity to protect your personal information.  - Validation
    this.staticcontent5 = {
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/start/div/div/div[2]/div/span[2]'))
    };



    //Open Your Saved Application button
    this.opensaveappbtn = {
        input: element(by.buttonText('Open Your Saved Application'))
    };

    //Open Your Saved Application button Spanish
    this.opensaveappspan = {
        input: element(by.buttonText('Abra su aplicación guardada'))
    };

    //Text below Open Saved application - English
    this.opentext ={
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/start/div[3]/div/div/div/span'))

    };

    /*********************Header Section********************************/
    //Logo first half
    this.logofirsthalf = {
        input: element(by.className('logo__text--liberty'))
    };

    //Logo Second half
    this.logosecondhalf = {
        input: element(by.className('logo__text--liberty_second_half'))
    };

    //Logo line two (Employee or Employer)
    this.logolinetwo = {
        input: element(by.className('logo__text_liberty_line--two'))
    };

    //Welcome Name
    this.welcomename = {
        //input: (element.all(by.className('link')).get(4))
        input: (element.all(by.className('col-xs-12 col-sm-12 col-md-6 topLinks')).get(1))

    };

    //Profile Link
    this.profilelink = {
        input: (element.all(by.className('link linkSeparator')).get(0))
    };

    //Logout Link
    this.logoutlink = {
        input: (element.all(by.className('link linkSeparator')).get(1))
    };

    //Home Link
    this.homelink = {
        input: (element.all(by.className('nav-item')).get(0))
    };

    //Forms Link
    this.formslink = {
        input: (element.all(by.className('nav-item')).get(1))
    };

    //Learn More Link
    this.learnmorelink = {
        input: (element.all(by.className('nav-item')).get(2))
    };

    //Employer home Link
    this.erhomelink = {
        input: (element.all(by.className('nav-item')).get(3))
    };

    //Manager home Link
    this.managerhomelink = {
        input: (element.all(by.className('nav-item')).get(4))
    };

};

module.exports = new Getting_StartedPage();

