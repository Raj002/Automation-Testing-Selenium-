/**
 * Created by n0238696 on 7/17/2017.
 */


var AboutAbsence = function(){

    var dateselection = element.all(by.className('undefined ui-inputtext ui-corner-all ui-state-default ui-widget'));
    var primarybutton = element.all(by.className('lds-button lds-button--primary'));


    this.SelectLeaveorClaimCategory = function(value1){

        var Leave_ClaimCategory  = element.all(by.css('[formcontrolname="leaveCategory"]'));


        if (value1 = 'Yes')
        {
            browser.executeScript("arguments[0].scrollIntoView()",Leave_ClaimCategory.get(0).getWebElement());
            Leave_ClaimCategory.get(0).click();

        }
        else
        {
            Leave_ClaimCategory.get(1).click();
        }

    };

    this.SelectLeaveorClaimtype = function(value1){

        var Leave_ClaimType  = element.all(by.css('[formcontrolname="leaveType"]'));


        switch (value1){

            case "Maternity":
                browser.executeScript("arguments[0].scrollIntoView()",Leave_ClaimType.get(0).getWebElement());
                Leave_ClaimType.get(0).click();
                break;

            case "BondwithChild":
                Leave_ClaimType.get(1).click();
                break;
        }

    };

    this.SelectDeliveryType = function(value1){

        var deliveryIndicator  = element.all(by.css('[formcontrolname="deliveryIndicator"]'));

        switch (value1){

            case "Vaginal":
                deliveryIndicator.get(0).click();
                break;

            case "CSection":
                deliveryIndicator.get(1).click();
                break;
        }

    };

    this.EnterDeliveryDate = function(value1){

        browser.executeScript("arguments[0].scrollIntoView()",dateselection.get(0).getWebElement());
        dateselection.get(0).sendKeys(value1,protractor.Key.TAB);

    };


    this.EnterLastdayWorked = function(value1){

        browser.executeScript("arguments[0].scrollIntoView()",dateselection.get(1).getWebElement());
        dateselection.get(1).sendKeys(value1,protractor.Key.TAB);

    };


    this.ClickContinue_ViewAdditionalInformation = function() {


        browser.executeScript("arguments[0].scrollIntoView()",primarybutton.get(0).getWebElement());
        primarybutton.get(0).click();

        var AdditionalInfo = element(by.className('heading--beta--top'));
        expect(AdditionalInfo.getText()).toEqual('Additional Information');

    };

    this.ClickContinue_ViewMedicalContacts = function(value1, value2) {


        browser.executeScript("arguments[0].scrollIntoView()",primarybutton.get(0).getWebElement());
        primarybutton.get(0).click();

        var AdditionalInfo = element(by.className('heading--beta--top'));
        if (value2 =="Spanish")
        {
            expect(AdditionalInfo.getText()).toEqual('Contactos medicos');
        } else {
            expect(AdditionalInfo.getText()).toEqual('Medical Contacts');
        }

    };








































    //About Your Contacts - Progress Bar
    this.contactspbarabsence = {
        input: element(by.css('[href="/employer/cli/absence"]'))
    };

    //About Your absence  - Header
    this.absenceheader = {
        input: (element.all(by.tagName('h1')).get(1))
    };

    this.Englishspanishlink = {
        input: element(by.className('link'))
    };
    this.txtillness = {
        input: element.all(by.className('undefined ui-inputtext ui-corner-all ui-state-default ui-widget')).get(0)

    };
    this.txtlastday = {
        input: element.all(by.className('undefined ui-inputtext ui-corner-all ui-state-default ui-widget')).get(1)

    };
    this.txthospital = {
        input: element.all(by.className('undefined ui-inputtext ui-corner-all ui-state-default ui-widget')).get(2)

    };
    this.txtsurgery1 = {
        input: element.all(by.className('undefined ui-inputtext ui-corner-all ui-state-default ui-widget')).get(3)

    };
    this.dateillness = {
        input: element.all(by.className('ui-state-default')).get(10)
    };
    this.datelastday = {
        input: element.all(by.className('ui-state-default')).get(9)
    }


    //Question - Will you be out for at least 3 consecutive days? - content
   this.consecutivedays = {
        input: (element.all(by.className('fieldset__label')).get(0))

    };

    //Question - Will you be out for at least 3 consecutive days? - radio button for Yes
    this.consecutivedaysradiobtny = {
        input: (element(by.id('continuous')))
    };

    //Question - Will you be out for at least 3 consecutive days? - radio button for No
    this.consecutivedaysradiobtnn = {
        input: (element(by.id('intermittent')))
    };




    //Question - Will you be out for at least 3 consecutive days? - Yes Label
    /*  this.consecutivedaysyeslbl = {
     input: (element.all(by.className('fieldset__input-group')).element(by.className('fieldset__label fieldset__label--radio no-feedback'))).get(0)
     };

     //Question - Will you be out for at least 3 consecutive days? - No Label
     this.consecutivedaysnolbl = {
     input: (element.all(by.className('fieldset__input-group')).element(by.className('fieldset__label fieldset__label--radio no-feedback'))).get(1)
     };*/


    //Question - What best describes the circumstances for your absence? - content
    this.leavetype = {
        input: (element.all(by.className('fieldset__label')).get(1))

    };

    //Question - Have you delivered
    this.lbldelivered = {
        input: (element.all(by.className('fieldset__label')).get(4))
    }


    //Question - What best describes the circumstances for your absence? - Drop down
    this.leavetypelist = {
        input: (element.all(by.className('ng-untouched ng-pristine ng-invalid')).get(0))

    };

    //Question - What is the reason for your absence? - content
     this.claimantcondition = {
     //input: (element.all(by.className('fieldset fieldset--pristine')).get(3))
         input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/absence/form/div/leave/div/fieldset[1]/div/label'))
     };

    //Question - What is the reason for your absence?- drop down
    this.claimantconditionlist = {
       // input: (element.all(by.className('ng-valid ng-touched ng-dirty')).get(0))
        input: element(by.css('[formcontrolname="leaveReason"]'))

    };

    this.leavetypelist1 = {
        // input: (element.all(by.className('ng-valid ng-touched ng-dirty')).get(0))
        input: element(by.css('[formcontrolname="leaveType"]'))

    };

    this.leavetypeoption = {
        input: element(by.css('[formcontrolname="leaveType"]')).all(by.tagName('option'))
    };
    this.deliverycompyes = {
       // input: element(by.css('[formcontrolname="deliveryComplicationIndicatorYes"]'))
        input: element(by.id('deliveryComplicationIndicatorYes'))
    };

    this.compindicatoryes = {
        input: element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(2)

    };
    this.compindicatorno = {
        input: element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(3)

    };
    this.compindicatorunknown = {
        input: element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(4)

    };

    this.compindicatoreeyes = {
        input: element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(2)

    };
    this.compindicatoreeno = {
        input: element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(3)

    };

    this.leavereasonoption = {
        input: element(by.css('[formcontrolname="leaveReason"]')).all(by.tagName('option'))
    };

    this.circumstanceoption = {
        input: element(by.css('[formcontrolname="claimantCondition"]')).all(by.tagName('option'))
    };

    //Please select the condition that best describes your circumstances
    this.circumstance = {
        input: element(by.css('[formcontrolname="claimantCondition"]'))

    };



      this.medcontactsection = {
        input: element(by.css('[href="#collapse4"]'))
    };

    //Question - What is the person’s relationship to you? - content

    this.relationship = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(3))
        //input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/absence/form/div/leave/div/fieldset[2]/div/label'))
    };

    this.invaliderror = {
        input: (element.all(by.className('fieldset__feedback fieldset__feedback--invalid')).get(2))

    };

    this.surdecreqmsg = {
        input: (element.all(by.className('fieldset__feedback fieldset__feedback--invalid')).get(9))

    };


    //Validation messages
    //Was this the result of an accident? - validation message
    this.lblvalmsgaccidentresult = {
        input: (element.all(by.className('fieldset__feedback fieldset__feedback--invalid')).get(5))
    };

    //Were you in a motor vehicle accident? - validation message
    this.lblvalmsgmotoracc = {
        input: (element.all(by.className('fieldset__feedback fieldset__feedback--invalid')).get(6))
    };

    //Did this occur while on the job? - validation message
    this.lblvalmsgonjob = {
        input: (element.all(by.className('fieldset__feedback fieldset__feedback--invalid')).get(7))
    };

    //Did you, or will you be, going to the hospital? - validation message
    this.lblvalmsghospital = {
        input: (element.all(by.className('fieldset__feedback fieldset__feedback--invalid')).get(8))
    };

    //Did you, or will you, have surgery? - validation message
    this.lblvalmsgsurgery = {
        input: (element.all(by.className('fieldset__feedback fieldset__feedback--invalid')).get(9))
    };

    //Question - What is the person’s relationship to you? - drop down
    this.relationshiplist = {
        input: element(by.css('[formcontrolname="relationship"]'))
    };

    //Question - What is the date of birth of the person you are caring for? - content
    this.carerecientdob = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(4))
        //input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/absence/form/div/leave/div/fieldset[3]/div/label'))
    };

    //Question - What is the date of birth of the person you are caring for? - Optional label
    this.carerecientdoboptional = {
        input: (element.all(by.className('fieldset__optional')).get(0))
    };

    //Question - What is the date of birth of the person you are caring for? - date picker
    this.carerecientdobdate = {
        input: element(by.css('[formcontrolname="careRecipientDateOfBirth"]'))
    };

    //Question - What is the first day of your leave of absence? - content
    this.leavebegin = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(4))
        //input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/absence/form/div/leave/div/fieldset[4]/div/label'))
    };

    //Question - What is the first day of your leave of absence? - date picker
    this.leavebegindate = {
        input: element(by.css('[formcontrolname="leaveBeginDate"]'))
    };


    //Question - What is the last day, or estimated last day, of your leave of absence?  - content
    this.leaveend = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(6))
        //input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/absence/form/div/leave/div/fieldset[5]/div/label'))
    };

    //Question - What is the last day, or estimated last day, of your leave of absence?  - Optional label
    this.leaveendoptional = {
        input: (element.all(by.className('fieldset__optional')).get(1))
    };

    //Question - What is the last day, or estimated last day, of your leave of absence?  - date picker
    this.leaveenddate = {
        input: element(by.css('[formcontrolname="leaveEndDate"]'))
    };
/*
    //Question - Other relationship  - content
    this.otherrelationship = {
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/absence/form/div/leave/div/fieldset[3]/div/label'))
    };
*/
    //Question - What is the last day, or estimated last day, of your leave of absence?  - date picker
    this.otherrelationshiptxt = {
        input: (element.all(by.className('fieldset__input ng-untouched ng-pristine ng-valid')).get(0))
    };

    //Continue Button
    this.continuebutton = {
        input: element(by.className('lds-button lds-button--primary'))
    };
    //Go Back Button
    this.gobackbutton = {
        input: element(by.className('lds-button lds-button--secondary'))
    };
    //Save For Later Button
    this.saveforlaterbutton = {
        input: element(by.buttonText('Save for Later'))
    };

    //Save for Later - Popup
    this.savepopup = {
        input: element(by.className('modal-title'))
    };

    //Exit Application button - Save for Later Popup
    this.exitappbtn = {
        input: element(by.buttonText('Exit Application'))
    };

    //Return to Application button - Save for Later Popup
    this.rettoappbtn = {
        input: element(by.buttonText('Return to Application'))
    };

    // Delete Application Button
    this.deleteapplicationbutton = {
        input: element(by.className('lds-button lds-button--delete'))
    };




    //Question - Have you delivered
    this.delivered = {
        input: element(by.css('[formcontrolname="deliveryIndicator"]'))
    };

    //Question - Delivery Date
    this.deliverydate = {

        input: element(by.css('[formcontrolname="deliveryDate"]'))
        // input: (element.all(by.className('ng-untouched ng-pristine ng-invalid')).get(1))
    };

    //Question - Last date worked
    this.lastdate = {
        input: element(by.css('[formcontrolname="lastDayWorked"]'))

    };

    //Question - illness begin
    this.illness = {
        input: element(by.css('[formcontrolname="incidentDate"]'))

    };


    this.admission = {
        input: element(by.css('[formcontrolname="admissionDate"]'))

    };

    this.txtsurgerydate = {
        input: element(by.css('[formcontrolname="surgeryDate"]'))

    };

    this.txtsurgerydesc = {
        input: element(by.css('[formcontrolname="surgeryDescription"]'))

    };
    //Verify medical contacts page
    this.medicalcontactspage = {
        input: (element.all(by.className('crumb')).get(3))

    };

    this.addlinforpage = {
        input: (element.all(by.className('accordion-toggle collapsed')).get(1))

    };

    //Verify medical contacts page header
    this.medicalheader = {
        input: element(by.className('heading--beta--top'))
    };


    //Care flow for Employer  - Beginning label verification for employer

    this.leavereasoner = {
        input: (element.all(by.className('fieldset fieldset--pristine ')).get(2))

    };

    //relationship to the Employer
    this.relationshiper = {
        input: (element.all(by.className('fieldset fieldset--pristine ')).get(3))

    };

    this.lblother = {
        input: (element.all(by.className('fieldset fieldset--pristine ')).get(4))

    };

    this.lblfirstdayabsence = {
        input: (element.all(by.className('fieldset fieldset--pristine ')).get(4))

    };

    this.lbldob = {
        input: (element.all(by.className('fieldset fieldset--pristine ')).get(5))

    };


    this.lbllastday = {
        input: (element.all(by.className('fieldset fieldset--pristine ')).get(6))

    };

    //What is the first day, or expected first day, of your leave of absence? question label
    this.lblfirstdate = {
        input: (element.all(by.className('fieldset fieldset--pristine ')).get(3))
        //input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/absence/form/div/leave/div/fieldset[2]/div/label'))
    };




    //What is the date the child was placed in your care? (optional) question
    this.childcaredatelbln = {
        input: (element.all(by.className('fieldset fieldset--pristine ')).get(4))
        //input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/absence/form/div/leave/div/fieldset[3]/div/label'))

    };

    //What is the date of birth of the person you are bonding with? question label
    this.lblbondwithdob = {
        input: (element.all(by.className('fieldset fieldset--pristine ')).get(5 ))
        //input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/absence/form/div/leave/div/fieldset[4]/div/label'))

    };

    //What is the last day, or estimated last day, of your leave of absence? question label
    this.lbllastdateabs = {
        input: (element.all(by.className('fieldset fieldset--pristine ')).get(6))
        //input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/absence/form/div/leave/div/fieldset[5]/div/label'))

    };

    this.illnesinjury = {
        input:(element.all(by.className('fieldset fieldset--pristine ')).get(7))
    };

    this.lblcircumcondition = {
        input:(element.all(by.className('fieldset__label')).get(4))

    };

    this.lblillness = {
        input:(element.all(by.className('fieldset__label')).get(5))
    };

    this.lbllastday1 = {
        input:(element.all(by.className('fieldset__label')).get(6))
    };

    this.lblaccidentresult = {
        input:(element.all(by.className('fieldset__label')).get(7))
    };

    this.lblmotorvehaccident = {
        input:(element.all(by.className('fieldset__label')).get(10))
    };

    this.rbtnaccidentyes = {
        input: element(by.id('accidentIndicatorYes'))

    }

    this.rbtnaccidentno = {
        input: element(by.id('accidentIndicatorNo'))
    }

    this.datepicker = {
        input: element(by.className('ng2-datetime-picker'))
    }

    this.rbtnmotoraccidentyes = {
        input: element(by.id('motorVehicleAccidentIndicatorYes'))

    }

    this.rbthospitalizationno = {
        input: element(by.id('hospitalizationIndicatorNo'))

    }

    this.lbloccurjob = {
        input:(element.all(by.className('fieldset__label')).get(13))
    };

    this.rbtnjobyes = {
        input: element(by.id('workRelatedIndicatorYes'))

    }

    this.lblgnghosp = {
        input:(element.all(by.className('fieldset fieldset--pristine')).get(8))
    };

    this.rbtnhospyes = {
        input: element(by.id('hospitalizationIndicatorYes'))

    }

    this.lbldatehosp = {
        input:(element.all(by.className('fieldset__label')).get(19))
    };

    this.lblsurgery = {
        input:(element.all(by.className('fieldset__label')).get(20))
    };


    this.lblsurgeryer = {
        input:(element.all(by.className('fieldset__label')).get(18))
    };

    this.lblsurgeryyes = {
        input:(element.all(by.className('fieldset__label')).get(19))
    };

    this.lblsurgeryno= {
        input:(element.all(by.className('fieldset__label')).get(20))
    };

    this.lblsurgeryunknown = {
        input:(element.all(by.className('fieldset__label')).get(21))
    };
    this.rbtnsurgery = {
        input: element(by.id('surgeryIndicatorYes'))

    };


    this.rbtnsurgeryno = {
        input: element(by.id('surgeryIndicatorNo'))

    };

    this.rbtnsurgeryunknown = {
        input: element(by.id('surgeryIndicatorUnknown'))

    };

    this.lblsurgeryrequiredmsg = {
        input:(element.all(by.className('fieldset__feedback fieldset__feedback--invalid')).get(7))

    }

    this.lbldatesurgery = {
        input:(element.all(by.className('fieldset fieldset--pristine')).get(11))
        //input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/absence/form/div/claim/div/fieldset[10]/div/label'))
    };

    this.lbldiagnosis = {
        input:(element.all(by.className('fieldset fieldset--pristine')).get(12))
        //input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/absence/form/div/claim/div/fieldset[11]/div/label'))
    };

    this.surdesques = {
        input:(element.all(by.className('fieldset fieldset--pristine')).get(3))

    };

    this.aboutabsencequestions = {
        input:  element.all(by.className('fieldset fieldset--pristine'))

    };

    this.lblsurgeryyes = {
        input: element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(10)
    };

    this.lblsurgeryno = {
        input: element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(11)
    };

    this.lblsurgeryunknown = {
        input: element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(12)
    };




    //Care flow for Employer  - End label verification for employer

    //Question - What was your last day worked? - content
    /* this.lastdayworked = {
     input: (element.all(by.className('fieldset__label')).get(3))
     };

     //Question - What was your last day worked? - Date picker
     this.lastdayworkeddate = {
     input: (element.all(by.className('ng-untouched ng-pristine ng-invalid')).get(2))
     };

     //Question - What was your last day worked? - content
     this.incidentdate = {
     input: (element.all(by.className('fieldset__label')).get(4))
     };

     //Question - What was your last day worked? - Date picker
     this.incidentdatepicker = {
     input: (element.all(by.className('ng-untouched ng-pristine ng-invalid')).get(3))
     };

     //Question - Was this the result of an accident? - content
     this.accidentresult = {
     input: (element(by.className('fieldset fieldset--pristine')).element(by.className('fieldset__label')))
     };

     //Question - Was this the result of an accident? - radio button for Yes
     this.accidentresultradiobtny     = {
     input: (element(by.id('continuous')))
     };

     //Question - Was this the result of an accident? - radio button for No
     this.accidentresultradiobtnn     = {
     input: (element(by.id('intermittent')))
     };

     //Question - Was this the result of an accident?- Yes Label
     this.consecutivedaysyeslbl = {
     input: (element.all(by.className('fieldset fieldset--pristine')).element(by.className('fieldset__label fieldset__label--radio no-feedback'))).get(0)
     };

     //Question - Was this the result of an accident?- No Label
     this.consecutivedaysnolbl = {
     input: (element.all(by.className('fieldset fieldset--pristine')).element(by.className('fieldset__label fieldset__label--radio no-feedback'))).get(1)
     };
     */

};



module.exports = new AboutAbsence();
