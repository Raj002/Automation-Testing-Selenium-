/**
 * Created by n0305595 on 6/20/2017.
 */

var Getting_StartedPage = require('./PageObject_GettingStarted.js');

var POAYP = function() {

    var Employer_Header =['Retrieve your information','Personal Information','Residential Information','Preferred Contact Information','Primary Work Location'];
    var Aboutyoupage_Label = ['First Name','Middle Initial','Last Name','Date of Birth','Gender','Country','Residential Address 1','Residential Address 2','Residential City',
        'Residential State','Postal Code','Personal Phone','Personal Email','Country of Employment','State of Employment'];

    var Aboutyoupage_Radio_label = ['Employee ID','Social Security Number'];

    var employeeid= element(by.css('[formcontrolname="empID"]'));
    var socialsecuritynumber = element(by.css('[formcontrolname="SSN"]'));
    var emailID = element(by.css('[formcontrolname="email"]'));
    var dateofbirth = element(by.css('[formcontrolname="dob"]'));
    var preferredphone = element(by.css('[formcontrolname="phone"]'));
    var primarybutton = element.all(by.className('lds-button lds-button--primary'));
    var deletebutton = element(by.className('lds-button lds-button--delete'));
    var secondarybutton = element(by.className('lds-button lds-button--secondary'));
    var lastname =   element(by.css('[formcontrolname="lastName"]'));
    var firstname =   element(by.css('[formcontrolname="firstName"]'));
    var prefemail =   element(by.css('[formcontrolname="email"]'));
    var resaddr1 =   element(by.css('[formcontrolname="residentialAdd1"]'));
    var resaddr2 =   element(by.css('[formcontrolname="residentialAdd2"]'));
    var rescity =   element(by.css('[formcontrolname="residentialCity"]'));
    var resstate =   element(by.css('[formcontrolname="selectedStateID"]'));
    var postalcode =   element(by.css('[formcontrolname="postalCode"]'));
    var gender  =   element.all(by.css('[formcontrolname="gender"]'));
    var uniqueID  =   element.all(by.css('[formcontrolname="uniqueID"]'));
    var country = element(by.css('[formcontrolname="selectedCountryID"]'));
    var empState = element(by.css('[formcontrolname="selectedEmpStateID"]'));
    var textentries = element.all(by.className('ui-inputtext ui-corner-all ui-state-default ui-widget'));


    this.Validate_AboutYouPageHeader = function () {

        var pageheader = element.all(by.tagName('h2'));
        pageheader.count().then(function (cnt) {
        var headercount = cnt;
            for (var i = 1; i < headercount; i++) {
                expect(pageheader.get(i).getText()).toEqual(Employer_Header[i-1]);

            }

        });


    };

    this.Validate_AboutYouPage_LabelName = function () {

        var labelName = element.all(by.className('fieldLabel'));
        labelName.count().then(function (cnt) {
            var labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(labelName.get(i).getText()).toEqual(Aboutyoupage_Label[i]);

            }

        });

        var radiolabelName = element.all(by.className('fieldset__label--radio no-feedback'));
        radiolabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(radiolabelName.get(i).getText()).toEqual(Aboutyoupage_Radio_label[i]);

            }

        });

    };




    this.Validate_PlaceHolderText = function () {

        expect(employeeid.getAttribute('placeholder')).toEqual('Enter Employee ID');
        expect(socialsecuritynumber.getAttribute('placeholder')).toEqual('Enter Social Security Number(9 digits)');
        expect(emailID.getAttribute('placeholder')).toEqual('name@domain.com');
        expect(dateofbirth.getAttribute('placeholder')).toEqual('mm/dd/yyyy');
        expect(preferredphone.getAttribute('placeholder')).toEqual('(###) ###-####');


    };

    this.Validate_ButtonText_Color = function (value1) {

        switch (value1) {

            case 'Employee':
                    expect(primarybutton.get(0).getText()).toEqual('Find My Information');
                    expect(deletebutton.getText()).toEqual('Delete Application');
                    expect(deletebutton.getCssValue("color")).toEqual("rgba(201, 40, 45, 1)");
                    break;

            case 'Employer':
                    expect(primarybutton.get(0).getText()).toEqual('Find Employee Information');
                    expect(primarybutton.get(0).getCssValue("color")).toEqual("rgba(255, 255, 255, 1)");

                    expect(deletebutton.getText()).toEqual('Cancel');
                    expect(deletebutton.getCssValue("color")).toEqual("rgba(201, 40, 45, 1)");
                    break;
        }



        expect(primarybutton.get(1).getText()).toEqual('Continue');
        expect(primarybutton.get(1).getCssValue("color")).toEqual("rgba(255, 255, 255, 1)");



        expect(secondarybutton.getText()).toEqual('Go Back');
        expect(secondarybutton.getCssValue("color")).toEqual("rgba(66, 117, 189, 1)");



    };

    this.Validate_ErrorMessage_MandatoryFields_NotEntered = function () {

        browser.executeScript('window.scrollTo(1280,2500);');
        primarybutton.get(1).click();
        element(by.buttonText('Close')).click();
        browser.sleep(500);
        var errormessage = element.all(by.className('fieldset__feedback_label fieldset__feedback--invalid'));
        errormessage.count().then(function (cnt) {
            var errorcount = cnt;
            for (var i = 0; i < errorcount; i++) {
                if (i != 1 && i != 6) {
                    expect(errormessage.get(i).getText()).toEqual('Required');
                }

            }

        });

    };


    this.Validate_Prepop_Valid_EmpID_LastName = function (value1,value2) {
        employeeid.sendKeys(value1);
        lastname.sendKeys(value2);
        primarybutton.get(0).click();
        browser.sleep(500);

        expect(firstname.getText()).toEqual('SARIENA');
        expect(resaddr1.getAttribute('value')).toEqual("27 LAKEWOOD AVE");
        expect(rescity.getAttribute('value')).toEqual("BUFFALO");
        expect(postalcode.getAttribute('value')).toEqual("14220");
        expect(resstate.getAttribute('value')).toEqual("NY");
        expect(dateofbirth.getAttribute('value')).toEqual("03/09/1994");
        expect(country.getAttribute('value')).toEqual("USA");
        expect(gender.get(0).isSelected()).toBe(true);


    };

    this.Validate_Prepop_Valid_SSN_LastName = function (value1,value2) {

        deletebutton.click();
        element(by.className('lds-button lds-button--save')).click();
        Getting_StartedPage.clickStart();

        textentries.get(0).sendKeys(value1);
        lastname.sendKeys(value2);
        primarybutton.get(0).click();
        browser.sleep(500);

        expect(firstname.getText()).toEqual('FEROZ');
        expect(resaddr1.getAttribute('value')).toEqual("3260 MILLERSPORT HWY");
        expect(resaddr2.getAttribute('value')).toEqual("APT #4");
        expect(rescity.getAttribute('value')).toEqual("GETZVILLE");
        expect(postalcode.getAttribute('value')).toEqual("14068");
        expect(resstate.getAttribute('value')).toEqual("NY");
        expect(dateofbirth.getAttribute('value')).toEqual("05/14/1977");
        expect(country.getAttribute('value')).toEqual("USA");
        expect(gender.get(1).isSelected()).toBe(true);


    };

    this.Validate_Prepop_Valid_SSN_InvalidLastName = function (value1,value2) {

        deletebutton.click();
        element(by.className('lds-button lds-button--save')).click();
        Getting_StartedPage.clickStart();
        browser.executeScript("arguments[0].scrollIntoView()",uniqueID.get(1).getWebElement());
        uniqueID.get(1).click();


        textentries.get(0).sendKeys(value1);
        lastname.sendKeys(value2);
        primarybutton.get(0).click();
        browser.sleep(500);

        var errorpopup = element(by.className('modal-body'));
        expect(errorpopup.getText()).toEqual('There was an error pre-populating your eligibility data.');
        element(by.buttonText('Close')).click();


    };

    this.EnterFirstName = function(value1){
        firstname.sendKeys(value1);

    };


    this.EnterLastName = function(value1){
        lastname.sendKeys(value1);

    };

    this.EnterEmployeeID = function(value1){
        employeeid.sendKeys(value1);

    };

    this.SelectGender = function(value1){

        browser.executeScript("arguments[0].scrollIntoView()",gender.get(0).getWebElement());
        if (value1 = 'Female')
        {
            gender.get(0).click();
        }
        else
        {
            gender.get(1).click();
        }

    };

    this.EnterDateofBirth = function(value1){

        textentries.get(1).clear();
        textentries.get(1).sendKeys(value1);
        var dobvalue = textentries.get(1).getAttribute('value');
        return dobvalue;

    };

    this.EnterResdentialAddress1 = function(value1){

        browser.executeScript("arguments[0].scrollIntoView()",resaddr1.getWebElement());
        resaddr1.sendKeys(value1);

    };

    this.EnterResdentialcity = function(value1){

        browser.executeScript("arguments[0].scrollIntoView()",rescity.getWebElement());
        rescity.sendKeys(value1);

    };

    this.EnterPostalCode = function(value1){
        browser.executeScript("arguments[0].scrollIntoView()",postalcode.getWebElement());
        postalcode.sendKeys(value1);

    };

    this.SelectState = function(value1){
        browser.executeScript("arguments[0].scrollIntoView()",resstate.getWebElement());
        resstate.$('[value = "'+ value1 +'"]').click();

    };

    this.SelectEmploymentState = function(value1){
        browser.executeScript("arguments[0].scrollIntoView()",empState.getWebElement());
        empState.$('[value = "'+ value1 +'"]').click();

    };

    this.EnterPersonalPhone = function(value1){
        textentries.get(2).sendKeys(value1);

    };

    this.EnterPersonalEmail = function(value1){
        prefemail.sendKeys(value1);
    };

    this.CancelExistingApplication = function(){

        browser.executeScript("arguments[0].scrollIntoView()",deletebutton.getWebElement());
        deletebutton.click();
        element(by.className('lds-button lds-button--save')).click();

    };

    this.Display_GettingStartedPage_OnRefresh = function() {

        browser.refresh();
        browser.sleep(20000);
        Getting_StartedPage.VerifyPageHeader();
        Getting_StartedPage.clickStart();

        expect(employeeid.getText()).toEqual('');
        expect(firstname.getText()).toEqual('');
        expect(lastname.getText()).toEqual('');
        expect(dateofbirth.getAttribute('value')).toEqual(null);
        expect(gender.get(0).isSelected()).toBe(false);
        expect(gender.get(1).isSelected()).toBe(false);
        expect(resaddr1.getAttribute('value')).toEqual("");
        expect(resaddr2.getAttribute('value')).toEqual("");
        expect(rescity.getAttribute('value')).toEqual("");
        expect(postalcode.getAttribute('value')).toEqual("");
        expect(resstate.getAttribute('value')).toEqual("0");
        expect(country.getAttribute('value')).toEqual("USA");


    };

    this.ClickContinue_ViewAboutYourAbsence = function() {

        primarybutton.get(1).click();
        //var Aboutyourabsence = element(by.className('heading--beta--top'));
       // expect(Aboutyourabsence.getText()).toEqual('Details of Employee absence');

    };















































    //About you page header
    this.aboutyouheader = {
        input: (element.all(by.tagName('h1')).get(1))
    };
    this.username = {
        input: element(by.id('username'))

    };
    this.password = {
        input: element(by.id('password'))

    };

    this.pageheader = {
        input: element.all(by.className('circleStateSubtext startPageLabel')).get(0)

    };

    this.pageheaderAYP = {
        input: element.all(by.className('circleStateSubtext aboutYouPageLabelER')).get(0)

    };

    this.pageheaderAYA = {
        input: element.all(by.className('circleStateSubtext aboutAbsencePageLabelER')).get(0)

    };

    this.pageheaderreview = {
        input: element.all(by.className('circleStateSubtext reviewPageER')).get(0)

    };

    this.pageheaderaddl = {
        input: element.all(by.className('circleStateSubtext moreInfoPageER')).get(0)

    };









    this.retriveheader = {
        input: element.all(by.className('heading--delta')).get(0)
    };
    //Header - "Please enter Either Your Employee ID or Your SSN"
    this.searchMessage = {
        input: element(by.id('esfieldsetSearchMessage'))
    };

    this.Englishspanishlink = {
        input: element(by.className('link'))
    };

    //EmployeeID - Radio Button
    this.empidradio = {
        input: element(by.id('empID'))
    };
    //EmployeeID -Radio Button Field Label
    this.empidtext = {
        input: element.all(by.className('fieldset__label--radio no-feedback')).get(0)
    };
    //SSN - Radio Button
    this.ssnradio = {
        input: element(by.id('SSN'))
    };

    this.searchbtnname = {
        input: element.all(by.className('lds-button lds-button--primary')).get(0)
    };

    //SSN - Radio Button Text
    this.ssntext = {
        input: element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(0)
    };
    //Employee ID - TextBox Label
    this.empidlabel = {
        input: element(by.id('esfieldsetEmpID')).element(by.className('fieldset__label'))
    };

    this.empidplace = {
        // input: element(by.name('firstname'))
        input: element(by.css('[formcontrolname="empID"]'))
    };

    this.ssnplaceholder = {
        // input: element(by.name('firstname'))
        input: element(by.css('[formcontrolname="SSN"]'))
    };


    //Employee ID - TextBox
    this.empidtbox = {
        input: element(by.name('empID'))
    };
    //Employee ID - Validation Message
    this.empidemsg = {
        input: (element(by.id('esfieldsetEmpID')).element(by.className('fieldset__feedback_label fieldset__feedback--invalid')))
    };
    //SSN - TextBox Label
    this.ssnlabel = {
        input: element(by.id('esfieldsetSSN')).element(by.className('fieldset__label'))
    };
    //SSN - TextBox
    this.ssntbox = {
        input: element(by.name('SSN'))
    };

    this.txtssn = {
        input: element.all(by.className('ui-inputtext ui-corner-all ui-state-default ui-widget')).get(0)
    };
    this.txtfax = {
        input: element.all(by.className('ui-inputtext ui-corner-all ui-state-default ui-widget')).get(3)
    }
    //SSN - Validation Message
    this.ssnemsg = {
        input: (element(by.id('esfieldsetSSN')).element(by.className('fieldset__feedback_label fieldset__feedback--invalid')))
    };
    //SSN - Format
    this.ssnformat = {
        input: (element(by.id('esfieldsetSSN')).element(by.className('fieldset__help-text')))
    };
    //Employee ID - Get Help - Link
    this.gethelplink1 = {
        input: (element(by.id('esfieldsetEmpIDheader')).element(by.className('link linkSeparator')))
    };
    //SSN - Get Help - Link
    this.gethelplink2 = {
        input: (element.all(by.className('link linkSeparator')).get(3))
    };

    //Find My Employee Button Name Validation
    this.findbtnname = {
        input: (element(by.buttonText('Find My Information')))
    };

    this.findbtnnameer = {
        input: (element(by.buttonText('Find Employee Information')))
    };

    //Find My Employee Button Name Validation
    this.findbtnnamespan = {
        input: (element(by.buttonText('Buscar Mi Información')))
    };

    //Personal Information Header - Validationlnametbox
    this.personalinfoheader = {
        input: element.all(by.className('heading--delta')).get(1)
    };

    //FirstName Label
    this.fnamelabel = {

        input: element(by.id('firstname'))
    };
    //FirstName - TextBox
    this.fnametbox = {
       // input: element(by.name('firstname'))
        input: element(by.css('[formcontrolname="firstName"]'))
    };


    //FirstName - Validation Message
    this.fnameemsg = {
        input: (element(by.id('esfieldsetFirstName')).element(by.className('fieldset__feedback_label fieldset__feedback--invalid')))
    };

    //MiddleName Label
    this.mnamelabel = {
        input: element.all(by.className('fieldLabel')).get(1)
    };

    //MiddleName - TextBox
    this.mnametbox = {
        input: (element(by.id('fieldsetMiddleName')).element(by.className('ng-untouched ng-pristine ng-valid')))
    };
    //MiddleName - Validation Message - No error message will be displayed for Middle Name

    //LastName Label
    this.lnamelabel = {
        input: element.all(by.className('fieldLabel')).get(2)
    };
    //LastName - TextBox
    this.lnametbox = {
       // input: element(by.name('lastName'))
        input: element(by.css('[formcontrolname="lastName"]'))
    };
    //LastName - Validation Message
    this.lnameemsg = {
        input: (element(by.id('esfieldsetLastName')).element(by.className('fieldset__feedback_label fieldset__feedback--invalid')))
    };

    //Gender - Label Validation
    this.genderlabel = {
        input: element(by.id('gender'))
    };

    //Radio button Male  - Label Validation
    this.malelabel = {
        input: element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(2)
    };

    //Radio button Female  - Label Validation
    this.femalelabel = {
        input: element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(3)
    };

    //Radio Button Male - Validation
    this.rbtnmale = {
        input: element(by.id('male'))
    };

    //Radio Button Female - Validation
    this.rbtnfemale = {
        input: element(by.id('female'))
    };

    //Gender - Validation Message
    this.genderemsg = {
        input: (element(by.id('esfieldsetgender')).element(by.className('fieldset__feedback fieldset__feedback--invalid')))
    };

    //Date of Birth Label
    this.doblabel = {
        input: element.all(by.className('fieldLabel')).get(3)
    };
    //Date of Birth format
    this.dobformatlabel = {
        input: (element(by.id('esfieldsetDob')).element(by.className('fieldset__help-text')))
    };
    //Date of Birth - TextBox
    this.dobtbox = {
        //input: (element(by.name('dob')))
        input: element(by.css('[formcontrolname="dob"]'))
       // input: element(by.className('ui-inputtext ui-corner-all ui-state-default ui-widget ui-state-filled'))

    };
    this.dobreqerrmsg = {
        input: (element(by.id('esfieldsetDob')).element(by.className('fieldset__feedback_label fieldset__feedback--invalid')))
    };

    this.dobtbox1 = {
        input: element.all(by.className('ui-inputtext ui-corner-all ui-state-default ui-widget')).get(1)
    }

    this.dobemsg = {
        input: (element(by.id('esfieldsetDob')).element(by.className('fieldset__feedback_label fieldset__feedback--invalid')))
    };
    //Preferred Personal Phone Label
    this.ppphonelabel = {
        input: element(by.id('phone'))
    };
    //Preferred Personal Phone format
    this.ppphoneformatlabel = {
        input: (element(by.id('esfieldsetPhone')).element(by.className('fieldset__help-text')))
    };
    //Preferred Personal Phone - TextBox
    this.ppphonetbox = {
        //input: (element(by.name('phone')))
        input: element(by.css('[formcontrolname="phone"]'))
    };

    this.mailplaceholder = {
        //input: (element(by.name('phone')))
        input: element(by.css('[formcontrolname="email"]'))
    };


    this.ppphonetbox1 = {
        //input: (element(by.name('phone')))
        input: element.all(by.className('ui-inputtext ui-corner-all ui-state-default ui-widget')).get(2)
    };
    //Preferred Personal Phone - Validation Message
    this.ppphoneemsg = {
        input: (element(by.id('esfieldsetPhone')).element(by.className('fieldset__feedback_label fieldset__feedback--invalid')))
    };
    //Preferred Personal Email Label
    this.ppemaillabel = {
        input: (element(by.id('email')))
    };
    //Preferred Personal Email format
    this.ppemailformatlabel = {
        input: (element(by.id('esfieldsetEmail')).element(by.className('fieldset__help-text')))
    };
    //Preferred Personal Email - TextBox
    this.ppemailtbox = {
        input: element(by.id('prefemail'))
    };
    //Preferred Personal Email - Validation Message
    this.ppemailemsg = {
        input: (element(by.id('esfieldsetEmail')).element(by.className('fieldset__feedback_label fieldset__feedback--invalid')))
    };
    //Emp Country - Label
    this.empcountrylabel = {
        input: element(by.id('country'))
    };
    //Emp Country - Drop down
    this.empcountrylist = {
        input: (element(by.name('country')))
    };

    this.empcountrylist1 = {
        //input: (element(by.name('phone')))
        input: element(by.css('[formcontrolname="selectedCountryID"]'))
    };


    this.empstatecountrylist1 = {
        //input: (element(by.name('phone')))
        input: element(by.css('[formcontrolname="selectedEmpCountryID"]'))
    };
    this.faxtextbox = {

        input: element(by.css('[formcontrolname="claimantpreferredfax"]'))
    };

    //Residential Adresss1  - Label
    this.resaddr1label = {
        input: (element(by.id('residentialAdd1')))
    };
    //Residential Adresss1  - text box
    this.resaddrtbox1 = {
        input: element(by.name('residentialAdd1'))
    };

    this.resaddrtbox2 = {
        input: element(by.css('[formcontrolname="residentialAdd2"]'))
    };

    //Residential Adresss1  - validation message
    this.resaddr1emsg = {
        input: (element(by.id('esfieldsetAdd1')).element(by.className('fieldset__feedback_label fieldset__feedback--invalid')))
    };
    //Residential Address 2- Label
    this.resaddr2label = {
        input: (element(by.id('residentialAdd2')))
    };

    //Residential Adresss2  - text box
    this.resaddrtbox2 = {
        input: element(by.name('res2'))
    };


    //Residential City  - Label
    this.rescitylabel = {
        input: element.all(by.className('fieldLabel')).get(8)
    };

    //Residential City  - text box
    this.rescitytbox = {
        input: element(by.name('residentialCity'))
    };

    this.rescityemsg = {
        input: (element(by.id('esfieldsetAdd3')).element(by.className('fieldset__feedback_label fieldset__feedback--invalid')))
    };

    //Residential State  - Label
    this.resstatelabel = {
        input: (element(by.id('state')))
    };

    //Residential State  - Dropdown
    this.resstatelist = {
        input: element(by.name('state'))
    };


    //Residential State  - Error
    this.resstateemsg = {
        input: (element(by.id('esfieldsetState')).element(by.className('fieldset__feedback fieldset__feedback--invalid')))
    };

    //Residential Postal Code  - Label
    this.postalcodelabel = {
        input: (element(by.id('postalcode')))
    };

    //Residential Postal Code  - text box
    this.postalcdetbox = {
        input: element(by.name('postalCode'))
    };

    //Postal Code Required validation message
    this.postalmsg = {
        input: element(by.id('esfieldsetPostalcode')).element(by.className('fieldset__feedback_label fieldset__feedback--invalid'))
    };

    //Preferred Method - Label
    this.prefmethodlabel = {
        input: element.all(by.className('fieldLabel')).get(13)
    };

    //Preferred Method - Email
    this.prefmethodemail = {
        input: (element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(4))
    };

    //Preferred Method - Fax
    this.prefmethodfax = {
        input: (element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(5))
    };

    //Preferred Method - Mail
    this.prefmethodmail = {
        input: (element.all(by.className('fieldset__label fieldset__label--radio no-feedback')).get(6))
    };

    //Preferred Method - Email -  Radio Button
    this.prefmethodrbtnemail = {
        input: (element(by.id('email')))
    };
    //Preferred Method - Fax -  Radio Button
    this.prefmethodrbtnfax = {
        input: (element(by.id('fax')))
    };
    //Preferred Method - Mail -  Radio Button
    this.prefmethodrbtnmail = {
        input: (element(by.id('Mail')))
    };

    //Primary Work  Location  Header - Validation
    this.primaryworkheader = {
        input: element.all(by.className('heading--delta')).get(1)
    };

    //Primary Work  Location  Header - Validation
    this.preferedheader = {
        input: element.all(by.className('heading--delta')).get(2)
    };




    //Preferred Method - Mail -  Radio Button
   /* this.prefmethodfax = {
        input: (element(by.name('fax')))
    };*/
    //CountryofEmploy - Label
    this.countryofemploylabel = {
        input: element.all(by.className('fieldLabel')).get(14)
    };

    //CountryofEmploy - Dropdown
    this.countryofemploylist = {
        input: (element(by.name('empcountry')))

    };

    //StateofEmployment - label
    this.stateofemploylabel = {
        input: element.all(by.className('fieldLabel')).get(15)

    };
    //StateofEmployment - dropdown
    this.stateofemploylist = {
        input: (element(by.name('empstate')))

    };

    //StateofEmployment - Validation Message
    this.stateofemployemsg = {
        input: (element(by.id('esfieldsetEmpState')).element(by.className('fieldset__feedback fieldset__feedback--invalid')))

    };
    //GoBack Button Name
    this.gobackbutton = {
        input: element(by.buttonText('Go Back'))
    };

    //Continue Button Name
    this.continuebutton = {
        input: element(by.buttonText('Continue'))
    };

    //Continue Button Name - Spanish
    this.continuebuttonspanish = {
        input: element(by.buttonText('Continuar'))
    };

    //Delete Button Name
    this.deletebutton = {
        input: element(by.buttonText('Delete Application'))
    };

    //Delete Button Name
    this.deletebuttonspanish = {
        input: element(by.buttonText('Eliminar solicitud'))
    };

    //ok Button Name in the Delete Application Popup
    this.okbutton = {
        input: element(by.buttonText('Ok'))
    };

    //ok Button Name in the Delete Application Popup -Spanish
    this.okbuttonspanish = {
        input: element(by.buttonText('Aceptar'))
    };


    // Cancel Button Name in the Delete Application Popup
    this.cancelbutton = {
        input: element(by.buttonText('Cancel'))
    };


    // Cancel Button Name in the Delete Application Popup - Spanish
    this.cancelbuttonspanish = {
        input: element(by.buttonText('Cancelar'))
    };



    //Delete application pop up header

    this.deletepopupheader = {
        input: (element.all(by.tagName('h4')).get(0))
    };

    //Delete button pop up message
    this.deletepopupmsg = {
        input: element(by.className('modal-body'))
    };

    //About Your Absence Page
    this.aboutyourabsence = {
        input: element(by.className('lds-main'))
    };

    // Getting Started Page header
    this.headermessage1 = {
        input: (element.all(by.tagName('h2')).get(1))
    };

    //Save for Later button
    this.saveforlaterbtn = {
        input: element(by.buttonText('Save for Later'))
    };

    //Save for Later button Spanish
    this.saveforlaterbtnspan = {
        input: element(by.buttonText('Guardar para más tarde'))
    };

    //Save for Later - Popup
    this.savepopup = {
        input: element(by.className('modal-title'))
    };

    //Exit Application button - Save for Later Popup
    this.exitappbtn = {
        input: element(by.buttonText('Exit Application'))
    };

    //Exit Application button - Spanish
    this.exitappbtnspan = {
        input: element(by.buttonText('Salir de la solicitud'))
    };

    //Return to Application button - Save for Later Popup
    this.rettoappbtn = {
        input: element(by.buttonText('Return to Application'))
    };

    //Return to Application button - Spanish
    this.rettoappbtnspan = {
        input: element(by.buttonText('Volver a la solicitud'))
    };

};

    module.exports = new POAYP();
