/**
 * Created by n0258375 on 7/11/2017.
 */


var POEER = function() {

    //En Espanol link
    this.spanlink = {
        input: (element.all(by.tagName('//a')).get(1))
    };

    //Review - Header
    this.reviewheader = {
        input: (element.all(by.tagName('h1')).get(1))
    };

    //Fraud statement - Header
    this.fraudstmntheader = {
        input: (element.all(by.className('col-xs-12')).get(6))
    };

    //Instruction text under Review page header
    this.instext = {
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/review/div[1]/div[1]'))
    };

    //Get Help link
    this.gethelplnk =  {
        input: element(by.css('.linkBold a'))
    };

    //About You page label
    this.abtyoulbl = {
        input: element(by.css('[href="#collapse1"]'))
    };

    //About You Accordion
    this.abtyouaccf = {
        input: element(by.css('[href="#collapse1"][aria-expanded="false"]'))
    };

    this.abtyouacct = {
        input: element(by.css('[href="#collapse1"][aria-expanded="true"]'))
    };

    //About Your Absence label
    this.abtyouabsencelbl = {
        input: element(by.css('[href="#collapse2"]'))
    };

    //About Your Absence Accordion
    this.abtyourabsaccf = {
        input: element(by.css('[href="#collapse2"][aria-expanded="false"]'))
    };

    this.abtyourabsacct = {
        input: element(by.css('[href="#collapse2"][aria-expanded="true"]'))
    };

    //Medical Contacts label
    this.medicalconlbl = {
        input: element(by.css('[href="#collapse4"]'))
    };

    //Medical Contacts Accordion
    this.medconaccf = {
        input: element(by.css('[href="#collapse4"][aria-expanded="false"]'))
    };

    this.medcont = {
        input: element(by.css('[href="#collapse4"][aria-expanded="true"]'))
    };

    //About You page Edit link
    this.abtyoueditlnk = {
        input: (element.all(by.className('editLink')).get(0))
    };

    //About Your Absence page Edit link
    this.abtyouabseditlnk = {
     input: (element.all(by.className('editLink')).get(1))
    };

    //Medical Contacts page Edit link
   this.medconeditlnk = {
        input: (element.all(by.className('editLink')).get(2))
    };

    //Submit Button
    this.submitbutton = {
        input: element(by.buttonText('Submit'))
    };

    //Submit Button - Spanish
    this.submitspanbutton = {
        input: element(by.buttonText('Enviar'))
    };

    //Go Back Button
    this.gobackbtn = {
        input: element(by.buttonText('Go Back'))
    };

    //Review header Progress bar
    this.reviewprgressbar = {
        input: element(by.xpath("//*[@id='progressbar']/div/div/ol/li[5]/a"))
    };

    //About You page
    this.abtyouhdr = {
        input: (element.all(by.tagName('h1')).get(1))
    };

    //About Your Absence page
    this.abtyourabshdr = {
    input: (element.all(by.tagName('h1')).get(1))
    };

    //Medical Contacts page
    this.medconhdr = {
    input: (element.all(by.tagName('h1')).get(1))
    };

    //Save for Later button
    this.saveforlaterbutton = {
        input: element(by.buttonText('Save for Later'))
    };

    //Save for Later - Popup
    this.savepopup = {
        input: element(by.className('modal-title'))
    };

    //Exit Application button - Save for Later Popup
    this.exitappbtn = {
        input: element(by.buttonText('Exit Application'))
    };

    //Return to Application button - Save for Later Popup
    this.rettoappbtn = {
        input: element(by.buttonText('Return to Application'))
    };

    //About you label - Employee ID

    this.lblemployeeid = {
        input:  element.all(by.className('fieldset__label')).get(0)

    };

    this.txtemployeeid = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(0)

    };

    this.lblfirstname = {
        input:  element.all(by.className('fieldset__label')).get(1)

    };

    this.txtfirstname = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(1)

    };

    this.lblmiddle = {
        input:  element.all(by.className('fieldset__label')).get(3)

    };

    this.txtmiddle = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(3)

    };


    this.lbllastname = {
        input:  element.all(by.className('fieldset__label')).get(5)

    };

    this.txtlastname = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(5)

    };

    this.lblgender1 = {
        input:  element.all(by.className('fieldset__label')).get(7)

    };

    this.txtgender1 = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(7)

    };

    this.lblstate = {
        input:  element.all(by.className('fieldset__label')).get(8)

    };

    this.txtstate = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(8)

    };

    this.lbldob = {
        input:  element.all(by.className('fieldset__label')).get(9)

    };

    this.txtdob = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(9)

    };

    this.otxtdob ={
        input:  element.all(by.className('fieldset__label_textwrap')).get(9)
    };


    this.ocountry ={
        input:  element.all(by.className('fieldset__label_textwrap')).get(8)
    };


    this.ophone ={
        input:  element.all(by.className('fieldset__label_textwrap')).get(11)
    };

    this.opostalcode ={
        input:  element.all(by.className('fieldset__label_textwrap')).get(10)
    };

    this.opemail ={
        input:  element.all(by.className('fieldset__label_textwrap')).get(13)
    };

    this.oecountry ={
        input:  element.all(by.className('fieldset__label_textwrap')).get(12)
    };

    this.lblpphone = {
        input:  element.all(by.className('fieldset__label')).get(11)

    };

    this.txtpphone = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(11)

    };

    this.lblpemail = {
        input:  element.all(by.className('fieldset__label')).get(13)

    };


    this.txtpemail = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(13)

    };

    this.lblprefmethod = {
        input:  element.all(by.className('fieldset__label')).get(15)

    };

    this.txtprefmethod = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(15)

    };

    this.lblresaddress1 = {
        input:  element.all(by.className('fieldset__label')).get(2)

    };

    this.txtresaddress1 = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(2)

    };

    this.lblresaddress2 = {
        input:  element.all(by.className('fieldset__label')).get(4)

    };

    this.txtresaddress2 = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(4)

    };

    this.lblrescity = {
        input:  element.all(by.className('fieldset__label')).get(6)

    };

    this.txtrescity = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(6)

    };

    this.lblcountry = {
        input:  element.all(by.className('fieldset__label')).get(10)

    };

    this.txtcountry = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(10)

    };

    this.lblpostalcode = {
        input:  element.all(by.className('fieldset__label')).get(12)

    };

    this.txtpostalcode = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(12)

    };

    this.lblcounofemploy = {
        input:  element.all(by.className('fieldset__label')).get(14)

    };

    this.txtcounofemploy = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(14)

    };

    this.lblfax = {
        input:  element.all(by.className('fieldset__label')).get(17)

    };


    this.txtfax = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(17)

    };

    this.lblstateofemploy = {
        input:  element.all(by.className('fieldset__label')).get(16)

    };

    this.txtstateofemploy = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(16)

    };

    this.lblphyfirstname = {
        input:  element.all(by.className('fieldset__label')).get(17)

    };

    this.txtphyfirstname = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(17)

    };

    this.lblhosphyfirstname = {
        input:  element.all(by.className('fieldset__label')).get(18)

    };

    this.txthosphyfirstname = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(18)

    };

    this.lblphylastname = {
        input:  element.all(by.className('fieldset__label')).get(19)

    };

    this.txtphylastname = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(19)

    };

    this.lblhosphyphonenumber = {
        input:  element.all(by.className('fieldset__label')).get(20)

    };

    this.txthosphyphonenumber = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(20)

    };

    this.lblphyphonenumber = {
        input:  element.all(by.className('fieldset__label')).get(21)

    };

    this.txtphyphonenumber = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(21)

    };

    };

    module.exports = new POEER();