exports.config = {
    framework: 'jasmine2',

    //seleniumAddress: 'http://localhost:4444/wd/hub',
    directConnect: true,
    specs: ['CLI_EE_AboutYourAbsence_CareFlow_English.js'],
    async: false,
    capabilities: {
        browserName: 'chrome'


    },
    onPrepare: function () {
        // Add Jasmine Spec Reporter
        var specReporter = require('jasmine-spec-reporter');
        jasmine.getEnv().addReporter(new specReporter({displayStacktrace: 'all'}));
        browser.driver.manage().window().maximize();

        var Jasmine2HtmlReporter = require('protractor-jasmine2-html-reporter');
        jasmine.getEnv().addReporter(
            new Jasmine2HtmlReporter({
                savePath: 'Report/screenshots',
                //takeScreenshots: true,
                //takeScreenShotsOnlyOnFailures: true,
                fileName: 'Protractor Automation Report'
            }));
    }

        }


