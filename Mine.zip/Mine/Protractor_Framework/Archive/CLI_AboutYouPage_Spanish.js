/**
 * Created by n0258375 on 6/29/2017.
 */

var POAYP = require('./PageObject_AboutYouPage.js');

//Function to take screenshot
var fs = require('fs');
function writeScreenShot(data, filename) {
 var stream = fs.createWriteStream(filename);
 stream.write(new Buffer(data, 'base64'));
 stream.end();
}
describe ('Open URL in browser and validate contacts page labels', function(){

    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;

// **********BEGINNING OF TESTCASE I*************************************************************************************************************************//
//Validating label name in About You page

    it('New CLI_About You Page: Label Name Validation', function() {

        //Open NEW CLI in browser and go to About You Page
        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/');
		
		//Click the 'En Espanol' link
		element(by.className('link')).click();

        //Click About You Page
        element(by.css('[href="/cli/claimant"]')).click();

        //Verify Employee ID - Radio button label
        var empid = POAYP.empidtext.input.getText();
        expect(empid).toEqual('Identificación del Empleado');

        //Verify Employee SSN - Radio button label
        var ssntext = POAYP.ssntext.input.getText();
        expect(ssntext).toEqual('Número de Seguro Social');

        //Verify Employee ID Text Box label when Employee ID radio button is selected
        var empidlabel = POAYP.empidlabel.input.getText();
        expect(empidlabel).toContain('Identificación del Empleado');

        //Select SSN- Radio button
        POAYP.ssnradio.input.click();

        //Verify SSN Radio Button Label name
        var ssnlabel = POAYP.ssnlabel.input.getText();
        expect(ssnlabel).toEqual('Número de Seguro Social')

        //Verify the ssn format label name
        var ssnformat = POAYP.ssnformat.input.getText();
        expect(ssnformat).toEqual('9 numbers (no dashes)');

        //Verify Personal Information Section - Header name
        var personalinfohdr = POAYP.personalinfoheader.input.getText();
        expect(personalinfohdr).toEqual('Información Personal');

        //Verify the First Name label Name
        var fnamelabel = POAYP.fnamelabel.input.getText();
        expect(fnamelabel).toContain('Primer Nombre');

        //Verify the Middle Name label Name
        var mnamelabel = POAYP.mnamelabel.input.getText();
        expect(mnamelabel).toContain('Inicial del Segundo Nombre');

        //Verify the Last Name label Name
        var lnamelabel = POAYP.lnamelabel.input.getText();
        expect(lnamelabel).toContain('Apellido');

        //Verify the Gender label Name
        var genderlabel = POAYP.genderlabel.input.getText();
        expect(genderlabel).toContain('Sexo');

        //Verify the Male label Name
        var malelabel = POAYP.malelabel.input.getText();
        expect(malelabel).toEqual('Masculino');

        //Verify the Female label Name
        var femalelabel = POAYP.femalelabel.input.getText();
        expect(femalelabel).toEqual('Femenino');

        //Verify Date of Birth Label Name
        var doblabel = POAYP.doblabel.input.getText();
        expect(doblabel).toContain('Fecha de Nacimiento');

        //Verify Preferred Phone Label Name
        var ppphonelabel = POAYP.ppphonelabel.input.getText();
        expect(ppphonelabel).toContain('Teléfono Personal Preferido');

        //Verify Preferred email Label Name
        var ppemaillabel = POAYP.ppemaillabel.input.getText();
        expect(ppemaillabel).toContain('Correo electrónico personal preferido');

        //Verify the Residential Address 1 label Name
        var resaddr1label = POAYP.resaddr1label.input.getText();
        expect(resaddr1label).toEqual('Dirección Residencial 1');

        //Verify the Residential Address 2 label Name
        var resaddr2label = POAYP.resaddr2label.input.getText();
        expect(resaddr2label).toEqual('Dirección Residencial 2');

        //Verify the Country label Name
        var empcountrylabel = POAYP.empcountrylabel.input.getText();
        expect(empcountrylabel).toContain('Pais');

        //Verify the Residential City label Name
        var rescitylabel = POAYP.rescitylabel.input.getText();
        expect(rescitylabel).toEqual('Ciudad');

        //Verify the Residential state drop down label Name
        var resstatelabel = POAYP.resstatelabel.input.getText();
        expect(resstatelabel).toEqual('Estado de Residencia');

        //Verify the Postal Code label Name
        var postalcodelabel = POAYP.postalcodelabel.input.getText();
        expect(postalcodelabel).toEqual('Código Posta');

        //Verify the Preferred Method label Name
        var prefmethodlabel = POAYP.prefmethodlabel.input.getText();
        expect(prefmethodlabel).toContain('Método preferido para correspondencia de carácter no confidencial');

        //Verify email label in Preferred Method
        var prefemaillabel = POAYP.prefmethodemail.input.getText();
        expect(prefemaillabel).toEqual('Correo electrónico personal preferido');

        //Verify Fax label in Preferred Method
        var preffaxlabel = POAYP.prefmethodfax.input.getText();
        expect(preffaxlabel).toEqual('Fax');

        //Verify Mail label in Preferred Method
        var prefmaillabel = POAYP.prefmethodmail.input.getText();
        expect(prefmaillabel).toEqual('Correo');

        //Verify the Primary Work Location label Name
        var primaryworkheader = POAYP.primaryworkheader.input.getText();
        expect(primaryworkheader).toEqual('Lugar de trabajo principal');

        //Verify the Employment Country label Name
        var employcountrylabel = POAYP.countryofemploylabel.input.getText();
        expect(employcountrylabel).toContain('País de Empleo');

        //Verify the State of Employment label Name
        var employstatelabel = POAYP.stateofemploylabel.input.getText();
        expect(employstatelabel).toContain('Estado de Empleo');

        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/AboutYouPage_Spanish/Testcase1.png');
        });

        browser.sleep(5000);

    });

// **********END OF TESTCASE I*************************************************************************************************************************//


// **********BEGINNING OF TESTCASE II*************************************************************************************************************************//
 //To verify when all the Mandatory fields are entered, the application navigates to About Your absence page

    it('New CLI_About You Page: About Your Absence page display_Mandatory fields entered', function() {

     //Open NEW CLI in browser and go to About You Page
     browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/');


     //Select About You Page
     element(by.css('[href="/cli/claimant"]')).click();

     //Enter valid value for Employee ID
     var empid = POAYP.empidtbox.input;
     empid.sendKeys('12345');

     //To enter values in SSN text box
     POAYP.ssnradio.input.click();

    //Enter valid value for SSN
     var ssntext = POAYP.ssntbox.input;
     ssntext.sendKeys('984575674');

     //Enter valid value for FirstName
     var firstname = POAYP.fnametbox.input;
     firstname.sendKeys('TestFirstname');

     //Enter valid value for Last Name
     var lastname = POAYP.lnametbox.input;
     lastname.sendKeys('TestLastName');

     //Select Gender
     POAYP.rbtnfemale.input.click();

     //Enter Valid value for Date of Birth
     var dob = POAYP.dobtbox.input;
     dob.sendKeys('11/12/1975');

     //Enter Valid value for  Preferred phone number
     var preferedphone = POAYP.ppphonetbox.input;
     preferedphone.sendKeys('9887821111');

     //Enter Valid value for  Preferred email
     var prefmail = POAYP.ppemailtbox.input;
     prefmail.sendKeys('test@tst.com');

     //Enter Valid value for  Residential Address1
     var resaddr1 = POAYP.resaddrtbox1.input;
     resaddr1.sendKeys('Testaddress1');

     //Enter Valid value for  Residential City
     var rescity = POAYP.rescitytbox.input;
     rescity.sendKeys('Testcity');

     //Select any Residential State
     var statelist = POAYP.resstatelist.input;
     statelist.$('[value = "AK"]').click();

     //Enter Valid value for  Postal Code
     var postalcode = POAYP.postalcdetbox.input;
     postalcode.sendKeys('78901');

     //Select any value for State of Employment
     var stateemploy = POAYP.stateofemploylist.input;
     stateemploy.$('[value = "AK"]').click();

     //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/AboutYouPage_Spanish/Testcase2.png');
        });


        //Click Continue button
     element(by.buttonText('Continuar')).click();

    //Verify whether About Your absence page is displayed
     expect(POAYP.aboutyourabsence.input.isDisplayed()).toBe(true);

    });
// **********END OF TESTCASE II*************************************************************************************************************************//

// **********BEGINNING OF TESTCASE III*************************************************************************************************************************//
  //To validate an error message is displayed when mandatory fields are not entered

  it('New CLI_About You Page: Error Message validations_Mandatory fiels not entered', function() {

    //Open NEW CLI in browser and go to About You Page
     browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/');

    //Select About You Page
    element(by.css('[href="/cli/claimant"]')).click();
	element(by.buttonText('Continuar')).click();

    //Take screenshot for no values entered
    browser.takeScreenshot().then(function (png) {
    writeScreenShot(png, './Testcase3_i.png');
    });

    //Click Close button in the error  pop up message
    element(by.buttonText('Cerrar')).click();

    //Verify Validation message when no empid is entered
    var empidemsg = POAYP.empidemsg.input.getText();
    expect(empidemsg).toEqual('Ingrese Identificación del empleado');

    //Verify Validation message when FirstName is not entered
    var fnameemsg = POAYP.fnameemsg.input.getText();
    expect(fnameemsg).toEqual('Ingrese el primer nombre');

    //Verify Validation message when LastName is not entered
    var lnameemsg = POAYP.lnameemsg.input.getText();
    expect(lnameemsg).toEqual('Ingrese el apellido');

    //Verify the validation message when Gender is not entered
    var genmsg = POAYP.genderemsg.input.getText();
    expect(genmsg).toEqual('Seleccione un género')

    //Verify Validation message when Preferred Phone is not entered
    var pphoneemsg = POAYP.ppphoneemsg.input.getText();
    expect(pphoneemsg).toEqual('Ingrese un número telefónico válido');

    //Verify Validation message when Preferred Email is not entered
    var pemailemsg = POAYP.ppemailemsg.input.getText();
    expect(pemailemsg).toEqual('Ingrese una dirección de correo electrónico válida');

    //Verify Validation message when Residential Address1 is not entered
    var resaddremsg = POAYP.resaddr1emsg.input.getText();
    expect(resaddremsg).toEqual('Obligatorio');

    //Verify Validation message when Residential city is not entered
    var rescityemsg = POAYP.rescityemsg.input.getText();
    expect(rescityemsg).toEqual('Obligatorio');

    //Verify the validation message when State is not selected
    var statemsg = POAYP.resstateemsg.input.getText();
    expect(statemsg).toEqual('Ingrese un estado');

    //Verify the validation message when Postal Code is not entered
    var psmsg = POAYP.postalmsg.input.getText();
    expect(psmsg).toEqual('Obligatorio');

    //Verify the validation message when State of Employment is not selected
    var stateempmsg = POAYP.stateofemployemsg.input.getText();
    expect(stateempmsg).toEqual('Ingrese un estado');

      browser.takeScreenshot().then(function (png) {
          writeScreenShot(png, './Screenshots/AboutYouPage_Spanish/Testcase3.png');
      });

  });
// **********END OF TESTCASE III*************************************************************************************************************************//

});
