/**
 * Created by n0258375 on 8/3/2017.
 */

//6177 - Story - Spanish validation

//Include the Page Objects for pages
var POGSP = require('./../Page Wise/PageObject_GettingStarted.js');
var POAYP = require('./../Page Wise/PageObject_AboutYouPage.js');
var POAYA = require('./../Page Wise/PageObject_AboutYourAbsence.js');
var POAYC = require('./../Page Wise/PageObject_ContactsPage.js');


//Function to take screenshot
var fs = require('fs');
function writeScreenShot(data, filename) {
    var stream = fs.createWriteStream(filename);
    stream.write(new Buffer(data, 'base64'));
    stream.end();
}

describe ('Open CLI URL in Browser and Validate Save for Later', function(){
    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;

// **********BEGINNING OF TESTCASE I*************************************************************************************************************************//

//Enter values and Save the application

    it('New CLI_Save for Later Validation', function() {

        //Open NEW CLI in browser and go to About You Page
        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/cli');
        //browser.sleep(5000);

        //Click the Start button
        var startbtn = POGSP.startbtnspan.input;
        expect(startbtn.isDisplayed()).toBe(true);
        startbtn.click();

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/Save for Later/English/Testcase1_i.png');
        });

        //Validate the About You page is displayed
        var abtyouph = POAYP.aboutyouheader.input.getText();
        expect(abtyouph).toEqual('Acerca de Usted');

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/Save for Later/English/Testcase1_i.png');
        });

        //Enter valid value for Employee ID
        var empid = POAYP.empidtbox.input;
        empid.sendKeys('12345');

        //Enter valid value for FirstName
        var firstname = POAYP.fnametbox.input;
        firstname.sendKeys('TestFirstname');

        //Enter valid value for Last Name
        var lastname = POAYP.lnametbox.input;
        lastname.sendKeys('TestLastName');

        //Select Gender
        POAYP.rbtnfemale.input.click();

        //Enter Valid value for Date of Birth
        var dob = POAYP.dobtbox.input;
        dob.sendKeys('11/12/1975');

        //Enter Valid value for  Preferred phone number
        var preferedphone = POAYP.ppphonetbox.input;
        preferedphone.sendKeys('(988) 782-1111');

        //Enter Valid value for  Preferred email
        var prefmail = POAYP.ppemailtbox.input;
        prefmail.sendKeys('test@tst.com');

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/Save for Later/English/Testcase1_i.png');
        });

        //Enter Valid value for  Residential Address1
        var resaddr1 = POAYP.resaddrtbox1.input;
        resaddr1.sendKeys('Testaddress1');

        //Enter Valid value for  Residential City
        var rescity = POAYP.rescitytbox.input;
        rescity.sendKeys('Testcity');

        //Select any Residential State
        var statelist = POAYP.resstatelist.input;
        statelist.$('[value = "AK"]').click();

        //Enter Valid value for  Postal Code
        var postalcode = POAYP.postalcdetbox.input;
        postalcode.sendKeys('78901');

        //Select any value for State of Employment
        var stateemploy = POAYP.stateofemploylist.input;
        stateemploy.$('[value = "AK"]').click();

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/Save for Later/English/Testcase1_i.png');
        });

        //Click the Save for Later button
        var saveforlaterbtn = POAYP.saveforlaterbtnspan.input.getText();
        expect(saveforlaterbtn).toEqual('Guardar para más tarde');
        saveforlaterbtn.click();

        //Validate Save for Later popup is displayed
        var savepop = POAYP.savepopup.input.getText();
        expect(savepop).toEqual('Guardar para más tarde');

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/Save for Later/English/Testcase1_i.png');
        });

        //Click the Exit Application button
        var exitappbtn = POAYP.exitappbtn.input.getText();
        expect(exitappbtn).toEqual('Salir de la solicitud');
        exitappbtn.click();

        //Validate Getting Started page is displayed
        var getstartllbl = POGSP.headermessage1.input.getText();
        expect(getstartllbl).toEqual('!!!EE Un mensaje de su empleador');

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/Save for Later/English/Testcase1_i.png');
        });

        //Validate Open Your Saved Application button is displayed
        var opensaveappbtn = POGSP.opensaveappbtn.input.getText();
        expect(opensaveappbtn).toEqual('Abra su aplicación guardada');
        opensaveappbtn.click();

        //Validate the About You page is displayed
        var abtyouph = POAYP.aboutyouheader.input.getText();
        expect(abtyouph).toEqual('Acerca de Usted');

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/Save for Later/English/Testcase1_i.png');
        });

        //Validate the Values are Saved
        expect(firstname.getAttribute('value')).toEqual("TestFirstname");
        expect(lastname.getAttribute('value')).toEqual("TestLastName");

        var empid = POAYP.empidtbox.input;
        expect(empid.getAttribute('value')).toEqual("12345");

        var dateofbirth = POAYP.dobtbox.input;
        expect(dateofbirth.getAttribute('value')).toEqual("11/12/1975");

        var prefphone = POAYP.ppphonetbox.input;

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/Save for Later/English/Testcase1_i.png');
        });

        var resaddr1 = POAYP.resaddrtbox1.input;
        expect(resaddr1.getAttribute('value')).toEqual("Testaddress1");

        var rescity = POAYP.rescitytbox.input;
        expect(rescity.getAttribute('value')).toEqual("Testcity");

        var postalcode = POAYP.postalcdetbox.input;
        expect(postalcode.getAttribute('value')).toEqual("78901");

        var empstate = POAYP.resstatelist.input;
        expect(empstate.getAttribute('value')).toEqual("AK");

        var employstate = POAYP.stateofemploylist.input;
        expect(employstate.getAttribute('value')).toEqual("AK");

        var empcountry = POAYP.empcountrylist.input;
        expect(empcountry.getAttribute('value')).toEqual("USA");

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/Save for Later/English/Testcase1_i.png');
        });

        var employcountry = POAYP.countryofemploylist.input;
        expect(employcountry.getAttribute('value')).toEqual("USA");

        var empidrbtn = POAYP.empidradio.input;
        expect(empidrbtn.isSelected()).toBe(true);

        var prefmethod = POAYP.prefmethodemail.input;
        //expect(prefmethod.isSelected()).toBe(true);

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/EE/Save for Later/English/Testcase1_i.png');



        });
    });
});