/**
 * Created by n0305595 on 6/20/2017.
 */

var POAYP = require('./PageObject_AboutYouPage.js');

//Function to take screenshot
var fs = require('fs');
function writeScreenShot(data, filename) {
 var stream = fs.createWriteStream(filename);
 stream.write(new Buffer(data, 'base64'));
 stream.end();
}
describe ('Open URL in browser and validate contacts page labels', function(){

    //Increase TimeOut_Interval
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;

// **********BEGINNING OF TESTCASE I*************************************************************************************************************************//
//Validating label name in About You page

    it('New CLI_About You Page: Label Name Validation', function() {

        //Open NEW CLI in browser and go to About You Page
        browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/cli');
        //browser.sleep(5000);

        //Click About You Page
        element(by.css('[href="/cli/claimant"]')).click();

        //Verify Employee ID - Radio button label
        var empid = POAYP.empidtext.input.getText();
        expect(empid).toEqual('Employee ID');

        //Verify Employee SSN - Radio button label
        var ssntext = POAYP.ssntext.input.getText();
        expect(ssntext).toEqual('Social Security Number');

        //Verify GetHelp link opens the Get Help pop up for EmployeeID
        POAYP.gethelplink1.input.click();
        expect(element(by.className('modal-content')).isDisplayed()).toBe(true);
        element(by.buttonText('OK')).click();

        //Verify Employee ID Text Box label when Employee ID radio button is selected
        var empidlabel = POAYP.empidlabel.input.getText();
        expect(empidlabel).toContain('Employee ID');

        //Select SSN- Radio button
        POAYP.ssnradio.input.click();

        //Verify SSN Radio Button Label name
        var ssnlabel = POAYP.ssnlabel.input.getText();
        expect(ssnlabel).toEqual('Social Security Number');

        //Verify GetHelp link opens the Get Help pop up for EmployeeSSN
        POAYP.gethelplink2.input.click();
        expect(element(by.className('modal-content')).isDisplayed()).toBe(true);
        element(by.buttonText('OK')).click();

        //Verify the ssn format label name
        var ssnformat = POAYP.ssnformat.input.getText();
        expect(ssnformat).toEqual('9 numbers (no dashes)');

        //Verify Search button label
        var searchbtnname = POAYP.searchbtnname.input.getText();
        expect(searchbtnname).toEqual('Search');

        //Verify Personal Information Section - Header name
        var personalinfohdr = POAYP.personalinfoheader.input.getText();
        expect(personalinfohdr).toEqual('Personal Information');

        //Verify the First Name label Name
        var fnamelabel = POAYP.fnamelabel.input.getText();
        expect(fnamelabel).toContain('First Name');

        //Verify the Middle Name label Name
        var mnamelabel = POAYP.mnamelabel.input.getText();
        expect(mnamelabel).toContain('Middle Initial');

        //Verify the Last Name label Name
        var lnamelabel = POAYP.lnamelabel.input.getText();
        expect(lnamelabel).toContain('Last Name');

        //Verify the Gender label Name
        var genderlabel = POAYP.genderlabel.input.getText();
        expect(genderlabel).toContain('Gender');

        //Verify the Male label Name
        var malelabel = POAYP.malelabel.input.getText();
        expect(malelabel).toEqual('Male');

        //Verify the Female label Name
        var femalelabel = POAYP.femalelabel.input.getText();
        expect(femalelabel).toEqual('Female');

        //Verify Date of Birth Label Name
        var doblabel = POAYP.doblabel.input.getText();
        expect(doblabel).toContain('Date of Birth');

        //Verify the Date of Birth Format
        var dobformat = POAYP.dobformatlabel.input.getText();
        expect(dobformat).toEqual('mm/dd/yyyy');


        //Verify Preferred Phone Label Name
        var ppphonelabel = POAYP.ppphonelabel.input.getText();
        expect(ppphonelabel).toContain('Preferred Personal Phone');

        //Verify Preferred Phone format
        var pphoneformat = POAYP.ppphoneformatlabel.input.getText();
        expect(pphoneformat).toEqual('(###) ###-####');

        //Verify Preferred email Label Name
        var ppemaillabel = POAYP.ppemaillabel.input.getText();
        expect(ppemaillabel).toContain('Preferred Personal Email');

        //Verify Preferred email format
        var pemailformat = POAYP.ppemailformatlabel.input.getText();
        expect(pemailformat).toEqual('name@domain.com');

        //Verify the Residential Address 1 label Name
        var resaddr1label = POAYP.resaddr1label.input.getText();
        expect(resaddr1label).toEqual('Residential Address 1');

        //Verify the Residential Address 2 label Name
        var resaddr2label = POAYP.resaddr2label.input.getText();
        expect(resaddr2label).toEqual('Residential Address 2');

        //Verify the Country label Name
        var empcountrylabel = POAYP.empcountrylabel.input.getText();
        expect(empcountrylabel).toContain('Country');

        //Verify the Residential City label Name
        var rescitylabel = POAYP.rescitylabel.input.getText();
        expect(rescitylabel).toEqual('Residential City');

        //Verify the Residential state drop down label Name
        var resstatelabel = POAYP.resstatelabel.input.getText();
        expect(resstatelabel).toEqual('Residential State');

        //Verify the Postal Code label Name
        var postalcodelabel = POAYP.postalcodelabel.input.getText();
        expect(postalcodelabel).toEqual('Postal Code');

        //Verify the Preferred Method label Name
        var prefmethodlabel = POAYP.prefmethodlabel.input.getText();
        expect(prefmethodlabel).toContain('Preferred method for non-confidential correspondence');

        //Verify email label in Preferred Method
        var prefemaillabel = POAYP.prefmethodemail.input.getText();
        expect(prefemaillabel).toEqual('Email');

        //Verify Fax label in Preferred Method
        var preffaxlabel = POAYP.prefmethodfax.input.getText();
        expect(preffaxlabel).toEqual('Fax');

        //Verify Mail label in Preferred Method
        var prefmaillabel = POAYP.prefmethodmail.input.getText();
        expect(prefmaillabel).toEqual('Mail');

        //Verify the Primary Work Location label Name
        var primaryworkheader = POAYP.primaryworkheader.input.getText();
        expect(primaryworkheader).toEqual('Primary Work Location');

        //Verify the Employment Country label Name
        var employcountrylabel = POAYP.countryofemploylabel.input.getText();
        expect(employcountrylabel).toContain('Country of Employment');

        //Verify the State of Employment label Name
        var employstatelabel = POAYP.stateofemploylabel.input.getText();
        expect(employstatelabel).toContain('State of Employment');


       //Verify label of continue button
        var continuebutton = POAYP.continuebutton.input.getText();
        expect(continuebutton).toContain('Continue')

        //Verify label of continue button
        var gobackbutton = POAYP.gobackbutton.input.getText();
        expect(gobackbutton).toContain('Go Back')

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/AboutYouPage/Testcase1.png');
        });
        browser.sleep(5000);

    });

// **********END OF TESTCASE I*************************************************************************************************************************//


// **********BEGINNING OF TESTCASE II*************************************************************************************************************************//
 //To verify when all the Mandatory fields are entered, the application navigates to About Your absence page

    it('New CLI_About You Page: About Your Absence page display_Mandatory fields entered', function() {

     //Open NEW CLI in browser and go to About You Page
     browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/');


     //Select About You Page
     element(by.css('[href="/cli/claimant"]')).click();

     //Enter valid value for Employee ID
     var empid = POAYP.empidtbox.input;
     empid.sendKeys('12345');

     //To enter values in SSN text box
     POAYP.ssnradio.input.click();

    //Enter valid value for SSN
     var ssntext = POAYP.ssntbox.input;
     ssntext.sendKeys('984575674');

     //Enter valid value for FirstName
     var firstname = POAYP.fnametbox.input;
     firstname.sendKeys('TestFirstname');

     //Enter valid value for Last Name
     var lastname = POAYP.lnametbox.input;
     lastname.sendKeys('TestLastName');

     //Select Gender
     POAYP.rbtnfemale.input.click();

     //Enter Valid value for Date of Birth
     var dob = POAYP.dobtbox.input;
     dob.sendKeys('11/12/1975');

     //Enter Valid value for  Preferred phone number
     var preferedphone = POAYP.ppphonetbox.input;
     preferedphone.sendKeys('9887821111');

     //Enter Valid value for  Preferred email
     var prefmail = POAYP.ppemailtbox.input;
     prefmail.sendKeys('test@tst.com');

     //Enter Valid value for  Residential Address1
     var resaddr1 = POAYP.resaddrtbox1.input;
     resaddr1.sendKeys('Testaddress1');

     //Enter Valid value for  Residential City
     var rescity = POAYP.rescitytbox.input;
     rescity.sendKeys('Testcity');

     //Select any Residential State
     var statelist = POAYP.resstatelist.input;
     statelist.$('[value = "AK"]').click();

     //Enter Valid value for  Postal Code
     var postalcode = POAYP.postalcdetbox.input;
     postalcode.sendKeys('78901');

     //Select any value for State of Employment
     var stateemploy = POAYP.stateofemploylist.input;
     stateemploy.$('[value = "AK"]').click();

        //Take screenshot
        browser.takeScreenshot().then(function (png) {
            writeScreenShot(png, './Screenshots/AboutYouPage/Testcase2.png');
        });



    //Click Continue button
     POAYP.continuebutton.input.click();

    //Verify whether About Your absence page is displayed
     expect(POAYP.aboutyourabsence.input.isDisplayed()).toBe(true);

    });
// **********END OF TESTCASE II*************************************************************************************************************************//

// **********BEGINNING OF TESTCASE III*************************************************************************************************************************//
  //To validate an error message is displayed when mandatory fields are not entered

  it('New CLI_About You Page: Error Message validations_Mandatory fields not entered', function() {

    //Open NEW CLI in browser and go to About You Page
     browser.get('https://dev1-lmbc-empr-mlc-cli-user-interface.pdc.np.paas.lmig.com/');

    //Select About You Page
    element(by.css('[href="/cli/claimant"]')).click();
    POAYP.continuebutton.input.click();

    //Take screenshot for no values entered
    browser.takeScreenshot().then(function (png) {
    writeScreenShot(png, './Testcase3_i.png');
    });

    //Click Close button in the error  pop up message
    element(by.buttonText('Close')).click();

    //Verify Validation message when no empid is entered
    var empidemsg = POAYP.empidemsg.input.getText();
    expect(empidemsg).toEqual('Enter Employee ID');

    //Verify Validation message when FirstName is not entered
    var fnameemsg = POAYP.fnameemsg.input.getText();
    expect(fnameemsg).toEqual('Enter First Name');

    //Verify Validation message when LastName is not entered
    var lnameemsg = POAYP.lnameemsg.input.getText();
    expect(lnameemsg).toEqual('Enter Last Name');

    //Verify the validation message when Gender is not entered
    var genmsg = POAYP.genderemsg.input.getText();
    expect(genmsg).toEqual('Select a Gender')

    //Verify Validation message when Preferred Phone is not entered
    var pphoneemsg = POAYP.ppphoneemsg.input.getText();
    expect(pphoneemsg).toEqual('Enter a valid phone number');

    //Verify Validation message when Preferred Email is not entered
    var pemailemsg = POAYP.ppemailemsg.input.getText();
    expect(pemailemsg).toEqual('Enter a valid email');

    //Verify Validation message when Residential Address1 is not entered
    var resaddremsg = POAYP.resaddr1emsg.input.getText();
    expect(resaddremsg).toEqual('Required');

    //Verify Validation message when Residential city is not entered
    var rescityemsg = POAYP.rescityemsg.input.getText();
    expect(rescityemsg).toEqual('Required');

    //Verify the validation message when State is not selected
    var statemsg = POAYP.resstateemsg.input.getText();
    expect(statemsg).toEqual('Enter a State');

    //Verify the validation message when Postal Code is not entered
    var psmsg = POAYP.postalmsg.input.getText();
    expect(psmsg).toEqual('Required');

    //Verify the validation message when State of Employment is not selected
    var stateempmsg = POAYP.stateofemployemsg.input.getText();
    expect(stateempmsg).toEqual('Enter a State');

      //Take screenshot
      browser.takeScreenshot().then(function (png) {
          writeScreenShot(png, './Screenshots/AboutYouPage/Testcase3.png');
      });


  });
// **********END OF TESTCASE III*************************************************************************************************************************//

});
