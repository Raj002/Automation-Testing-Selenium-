/**
 * Created by n0238696 on 7/11/2017.
 */


var ReviewPage = function() {

    var primarybutton = element.all(by.className('lds-button lds-button--primary'));
    var valuelabels = element.all(by.className('fieldLabel--leftAlign'));
    var txtinstructionaleng = 'Please review the information below for accuracy before submitting your absence. To make any changes, select “Edit” to return to the appropriate section';
    var txtinstructionalspn = 'Por favor revise la información de abajo antes de presentar su ausencia. Para realizar cualquier cambio, seleccione "Editar" para volver a la sección correspondiente';

    this.ClickSubmit_ViewConfirmation = function(){

        browser.executeScript("arguments[0].scrollIntoView()",primarybutton.get(0).getWebElement());
        primarybutton.get(0).click();
        browser.sleep(40000);
    };

    this.VerifyDateofBirth = function(){

        expect(valuelabels.get(9).getText()).toEqual('01/01/1900');

    };

    this.VerifyAdditionalInfoSection = function(){
        var sections = element.all(by.className('accordion-toggle collapsed'));
        expect(sections.get(1).getText()).toEqual('Additional Information');
    };

    this.VerifyMedicalContactsSection = function(){
        var sections = element.all(by.className('accordion-toggle collapsed'));
        expect(sections.get(1).getText()).toEqual('Medical Contacts');
    };

    this.VerifyMedicalContactsSection_Spanish = function(){
        var sections = element.all(by.className('accordion-toggle collapsed'));
        expect(sections.get(1).getText()).toEqual('Contactos Médicos');
    };

    this.VeirfyAddInstructionaltxt_Eng = function(){
        expect(element.byxpath("").getText()).ToEqual(txtinstructionaleng);
    };
    this.VeirfyAddInstructionaltxt_Spn = function(){
        expect(element.byxpath("").getText()).ToEqual(txtinstructionalspn);
    };






























    //About Your Contacts - Progress Bar
    this.reviewpbar = {
        input: element(by.css('[href="/employer/cli/review"]'))
    };

    //Review - Header
    this.reviewheader = {
        input: (element.all(by.tagName('h1')).get(1))
    };

    //Fraud statement - Header
    this.fraudstmntheader = {
        input: (element.all(by.className('col-xs-12')).get(5))
        //input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/review/div[3]/div/text()[1]'))
    };

    //Intructional text content
    this.instructionaltextcontent = {
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/review/div[1]/div[1]'))
    };

    //Get Help Label
    this.gethlplabel = {
        input: element(by.css('.linkBold a'))
    };


    //pop up window validation
    this.popuphelp = {
        input: element(by.className('modal-dialog'))
    }


    //About You section
    this.aboutyousection = {
        input: element(by.css('[href="#collapse1"]'))
    };
    //About Your Employee accordian
    this.aboutyouaccordianf = {
        input: element(by.css('[href="#collapse1"][aria-expanded="false"]'))
    };

    this.aboutyouaccordiant = {
        input: element(by.css('[href="#collapse1"][aria-expanded="true"]'))
    };

     //About Your Absence
    this.aboutyourabsencesection = {
        input: element(by.css('[href="#collapse2"]'))
    };

    //About Your Employee Absence accordian
    this.aboutabsenceaccordianf = {
        input: element(by.css('[href="#collapse2"][aria-expanded="false"]'))

            };

    this.aboutabsenceaccordiant = {
        input: element(by.css('[href="#collapse2"][aria-expanded="true"]'))
    };

    //Additional Information Section
    this.addlinfosection = {
        input: element(by.css('[href="#collapse3"]'))
    };

    //Additional Information accordian
    this.addlinfoaccordianf = {
        input: element(by.css('[href="#collapse3"][aria-expanded="false"]'))
    };

    this.addlinfoaccordiant = {
        input: element(by.css('[href="#collapse3"][aria-expanded="true"]'))
    };


    //About You section - Edit
    this.aboutyousedit = {
        input: (element.all(by.className('editLink')).get(0))
    };

    //About Your Absence - Edit
    this.aboutyourabsenceedit = {
        input: (element.all(by.className('editLink')).get(1))
    };


    //Additional information - Edit
    this.addlinfoedit = {
        input: (element.all(by.className('editLink')).get(2))
    };

    //Submit Button
    this.submitbutton = {
        input: element(by.buttonText('Submit'))
    };
    //Go Back Button
    this.gobackbutton = {
        input: element(by.buttonText('Go Back'))
    };

    //Verify About Your Employee page

    this.abtyouremppage = {
        input: (element.all(by.tagName('h1')).get(1))
    };

    this.abtyourabsemppage = {
        input: (element.all(by.tagName('h1')).get(1))
    };

    this.addlinfopage = {
        input: (element.all(by.tagName('h1')).get(1))
    };

    //labels for addl information page
    this.lbldateofhire = {
        input:  element.all(by.className('fieldset__label')).get(31)
    };

    this.lbladdlempid = {
        input:  element.all(by.className('fieldset__label')).get(32)
    };
    //labels for addl information page
    this.lblclass = {
        input:  element.all(by.className('fieldset__label')).get(33)
    };

    this.lblworkstate = {
        input:  element.all(by.className('fieldset__label')).get(34)
    };

    this.lblempcontribution = {
        input:  element.all(by.className('fieldset__label')).get(35)
    };

    this.lblsubsidiary = {
        input:  element.all(by.className('fieldset__label')).get(36)
    };


    this.lblemprcontribution = {
        input:  element.all(by.className('fieldset__label')).get(37)
    };

    this.lbllocbranch = {
        input:  element.all(by.className('fieldset__label')).get(38)
    };

    this.lblbenefitpercent = {
        input:  element.all(by.className('fieldset__label')).get(39)
    };

    this.lblemptype = {
        input:  element.all(by.className('fieldset__label')).get(40)
    };

    this.lbldaysperweek = {
        input:  element.all(by.className('fieldset__label')).get(41)
    };

    this.lbljob = {
        input:  element.all(by.className('fieldset__label')).get(42)
    };
    this.lblhourdays = {
        input:  element.all(by.className('fieldset__label')).get(43)
    };

    this.lblphydemands = {
        input:  element.all(by.className('fieldset__label')).get(44)
    };


    this.lblschdays = {
        input:  element.all(by.className('fieldset__label')).get(45)
    };

    this.lblpaytype = {
        input:  element.all(by.className('fieldset__label')).get(46)
    };
    this.lblcurrstatus = {
        input:  element.all(by.className('fieldset__label')).get(47)
    };


    this.lblearnings = {
        input:  element.all(by.className('fieldset__label')).get(48)
    };

    this.lblincometype = {
        input:  element.all(by.className('text-nowrap')).get(0)
    };
    this.lblincomeamount = {
        input:  element.all(by.className('text-nowrap')).get(1)
    };
    this.lblbegindate = {
        input:  element.all(by.className('text-nowrap')).get(2)
    };
    this.lblenddate = {
        input:  element.all(by.className('text-nowrap')).get(3)
    };
    this.lblapplieddate = {
        input:  element.all(by.className('text-nowrap')).get(4)
    };



    this.txtdateofhire = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(31)
    };

    this.txtempid = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(32)
    };

    this.txtclass1 = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(33)
    };

    this. txtworkstate = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(34)
    };

    this.txtemppremium = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(35)

    };

    this.txtsubsidiary = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(36)
    };


    this.txtemprpremium = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(37)
    };

    this.txtlocbranch = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(38)
    };

    this.txtbenefit = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(39)
    };

    this. txtemptype ={
        input:  element.all(by.className('fieldset__label_textwrap')).get(40)
    };

    this.txtdays = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(41)
    };

    this.txtjob = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(42)
    };

    this.txthours = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(43)

    };


    this.txtphydem = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(44)
    };

    this.txtschdays = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(45)

    };


    this.txtpaytype = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(46)
    };

    this.txtcurworkstatus={
        input:  element.all(by.className('fieldset__label_textwrap')).get(47)

    };


    this.txtearnings = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(48)
    }

   this.txtincomeamt= {
        input:  element.all(by.className('fieldset__label_textwrap')).get(48)
    }

    /*this.txtincometype = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(50)
    }
    this.txtbegindate = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(51)
    }
    this.txtenddate = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(52)
    }
    this.txtapplieddate = {
        input:  element.all(by.className('fieldset__label_textwrap')).get(53)
    }*/











};

module.exports = new ReviewPage();