/**
 * Created by n0238696 on 7/17/2017.
 */


var AboutAbsence = function(){

    var dateselection = element.all(by.className('undefined ui-inputtext ui-corner-all ui-state-default ui-widget'));
    var primarybutton = element.all(by.className('lds-button lds-button--primary'));
    var Claimantcondition = element.all(by.css('[formcontrolname="claimantCondition"]'));
    var Claimantcondition = element.all(by.css('[formcontrolname="claimantCondition"]'));
    var dateclassname = 'ui-inputtext ui-widget ui-state-default ui-corner-all';
    var Diagnosis_question = ['We are asking that you not provide any genetic information when responding to this request for medical information.'];
    var readmore = ["The Genetic Information Nondiscrimination Act of 2008 (GINA) prohibits employers" +
    " and other entities covered by GINA Title II from requesting or requiring genetic information of an individual or " +
    "family member of the individual, except as specifically allowed by this law. To comply with this law, we are asking that you not provide any genetic information when responding to this request for " +
    "medical information. \"Genetic information\" as defined by GINA, includes an individual's family medical history," +
    " the results of an individual's or family member's genetic tests, the fact that an individual or an individual's " +
    "family member sought or received genetic services, and genetic information of a fetus carried by an individual or" +
    " an individual's family member or an embryo lawfully held by an individual or family member receiving assistive " +
    "reproductive services."];

    var Maternity_Questions_Employee_English = ['Will you be out for at least 3 consecutive days?',
        'What best describes the circumstances for your absence?',
        'Have you already delivered?',
        'What date did you deliver?',
        'What was the last day worked or expected last day worked?',
        'What date did you arrive at the hospital?',
        "What was, or is, your discharge date from the hospital?"];

    var Maternity_Questions_Employee_Spanish = ['¿Estará ausente del trabajo por más de 3 días consecutivos de calendario?',
        '¿Lo que describe mejor las circunstancias para su ausencia?',
        '¿Ya dio a luz?',
        '¿Qué fecha entregaste?',
        '¿Cuál fue el último día trabajado o esperado el último día de trabajo?',
        '¿A qué fecha llegó al hospital?',
        "¿Cuál fue o es la fecha de alta del hospital?"];


    var Maternity_Questions = ['Will the Associate be out for a continuous period of time?',
        'What best describes the circumstances for the absence?',
        'Has the Associate already delivered?',
        'What date did the Associate deliver?',
        'What was the last day worked or expected last day worked?',
        'What date did the Associate arrive at the hospital?',
        "What was, or is, the Associate's discharge date from the hospital?"];

    var OtherLeaveFlow_Questions = ['Will the Associate be out for a continuous period of time?',
        'What best describes the circumstances for the absence?',
        "What is the reason for the Associate's absence?",
        'What is the first day, or expected first day, of the leave of absence?',
        "What is the last day, or estimated last day, of the Associate's leave of absence?"];

    var OtherLeaveFlow_Questions_English = ['Will you be out for at least 3 consecutive days?',
        'What best describes the circumstances for your absence?',
        "What is the reason for your absence?",
        'What is the first day, or expected first day, of your leave of absence?',
        "What is the last day, or estimated last day, of your leave of absence?"];

    var OtherLeaveFlow_Questions_Spanish = ['¿Estará ausente del trabajo por más de 3 días consecutivos de calendario?',
        '¿Lo que describe mejor las circunstancias para su ausencia?',
        "¿Qué es la razón para su hoja?",
        '¿Cuál es el primer día del primer día esperado de su ausencia?',
        "¿Cuál es el último día, o estimado último día, de su licencia?"];

    var CareFlow_Questions = ['Will the Associate be out for a continuous period of time?',
        'What best describes the circumstances for the absence?',
        "What is the reason for the Associate's absence?",
        "What is the person's relationship to the Associate?",
        'What is the first day, or expected first day, of the leave of absence?',
        "What is the date of birth of the person the Associate is caring for?",
        "What is the last day, or estimated last day, of the Associate's leave of absence?"];



    var reasonabsence = ['Select','Child','Parent','Spouse','Domestic Violence','Military Leave','Other'];
    var reasonorder = ['Select','Absence plus treatment','Chronic Condition','Domestic Violence','Exigency','Hospital Care','Multiple Treatments','Permanent/Long-Term Condition','Work Related','Other'];
    var reasonordermale = ['Select','Absence plus treatment','Chronic Condition','Domestic Violence','Exigency','Hospital Care','Multiple Treatments','Permanent/Long-Term Condition','Work Related','Other'];
    var reasonorder_Spanish = ['Seleccione','Ausencia Más Tratamiento','Condiciones crónicas que requieren tratamiento','Violencia domestica','Exigencia','Cuidado hospitalario','Múltiples tratamientos','Condición permanente/de largo plazo','Relativo al trabajo','Otro tipo de licencia, no mencionado arriba'];
    var deliveryComplication = element.all(by.css('[formcontrolname="deliveryComplicationIndicator"]'));
    var Leave_ClaimType  = element.all(by.css('[formcontrolname="leaveType"]'));
    var dropdown_1 = element(by.css('[formcontrolname="leaveReason"]'));
    var dropdown_1_options = element(by.css('[formcontrolname="leaveReason"]')).all(by.tagName('option'));
    var dropdown_2 = element(by.css('[formcontrolname="relationship"]'));
    var dropdown_2_options = element(by.css('[formcontrolname="relationship"]')).all(by.tagName('option'));
    var radioaccidentresult = element.all(by.css('[formcontrolname="accidentIndicator"]'));
    var radiomotoraccident = element.all(by.css('[formcontrolname="motorVehicleAccidentIndicator"]'));
    var radioonjob = element.all(by.css('[formcontrolname="workRelatedIndicator"]'));
    var radiohospital = element.all(by.css('[formcontrolname="hospitalizationIndicator"]'));
    var radiosurgery = element.all(by.css('[formcontrolname="surgeryIndicator"]'));
    var lblmotoraccident = element.all(by.id('motorVehicleAccidentIndicator'));



    this.SelectLeaveorClaimCategory = function(value1){

        var Leave_ClaimCategory  = element.all(by.css('[formcontrolname="leaveCategory"]'));


        if (value1 == 'Yes')
        {
            browser.executeScript("arguments[0].scrollIntoView()",Leave_ClaimCategory.get(0).getWebElement());
            Leave_ClaimCategory.get(0).click();

        }
        else
        {
            browser.executeScript("arguments[0].scrollIntoView()",Leave_ClaimCategory.get(1).getWebElement());
            Leave_ClaimCategory.get(1).click();
            browser.sleep(5000);
        }

    };

    this.SelectLeaveorClaimtype = function(value1,value2){

        switch (value1){

            case "Maternity":
                browser.executeScript("arguments[0].scrollIntoView()",Leave_ClaimType.get(0).getWebElement());
                Leave_ClaimType.get(0).click();
                break;

            case "BondwithChild":

                if (value2 =="Female") {Leave_ClaimType.get(1).click();}
                else { Leave_ClaimType.get(0).click();}
                break;


            case "MOC":
                if (value2 =="Female") {Leave_ClaimType.get(3).click();}
                else { Leave_ClaimType.get(2).click();}
                break;


            case "CareFlow":
                if (value2 =="Female") { Leave_ClaimType.get(2).click();}
                else { Leave_ClaimType.get(1).click(); }
                break;

            case "Other-Leave":

                if (value2 =="Female") {Leave_ClaimType.get(4).click(); }
                else {Leave_ClaimType.get(3).click(); }
                break;


        }

    };

    this.SelectClaimantCondition = function(value1){

        switch (value1){

            case "Illness":
                browser.executeScript("arguments[0].scrollIntoView()",Claimantcondition.get(0).getWebElement());
                Claimantcondition.get(0).click();
                browser.sleep(2000);
                break;

            case "Injury":
                browser.executeScript("arguments[0].scrollIntoView()",Claimantcondition.get(1).getWebElement());
                Claimantcondition.get(1).click();
                browser.sleep(2000);
                break;

            case "PaidLeave":
                browser.executeScript("arguments[0].scrollIntoView()",Claimantcondition.get(2).getWebElement());
                Claimantcondition.get(2).click();
                browser.sleep(2000);
                break;
        }

    };

    this.CustomMessage_PaidLeave = function(){
        expect(element.all(by.className('fieldset__feedback fieldset__feedback--invalid')).get(0).isDisplayed()).toBe(true);
    }

    this.Continuebuttondisabled_validation = function(){

        //expect(primarybutton.isEnabled()).toBe(false);
        expect(primarybutton.getCssValue("color")).toEqual([ 'rgba(255, 255, 255, 1)' ]);
        expect(primarybutton.getCssValue("background-color")).toEqual([ 'rgba(235, 187, 144, 1)' ]);
    }


    this.SelectDeliveryType = function(value1){

        var deliveryIndicator  = element.all(by.css('[formcontrolname="deliveryIndicator"]'));

        switch (value1){

            case "Vaginal":
                browser.executeScript("arguments[0].scrollIntoView()",deliveryIndicator.get(0).getWebElement());
                deliveryIndicator.get(0).click();
                break;

            case "CSection":
                browser.executeScript("arguments[0].scrollIntoView()",deliveryIndicator.get(1).getWebElement());
                deliveryIndicator.get(1).click();
                break;

            case "No_NotYet":
                browser.executeScript("arguments[0].scrollIntoView()",deliveryIndicator.get(2).getWebElement());
                deliveryIndicator.get(2).click();
                break;
        }

    };


    this.VerifyFormat_DateQuestion_1 = function(value1){


        var dateselect = element(by.className('ng-tns-c0-0 '+ dateclassname));
        dateselect.clear();
        browser.executeScript("arguments[0].scrollIntoView()",dateselect.getWebElement());
        dateselect.sendKeys(value1,protractor.Key.TAB);
        return dateselect.getAttribute('value');

    };
    this.VerifyFormat_DateQuestion_2 = function(value1){

        var dateselect = element(by.className('ng-tns-c0-1 '+ dateclassname));
        dateselect.clear();
        browser.executeScript("arguments[0].scrollIntoView()",dateselect.getWebElement());
        dateselect.sendKeys(value1,protractor.Key.TAB);
        return dateselect.getAttribute('value');

    };
    this.VerifyFormat_DateQuestion_3 = function(value1){

        var dateselect = element(by.className('ng-tns-c0-2 '+ dateclassname));
        dateselect.clear();
        browser.executeScript("arguments[0].scrollIntoView()",dateselect.getWebElement());
        dateselect.sendKeys(value1,protractor.Key.TAB);
        return dateselect.getAttribute('value');

    };
    this.VerifyFormat_DateQuestion_4 = function(value1){

        var dateselect = element(by.className('ng-tns-c0-3 '+ dateclassname));
        dateselect.clear();
        browser.executeScript("arguments[0].scrollIntoView()",dateselect.getWebElement());
        dateselect.sendKeys(value1,protractor.Key.TAB);
        return dateselect.getAttribute('value');

    };
    this.DateEntry = function(value1) {

        var date;
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1;
        var yyyy = today.getFullYear();


        switch (value1) {

            case 'greater than 1 year':

                date = mm + "/" + (dd +1) + "/" + (yyyy + 1);
                break;

            case 'lesser than 1 year':

                date = mm + "/" + (dd -1)+ "/" + (yyyy - 1);
                break;

            case 'invalid date':

                date = (mm + 13) + "/" + (dd + 31) + "/" + yyyy;
                break;

            case 'greater than 2 year':

                date = mm + "/" + (dd + 1) + "/" + (yyyy + 2);
                break;

            case 'today':

                date = mm + "/" + dd + "/" + yyyy;
                break;

            case 'future date':

                date = mm + "/" + (dd + 1) + "/" + yyyy;
                break;
        }

        return date;
    };

    this.Verify_ErrorMessage_datefeilds_Bondflow = function(value1) {

        var errorMessage = element.all(by.className('fieldset__feedback fieldset__feedback--invalid--withnomargin'));

        switch (value1) {

            case 'Err_Msg_Outside valid window_Greater':

                expect(errorMessage.get(2).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(3).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(4).getText()).toEqual('The Date of Birth entered is more than one year from today.');
                expect(errorMessage.get(5).getText()).toEqual('The Leave End Date must be within +2 or -1 years from today.');
                browser.sleep(2000);
                break;

            case 'Err_Msg_Outside valid window_lesser':

                expect(errorMessage.get(2).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(3).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(4).getText()).toEqual('The Date of Birth entered is more than one year from today.');
                expect(errorMessage.get(5).getText()).toEqual('The Leave End Date must be within +2 or -1 years from today.');
                browser.sleep(2000);
                break;

            case 'Err_Msg_Invalid format':

                expect(errorMessage.get(2).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                expect(errorMessage.get(3).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                expect(errorMessage.get(4).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                expect(errorMessage.get(5).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                browser.sleep(2000);
                break;

        }
        element(by.className('ng-tns-c1-0 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();
        element(by.className('ng-tns-c1-1 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();
        element(by.className('ng-tns-c1-2 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();
        element(by.className('ng-tns-c1-3 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();


    };

    this.Verify_ErrorMessage_datefeilds_Careflow = function(value1) {

        var errorMessage = element.all(by.className('fieldset__feedback fieldset__feedback--invalid--withnomargin'));

        switch (value1) {

            case 'Err_Msg_Outside valid window_Greater':

                expect(errorMessage.get(2).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(3).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(4).getText()).toEqual('The Leave End Date must be within +2 or -1 years from today.');
                browser.sleep(2000);
                break;

            case 'Err_Msg_Outside valid window_lesser':

                expect(errorMessage.get(2).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(3).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(4).getText()).toEqual('The Leave End Date must be within +2 or -1 years from today.');
                browser.sleep(2000);
                break;

            case 'Err_Msg_Invalid format':

                expect(errorMessage.get(2).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                expect(errorMessage.get(3).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                expect(errorMessage.get(4).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                browser.sleep(2000);
                break;

        }
        element(by.className('ng-tns-c1-0 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();
        element(by.className('ng-tns-c1-1 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();
        element(by.className('ng-tns-c1-2 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();



    };

    this.Verify_ErrorMessage_datefeilds_Maternityflow = function(value1) {

        var errorMessage = element.all(by.className('fieldset__feedback fieldset__feedback--invalid--withnomargin'));

        switch (value1) {

            case 'Err_Msg_Outside valid window_Greater':

                expect(errorMessage.get(3).getText()).toEqual('The delivery date entered cannot be in the future.');
                expect(errorMessage.get(4).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(5).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(6).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                browser.sleep(2000);
                break;

            case 'Err_Msg_Outside valid window_lesser':

                expect(errorMessage.get(3).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(4).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(5).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                browser.sleep(2000);
                break;

            case 'Err_Msg_Invalid format':

                expect(errorMessage.get(3).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                expect(errorMessage.get(4).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                expect(errorMessage.get(5).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                expect(errorMessage.get(6).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                browser.sleep(2000);
                break;

        }
        element(by.className('ng-tns-c1-0 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();
        element(by.className('ng-tns-c1-1 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();
        element(by.className('ng-tns-c1-2 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();
        element(by.className('ng-tns-c1-3 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();


    };

    this.Verify_ErrorMessage_datefeilds_Maternityflow_ER = function(value1) {

        var errorMessage = element.all(by.className('fieldset__feedback fieldset__feedback--invalid--withnomargin'));

        switch (value1) {

            case 'Err_Msg_Outside valid window_Greater':

                expect(errorMessage.get(3).getText()).toEqual('The delivery date entered cannot be in the future.');
                expect(errorMessage.get(4).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(5).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(6).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                browser.sleep(2000);
                break;

            case 'Err_Msg_Outside valid window_lesser':

                expect(errorMessage.get(3).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(4).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(5).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                browser.sleep(2000);
                break;

            case 'Err_Msg_Invalid format':

                expect(errorMessage.get(3).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                expect(errorMessage.get(4).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                expect(errorMessage.get(5).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                expect(errorMessage.get(6).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                browser.sleep(2000);
                break;

        }
        element(by.className('ng-tns-c1-0 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();
        element(by.className('ng-tns-c1-1 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();
        element(by.className('ng-tns-c1-2 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();
        element(by.className('ng-tns-c1-3 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();


    };

    this.Verify_ErrorMessage_datefeilds_MOCflow = function(value1) {

        var errorMessage = element.all(by.className('fieldset__feedback fieldset__feedback--invalid--withnomargin'));

        switch (value1) {

            case 'Err_Msg_Outside valid window_Greater':

                expect(errorMessage.get(3).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(4).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                browser.sleep(2000);
                break;

            case 'Err_Msg_Outside valid window_lesser':

                expect(errorMessage.get(3).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(4).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                browser.sleep(2000);
                break;

            case 'Err_Msg_Invalid format':

                expect(errorMessage.get(3).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                expect(errorMessage.get(4).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                browser.sleep(2000);
                break;

        }
        element(by.className('ng-tns-c1-0 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();
        element(by.className('ng-tns-c1-1 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();


    };

    this.Verify_ErrorMessage_datefeilds_Otherflow = function(value1) {

        var errorMessage = element.all(by.className('fieldset__feedback fieldset__feedback--invalid--withnomargin'));

        switch (value1) {

            case 'Err_Msg_Outside valid window_Greater':

                expect(errorMessage.get(2).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(3).getText()).toEqual('The Leave End Date must be within +2 or -1 years from today.');
                browser.sleep(2000);
                break;

            case 'Err_Msg_Outside valid window_lesser':

                expect(errorMessage.get(2).getText()).toEqual('The date entered must be +1 or -1 years of the current date.');
                expect(errorMessage.get(3).getText()).toEqual('The Leave End Date must be within +2 or -1 years from today.');
                browser.sleep(2000);
                break;

            case 'Err_Msg_Invalid format':

                expect(errorMessage.get(2).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                expect(errorMessage.get(3).getText()).toEqual('Enter a valid date MM/DD/YYYY');
                browser.sleep(2000);
                break;

        }
        element(by.className('ng-tns-c1-0 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();
        element(by.className('ng-tns-c1-1 ui-inputtext ui-widget ui-state-default ui-corner-all')).clear();


    };






    this.EnterDateQuestion_1 = function(value1){

        var dateselect = element(by.className('ng-tns-c1-0 '+ dateclassname));
        dateselect.clear();
        browser.executeScript("arguments[0].scrollIntoView()",dateselect.getWebElement());
        dateselect.sendKeys(value1,protractor.Key.TAB);

    };


    this.EnterDateQuestion_2 = function(value1){

        var dateselect = element(by.className('ng-tns-c1-1 '+ dateclassname));
        dateselect.clear();
        browser.executeScript("arguments[0].scrollIntoView()",dateselect.getWebElement());
        dateselect.sendKeys(value1,protractor.Key.TAB);

    };

    this.EnterDateQuestion_3 = function(value1){

        var dateselect = element(by.className('ng-tns-c1-2 '+ dateclassname));
        dateselect.clear();
        browser.executeScript("arguments[0].scrollIntoView()",dateselect.getWebElement());
        dateselect.sendKeys(value1,protractor.Key.TAB);

    };


    this.EnterDateQuestion_4 = function(value1){

        var dateselect = element(by.className('ng-tns-c1-3 '+ dateclassname));
        //var dateselect = element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/absence/form/div[1]/leave/div/div[5]/div/p-calendar/span/input'));
        dateselect.clear();
        browser.executeScript("arguments[0].scrollIntoView()",dateselect.getWebElement());
        dateselect.sendKeys(value1,protractor.Key.TAB);

    };


    this.EnterSurgeryDescription = function(value1){

        var Surgerydesc = element(by.css('[formcontrolname="surgeryDescription"]'));
        Surgerydesc.clear();
        browser.executeScript("arguments[0].scrollIntoView()",Surgerydesc.getWebElement());
        Surgerydesc.sendKeys(value1,protractor.Key.TAB);

    };

    this.EnterSurgeryComplicationtxt = function(value1){

        var SurgeryComplication = element(by.css('[formcontrolname="surgeryComplicationText"]'));
        SurgeryComplication.clear();
        browser.executeScript("arguments[0].scrollIntoView()",SurgeryComplication.getWebElement());
        SurgeryComplication.sendKeys(value1,protractor.Key.TAB);

    };

    this.SelectComplicationIndicator = function(value1){

        if (value1 == "Yes")
        { deliveryComplication.get(0).click();}
        else
        {deliveryComplication.get(1).click();}

    };

    this.diagonsisquestionvalidation = function(value1){

        var Diagnosisquestion = element.all(by.className('fieldset__optional'));
        var readmorecontent = element(by.className('modal-body'));
        var errorMessage = element.all(by.className('fieldset__feedback fieldset__feedback--invalid--withnomargin'));

        switch (value1) {

            case 'Employee_claimleave':
                expect(Diagnosisquestion.get(0).getText()).toContain(Diagnosis_question);
                Diagnosisquestion.get(1).click();
                expect(readmorecontent.getText()).toContain(readmore);
                primarybutton.get(1).click();
                primarybutton.get(0).click();
                primarybutton.get(1).click();
                expect(errorMessage.get(8).getText()).toContain('Required');
                break;

            case 'Employee_claimonly':
                expect(Diagnosisquestion.get(0).getText()).toContain(Diagnosis_question);
                Diagnosisquestion.get(1).click();
                expect(readmorecontent.getText()).toContain(readmore);
                primarybutton.get(1).click();
                primarybutton.get(0).click();
                primarybutton.get(1).click();
                expect(errorMessage.get(6).getText()).toContain('Required');
                break;

            case "Employer_Claimleave_claimonly":
                expect(Diagnosisquestion.get(5).getText()).toContain('optional');
                expect(Diagnosisquestion.get(6).getText()).toContain(Diagnosis_question);
                Diagnosisquestion.get(7).click();
                expect(readmorecontent.getText()).toContain(readmore);
                primarybutton.get(1).click();
                break;

            case "Employer_Employee_leaveonly":
                expect(Diagnosisquestion.get(2).getText()).toContain('optional');
                expect(Diagnosisquestion.get(3).getText()).toContain(Diagnosis_question);
                Diagnosisquestion.get(4).click();
                expect(readmorecontent.getText()).toContain(readmore);
                primarybutton.get(1).click();
                break;
        }
        browser.sleep(2000);
    };





    this.QuestionsLabelValidations = function(value1)
    {

        var i,Questions_Count;
        Questions_Label.count().then(function (lbl_Count) {
            Questions_Count = lbl_Count;

            switch (value1){

                case "Employer-Maternity-Vaginal" || "Employer-Maternity_CSection":
                    for (i=0;i < Questions_Count;i++){
                        expect(Questions_Label.get(i).getText()).toEqual(Maternity_Questions[i]);
                        expect(Questions_Label.get(i).isDisplayed()).toBe(true);
                        expect(Questions_Label.get(i).getText()).not.toEqual('Please select the condition that best describes your circumstances?');
                    }
                    break;

                case "Employee-Maternity-Vaginal" || "Employee-Maternity_CSection":
                    for (i=0;i < Questions_Count;i++){
                        expect(Questions_Label.get(i).getText()).toEqual(Maternity_Questions_Employee_English[i]);
                        expect(Questions_Label.get(i).isDisplayed()).toBe(true);
                        expect(Questions_Label.get(i).getText()).not.toEqual('Please select the condition that best describes your circumstances?');
                    }
                    break;

                case "Employee-Spanish-Maternity-Vaginal" || "Employee-Spanish-Maternity_CSection":
                    for (i=0;i < Questions_Count;i++){
                        expect(Questions_Label.get(i).getText()).toEqual(Maternity_Questions_Employee_Spanish[i]);
                        expect(Questions_Label.get(i).isDisplayed()).toBe(true);

                    }
                    break;

                case  "Employer-No Not Yet":
                    for (i=0;i < Questions_Count-2;i++){
                        expect(Questions_Label.get(i).getText()).toEqual(Maternity_Questions[i]);
                        expect(Questions_Label.get(i).isDisplayed()).toBe(true);
                        expect(Questions_Label.get(i).getText()).not.toEqual('Please select the condition that best describes your circumstances?');
                    }
                    expect(element(by.id('deliveryComplicationIndicator')).getText()).toEqual('Has the Associate experienced any complications during her pregnancy?');
                    break;

                case  "Employee-No Not Yet":

                    expect(Questions_Label.get(0).getText()).toEqual('Will you be out for at least 3 consecutive days?');
                    expect(Questions_Label.get(1).getText()).toEqual('What best describes the circumstances for your absence?');
                    expect(Questions_Label.get(2).getText()).toEqual('Have you already delivered?');
                    expect(Questions_Label.get(3).getText()).toEqual('What is your expected delivery date?');
                    expect(Questions_Label.get(4).getText()).toEqual('What was the last day worked or expected last day worked?');
                    expect(element(by.id('deliveryComplicationIndicator')).getText()).toEqual('Have you experienced any complications during your pregnancy?');
                    break;

                case  "Employee-Spanish-No Not Yet":

                    expect(Questions_Label.get(0).getText()).toEqual('¿Estará ausente del trabajo por más de 3 días consecutivos de calendario?');
                    expect(Questions_Label.get(1).getText()).toEqual('¿Lo que describe mejor las circunstancias para su ausencia?');
                    expect(Questions_Label.get(2).getText()).toEqual('¿Ya dio a luz?');
                    expect(Questions_Label.get(3).getText()).toEqual('¿Cuál es la fecha aproximada de su parto?');
                    expect(Questions_Label.get(4).getText()).toEqual('¿Cuál fue el último día trabajado o esperado el último día de trabajo?');
                    expect(element(by.id('deliveryComplicationIndicator')).getText()).toEqual('¿Ha experimentado alguna complicación durante su embarazo?');
                    break;


                case "Employer-OtherLeaveFlow":
                    for (i=0;i < Questions_Count;i++){
                        expect(Questions_Label.get(i).getText()).toEqual(OtherLeaveFlow_Questions[i]);
                        expect(Questions_Label.get(i).isDisplayed()).toBe(true);

                    }

                    break;

                case "Employee-English-OtherLeaveFlow":
                    for (i=0;i < Questions_Count;i++){
                        expect(Questions_Label.get(i).getText()).toEqual(OtherLeaveFlow_Questions_English[i]);
                        expect(Questions_Label.get(i).isDisplayed()).toBe(true);

                    }

                    break;

                case "Employee-Spanish-OtherLeaveFlow":
                    for (i=0;i < Questions_Count;i++){
                        expect(Questions_Label.get(i).getText()).toEqual(OtherLeaveFlow_Questions_Spanish[i]);
                        expect(Questions_Label.get(i).isDisplayed()).toBe(true);

                    }

                    break;

                case "Employer-CareFlow":
                    for (i=0;i < Questions_Count;i++){
                        expect(Questions_Label.get(i).getText()).toEqual(CareFlow_Questions[i]);
                        expect(Questions_Label.get(i).isDisplayed()).toBe(true);

                    }
                    break;

                case "Employee-CareFlow":

                    expect(Questions_Label.get(0).getText()).toEqual('Will you be out for at least 3 consecutive days?');
                    expect(Questions_Label.get(1).getText()).toEqual('What best describes the circumstances for your absence?');
                    expect(Questions_Label.get(2).getText()).toEqual('What is the reason for your absence?');
                    expect(Questions_Label.get(3).getText()).toEqual('What is the person’s relationship to you?');
                    expect(Questions_Label.get(4).getText()).toEqual('What is the first day, or expected first day, of your leave of absence?');
                    expect(Questions_Label.get(5).getText()).toEqual('What is the date of birth of the person you are caring for?');
                    expect(Questions_Label.get(6).getText()).toEqual('What is the last day, or estimated last day, of your leave of absence?');
                    break;

                case "Employee-Spanish-CareFlow":

                    expect(Questions_Label.get(0).getText()).toEqual('¿Estará ausente del trabajo por más de 3 días consecutivos de calendario?');
                    expect(Questions_Label.get(1).getText()).toEqual('¿Lo que describe mejor las circunstancias para su ausencia?');
                    expect(Questions_Label.get(2).getText()).toEqual('¿Qué es la razón para su hoja?');
                    expect(Questions_Label.get(3).getText()).toEqual('¿Qué relación tiene esta persona con usted?');
                    expect(Questions_Label.get(4).getText()).toEqual('¿Cuál es el primer día del primer día esperado de su ausencia?');
                    expect(Questions_Label.get(5).getText()).toEqual('¿Cuál es la fecha de nacimiento de la persona que está cuidando?');
                    expect(Questions_Label.get(6).getText()).toEqual('¿Cuál es el último día, o estimado último día, de su licencia?');
                    break;

                case "Employer-BondFlow":

                    expect(Questions_Label.get(0).getText()).toEqual('Will the Associate be out for a continuous period of time?');
                    expect(Questions_Label.get(1).getText()).toEqual('What best describes the circumstances for the absence?');
                    expect(Questions_Label.get(2).getText()).toEqual("What is the reason for the Associate's absence?");
                    expect(Questions_Label.get(3).getText()).toEqual("What is the person's relationship to the Associate?");
                    expect(Questions_Label.get(4).getText()).toEqual('What is the first day, or expected first day, of the leave of absence?');
                    expect(Questions_Label.get(5).getText()).toEqual('What is the date of birth of the person the Associate is bonding with?');
                    expect(Questions_Label.get(6).getText()).toEqual("What is the last day, or estimated last day, of the Associate's leave of absence?");
                    break;
                case "Employer-BondFlow-Fostercare-Adoption":

                    expect(Questions_Label.get(0).getText()).toEqual('Will the Associate be out for a continuous period of time?');
                    expect(Questions_Label.get(1).getText()).toEqual('What best describes the circumstances for the absence?');
                    expect(Questions_Label.get(2).getText()).toEqual("What is the reason for the Associate's absence?");
                    expect(Questions_Label.get(3).getText()).not.toEqual("What is the person's relationship to the Associate?");
                    expect(Questions_Label.get(3).getText()).toEqual('What is the first day, or expected first day, of the leave of absence?');
                    expect(Questions_Label.get(4).getText()).toEqual("What is the date the child was placed in the Associate's care?");
                    expect(Questions_Label.get(5).getText()).toEqual("What is the date of birth of the person the Associate is bonding with?");
                    expect(Questions_Label.get(6).getText()).toEqual("What is the last day, or estimated last day, of the Associate's leave of absence?");
                    break;


                case "Employee-BondFlow":

                    expect(Questions_Label.get(0).getText()).toEqual('Will you be out for at least 3 consecutive days?');
                    expect(Questions_Label.get(1).getText()).toEqual('What best describes the circumstances for your absence?');
                    expect(Questions_Label.get(2).getText()).toEqual("What is the reason for your absence?");
                    expect(Questions_Label.get(3).getText()).toEqual("What is the person’s relationship to you?");
                    expect(Questions_Label.get(4).getText()).toEqual('What is the first day, or expected first day, of your leave of absence?');
                    expect(Questions_Label.get(5).getText()).toEqual('What is the date of birth of the person you are bonding with?');
                    expect(Questions_Label.get(6).getText()).toEqual("What is the last day, or estimated last day, of your leave of absence?");
                    break;
                case "Employee-BondFlow-Fostercare-Adoption":

                    expect(Questions_Label.get(0).getText()).toEqual('Will you be out for at least 3 consecutive days?');
                    expect(Questions_Label.get(1).getText()).toEqual('What best describes the circumstances for your absence?');
                    expect(Questions_Label.get(2).getText()).toEqual("What is the reason for your absence?");
                    expect(Questions_Label.get(3).getText()).not.toEqual("What is the person’s relationship to you?");
                    expect(Questions_Label.get(3).getText()).toEqual('What is the first day, or expected first day, of your leave of absence?');
                    expect(Questions_Label.get(4).getText()).toEqual("What is the date the child was placed in your care?");
                    expect(Questions_Label.get(5).getText()).toEqual("What is the date of birth of the person you are bonding with?");
                    expect(Questions_Label.get(6).getText()).toEqual("What is the last day, or estimated last day, of your leave of absence?");
                    break;

                case "Employee-Spanish-BondFlow":

                    expect(Questions_Label.get(0).getText()).toEqual('¿Estará ausente del trabajo por más de 3 días consecutivos de calendario?');
                    expect(Questions_Label.get(1).getText()).toEqual('¿Lo que describe mejor las circunstancias para su ausencia?');
                    expect(Questions_Label.get(2).getText()).toEqual("¿Qué es la razón para su hoja?");
                    expect(Questions_Label.get(3).getText()).toEqual("¿Qué relación tiene esta persona con usted?");
                    expect(Questions_Label.get(4).getText()).toEqual('¿Cuál es el primer día del primer día esperado de su ausencia?');
                    expect(Questions_Label.get(5).getText()).toEqual('¿Cuál es la fecha de nacimiento de la persona con la que estás vinculado?');
                    expect(Questions_Label.get(6).getText()).toEqual("¿Cuál es el último día, o estimado último día, de su licencia?");
                    break;
                case "Employee-Spanish-BondFlow-Fostercare-Adoption":

                    expect(Questions_Label.get(0).getText()).toEqual('¿Estará ausente del trabajo por más de 3 días consecutivos de calendario?');
                    expect(Questions_Label.get(1).getText()).toEqual('¿Lo que describe mejor las circunstancias para su ausencia?');
                    expect(Questions_Label.get(2).getText()).toEqual("¿Qué es la razón para su hoja?");
                    expect(Questions_Label.get(3).getText()).not.toEqual("¿Qué relación tiene esta persona con usted?");
                    expect(Questions_Label.get(3).getText()).toEqual('¿Cuál es el primer día del primer día esperado de su ausencia?');
                    expect(Questions_Label.get(4).getText()).toEqual("¿Cuál es la fecha en que el niño fue puesto bajo su cuidado?");
                    expect(Questions_Label.get(5).getText()).toEqual("¿Cuál es la fecha de nacimiento de la persona con la que estás vinculado?");
                    expect(Questions_Label.get(6).getText()).toEqual("¿Cuál es el último día, o estimado último día, de su licencia?");
                    break;

                case "Employer-MOC-Illness":

                    expect(Questions_Label.get(0).getText()).toEqual('Will the Associate be out for a continuous period of time?');
                    expect(Questions_Label.get(1).getText()).toEqual('What best describes the circumstances for the absence?');
                    expect(Questions_Label.get(2).getText()).toEqual("Please select the condition that best describes the circumstances?");
                    expect(Questions_Label.get(3).getText()).toEqual("When did this illness begin?");
                    expect(Questions_Label.get(4).getText()).toEqual('What was the last day worked or expected last day worked?');
                    expect(Questions_Label.get(5).getText()).toEqual('Was this the result of an accident?');
                    expect(Questions_Label.get(6).getText()).toEqual("Was the Associate in a motor vehicle accident?");
                    expect(Questions_Label.get(7).getText()).toEqual("Did this occur while on the job?");
                    expect(Questions_Label.get(8).getText()).toEqual("Did/Will the Associate be going to the hospital?");
                    expect(Questions_Label.get(9).getText()).toEqual("What date did/will the Associate go to the hospital?");
                    expect(Questions_Label.get(10).getText()).toEqual("Did/Will the Associate have surgery?");
                    expect(Questions_Label.get(11).getText()).toEqual("What was, or is, the date of the Associate's surgery?");
                    expect(element(by.id('surgeryDescription')).getText()).toEqual("Please provide the Associate's diagnosis or a description of the condition or symptoms.");

                    break;
                case "Employer-MOC-Injury":

                    expect(Questions_Label.get(0).getText()).toEqual('Will the Associate be out for a continuous period of time?');
                    expect(Questions_Label.get(1).getText()).toEqual('What best describes the circumstances for the absence?');
                    expect(Questions_Label.get(2).getText()).toEqual("Please select the condition that best describes the circumstances?");
                    expect(Questions_Label.get(3).getText()).toEqual("What was the date of the injury?");
                    expect(Questions_Label.get(4).getText()).toEqual('What was the last day worked or expected last day worked?');
                    expect(Questions_Label.get(5).getText()).toEqual('Was this the result of an accident?');
                    expect(Questions_Label.get(6).getText()).toEqual("Was the Associate in a motor vehicle accident?");
                    expect(Questions_Label.get(7).getText()).toEqual("Did this occur while on the job?");
                    expect(Questions_Label.get(8).getText()).toEqual("Did/Will the Associate be going to the hospital?");
                    expect(Questions_Label.get(9).getText()).toEqual("What date did/will the Associate go to the hospital?");
                    expect(Questions_Label.get(10).getText()).toEqual("Did/Will the Associate have surgery?");
                    expect(Questions_Label.get(11).getText()).toEqual("What was, or is, the date of the Associate's surgery?");
                    expect(element(by.id('surgeryDescription')).getText()).toEqual("Please provide the Associate's diagnosis or a description of the condition or symptoms.");

                    break;
                case "Employee-MOC-Illness":

                    expect(Questions_Label.get(0).getText()).toEqual('Will you be out for at least 3 consecutive days?');
                    expect(Questions_Label.get(1).getText()).toEqual('What best describes the circumstances for your absence?');
                    expect(Questions_Label.get(2).getText()).toEqual("Please select the condition that best describes your circumstances?");
                    expect(Questions_Label.get(3).getText()).toEqual("When did this illness begin?");
                    expect(Questions_Label.get(4).getText()).toEqual('What was the last day worked or expected last day worked?');
                    expect(Questions_Label.get(5).getText()).toEqual('Was this the result of an accident?');
                    expect(Questions_Label.get(6).getText()).toEqual("Were you in a motor vehicle accident?");
                    expect(Questions_Label.get(7).getText()).toEqual("Did this occur while on the job?");
                    expect(Questions_Label.get(8).getText()).toEqual("Did you, or will you be, going to the hospital?");
                    expect(Questions_Label.get(9).getText()).toEqual("What date did you, or will you, go to the hospital?");
                    expect(Questions_Label.get(10).getText()).toEqual("Did you, or will you, have surgery?");
                    expect(Questions_Label.get(11).getText()).toEqual("What was, or is, the date of your surgery?");
                    expect(element(by.id('surgeryDescription')).getText()).toEqual("Please provide your diagnosis or a description of your condition or symptoms.");

                    break;
                case "Employee-MOC-Injury":

                    expect(Questions_Label.get(0).getText()).toEqual('Will you be out for at least 3 consecutive days?');
                    expect(Questions_Label.get(1).getText()).toEqual('What best describes the circumstances for your absence?');
                    expect(Questions_Label.get(2).getText()).toEqual("Please select the condition that best describes your circumstances?");
                    expect(Questions_Label.get(3).getText()).toEqual("What was the date of your injury?");
                    expect(Questions_Label.get(4).getText()).toEqual('What was the last day worked or expected last day worked?');
                    expect(Questions_Label.get(5).getText()).toEqual('Was this the result of an accident?');
                    expect(Questions_Label.get(6).getText()).toEqual("Were you in a motor vehicle accident?");
                    expect(Questions_Label.get(7).getText()).toEqual("Did this occur while on the job?");
                    expect(Questions_Label.get(8).getText()).toEqual("Did you, or will you be, going to the hospital?");
                    expect(Questions_Label.get(9).getText()).toEqual("What date did you, or will you, go to the hospital?");
                    expect(Questions_Label.get(10).getText()).toEqual("Did you, or will you, have surgery?");
                    expect(Questions_Label.get(11).getText()).toEqual("What was, or is, the date of your surgery?");
                    expect(element(by.id('surgeryDescription')).getText()).toEqual("Please provide your diagnosis or a description of your condition or symptoms.");


                    break;
                case "Employee-Spanish-MOC-Illness":

                    expect(Questions_Label.get(0).getText()).toEqual('¿Estará ausente del trabajo por más de 3 días consecutivos de calendario?');
                    expect(Questions_Label.get(1).getText()).toEqual('¿Lo que describe mejor las circunstancias para su ausencia?');
                    expect(Questions_Label.get(2).getText()).toEqual("¿Cuál es la razón para su ausencia?");
                    expect(Questions_Label.get(3).getText()).toEqual("¿Cuándo comenzó esta enfermedad?");
                    expect(Questions_Label.get(4).getText()).toEqual('¿Cuál fue el último día trabajado o esperado el último día de trabajo?');
                    expect(Questions_Label.get(5).getText()).toEqual('¿Fue resultado de un accidente?');
                    expect(Questions_Label.get(6).getText()).toEqual("¿Estuvo involucrado en un accidente con vehículos de motor?");
                    expect(Questions_Label.get(7).getText()).toEqual("¿Ocurrió esto en el trabajo?");
                    expect(Questions_Label.get(8).getText()).toEqual("¿Usted, o usted será, que va al hospital?");
                    expect(Questions_Label.get(9).getText()).toEqual("¿A qué fecha fue usted, o usted, al hospital?");
                    expect(Questions_Label.get(10).getText()).toEqual("¿Cuál fue o será la fecha de su cirugía?");
                    expect(Questions_Label.get(11).getText()).toEqual("¿Cuál fue o será la fecha de su cirugía?");
                    expect(element(by.id('surgeryDescription')).getText()).toEqual("Proporcione su diagnóstico o una descripción de su condición o síntomas.");

                    break;
                case "Employee-Spanish-MOC-Injury":

                    expect(Questions_Label.get(0).getText()).toEqual('¿Estará ausente del trabajo por más de 3 días consecutivos de calendario?');
                    expect(Questions_Label.get(1).getText()).toEqual('¿Lo que describe mejor las circunstancias para su ausencia?');
                    expect(Questions_Label.get(2).getText()).toEqual("¿Cuál es la razón para su ausencia?");
                    expect(Questions_Label.get(3).getText()).toEqual("¿Cuál fue la fecha de su lesión?");
                    expect(Questions_Label.get(4).getText()).toEqual('¿Cuál fue el último día trabajado o esperado el último día de trabajo?');
                    expect(Questions_Label.get(5).getText()).toEqual('¿Fue resultado de un accidente?');
                    expect(Questions_Label.get(6).getText()).toEqual("¿Estuvo involucrado en un accidente con vehículos de motor?");
                    expect(Questions_Label.get(7).getText()).toEqual("¿Ocurrió esto en el trabajo?");
                    expect(Questions_Label.get(8).getText()).toEqual("¿Usted, o usted será, que va al hospital?");
                    expect(Questions_Label.get(9).getText()).toEqual("¿A qué fecha fue usted, o usted, al hospital?");
                    expect(Questions_Label.get(10).getText()).toEqual("¿Cuál fue o será la fecha de su cirugía?");
                    expect(Questions_Label.get(11).getText()).toEqual("¿Cuál fue o será la fecha de su cirugía?");
                    expect(element(by.id('surgeryDescription')).getText()).toEqual("Proporcione su diagnóstico o una descripción de su condición o síntomas.");;

                    break;

            }

        });
        browser.sleep(3000);

    };

    this.DeliveryComplicationOptions = function(value1){
        var DeliveryComplication = element(by.className('fieldset__input-group'));
        expect(DeliveryComplication.getText()).toContain(['Yes No Unknown']);
    };

    this.DeliveryComplicationOptions_Employee_English = function(value1){
        var DeliveryComplication = element(by.className('fieldset__input-group'));
        expect(DeliveryComplication.getText()).toContain(['Yes No']);
    };
    this.DeliveryComplicationOptions_Employee_Spanish = function(value1){
        var DeliveryComplication = element(by.className('fieldset__input-group'));
        expect(DeliveryComplication.getText()).toContain(['Sí No']);
    };

    this.SurgeryOptions = function(){
        var SurgeryOption = element.all(by.className('fieldset__input-group')).get(4);
        expect(SurgeryOption.getText()).toContain(['Yes No Unknown, at this time']);
    };

    this.SurgeryOptions_Spanish = function(){
        var SurgeryOption = element.all(by.className('fieldset__input-group')).get(4);
        expect(SurgeryOption.getText()).toContain(['Sí No Desconocido, en este momento']);
    };

    this.VerifyMaternityNotAvailableforLeaveFlow = function(){

        expect(Leave_ClaimType.get(0).getText()).not.toEqual('Maternity'||'Maternid')
    };

    this.lblmotorquestion = function(value1){

        if (value1 =="Yes")
        expect(lblmotoraccident.get(0).getText()).toEqual('¿Estuvo involucrado en un accidente con vehículos de motor?');
        else
        expect(lblmotoraccident.isPresent()).toEqual(false);
    };

    this.LastQuestion_Validation = function(value1){

        switch (value1) {

            case ("Employer-Maternity-Vaginal" || "Employer-MOC"):
                expect(element(by.id('surgeryComplication')).getText()).toEqual("Please provide details around the Associate's related complications, surgeries, injuries, or any additional details related to the absence.");
                break;

            case "Employee-Maternity-Vaginal" || "Employee-MOC":
                expect(element(by.id('surgeryComplication')).getText()).toEqual("Please provide details around your related complications, surgeries, injuries, or any additional details related to your absence.");
                break;
            case ("Employee-Spanish-Maternity-Vaginal" || "Employee-Spanish-MOC"):
                expect(element(by.id('surgeryComplication')).getText()).toEqual("Proporcione detalles sobre sus complicaciones relacionadas, cirugías, lesiones o cualquier detalle adicional relacionado con su ausencia.");
                break;
        }

    };


    this.ClickContinue_ViewAdditionalInformation = function() {


        browser.executeScript("arguments[0].scrollIntoView()",primarybutton.get(0).getWebElement());
        primarybutton.get(0).click();


        var AdditionalInfo = element(by.className('col-xs-10'));


        var AdditionalInfo = element(by.className('heading--beta--top'));
        var AdditionalInfo = (element.all(by.tagName('h2')).get(0));

        var AdditionalInfo = element(by.className('heading--beta--top'));

        var AdditionalInfo = (element.all(by.tagName('h2')).get(0));

        expect(AdditionalInfo.getText()).toEqual('Additional Information');
        expect(AdditionalInfo.getText()).not.toEqual('Medical Contacts');

    };

    this.ClickContinue = function() {


        browser.executeScript("arguments[0].scrollIntoView()",primarybutton.get(0).getWebElement());
        primarybutton.get(0).click();


    };

    this.ClickGoBack = function(){

        var Goback = element(by.className('lds-button lds-button--secondary lds-button--save'));
        browser.executeScript("arguments[0].scrollIntoView()",Goback.getWebElement());
        Goback.click();
    };

    this.ClickContinue_ViewMedicalContacts = function(value1) {

        browser.executeScript("arguments[0].scrollIntoView()",primarybutton.get(0).getWebElement());
        primarybutton.get(0).click();

        var AdditionalInfo = element(by.className('heading--beta--top'));
        if (value1 =="Employee-Spanish")
        if (value1 =="Employee-Spanish")
        {
            expect(AdditionalInfo.getText()).toEqual('Contactos medicos');
        } else {
            expect(AdditionalInfo.getText()).toEqual('Medical Contacts');
        }

    };

    this.Select_List_1_Value = function(value1){
        dropdown_1.$('[value = "' + value1 +'"]').click();
        browser.sleep(2000);


    };

    this.Select_List_2_Value = function(value1){
        dropdown_2.$('[value = "' + value1 +'"]').click();
        browser.sleep(2000);


    };

    this.Dropdown_1_Options = function(value1) {

        var i, Options_Count;
        dropdown_1_options.count().then(function (lbl_Count) {
            Options_Count = lbl_Count;
            switch (value1){
                case "CareFlow":
                    for (i=0;i < Options_Count;i++){
                        expect(dropdown_1_options.get(i).getText()).toEqual(reasonabsence[i]); }

                    break;
                case "MOC-Female":
                    for (i=0;i < Options_Count;i++){
                        expect(dropdown_1_options.get(i).getText()).toEqual(reasonorder[i]);}

                    break;

                case "MOC-Spanish":
                    for (i=0;i < Options_Count;i++){
                        expect(dropdown_1_options.get(i).getText()).toEqual(reasonorder_Spanish[i]);}

                    break;
            }

        });


    };

    this.Verify_ErrorMessage = function(value1) {

        var errorMessage = element(by.className('fieldset__feedback fieldset__feedback--invalid--dropdown'));
        if (value1 =='Spanish'){
            expect(errorMessage.getText()).toEqual('Obligatorio');

        }
        else {
            expect(errorMessage.getText()).toEqual('Required');
        }

    };

    this.Verify_RequiredErrorMessage = function(value1) {

        var errorMessage = element.all(by.className('fieldset__feedback fieldset__feedback--invalid--withnomargin'));
        if (value1 =='Spanish'){
            expect(errorMessage.get(5).getText()).toEqual('Obligatorio');
            expect(errorMessage.get(6).getText()).toEqual('Obligatorio');
            expect(errorMessage.get(7).getText()).toEqual('Obligatorio');
            expect(errorMessage.get(9).getText()).toEqual('Obligatorio');

        }
        else {
            expect(errorMessage.get(5).getText()).toEqual('');
            expect(errorMessage.get(6).getText()).toEqual('');
            expect(errorMessage.get(7).getText()).toEqual('');
            expect(errorMessage.get(9).getText()).toEqual('');
        }
        element(by.buttonText('Close')).click();

    };

    this.Verify_OtherRelationshipLabel = function(value1) {
        if (value1 == 'Spanish')
        {
            expect(Questions_Label.get(4).getText()).toEqual('Otras Relaciones');

        }else
        {
            expect(Questions_Label.get(4).getText()).toEqual('Other Relationship');}

    };


    this.VerifyInlocoParentisoption = function(value1){

        if (value1 == 'Spanish')
        {
            expect(dropdown_2.getText()).toContain('En loco Parentis (En lugar del padre)')
        }
        else {
            expect(dropdown_2.getText()).toContain('In loco Parentis (In place of parent)')
        }
    };


    this.SelectAccidentResult = function(value1){
        if (value1=='Yes')
        {
            browser.executeScript("arguments[0].scrollIntoView()",radioaccidentresult.get(0).getWebElement());
            radioaccidentresult.get(0).click();
        }
        else
        {
            radioaccidentresult.get(1).click();
        }
    }

    this.SelectMotorAccident = function(value1){
        if (value1=='Yes')
        {
            browser.executeScript("arguments[0].scrollIntoView()",radiomotoraccident.get(0).getWebElement());
            radiomotoraccident.get(0).click();
        }
        else
        {
            radiomotoraccident.get(1).click();
        }
    }


    this.SelectOnJob = function(value1){
        if (value1=='Yes')
        {
            browser.executeScript("arguments[0].scrollIntoView()",radioonjob.get(0).getWebElement());
            radioonjob.get(0).click();
        }
        else
        {
            radioonjob.get(1).click();
        }
    }

    this.SelectGoingHospital = function(value1){
        if (value1=='Yes')
        {
            browser.executeScript("arguments[0].scrollIntoView()",radiohospital.get(0).getWebElement());
            radiohospital.get(0).click();
        }
        else
        {
            radiohospital.get(1).click();
        }
    }

    this.SelectSurgery = function(value1){
        if (value1=='Yes')
        {
            browser.executeScript("arguments[0].scrollIntoView()",radiosurgery.get(0).getWebElement());
            radiosurgery.get(0).click();
        }
        else
        {
            radiosurgery.get(1).click();
        }
    }





};



module.exports = new AboutAbsence();
