/**
 * Created by n0275896 on 8/17/2017.
 */
var POAYA = require('./PageObject_AboutYourAbsence.js');
var POAYP = require('./PageObject_AboutYouPage.js');
var POAIP = require('./PageObject_Additional_InformationPage.js');
var PORPER = require('./PageObject_ER_ReviewPage.js');
var TestDataAYE = require('./../TestData/AboutYourEmployee.js');


var POCommonFunctions = function(){

    var empid = POAYP.empidtbox.input;
    var firstname = POAYP.fnametbox.input;
    var lastname = POAYP.lnametbox.input;
    var dob = POAYP.dobtbox.input;
    var preferedphone = POAYP.ppphonetbox.input;
    var prefmail = POAYP.ppemailtbox.input;
    var resaddr1 = POAYP.resaddrtbox1.input;
    var rescity = POAYP.rescitytbox.input;
    var statelist = POAYP.resstatelist.input;
    var postalcode = POAYP.postalcdetbox.input;
    var stateemploy = POAYP.stateofemploylist.input;
    var engsplink = POAYP.Englishspanishlink.input;
    var leaveclaimlist = POAYA.leavetypelist.input;
    var circumstance = POAYA.circumstance.input;
    var leavebegindate = POAYA.leavebegindate.input;
    var leaveenddate = POAYA.leaveenddate.input;
    var lastworkingdate = POAYA.lastdate.input;

    var illness = POAYA.illness.input;
    var lastworkingdate = POAYA.lastdate.input;
    var medicalcontactpage = POAYA.medicalcontactspage.input;
    var medicalheader = POAYA.medicalheader.input;
    var circumstanceoption = POAYA.circumstanceoption.input;
    var dob1 = POAYP.dobtbox1.input;
    var pphone1 = POAYP.ppphonetbox1.input;
    var ssntext = POAYP.ssntbox.input;
    var middlename = POAYP.mnametbox.input;
    var resaddr2 = POAYP.resaddrtbox2.input;
    var lblcirumcondition = POAYA.lblcircumcondition.input;
    var lblillness = POAYA.lblillness.input;
    var lbllastday = POAYA.lbllastday1.input;
    var lblresaccident = POAYA.lblaccidentresult.input;
    var lblmotor = POAYA.lblmotorvehaccident.input;
    var rbtnaccident = POAYA.rbtnaccidentyes.input;
    var rbtnmotoraccident = POAYA.rbtnmotoraccidentyes.input;
    var lblonjob = POAYA.lbloccurjob.input;
    var rbtnjobyes = POAYA.rbtnjobyes.input;
    var lblhosp = POAYA.lblgnghosp.input;
    var rbtnhosp = POAYA.rbtnhospyes.input;
    var lblsurgery = POAYA.lblsurgery.input;
    var rbtnsurgery = POAYA.rbtnsurgery.input;
    var lbldatehosp = POAYA.lbldatehosp.input;
    var lbldatesurgery = POAYA.lbldatesurgery.input;
    var lbldiag = POAYA.lbldiagnosis.input;
    var txtadmission = POAYA.admission.input;
    var txtsurgerydesc = POAYA.txtsurgerydesc.input;
    var txtsurgery = POAYA.txtsurgerydate.input;
    var absencequestions =  POAYA.aboutabsencequestions.input;
    var surdecreqmsg = POAYA.surdecreqmsg.input;
    var surdesques = POAYA.surdesques.input;
    var txtssn1 = POAYP.txtssn.input;

    var lblsurgeryno = POAYA.lblsurgeryno.input;
    var lblsurgryunknown = POAYA.lblsurgeryunknown.input;
    var lblsurgeryyes = POAYA.lblsurgeryyes.input;
    var rbtnsurgeryno = POAYA.rbtnsurgeryno.input;
    var rbtnsurgeryunknown = POAYA.rbtnsurgeryunknown.input;
    var username = POAYP.username.input;
    var password = POAYP.password.input;
    var txtillness = POAYA.txtillness.input;
    var txtlastday = POAYA.txtlastday.input;
    var dateillness = POAYA.dateillness.input;
    var datelastday = POAYA.datelastday.input;
    var txthiredate = POAIP.txthiredate.input;
    var txtbegandate = POAIP.txtbegandate.input;
    var txtapplieddate = POAIP.txtapplieddate.input;
    var txtceaseddate = POAIP.txtceasedate.input;
    var rbthospitalizationno = POAYA.rbthospitalizationno.input;


    var employerurl = 'https://www-test.mylibertyconnection.com/public/index.html';
    var employeeurl = 'https://tst-benefits.mylibertyconnection.com/cli/employee';

    this.employeeurl = function cliemployeeurl() {

        //Fill all the details in About You page and click continue for About Your Absence page

        browser.get(employeeurl);
    };

    this.employerurl = function cliemployerurl() {

        //Fill all the details in About You page and click continue for About Your Absence page

        browser.get(employerurl);
    };

    this.employeelogin = function employeelogin() {
        browser.sleep(40000);
        username.sendKeys('cather1');
        password.sendKeys('Test1234');
        element(by.buttonText('Login')).click();
        browser.sleep(40000);

    };

    this.employeeloginee = function employeeloginee() {
        browser.sleep(90000);
        username.sendKeys('cather1');
        password.sendKeys('Test1234');
        element(by.buttonText('Login')).click();
        browser.sleep(90000);

    };



    this.callCLI = function CLI() {

        element(by.buttonText('New ER CLI')).click();
        browser.sleep(90000);

    };

    this.callCLIEE = function CLI() {

        //element(by.buttonText('NEW EE CLI')).click();
        input: element(by.xpath('/html/body/div/div[3]/div/div/div/div/div[1]/div/a[2]')).click();
        browser.sleep(20000);    };

    this.eehome = function CLI() {



        input: element(by.xpath('//*[@id="bs-example-navbar-collapse-1"]/ul/li[5]/a')).click();
        browser.sleep(20000);    };


    //this.callCLIemployee = function CLIemployee() {

    //this.callCLIemployee = function CLIemployee() {

    this.callCLIemployee = function CLIemployee() {


       // element(by.buttonText('NEW EE CLI')).click();
       element.all(by.className('btn btnhome')).get(1).click();
       browser.sleep(20000);     };


    this.enteraboutyouremployeepagemale = function fillaboutyouremppage_male(){

        browser.get(employerurl);
        browser.sleep(90000);
        element(by.buttonText('Start')).click();

        //Select About You Page
        // element(by.css('[href="/employer/cli/claimant"]')).click();

        POAYP.empidradio.input.click();

        //Enter valid value for Employee ID
        empid.sendKeys(TestDataAYE.EmpID);
        firstname.sendKeys(TestDataAYE.FirstName);
        lastname.sendKeys(TestDataAYE.LastName);
        dob.click();
        dob1.sendKeys(TestDataAYE.DOB);
        POAYP.rbtnmale.input.click();

        //Enter Valid value for  Residential Address1
        resaddr1.sendKeys(TestDataAYE.Addr1);

        //Enter Valid value for  Residential City
        rescity.sendKeys(TestDataAYE.City);

        //Select any Residential State
        statelist.$('[value = "AK"]').click();

        //Enter Valid value for  Postal Code
        postalcode.sendKeys(TestDataAYE.postalCode);


        //Enter Valid value for  Preferred phone number
        // preferedphone.click();
        pphone1.sendKeys(TestDataAYE.PrefPersonalPhone);

        //Enter Valid value for  Preferred email
        prefmail.sendKeys(TestDataAYE.PrefPersemail);

        //Select any value for State of Employment
        stateemploy.$('[value = "AK"]').click();


        //Click Continue button
        POAYP.continuebutton.input.click();
        //element(by.css('[href="/employer/cli/absence"]')).click();



    };

    this.enteraboutyouremppagefemale = function fillaboutyouremppage_female(){




        browser.sleep(20000);
        element(by.buttonText('Start')).click();

        //Select About You Page
       // element(by.css('[href="/employer/cli/claimant"]')).click();

        POAYP.empidradio.input.click();

        //Enter valid value for Employee ID
        empid.sendKeys(TestDataAYE.EmpID);
        firstname.sendKeys(TestDataAYE.FirstName);
        lastname.sendKeys(TestDataAYE.LastName);
        dob.click();
        dob1.sendKeys(TestDataAYE.DOB);
        POAYP.rbtnfemale.input.click();

        //Enter Valid value for  Residential Address1
        resaddr1.sendKeys(TestDataAYE.Addr1);

        //Enter Valid value for  Residential City
        rescity.sendKeys(TestDataAYE.City);

        //Select any Residential State
        statelist.$('[value = "AK"]').click();

        //Enter Valid value for  Postal Code
        postalcode.sendKeys(TestDataAYE.postalCode);

        browser.executeScript('window.scrollTo(600,1600);');
        //Enter Valid value for  Preferred phone number
       // preferedphone.click();
        pphone1.sendKeys(TestDataAYE.PrefPersonalPhone);

        //Enter Valid value for  Preferred email
        prefmail.sendKeys(TestDataAYE.PrefPersemail);

        //Select any value for State of Employment
        stateemploy.$('[value = "AK"]').click();


        //Click Continue button
        POAYP.continuebutton.input.click();
        //element(by.css('[href="/employer/cli/absence"]')).click();

        //Verify About your Absence is displayed
       // var aboutyourabsencehdr = POAYA.absenceheader.input.getText();
       // expect(aboutyourabsencehdr).toEqual('Details of Employee absence');

    };


    this.enteraboutyouremppagefemalespanish = function fillaboutyouremppage_female(){




        browser.sleep(20000);
        element(by.buttonText('Comienzo')).click();

        //Select About You Page
        // element(by.css('[href="/employer/cli/claimant"]')).click();

        POAYP.empidradio.input.click();

        //Enter valid value for Employee ID
        empid.sendKeys(TestDataAYE.EmpID);
        firstname.sendKeys(TestDataAYE.FirstName);
        lastname.sendKeys(TestDataAYE.LastName);
        dob.click();
        dob1.sendKeys(TestDataAYE.DOB);
        POAYP.rbtnfemale.input.click();

        //Enter Valid value for  Residential Address1
        resaddr1.sendKeys(TestDataAYE.Addr1);

        //Enter Valid value for  Residential City
        rescity.sendKeys(TestDataAYE.City);

        //Select any Residential State
        statelist.$('[value = "AK"]').click();

        //Enter Valid value for  Postal Code
        postalcode.sendKeys(TestDataAYE.postalCode);


        //Enter Valid value for  Preferred phone number
        // preferedphone.click();
        pphone1.sendKeys(TestDataAYE.PrefPersonalPhone);

        //Enter Valid value for  Preferred email
        prefmail.sendKeys(TestDataAYE.PrefPersemail);

        //Select any value for State of Employment
        stateemploy.$('[value = "AK"]').click();


        //Click Continue button
        POAYP.continuebuttonspanish.input.click();
        //element(by.css('[href="/employer/cli/absence"]')).click();

        //Verify About your Absence is displayed
        // var aboutyourabsencehdr = POAYA.absenceheader.input.getText();
        // expect(aboutyourabsencehdr).toEqual('Details of Employee absence');

    };

    this.enteraboutyoupagespanishfemale = function fillaboutyoupage_female_Spanish(){

        //Fill all the details in About You page and click continue for About Your Absence page

        //Open NEW CLI in browser and go to About You Page
        browser.get(employeeurl);

        //Select About You Page
        element(by.css('[href="/cli/claimant"]')).click();
        POAYP.empidradio.input.click();

        //Enter valid value for Employee ID
        empid.sendKeys('12345');
        firstname.sendKeys('TestFirstname');
        lastname.sendKeys('TestLastName');
        dob.click();
        dob1.sendKeys('11/12/1975');
        POAYP.rbtnfemale.input.click();

        //Enter Valid value for  Residential Address1
        resaddr1.sendKeys('Testaddress1');

        //Enter Valid value for  Residential City
        rescity.sendKeys('Testcity');

        //Select any Residential State
        statelist.$('[value = "AK"]').click();

        //Enter Valid value for  Postal Code
        postalcode.sendKeys('78901');


        //Enter Valid value for  Preferred phone number
       // preferedphone.click();
        pphone1.sendKeys('9089089098')

        //Enter Valid value for  Preferred email
        prefmail.sendKeys('test@tst.com');

        //Select any value for State of Employment
        stateemploy.$('[value = "AK"]').click();


        //Click Continue button
        POAYP.continuebuttonspanish.input.click();
        //element(by.css('[href="/cli/absence"]')).click();

        //Verify About your Absence is displayed
        var aboutyourabsencehdr = POAYA.absenceheader.input.getText();
        expect(aboutyourabsencehdr).toEqual('Acerca de su ausencia');

    };
    this.enteraboutyoupagespanishmale = function fillaboutyoupage_male_Spanish(){

        browser.get(employeeurl);

        //Select About You Page
        element(by.css('[href="/cli/claimant"]')).click();

        //Enter valid value for Employee ID
        empid.sendKeys('12345');

        //Enter valid value for FirstName
        firstname.sendKeys('TestFirstname');

        //Enter valid value for Last Name
        lastname.sendKeys('TestLastName');

        dob.click();
        dob1.sendKeys('11/12/1975');

        //Select Gender
        POAYP.rbtnmale.input.click();

        //Enter Valid value for  Preferred email
        prefmail.sendKeys('test@tst.com');
        pphone1.sendKeys('9089089098')

        //Enter Valid value for  Residential Address1
        resaddr1.sendKeys('Testaddress1');

        //Enter Valid value for  Residential City
        rescity.sendKeys('Testcity');

        //Select any Residential State
        statelist.$('[value = "AK"]').click();

        //Enter Valid value for  Postal Code
        postalcode.sendKeys('78901');

        //Select any value for State of Employment
        stateemploy.$('[value = "AK"]').click();



        //Click Continue button
        POAYP.continuebuttonspanish.input.click();

    };
    this.enteraboutyoupagemale = function fillaboutyoupage_male(){

        //Fill all the details in About You page and click continue for About Your Absence page

        //Open NEW CLI in browser and go to About You Page
        browser.get(employeeurl);
        browser.sleep(90000);

        //Click About You Page
        element(by.buttonText('Start')).click();


        //POAYP.empidradio.input.click();



        empid.sendKeys(TestDataAYE.EmpID);
        firstname.sendKeys(TestDataAYE.FirstName);
        lastname.sendKeys(TestDataAYE.LastName);
        dob.click();
        dob1.sendKeys(TestDataAYE.DOB);

        //Select Gender
        POAYP.rbtnmale.input.click();

        //Enter Valid value for  Residential Address1
        resaddr1.sendKeys(TestDataAYE.Addr1);

        //Enter Valid value for  Residential City
        rescity.sendKeys(TestDataAYE.City);

        //Select any Residential State
        statelist.$('[value ="'+ TestDataAYE.ResState+'"]').click();


        //Enter Valid value for  Postal Code
        postalcode.sendKeys(TestDataAYE.postalCode);


        //Enter Valid value for  Preferred phone number
        // preferedphone.click();
        pphone1.sendKeys(TestDataAYE.PrefPersonalPhone);

        //Enter Valid value for  Preferred email
        prefmail.sendKeys(TestDataAYE.PrefPersemail);

        //Select any value for State of Employment
        stateemploy.$('[value ="'+ TestDataAYE.EmpState+'"]').click();
        //browser.executeScript('window.scrollTo(580,1500);');

        POAYP.continuebutton.input.click();




        //element(by.css('[href="/cli/absence"]')).click();

        //Verify About your Absence is displayed
        var aboutyourabsencehdr = POAYA.absenceheader.input.getText();
        expect(aboutyourabsencehdr).toEqual('About Your Absence');

    };

    this.enteraboutyoupage = function fillaboutyoupage_female(){

        //Fill all the details in About You page and click continue for About Your Absence page

        //Open NEW CLI in browser and go to About You Page
        browser.ignoreSynchronization = true;
        browser.waitForAngularEnabled(false);
        browser.get(employeeurl);
        browser.sleep(15000);
        username.sendKeys('mcfarlandc');
        password.sendKeys('Test1234');
        element(by.buttonText('Login')).click();
        browser.sleep(90000);
      //  browser.waitForAngularEnabled(true);
        browser.get('https://dev1-lmbc-empr-mlc-gateway.pdc.np.paas.lmig.com/cli/employee');
        browser.sleep(90000);

        //Click About You Page
        element(by.buttonText('Start')).click();


       // POAYP.empidradio.input.click();
      //  txtssn1.sendKeys('234234234')



        empid.sendKeys(TestDataAYE.EmpID);
        firstname.sendKeys(TestDataAYE.FirstName);
        lastname.sendKeys(TestDataAYE.LastName);
        dob.click();
        dob1.sendKeys(TestDataAYE.DOB);

        //Select Gender
        POAYP.rbtnfemale.input.click();

        //Enter Valid value for  Residential Address1
        resaddr1.sendKeys(TestDataAYE.Addr1);

        //Enter Valid value for  Residential City
        rescity.sendKeys(TestDataAYE.City);

        //Select any Residential State
        statelist.$('[value ="'+ TestDataAYE.ResState+'"]').click();


        //Enter Valid value for  Postal Code
        postalcode.sendKeys(TestDataAYE.postalCode);


        //Enter Valid value for  Preferred phone number
        // preferedphone.click();
        pphone1.sendKeys(TestDataAYE.PrefPersonalPhone);

        //Enter Valid value for  Preferred email
        prefmail.sendKeys(TestDataAYE.PrefPersemail);
        browser.executeScript('window.scrollTo(400,1500);');

        //Select any value for State of Employment
        stateemploy.$('[value ="'+ TestDataAYE.EmpState+'"]').click();
       browser.executeScript('window.scrollTo(600,1600);');

        POAYP.continuebutton.input.click();


        //Verify About your Absence is displayed
        var aboutyourabsencehdr = POAYA.absenceheader.input.getText();
        expect(aboutyourabsencehdr).toEqual('About Your Absence');

    };
    this.enterDetailsofabsencepage = function fillaboutyourabsence(){

        browser.executeScript('window.scrollTo(80,100);');
        //Select the Continous radio button
        POAYA.consecutivedaysradiobtny.input.click();

        leaveclaimlist.$('[value = "OWN"]').click();
        browser.sleep(100);
        circumstance.$('[value = "S"]').click();
        browser.sleep(100);
        browser.executeScript('window.scrollTo(100,600);');
        txtillness.click();
        dateillness.click();
        txtlastday.click();
        datelastday.click();

        rbtnaccident.click();
        rbtnmotoraccident.click();

        browser.executeScript('window.scrollTo(100,600);');
        rbtnjobyes.click();

        browser.executeScript('window.scrollTo(140,1000);');
        rbthospitalizationno.click();
        //rbtnhosp.click();
        var txthospital = POAYA.txthospital.input;
        var txtsurgery1 = POAYA.txtsurgery1.input;
        txthospital.sendKeys('10/09/2017',protractor.Key.TAB)


        rbtnsurgeryno.click();
       // txtsurgery.click();

        txtsurgerydesc.sendKeys('test');


    };
    this.enteraddldetailspage = function filladdldetailspage(){
        //Enter date in Date of Hire
        browser.sleep(1000);
        var txthiredate = POAIP.txthiredate.input;
        txthiredate.sendKeys('02/02/2017',protractor.Key.TAB);


        //Enter Employee ID
        var empidtxt = POAIP.empidtxt.input;
        empidtxt.sendKeys('98980');

        //Enter Work State in drop down
        var workstatelist = POAIP.workstatelist.input;
        workstatelist.$('[value = "AK"]').click();

        //Enter Subsidiary text box
        var substext = POAIP.substext.input;
        substext.sendKeys('1000');

        //Enter Location/Branch text box
        var locbranchtxt = POAIP.locbranchtxt.input;
        locbranchtxt.sendKeys('NewYork');

        //Enter Employee Type in drop down
        var emptypelist = POAIP.emptypelist.input;
        emptypelist.$('[value = "F"]').click();

        //Enter Job Requirements Description text box
        var jobreqdesctxt = POAIP.jobreqdesctxt.input;
        jobreqdesctxt.sendKeys('Test job desc');

        //Enter Physical Demands in drop down
        var phydemandsclist = POAIP.phydemandsclist.input;
        phydemandsclist.$('[value = "S"]').click();

        //Enter Pay Type in drop down
        var paytypelist = POAIP.paytypelist.input;
        paytypelist.$('[value = "Salary"]').click();

        //Enter Earnings (excluding commissions and bonuses) text box
        var earningstxt = POAIP.earningstxt.input;
        earningstxt.sendKeys('4500');


        //Has or will this employee receive another source of income for the entire portion of the absence covered by this claim?
        //Please select from the following
        var sourceofincomelist = POAIP.sourceofincomelist.input;
        sourceofincomelist.$('[value = "Separation Pay"]').click();

        //Enter Other Income Amount (Please indicate per Week/per Month) text box
        var otherincomeamttxt = POAIP.otherincomeamttxt.input;
        otherincomeamttxt.sendKeys('250');


        txtbegandate.sendKeys('02/02/2017',protractor.Key.TAB);


        txtceaseddate.sendKeys('02/02/2017',protractor.Key.TAB);


        txtapplieddate.sendKeys('02/02/2017',protractor.Key.TAB);

        //Enter Class text box
        var classtext = POAIP.classtext.input;
        classtext.sendKeys('B1');

        //Enter Employee Premium Contribution text box
        var eecontributiontext = POAIP.eecontributiontext.input;
        eecontributiontext.sendKeys('45');

        //Enter Employer Premium Contribution text box
        var ercontributiontext = POAIP.ercontributiontext.input;
        ercontributiontext.sendKeys('55');

        //Enter Benefit Percent text box
        var benefitpercenttxt = POAIP.benefitpercenttxt.input;
        benefitpercenttxt.sendKeys('20');
        browser.executeScript('window.scrollTo(2000,2000);');

        //Enter Days per Week text box
        var daysperweektxt = POAIP.daysperweektxt.input;
        daysperweektxt.sendKeys('6');

        //Enter Hours per Day text box
        var hrsperdaytxt = POAIP.hrsperdaytxt.input;
        hrsperdaytxt.sendKeys('8');

        //Click Scheduled Work Days check box (Monday)
        POAIP.mondaycheckbox.input.click();



        //Enter Current Work Status in drop down
        var curwrkstatuslist = POAIP.curwrkstatuslist.input;
        curwrkstatuslist.$('[value = "A"]').click();
        browser.executeScript('window.scrollTo(3300,2600);');

        POAIP.continuebutton.input.click();
        browser.sleep(500);

    };

    this.username = {
        input: element(by.id('username'))
    };
    this.password = {
        input: element(by.id('password'))
    };
    this.login = {
        input: element(by.buttonText('Login'))
    };

    this.customerselection = {
        input: (element.all(by.css(['data-bind="click: $parent.viewCustomer, html: title"'])).get(157))
    };

    this.superadminlogin = function superadmin_login(){
        browser.ignoreSynchronization = true;
        browser.waitForAngularEnabled(false);
        browser.get('https://www-test.mylibertyconnection.com/public/index.html');
        browser.sleep(9000);

    };

};
module.exports = new POCommonFunctions();