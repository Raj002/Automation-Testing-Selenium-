/**
 * Created by n0275896 on 6/28/2017.
 */

var ResuableFunction = require('./..//PageWise/helpers/helpers.js');

var Getting_StartedPage = function() {

    var progress_bar = ['Get Started','About Your Employee','About Absence','Additional Information','Review'];
    var progress_bar_English = ['Get Started','About You','About Your Absence','Review'];
    var progress_bar_Spanish = ['Empezar','Acerca de usted','Acerca de su ausencia','Revisión'];
    var header1 = element(by.tagName('h1'));
    var pageheading = element(by.id('start-page-heading'));
    var header2 = element.all(by.tagName('h2'));
    var btnstart = element(by.className('lds-button lds-button--primary'));

    var static_content = ['1. Information to identify your employee (may include social security number or other ID as required by your employer)',
        '2. Claim or leave information, including reason and dates of medical or other authorized events',
        'NOTE:','For added security, your session will automatically time-out following 15 minutes of inactivity to protect your personal information.'];

    var static_content_English = ['1. Information to identify yourself (may include your social security number or other ID as required by your employer)',
    '2. Claim or leave information, including reason and dates of medical or other authorized events',
    '3. Physician or hospital contact information (if available)',
    'NOTE:','For added security, your session will automatically time-out following 15 minutes of inactivity to protect your personal information.'];

    var static_content_Spanish = ['1. Información para identificarse (puede incluir su número de seguro social u otra identificación según lo requiera su empleador)',
        '2. Reclamar o dejar información, incluyendo la razón y las fechas de los eventos médicos u otros eventos autorizados',
        '3. Información de contacto del médico o del hospital (si está disponible)',
        'NOTA:','Para mayor seguridad, su sesión se apagará automáticamente después de 15 minutos de inactividad para proteger su información personal.'];


    this.VerifyGettingStartedCircleColor = function () {
        var firstcircle = element(by.className('fa fa-circle'));
        expect(firstcircle.getCssValue("color")).toEqual("rgba(0, 38, 99, 1)");

    };


    this.VerifyProgressBarHeader = function (value1) {


        var i;

        switch (value1)
        {
            case "Employer":
                            for (i = 1; i <= 3; i++) {

                                var progress_barmenu = '//*[@id="progressbar"]/div/ul[2]/li[' + i + ']/circle-lable/figure';

                                var options = element(by.xpath(progress_barmenu));
                                expect(options.getText()).toEqual(progress_bar[i-1]);
                            }
                            break;

            case "Employee-English":

                            for (i = 1; i <= 4; i++) {

                                var progress_barmenu = '//*[@id="progressbar"]/div/ul[2]/li[' + i + ']/circle-lable/figure';
                                var options = element(by.xpath(progress_barmenu));
                                expect(options.getText()).toEqual(progress_bar_English[i-1]);
                            }
                            break;

            case "Employee-Spanish":

                            for (i = 1; i <= 4; i++) {

                                var progress_barmenu = '//*[@id="progressbar"]/div/ul[2]/li[' + i + ']/circle-lable/figure';
                                var options = element(by.xpath(progress_barmenu));
                                expect(options.getText()).toEqual(progress_bar_Spanish[i-1]);
                            }
                            break;

        }

    };

    this.VerifyTransparentCircle = function (value1,value2) {

        for (var i = 0; i <= value2; i++) {
            var circle = element.all(by.className('fa fa-circle-thin')).get(i);
            expect(circle.getCssValue("color")).toEqual("rgba(193, 192, 193, 1)");
        }

    };

    this.VerifyCLIHeader = function (value1) {
        if (value1=='Spanish')
        {
            expect(header1.getText()).toEqual('Reportar un reclamo o una licencia de ausencia');
        }
        else
        {
        expect(header1.getText()).toEqual('Report a Claim or Leave of Absence');}

    };


    this.VerifyCLIPermission = function (value1) {

        var customer;
        var warning = element(by.className('alert alert-danger'));

        switch(value1) {
            case "Catholic Health":
                expect(header1.getText()).toEqual('Report a Claim or Leave of Absence');
                break;
            case "Baird":
                expect(warning.getText()).toContain('User is not authorized to view the requested page. Please contact administrator for further assistance.');
                break;
            case "Commercial Metal - Group Benefit":
                expect(warning.getText()).toContain('User is not authorized to view the requested page. Please contact administrator for further assistance.');
                break;
            case "Tetra Pak":
                expect(header1.getText()).toEqual('Report a Claim');
                break;
            case "Healthways Inc":
                expect(header1.getText()).toEqual('Report a Claim');
                break;

            case "Brown Shoe":
                expect(header1.getText()).toEqual('Report a Leave of Absence');
                break;
            case "2012 Disc Customer":
                expect(header1.getText()).toEqual('Report a Claim');
                break;
        }



        };

    this.VerifyPageHeader = function (value1) {

        //expect(pageheading.getText()).toEqual('ER A Message From Your Employer');
        switch (value1){
            case "Employer" || "Employee-English":
                expect(header2.get(2).getText()).toEqual('Welcome. To continue, please make sure you have the following information:');
                break;
            case "Employee-Spanish":
                expect(header2.get(2).getText()).toEqual('Bienvenido. Para continuar, por favor asegúrese de tener la siguiente información:');
                break;
        }


    };

    this.VerifyGettingStarted_StaticContent = function (value1) {

        var staticcontent = '/html/body/sd-app/section/cli-home-component/div/div/div[2]/start/div/div/div[2]/div/';
        var i;

        switch (value1){

            case "Employer":

                    for (i = 1; i <= 2; i++)
                    {

                        content = element(by.xpath(staticcontent+ 'div[' + i + ']'));
                        expect(content.getText()).toEqual(static_content[i-1]);
                        var j = i + 2;
                        content =  element(by.xpath(staticcontent + 'div[4]' + '/span[' + i + ']'));
                        expect(content.getText()).toEqual(static_content[i+1]);

                    }
                break;

            case "Employee-English":

                for (i = 1; i <= 3; i++)
                {

                    content = element(by.xpath(staticcontent+ 'div[' + i + ']'));
                    expect(content.getText()).toEqual(static_content_English[i-1]);
                    var j = i + 2;
                    content =  element(by.xpath(staticcontent + 'div[4]' + '/span[' + i + ']'));
                    expect(content.getText()).toEqual(static_content_English[i+1]);

                }
                break;

            case "Employee-Spanish":

                content = element(by.xpath(staticcontent+ 'div[' + 1 + ']'));
                expect(content.getText()).toEqual('1. Información para identificarse (puede incluir su número de seguro social u otra identificación según lo requiera su empleador)');
                content = element(by.xpath(staticcontent+ 'div[' + 2 + ']'));
                expect(content.getText()).toEqual('2. Reclamar o dejar información, incluyendo la razón y las fechas de los eventos médicos u otros eventos autorizados');
                content = element(by.xpath(staticcontent+ 'div[' + 3 + ']'));
                expect(content.getText()).toEqual('3. Información de contacto del médico o del hospital (si está disponible)');
                content =  element(by.xpath(staticcontent + 'div[4]' + '/span[' + 1 + ']'));
                expect(content.getText()).toEqual('NOTA:');
                content =  element(by.xpath(staticcontent + 'div[4]' + '/span[' + 2 + ']'));
                expect(content.getText()).toEqual('Para mayor seguridad, su sesión se apagará automáticamente después de 15 minutos de inactividad para proteger su información personal.');
                break;


        }




    };

    this.VerifyGetHelp_Popup = function () {

        var gethelp = element(by.css('.linkBold a'));
        expect(gethelp.getText()).toEqual('Get Help');
        gethelp.click();

        var popuphelp = element(by.className('modal-dialog'));
        expect(popuphelp.isDisplayed()).toBe(true);
        element(by.buttonText('Close')).click();

    };

    this.VerifyGetHelp_Popup_Spanish = function () {

        var gethelp = element(by.css('.linkBold a'));
        expect(gethelp.getText()).toEqual('!!Get Help!!');
        gethelp.click();

        var popuphelp = element(by.className('modal-dialog'));
        expect(popuphelp.isDisplayed()).toBe(true);
        element(by.buttonText('Cerrar')).click();

    };

    this.VerifyStartButtonText_Color = function (value1) {

        var btnstart = element(by.className('lds-button lds-button--primary'));
        expect(btnstart.getCssValue("color")).toEqual("rgba(255, 255, 255, 1)");

        switch (value1) {

            case "Employer":
                expect(btnstart.getText()).toEqual('Start');
                break;

            case "Employee-English":
                expect(btnstart.getText()).toEqual('Start' || 'Open Your Saved Application');
                break;


            case "Employee-Spanish":
                expect(btnstart.getText()).toEqual('Comienzo' || 'Open Your Saved Application');
                break;
        }

    };

    this.clickStart = function (value1) {
        browser.sleep(4000);

        var i;

        switch (value1) {

            case "Employer":

                browser.executeScript("arguments[0].scrollIntoView()",btnstart.getWebElement());
                btnstart.click();
                browser.sleep(1000);
                expect(header2.get(1).getText()).toEqual('Personal Information');
                break;

            case "Employee-English":

                browser.executeScript("arguments[0].scrollIntoView()",btnstart.getWebElement());
                btnstart.click();
                browser.sleep(1000);
                expect(header2.get(1).getText()).toEqual('Personal Information');
                break;

            case "Employee-Spanish":
                browser.sleep(10000);
                browser.executeScript("arguments[0].scrollIntoView()",btnstart.getWebElement());
                btnstart.click();
                browser.sleep(1000);
                expect(header2.get(1).getText()).toEqual('Información Personal');
        }

    };

    this.clickStartbutton = function (value1) {
        browser.sleep(4000);

        var i;

        switch (value1) {

            case "Employer":

                browser.executeScript("arguments[0].scrollIntoView()",btnstart.getWebElement());
                btnstart.click();
                browser.sleep(1000);
                break;

            case "Employee-English":

                browser.executeScript("arguments[0].scrollIntoView()",btnstart.getWebElement());
                btnstart.click();
                browser.sleep(1000);
                break;

            case "Employee-Spanish":
                browser.sleep(10000);
                browser.executeScript("arguments[0].scrollIntoView()",btnstart.getWebElement());
                btnstart.click();
                browser.sleep(1000);

        }

    };

    this.VerifyOpenSavedApplication = function() {
        expect(btnstart.getText()).toEqual('Open Your Saved Application');
        expect(btnstart.getText()).not.toEqual('Start');

        var savetext = element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/start/div/div/div[3]/div/div/div/span'));
        var datetoday = ResuableFunction.TodayDate();
        expect(savetext.getText()).toContain('Saved ' + datetoday);


    };

    this.VerifyOpenSavedApplication_Spanish = function() {
        expect(btnstart.getText()).toEqual('Abra su aplicación guardada');
        expect(btnstart.getText()).not.toEqual('Comienzo');

        var savetext = element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/start/div/div/div[3]/div/div/div/span'));
        var datetoday = ResuableFunction.TodayDate();
        expect(savetext.getText()).toContain('Tiempo ' + datetoday);


    };




};

module.exports = new Getting_StartedPage();

