/**
 * Created by n0258375 on 11/27/2017.
 */

var View_SubmissionPage = function() {

    var pageheader = element(by.tagName("h1"));
    var clmlvenumber = element(by.tagName("b"));
    var clmlvetext = element(by.id("claimLeaveIDtext"));
    var primarybutton = element.all(by.className('lds-button lds-button--primary'));

    var lbl_maternity_vaginal = ['*****4440','MICHELLE','','Abbott','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Email','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','AlaABBOTTska','Yes','Maternity','Yes, Vaginal','11/01/2017','11/01/2017','','','','','',''];

    var lbl_maternity_vaginal_EE_Spanish = ['*****4440','MICHELLE','','Abbott','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Email','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','Sí','Maternidad','Sí, parto vaginal','11/01/2017','11/01/2017','','','','','',''];

    var lbl_Continuous_Bond_Child = ['*****4440','MICHELLE','','Abbott','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Email','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','Yes','Bond with child','Newborn','Child of Domestic Partner',
        '11/01/2017','11/03/2017','11/08/2017'];

    var lbl_Continuous_Bond_Child_Spanish = ['*****4440','MICHELLE','','Abbott','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Email','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','Sí','Atender a un hijo después de su nacimiento','Recién nacido',
        'Parientes más próximos','11/01/2017','11/03/2017','11/08/2017'];

    var lbl_ER_Continuous_Maternity_Vaginal = ['24440','Tester','','Test','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Mail','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','Yes','Maternity','Yes, Vaginal','11/01/2017','11/01/2017','','','',
        '11/02/2017','118877','New York','test','NewYork','Full-Time',
        'Sample text will display here','Light','Vacation','$40.00','23','50%','50%','50%','5','8',
        'Monday, Tuesday, Wednesday, Thursday, Friday','Active'];

    var lbl_ER_Continuous_Bond_Child = ['24440','Tester','','Test','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Mail','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','Yes','Bond with child','Newborn','Child of Domestic Partner',
        '11/01/2017','11/03/2017','11/08/2017','11/02/2017','118877','New York','test','NewYork','Full-Time',
        'Sample text will display here','Light','Vacation','$40.00','23','50%','50%','50%','5','8',
        'Monday, Tuesday, Wednesday, Thursday, Friday','Active'];

    var er_table_values = ['340','11/02/2017','11/02/2017','11/02/2017'];

    var lbl_ER_Intermittent_Bond_Child = ['24440','Tester','','Test','Male','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Mail','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','No','Bond with child','Newborn','Child of Domestic Partner',
        '11/01/2017','11/03/2017','11/08/2017','','','','','','',
        '','','','','','','','','','','',''];

    var lbl_Intermittent_Bond_Child = ['*****4440','MICHELLE','','Abbott','Male','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Email','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','No','Bond with child','Foster Care',
        '11/01/2017','11/03/2017','11/08/2017',''];

    var lbl_EE_Leave_Only= ['*****4440','QACust','','Test','Male','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Email','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','Yes','Bond with child','Foster Care',
        '11/01/2017','11/03/2017','11/08/2017',''];

    var lbl_Spanish_Intermittent_Bond_Child = ['*****4440','MICHELLE','','Abbott','Male','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Email','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','No','Atender a un hijo después de su nacimiento','Cuidado adoptivo',
        '11/01/2017','11/03/2017','11/08/2017',''];

    var lbl_maternity_notyet = ['*****4440','MICHELLE','','Abbott','Female','01/01/1987','(999) 777-5550','TESTemail@test.com',
        'Email','123 Test','','Dover','New Hampshire','United States','23345', 'United States','Alaska','Yes','Maternity',
        'No, Not yet','12/20/2017','11/01/2017','No','','','',''];

    var lbl_maternity_notyet_Spanish_EE = ['*****4440','MICHELLE','','Abbott','Female','01/01/1987','(999) 777-5550','TESTemail@test.com',
        'Email','123 Test','','Dover','New Hampshire','United States','23345', 'United States','Alaska','Sí','Maternidad',
        'No, todavía no','12/20/2017','11/01/2017','No','','','',''];

    var lbl_ER_Continuous_maternity_notyet = ['24440','Tester','','Test','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Mail','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','Yes','Maternity','No, Not yet','12/20/2017','11/01/2017','No','','','','','','','',
        '','','','','','','','','','','',''];

    var lbl_Continuous_Care = ['*****4440','MICHELLE','','Abbott','Female','01/01/1987','(999) 777-5550','TESTemail@test.com',
        'Email','123 Test','','Dover','New Hampshire','United States','23345', 'United States','Alaska','Yes',
        'Care for family member, (including military)','Child','Child','11/01/2017','11/10/2017',''];

    var lbl_Continuous_Care_EE_Spanish = ['*****4440','MICHELLE','','Abbott','Male','01/01/1987','(999) 777-5550','TESTemail@test.com',
        'Email','123 Test','','Dover','New Hampshire','United States','23345', 'United States','Alaska','Sí',
        'Cuidar de un miembro de su familia (incluyendo militares)','Hijo(a)','Hijo(a)','11/01/2017','11/10/2017',''];

    var lbl_Intermittent_Care_EE_Spanish = ['*****4440','MICHELLE','','Abbott','Female','01/01/1987','(999) 777-5550','TESTemail@test.com',
        'Email','123 Test','','Dover','New Hampshire','United States','23345', 'United States','Alaska','No',
        'Cuidar de un miembro de su familia (incluyendo militares)','Hijo(a)','Hijo(a)','11/01/2017','11/10/2017',''];

    var lbl_Intermittent_Care = ['*****4440','MICHELLE','','Abbott','Female','01/01/1987','(999) 777-5550','TESTemail@test.com',
        'Email','123 Test','','Dover','New Hampshire','United States','23345', 'United States','Alaska','No',
        'Care for family member, (including military)','Child','Child','11/01/2017','11/10/2017',''];

    var lbl_MOC_Illness = ['*****4440','MICHELLE','','Abbott','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Email','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','Yes','My own illness, injury, or medical treatment','Illness or related medical treatment',
        '11/01/2017','11/01/2017','Yes','Yes','Yes','No','No','user text 1','user text 2','','',''];

    var lbl_MOC_Illness_EE_Spanish = ['*****4440','MICHELLE','','Abbott','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Email','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','Sí','Mi propia enfermedad, lesión o tratamiento médico','Enfermedad o tratamiento médico relacionado',
        '11/01/2017','11/01/2017','Sí','Sí','Sí','No','No','user text 1','user text 2','','',''];

    var lbl_MOC_Injury_EE_Spanish = ['*****4440','MICHELLE','','Abbott','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Email','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','Sí','Mi propia enfermedad, lesión o tratamiento médico','Lesión o tratamiento médico para una lesión',
        '11/01/2017','11/01/2017','Sí','Sí','Sí','No','No','user text 1','user text 2','','',''];

    var lbl_Intermittent_MOC_CC = ['*****4440','MICHELLE','','Abbott','Female','01/01/1987','(999) 777-5550','TESTemail@test.com',
        'Email','123 Test','','Dover','New Hampshire','United States','23345', 'United States','Alaska','No',
        'My own illness, injury, or medical treatment','Chronic Condition','11/01/2017','11/10/2017','Phyfirstname',
        'Phylastname','(989) 811-2200'];

    var lbl_Intermittent_MOC_CC_EE_Spanish = ['*****4440','MICHELLE','','Abbott','Female','01/01/1987','(999) 777-5550','TESTemail@test.com',
        'Email','123 Test','','Dover','New Hampshire','United States','23345', 'United States','Alaska','No',
        'Mi propia enfermedad, lesión o tratamiento médico','Condiciones crónicas que requieren tratamiento','11/01/2017','11/10/2017','Phyfirstname',
        'Phylastname','(989) 811-2200'];

    var lbl_MOC_Injury = ['*****4440','MICHELLE','','Abbott','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Email','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','Yes','My own illness, injury, or medical treatment','Injury or related medical treatment',
        '11/01/2017','11/01/2017','Yes','Yes','Yes','No','No','user text 1','user text 2','','',''];

    var lbl_Intermittent_MOC_AT = ['*****4440','MICHELLE','','Abbott','Female','01/01/1987','(999) 777-5550','TESTemail@test.com',
        'Email','123 Test','','Dover','New Hampshire','United States','23345', 'United States','Alaska','No',
        'My own illness, injury, or medical treatment','Absence plus treatment','11/01/2017','11/10/2017','Phyfirstname','Phylastname','(989) 811-2200'];

    var lbl_Intermittent_MOC_AT_EE_Spanish = ['*****4440','MICHELLE','','Abbott','Female','01/01/1987','(999) 777-5550','TESTemail@test.com',
        'Email','123 Test','','Dover','New Hampshire','United States','23345', 'United States','Alaska','No',
        'Mi propia enfermedad, lesión o tratamiento médico','Ausencia Más Tratamiento','11/01/2017','11/10/2017',
        'Phyfirstname','Phylastname','(989) 811-2200'];

        var lbl_ER_Continuous_Careflow = ['24440','Tester','','Test','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Mail','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','Yes','Care for family member, (including military)','Child','Child 18+',
        '11/01/2017','11/03/2017','11/08/2017','11/02/2017','118877','New York','test','NewYork','Full-Time',
        'Sample text will display here','Light','Vacation','$40.00','23','50%','50%','50%','5','8',
        'Monday, Tuesday, Wednesday, Thursday, Friday','Active'];

    var lbl_ER_Intermittent_Careflow = ['24440','Tester','','Test','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Mail','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','No','Care for family member, (including military)','Child','Child 18+',
        '11/01/2017','11/03/2017','11/08/2017','','','','','','','','','','','','','','','','','',''];

    var lbl_ER_Intermittent_Other = ['24440','Tester','','Test','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Mail','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','No','Other leave type, not listed above','Work Related Injury/Illness','12/01/2017',
        '12/05/2017','11/02/2017','118877','New York','test','NewYork','Full-Time','Sample text will display here','Light',
        'Vacation','$40.00','23','50%','50%','50%','5','8','Monday, Tuesday, Wednesday, Thursday, Friday','Active'];

    var lbl_ER_Intermittent_MOC_AT = ['24440','Tester','','Test','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Mail','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','No','My own illness, injury, or medical treatment','Absence plus treatment','12/01/2017',
        '12/05/2017','11/02/2017','118877','New York','test','NewYork','Full-Time','Sample text will display here','Light',
        'Vacation','$40.00','23','50%','50%','50%','5','8','Monday, Tuesday, Wednesday, Thursday, Friday','Active'];

    var lbl_ER_Continuous_MOC_Illness = ['24440','Tester','','Test','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Mail','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','Yes','My own illness, injury, or medical treatment','Illness or related medical treatment',
        '12/01/2017','12/04/2017','Yes','Yes','Yes','Yes','12/04/2017','Yes','12/04/2017','Text','Sample Text',
        '11/02/2017','118877','New York','test','NewYork','Full-Time','Sample text will display here',
        'Light','Vacation','$40.00','23','50%','50%','50%','5','8','Monday, Tuesday, Wednesday, Thursday, Friday','Active'];

    var lbl_ER_Leaveonly = ['*****4440','Tester','','Test','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Mail','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','No','Care for family member, (including military)','Child','Child 18+',
        '11/01/2017','11/03/2017','11/08/2017','','','','','','','','','','','','','','','','','',''];

    var lbl_ER_Claim_only_Illness = ['*****4440','Tester','','Test','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Mail','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','Illness or related medical treatment',
        '12/01/2017','12/04/2017','Yes','Yes','Yes','Yes','12/04/2017','Yes','12/04/2017','Text','Sample Text',
        '11/02/2017','118877','New York','test','NewYork','Full-Time','Sample text will display here',
        'Light','Vacation','$40.00','23','50%','50%','50%','5','8','Monday, Tuesday, Wednesday, Thursday, Friday','Active'];

    var lbl_EE_Claim_only_Injury = ['*****4440','Test','','Bailey','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Email','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','Injury or related medical treatment',
        '12/01/2017','12/04/2017','Yes','Yes','Yes','Yes','12/04/2017','Yes','12/04/2017','Text','Sample Text',
        'Phyfirstname','Phylastname','(989) 811-2200'];

    var lbl_ER_Continuous_MOC_Injury = ['24440','Tester','','Test','Female','01/01/1987','(999) 777-5550',
        'TESTemail@test.com','Mail','123 Test','','Dover','New Hampshire','United States','23345',
        'United States','Alaska','Yes','My own illness, injury, or medical treatment','Injury or related medical treatment',
        '12/01/2017','12/04/2017','Yes','Yes','Yes','Yes','12/04/2017','Yes','12/04/2017','Text','Sample Text',
        '11/02/2017','118877','New York','test','NewYork','Full-Time','Sample text will display here',
        'Light','Vacation','$40.00','23','50%','50%','50%','5','8','Monday, Tuesday, Wednesday, Thursday, Friday','Active'];

    this.FieldLabelvalidations  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {

                expect(LabelName.get(i).getText()).toEqual(lbl_maternity_vaginal[i]);


            }
        });
    };

    this.FieldLabelvalidations_notyet  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {

                expect(LabelName.get(i).getText()).toEqual(lbl_maternity_notyet[i]);


            }
        });
    };

    this.lbl_Continuous_Care  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {

                expect(LabelName.get(i).getText()).toEqual(lbl_Continuous_Care[i]);


            }
        });
    };

    this.lbl_addinfo_tablevalues  = function (){

        var LabelName = element.all(by.className('container-fluid'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {

                expect(LabelName.get(i).getText()).toContain(er_table_values[i]);


            }
        });
    };

    this.lbl_ER_Maternity_Notyet  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {

                expect(LabelName.get(i).getText()).toEqual(lbl_ER_Continuous_maternity_notyet[i]);


            }
        });
    };

    this.lbl_Intermittent_Care  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {

                expect(LabelName.get(i).getText()).toEqual(lbl_Intermittent_Care[i]);


            }
        });
    };

    this.lbl_Intermittent_MOC_CC  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {

                expect(LabelName.get(i).getText()).toEqual(lbl_Intermittent_MOC_CC[i]);


            }
        });
    };

    this.lbl_Intermittent_MOC_AT  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {

                expect(LabelName.get(i).getText()).toEqual(lbl_Intermittent_MOC_AT[i]);


            }
        });
    };

    this.lbl_Continuous_Bondwithchild  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_Continuous_Bond_Child[i]);

            }
        });
    };


    this.lbl_EE_Continuous_Bond_Child_Spanish  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_Continuous_Bond_Child_Spanish[i]);

            }
        });
    };

    this.lbl_ER_Continuous_Bondwithchild  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_ER_Continuous_Bond_Child[i]);

            }
        });
    };

    this.lbl_ER_Continuous_Maternity_Vaginal  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_ER_Continuous_Maternity_Vaginal[i]);

            }
        });
    };

    this.lbl_ER_Intermittent_Bondwithchild  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_ER_Intermittent_Bond_Child[i]);

            }
        });
    };

    this.lbl_Intermittent_Bondwithchild  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_Intermittent_Bond_Child[i]);

            }
        });
    };

    this.lbl_Continous_MOC_Illness  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_MOC_Illness[i]);

            }
        });
    };

    this.lbl_Continous_MOC_Injury  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_MOC_Injury[i]);

            }
        });
    };


    this.Click_CloseButton = function(){

        browser.executeScript("arguments[0].scrollIntoView()",primarybutton.get(0).getWebElement());
        primarybutton.get(0).click();

    };

    this.lbl_ER_Continuous_Careflow  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_ER_Continuous_Careflow[i]);

            }
        });
    };

    this.lbl_ER_Intermittent_Careflow  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_ER_Intermittent_Careflow[i]);

            }
        });
    };

    this.lbl_ER_Intermittent_Other  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_ER_Intermittent_Other[i]);

            }
        });
    };

    this.lbl_ER_Intermittent_MOC_AT  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_ER_Intermittent_MOC_AT[i]);

            }
        });
    };

    this.lbl_ER_Continuous_MOC_Illness  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_ER_Continuous_MOC_Illness[i]);

            }
        });
    };

    this.lbl_ER_Continuous_MOC_Injury  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_ER_Continuous_MOC_Injury[i]);

            }
        });
    };

    this.lbl_ER_Leave_Only  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_ER_Claim_only_Illness[i]);

            }
        });
    };

    this.lbl_EE_Claim_only_Injury  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_EE_Claim_only_Injury[i]);

            }
        });
    };


    this.lbl_Spanish_Intermittent_Bond_Child  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_Spanish_Intermittent_Bond_Child[i]);

            }
        });
    };


    this.lbl_maternity_notyet_Spanish_EE  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_maternity_notyet_Spanish_EE[i]);

            }
        });
    };


    this.lbl_maternity_vaginal_EE_Spanish  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_maternity_vaginal_EE_Spanish[i]);

            }
        });
    };


    this.lbl_Continuous_Care_EE_Spanish  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_Continuous_Care_EE_Spanish[i]);

            }
        });
    };


    this.lbl_Intermittent_Care_EE_Spanish  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_Intermittent_Care_EE_Spanish[i]);

            }
        });
    };


    this.lbl_MOC_Illness_EE_Spanish  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_MOC_Illness_EE_Spanish[i]);

            }
        });
    };


    this.lbl_MOC_Injury_EE_Spanish  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_MOC_Injury_EE_Spanish[i]);

            }
        });
    };


    this.lbl_Intermittent_MOC_AT_EE_Spanish  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_Intermittent_MOC_AT_EE_Spanish[i]);

            }
        });
    };

    this.lbl_Intermittent_MOC_CC_EE_Spanish  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_Intermittent_MOC_CC_EE_Spanish[i]);

            }
        });
    };

    this.lbl_ER_Leaveonly  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_ER_Leaveonly[i]);

            }
        });
    };

    this.lbl_EE_Leave_Only  = function (){

        var LabelName = element.all(by.className('fieldLabel--leftAlign'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toEqual(lbl_EE_Leave_Only[i]);

            }
        });
    };


};

module.exports = new View_SubmissionPage();