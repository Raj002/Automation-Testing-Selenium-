/**
 * Created by n0305595 on 6/19/2017.
 */
var phyfirstname = element(by.css('[formcontrolname="physicianFirstName"]'));
var phylastname = element(by.css('[formcontrolname="physicianLastName"]'));
var phyphonenumber = element(by.className('ui-inputtext ui-corner-all ui-state-default ui-widget'));

var MedicalContactsPage = function(){

    var instructtext = element(by.id('header2'));

    this.instructtext_med = function(value1){

        browser.executeScript("arguments[0].scrollIntoView()",instructtext.getWebElement());

        if (value1 == "Employee-English") {
            expect(instructtext.getText()).toEqual('Please provide us with the contact information for your physician to help expedite the processing of your absence request.');
        } else

        {
            expect(instructtext.getText()).toEqual('Proporcione la información de contacto de su médico para ayudarlo a agilizar el procesamiento de su solicitud de ausencia.');
        }


    };

    var primarybutton = element(by.className('lds-button lds-button--primary'));

    this.EnternoValues_ClickContinue_ViewReviewPage = function(value1){

        browser.executeScript("arguments[0].scrollIntoView()",primarybutton.getWebElement());
        primarybutton.click();

    };

    this.Contacts_Header = function(value1) {

        var MedicalContacts = element(by.id('header3'));

        if (value1 == "Employee-English") {
            expect(MedicalContacts.getText()).toEqual('Where did you get assistance?');
        } else
        {
            expect(MedicalContacts.getText()).toEqual('¿Dónde obtuviste asistencia?');
        }


    };

    this.EnterPhyFirstName = function(value1){

        browser.executeScript("arguments[0].scrollIntoView()",phyfirstname.getWebElement());
        phyfirstname.sendKeys(value1);
        browser.sleep(1000);

    };

    this.EnterPhyLastName = function(value1){

        browser.executeScript("arguments[0].scrollIntoView()",phylastname.getWebElement());
        phylastname.sendKeys(value1);
        browser.sleep(1000);

    };

    this.EnterPhyPhoneNumber = function(value1){

        browser.executeScript("arguments[0].scrollIntoView()",phyphonenumber.getWebElement());
        phyphonenumber.sendKeys(value1);
        browser.sleep(1000);

    };






































        this.contactspbar = {
        input: element(by.css('[href="/cli/contacts"]'))
    };
    //Medical Contacts - Header
    this.medheader = {
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/contacts/div[1]/div[1]/h1'))
    };
    //"Please provide us with one of the contacts below to help expedite the processing of your absence request." - Static Text
    this.statictext = {
        input: element(by.id('header2'))
    };
    //"Treating Physician Information" - Header
    this.physicianinfoheader = {
        input: element(by.id('header3'))
    };
    //Physician's First Name - Label
    this.physicianfnamelabel = {
        input: element.all(by.className('fieldset__label_optional')).get(0)
    };
    //Physician's First Name (optional) - Label
    this.physicianfnameoplabel = {
        input: element.all(by.className('fieldset__optional')).get(0)
    };
    //Physician's First Name  - Textbox
    this.physicianfnametbox = {
        input: element(by.id('physicianFirstName'))
    };
    //Physician's Last Name - Label
    this.physicianlnamelabel = {
        input: element.all(by.className('fieldset__label_optional')).get(1)
    };
    //Physician's Last Name (optional) - Label
    this.physicianlnameoplabel = {
        input: element.all(by.className('fieldset__optional')).get(1)
    };
    //Physician's Last Name  - Textbox
    this.physicianlnametbox = {
        input: element(by.id('physicianLastName'))
    };
    //Physician's Phone Number - Label
    this.physicianpnumlabel = {
        input: element.all(by.className('fieldset__label_optional')).get(2)
    };
    //Physician's Phone Number (optional) - Label
    this.physicianpnumoplabel = {
        input: element.all(by.className('fieldset__optional')).get(2)
    };
    //Physician's Phone Number  - Textbox
    this.physicianpnumtbox = {
        input: element(by.id('physicianphone'))
    };
    //Physician's Phone Number format - Label
    this.physicianpnumformatlabel = {
        input: element.all(by.className('fieldset__help-text')).get(0)
    };
    //Hospital Name or Physicians Practice Name - Label
    this.physicianhnamelabel = {
        input: element.all(by.className('fieldset__label_optional')).get(3)
    };
    //Hospital Name or Physicians Practice Name (optional) - Label
    this.physicianhnameoplabel = {
        input: element.all(by.className('fieldset__optional')).get(3)
    };
    //Hospital Name or Physicians Practice Name   - Textbox
    this.physicianhnametbox = {
        input: element(by.id('hospitalName'))
    };
    //Hospital or Physicians Practice Phone Number - Label
    this.physicianhpnumlabel = {
        input: element.all(by.className('fieldset__label_optional')).get(4)
    };
    //Hospital or Physicians Practice Phone Number (optional) - Label
    this.physicianhpnumoplabel = {
        input: element.all(by.className('fieldset__optional')).get(4)
    };
    //Hospital or Physicians Practice Phone Number format - Label
    this.physicianhpnumformatlabel = {
        input: element.all(by.className('fieldset__help-text')).get(1)
    };
    //Hospital or Physicians Practice Phone Number format - Textbox
    this.physicianhpnumtbox = {
        input: element(by.id('hospitalNumber'))
    };
    //Continue Button
    this.continuebutton = {
        input: element(by.className('lds-button lds-button--primary'))
    };
    //Go Back Button
    this.gobackbutton = {
        input: element(by.className('lds-button lds-button--secondary'))
    };
    //Save For Later Button
    this.saveforlaterbutton = {
        input: element(by.buttonText('Save for Later'))
    };

    //Save for Later - Popup
    this.savepopup = {
        input: element(by.className('modal-title'))
    };

    //Exit Application button - Save for Later Popup
    this.exitappbtn = {
        input: element(by.buttonText('Exit Application'))
    };

    //Return to Application button - Save for Later Popup
    this.rettoappbtn = {
        input: element(by.buttonText('Return to Application'))
    };

    // Delete Application Button
    this.deleteapplicationbutton = {
        input: element(by.className('lds-button lds-button--delete'))
    }
    //Validation message
    this.validationmessage = {
        input: element.all(by.className('fieldset__feedback fieldset__feedback--invalid'))
    };

    //ok Button Name in the Delete Application Popup
    this.okbutton = {
        input: element(by.buttonText('Ok'))
    };


    // Cancel Button Name in the Delete Application Popup
    this.cancelbutton = {
        input: element(by.buttonText('Cancel'))
    };

    //Delete application pop up header

    this.deletepopupheader = {
        input: (element.all(by.tagName('h4')).get(0))
    };

    //Delete button pop up message
    this.deletepopupmsg = {
        input: element(by.className('modal-body'))
    };


};



module.exports = new MedicalContactsPage();