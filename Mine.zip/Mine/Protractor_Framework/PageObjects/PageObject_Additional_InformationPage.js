/**
 * Created by n0238696 on 7/31/2017.
 */


var AddlInfoPage = function() {


    var primarybutton = element.all(by.className('lds-button lds-button--primary'));
    var dateclassname = 'ui-inputtext ui-widget ui-state-default ui-corner-all';
    var dateselection = element.all(by.className('undefined ui-inputtext ui-corner-all ui-state-default ui-widget'));
    var lbl_AddlDetails = ['Date of Hire','Associate Access Code','Work State','Subsidiary','Location/Branch','Associate Type','Job Requirements Description','Physical Demands','Pay Type',
        'Earnings (excluding commissions and bonuses)','Class','Benefit Percent','Associate Premium Contribution','Employer Premium Contribution','Has or will this employee receive another source of income for the entire portion of the absence covered by this claim?'
        ,'Days per Week','Hours per Day','Scheduled Work Days','Current Work Status'];
    var lbl_headings = ['Employment Details','Other Income (Maximum of 10 incomes)','Work Schedule (At Time Last Worked)'];
    var txtbox_entries = element(by.className('input_txt-box--regular ng-untouched ng-pristine ng-valid'));
    var Empcontribution = element(by.className('input_txt-box--regular ng-untouched ng-pristine ng-invalid'));
    var dropdown_entries = element(by.className('optionStyle fieldset__input--suppress_margin ng-untouched ng-pristine ng-valid'));
    var txt_Jobreqdesc = element(by.className('txt_area_input ng-untouched ng-pristine ng-valid'));
    var otherincomeamt = element(by.className('ng-untouched ng-pristine ng-valid'));
    var othericomedateclassname = 'ui-inputtext ui-widget ui-state-default ui-corner-all';
    var addotherincome_btn = element.all(by.className('lds-button lds-button--secondary'));
    var otherincom_id = element(by.id('addIncome'));
    var Monday = element(by.css('[formcontrolname="Monday"]'));
    var Tuesday = element(by.css('[formcontrolname="Tuesday"]'));
    var Wednesday = element(by.css('[formcontrolname="Wednesday"]'));
    var Thursday = element(by.css('[formcontrolname="Thursday"]'));
    var Friday = element(by.css('[formcontrolname="Friday"]'));
    var Saturday = element(by.css('[formcontrolname="Saturday"]'));
    var Sunday = element(by.css('[formcontrolname="Sunday"]'));
    var invalidmessage = element.all(by.className('input_error-padding'));
    var income_dropdown = element(by.id('incomeSource'));


    this.EnternoValues_ClickContinue_ViewReviewPage = function(){

        browser.executeScript("arguments[0].scrollIntoView()",primarybutton.get(0).getWebElement());
        primarybutton.get(0).click();

        //var AdditionalInfo = element(by.className('heading--beta--top'));
        //expect(AdditionalInfo.getText()).toEqual('Review');

    };

    this.dateofhire = function(value1){


        browser.sleep(2000);
        //var dateselect = element(by.className('ng-tns-c0-2 '+ dateclassname));
        var dateselect = element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/moreinfo/form/div/div[3]/div[1]/p-calendar/span/input'));
        browser.executeScript("arguments[0].scrollIntoView()",dateselect.getWebElement());
        dateselect.clear();

        dateselect.sendKeys(value1,protractor.Key.TAB);
        return dateselect.getAttribute('value');
    };

    this.Labelvalidations  = function (){

        var LabelName = element.all(by.className('label_text'));
        LabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(LabelName.get(i).getText()).toContain(lbl_AddlDetails[i]);

            }
        });
    };

    this.SectionsHeadingValidations  = function (){

        var headingName = element.all(by.tagName('h3'));
        headingName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            for (var i = 0; i < labelcount; i++) {
                expect(headingName.get(i).getText()).toEqual(lbl_headings[i]);

            }
        });
    };



    this.EnterTextBoxValue= function(value1){

        browser.executeScript("arguments[0].scrollIntoView()",txtbox_entries.getWebElement());
        txtbox_entries.sendKeys(value1);
        browser.sleep(1000);

    };

    this.EnterEmpcontribution= function(value1){

        browser.sleep(2000);
        browser.executeScript("arguments[0].scrollIntoView()",Empcontribution.getWebElement());
        Empcontribution.sendKeys(value1);
        browser.sleep(1000);

    };

    this.Selectdropdown= function(value1){

        browser.sleep(2000);
        browser.executeScript("arguments[0].scrollIntoView()",dropdown_entries.getWebElement());
        dropdown_entries.$('[value = "'+ value1 +'"]').click();
        browser.sleep(1000);

    };

    this.Selectincomedropdown= function(value1){

        browser.sleep(2000);
        browser.executeScript("arguments[0].scrollIntoView()",income_dropdown.getWebElement());
        income_dropdown.$('[value = "'+ value1 +'"]').click();
        browser.sleep(1000);

    };

    this.EnterJobReqDesc= function(value1){

        browser.sleep(2000);
        browser.executeScript("arguments[0].scrollIntoView()",txt_Jobreqdesc.getWebElement());
        otherincomeamt.sendKeys(value1);
        browser.sleep(1000);

    };

    this.EnterOtherincomamount= function(value1){

        browser.sleep(2000);
        browser.executeScript("arguments[0].scrollIntoView()",otherincomeamt.getWebElement());
        otherincomeamt.sendKeys(value1);
        browser.sleep(1000);

    };

    this.Otherincomebegandate = function(value1){

        browser.sleep(1000);
        //var dateselect = element(by.className('ng-tns-c0-3 '+ othericomedateclassname));
        var dateselect = element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/moreinfo/form/div/div[11]/div/other-income/form/div/div[4]/div/p-calendar/span/input'));
        dateselect.clear();
        browser.executeScript("arguments[0].scrollIntoView()",dateselect.getWebElement());
        dateselect.sendKeys(value1,protractor.Key.TAB);
        return dateselect.getAttribute('value');

    };

    this.Otherincomeceaseddate = function(value1){

        browser.sleep(1000);
        //var dateselect = element(by.className('ng-tns-c0-4 '+ othericomedateclassname));
        var dateselect = element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/moreinfo/form/div/div[11]/div/other-income/form/div/div[5]/div/p-calendar/span/input'));
        dateselect.clear();
        browser.executeScript("arguments[0].scrollIntoView()",dateselect.getWebElement());
        dateselect.sendKeys(value1,protractor.Key.TAB);
        return dateselect.getAttribute('value');

    };

    this.Otherincomeapplieddate = function(value1){

        browser.sleep(1000);
        //var dateselect = element(by.className('ng-tns-c0-5 '+ othericomedateclassname));
        var dateselect = element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/moreinfo/form/div/div[11]/div/other-income/form/div/div[6]/div/p-calendar/span/input'));
        dateselect.clear();
        browser.executeScript("arguments[0].scrollIntoView()",dateselect.getWebElement());
        dateselect.sendKeys(value1,protractor.Key.TAB);
        return dateselect.getAttribute('value');

    };

    this.Clickaddotherincome= function(value1) {

        browser.sleep(2000);
        browser.executeScript("arguments[0].scrollIntoView()", otherincom_id.getWebElement());
        otherincom_id.click();
        browser.sleep(1000);

    };

    this.SelectTuesday= function(value1) {

        browser.sleep(2000);
        browser.executeScript("arguments[0].scrollIntoView()", otherincomeamt.get(4).getWebElement());
        otherincomeamt.get(4).click();
        browser.sleep(2000);

    };

    this.SelectWednesday= function(value1) {

        browser.sleep(2000);
        browser.executeScript("arguments[0].scrollIntoView()", otherincomeamt.get(5).getWebElement());
        otherincomeamt.get(5).click();
        browser.sleep(2000);

    };

    this.SelectThursday= function(value1) {

        browser.sleep(2000);
        browser.executeScript("arguments[0].scrollIntoView()", otherincomeamt.get(6).getWebElement());
        otherincomeamt.get(6).click();
        browser.sleep(2000);

    };















    //Additional Information - Progress Bar
    this.addinfobar = {
        input: element(by.css('[href="/employer/cli/moreinfo"]'))
    };

    //Additional Information - Header text
    this.addinfoheader  = {
        input: (element.all(by.tagName('h1')).get(1))
    };

    //Employment Details - Header text
    this.empdetails = {
        input: (element.all(by.tagName('h2')).get(1))
    };

    //Hire date label
    this.hiredatelabel = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(0))
    };

    //Hire date
    this.hiredatetextbox = {
        input: element(by.id('dateOfHire'))
    };

    //Hire date label optional
    this.hiredatelabelopt = {
        input: (element.all(by.className('fieldset__optional')).get(0))
    };

    //Employee ID
    this.empidlabel = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(1))
    };

    //Employee ID - text box
    this.empidtxt = {
        input: element(by.id('employeeID'))
    };

    //Employee ID  optional
    this.empidlabelopt = {
        input: (element.all(by.className('fieldset__optional')).get(1))
    };

    //Work State - Label
    this.workstatelabel = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(2))
    };

    //Work State - drop down
    this.workstatelist = {
        input: element(by.id('workState'))
    };

    //Work State optional
    this.workstatelabelopt = {
        input: (element.all(by.className('fieldset__optional')).get(2))
    };

    //Subsidiary - label
    this.subslbl = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(3))
    };

    //Subsidiary - text box
    this.substext = {
        input: element(by.id('subsidiary'))
    };

    //Subsidiary optional
    this.subslblopt = {
        input: (element.all(by.className('fieldset__optional')).get(3))
    };

    //Location / Branch - Label
    this.locbranchlbl = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(4))
    };

    //Location / Branch - text box
    this.locbranchtxt = {
        input: element(by.id('locationBranch'))
    };

    //Location / Branch optional
    this.locbranchlblopt = {
        input: (element.all(by.className('fieldset__optional')).get(4))
    };

    //Employee Type - Label
    this.emptypelbl = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(5))
    };

    //Employee Type - dropdown
    this.emptypelist = {
        input: element(by.id('employeeType'))
    };

    //Employee Type optional
    this.emptypelblopt = {
        input: (element.all(by.className('fieldset__optional')).get(5))
    };

    //Job Requirements Description - Label
    this.jobreqdesclbl = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(6))
    };

    //Job Requirements Description  - text box
    this.jobreqdesctxt = {
        input: element(by.id('jobReqDesc'))
    };

    //Job Requirements Description optional
    this.jobreqdesclblopt = {
        input: (element.all(by.className('fieldset__optional')).get(6))
    };

    //Physical Demands - Label
    this.phydemandsclbl = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(7))
    };

    //Physical Demands - dropdown
    this.phydemandsclist = {
        input: element(by.css('[formcontrolname="physicalDemand"]'))
    };

    //Physical Demands optional
    this.phydemandsclblopt = {
        input: (element.all(by.className('fieldset__optional')).get(7))
    };

    //Pay Type - Label
    this.paytypelbl = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(8))
    };

    //Pay Type - dropdown
    this.paytypelist = {
        input: element(by.css('[formcontrolname="payType"]'))
    };

    //Pay Type optional
    this.paytypelblopt = {
        input: (element.all(by.className('fieldset__optional')).get(8))
    };

    //Earnings- Label
    this.earningslbl = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(9))
    };

    //Earnings  - text box
    this.earningstxt = {
        input: element(by.id('earnings'))
    };

    //Earnings optional
    this.earningslblopt = {
        input: (element.all(by.className('fieldset__optional')).get(9))
    };

    //Has or will this employee receive another source of income for the entire portion of the absence covered by this claim?
    //Please select from the following
    //Question Label
    this.sourceofincomelbl = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(11))
    };

    //Question Label dropdown
    this.sourceofincomelist = {
        //input: (element.all(by.className('inputdropdown ng-untouched ng-pristine ng-valid')).get(0))
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/moreinfo/form/div/div[3]/div/section/other-income/div/fieldset[2]/div/select'))
    };


    this.sourceofincomelistdropdown = {
        //input: (element.all(by.className('inputdropdown ng-untouched ng-pristine ng-valid')).get(0))
       // input: (element.all(by.className('inputdropdown ng-untouched ng-pristine ng-valid')).get(1))
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/moreinfo/form/div/div[3]/div/section/other-income/div/fieldset[2]/div/select'))
        //input: (element(by.css('[formcontrolname="otherIncome"]')).element(by.className('inputdropdown ng-untouched ng-pristine ng-valid')))

    };

    //Question Label optional
    this.sourceofincomelblopt = {
        input: (element.all(by.className('fieldset__optional')).get(10))
    };

    //Other Income Amount (Please indicate per Week/per Month) label
    this.otherincomeamtlbl   = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(12))
    };

    //Other Income Amount (Please indicate per Week/per Month)textbox
    this.otherincomeamttxt = {
        input: element(by.id('amount'))
    };

    //Other Income Amount (Please indicate per Week/per Month) optional
    this.otherincomeamtlblopt = {
        input: (element.all(by.className('fieldset__optional')).get(11))
    };

    //Date employee began receiving other income label
    this.begandatelbl  = {
       input: (element.all(by.className('fieldset fieldset--pristine')).get(13))
       // input: element(by.xpath('/ng2-datetime-picker'))
    };

    //Date employee began receiving other income datepicker
    this.begandate   = {
        //input: (element.all(by.className('ng-pristine ng-valid ng-touched')).get(0))
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/moreinfo/form/div/div[3]/div/section/other-income/div/fieldset[4]/div/input'))

    };

    //Date employee began receiving other income optional
    this.begandatelblopt = {
        input: (element.all(by.className('fieldset__optional')).get(12))
    };

    //Date employee ceased receiving other income label
    this.ceaseddatelbl     = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(14))
    };

    //Date employee ceased receiving other income datepicker
    this.ceaseddate    = {
       //input: (element.all(by.className('ng-untouched ng-pristine ng-valid')).get(1))
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/moreinfo/form/div/div[3]/div/section/other-income/div/fieldset[5]/div/input'))

    };

    //Date employee ceased receiving other income optional
    this.ceaseddatelblopt = {
        input: (element.all(by.className('fieldset__optional')).get(13))
    };

    //Date employee applied for other income label
    this.applieddatelbl     = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(15))
    };

    //Date employee applied for other income datepicker
    this.applieddate    = {
       // input: (element.all(by.className('ng-untouched ng-pristine ng-valid')).get(2))
        input: element(by.xpath('/html/body/sd-app/section/cli-home-component/div/div/div[2]/moreinfo/form/div/div[3]/div/section/other-income/div/fieldset[6]/div/input'))

    };

    //Date employee applied for other income optional
    this.applieddatelblopt = {
        input: (element.all(by.className('fieldset__optional')).get(14))
    };

    //Class - Label
    this.classlbl = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(16))
    };

    //Class - text box
    this.classtext = {
        input: element(by.css('[formcontrolname="incomeClass"]'))
    };

    //Class optional
    this.classlblopt = {
        input: (element.all(by.className('fieldset__optional')).get(15))
    };

    //Employee Premium Contribution - Label
    this.eecontributionlbl = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(17))
    };

    //Employee Premium Contribution - text box
    this.eecontributiontext = {
        input: element(by.css('[formcontrolname="empPremiumContribution"]'))
    };

    //Employee Premium Contribution optional
    this.eecontributionlblopt = {
        input: (element.all(by.className('fieldset__optional')).get(16))
    };

    //Employer  Premium Contribution - Label
    this.ercontributionlbl = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(18))
    };

    //Employer  Premium Contribution - text box
    this.ercontributiontext = {
        input: element(by.css('[formcontrolname="emprPremiumContribution"]'))
    };
    this.datepicker = {
        input: element(by.className('ng2-datetime-picker'))
    }

    //ER Premium Contribution optional
    this.ercontributionlblopt = {
        input: (element.all(by.className('fieldset__optional')).get(17))
    };

    //Benefit Percent - Label
    this.benefitpercentlbl = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(19))
    };

    //Benefit Percent - text box
    this.benefitpercenttxt = {
        input: element(by.css('[formcontrolname="benefitPercent"]'))
    };

    //Benefit Percent  optional
    this.benefitpercentlblopt = {
        input: (element.all(by.className('fieldset__optional')).get(18))
    };

    //Days per Week - Label
    this.daysperweeklbl = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(20))
    };

    //Days per Week - text box
    this.daysperweektxt = {
        input: element(by.css('[formcontrolname="daysPerWeek"]'))
    };

    //Days per Week  optional
    this.daysperweeklblopt = {
        input: (element.all(by.className('fieldset__optional')).get(19))
    };

    //Hours per Day - Label
    this.hrsperdaylbl = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(21))
    };

    //Hours per Day - text box
    this.hrsperdaytxt = {
        input: element(by.css('[formcontrolname="hoursPerDay"]'))
    };

    //Hours per Day optional
    this.hrsperdaylblopt = {
        input: (element.all(by.className('fieldset__optional')).get(20))
    };


    //Scheduled Work Days - Label
    this.scheduledwrkdayslbl = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(22))
    };

    //Scheduled Work Days - Monday check box
    this.mondaycheckbox = {
        input: element(by.css('[formcontrolname="Monday"]'))
    };

    //Scheduled Work Days optional
    this.scheduledwrkdayslblopt = {
        input: (element.all(by.className('fieldset__optional')).get(21))
    };

    //Current Work Status - Label
    this.curwrkstatuslbl = {
        input: (element.all(by.className('fieldset fieldset--pristine')).get(23))
    };

    //Current Work Status - Drop down
    this.curwrkstatuslist = {
        input: element(by.css('[formcontrolname="currentWorkStatus"]'))
    };

    //Current Work Status optional
    this.curwrkstatuslblopt = {
        input: (element.all(by.className('fieldset__optional')).get(22))
    };

    // Cancel Button
    this.cancelbutton = {
        input: element(by.buttonText('Cancel'))
    };

    // Continue Button
    this.continuebutton = {
        input: element(by.buttonText('Continue'))
    };

    //Go Back Button
    this.gobackbutton = {
        input: element(by.buttonText('Go Back'))
    };

    //Go Back Button
    this.otherincomebutton = {
        input: element(by.buttonText('Add Other Income'))
    };

    this.txthiredate = {
        input: element.all(by.className('undefined ui-inputtext ui-corner-all ui-state-default ui-widget')).get(0)

    };
    this.txtbegandate = {
        input: element.all(by.className('undefined ui-inputtext ui-corner-all ui-state-default ui-widget')).get(1)

    };
    this.txtceasedate = {
        input: element.all(by.className('undefined ui-inputtext ui-corner-all ui-state-default ui-widget')).get(2)

    };
    this.txtapplieddate = {
        input: element.all(by.className('undefined ui-inputtext ui-corner-all ui-state-default ui-widget')).get(3)

    };

    this.Select_Workdays = function (value1) {

        switch (value1) {

            case 'Weekdays':
                Monday.click();
                Tuesday.click();
                Wednesday.click();
                Thursday.click();
                Friday.click();
                break;

            case 'Alldays':
                Monday.click();
                Tuesday.click();
                Wednesday.click();
                Thursday.click();
                Friday.click();
                Saturday.click();
                Sunday.click();
                break;

            case 'Weekends':
                Saturday.click();
                Sunday.click();
                break;

            case 'Alternatedays':
                Monday.click();
                Wednesday.click();
                Friday.click();
                Sunday.click();
                break;
        }
    };

    this.invalid_msg = function(value1) {

        switch(value1) {

            case 'HireDate':

                expect(invalidmessage.get(0).isDisplayed()).toBe(true);
                expect(invalidmessage.get(0).getText()).toContain('Enter a valid date MM/DD/YYYY');
                break;

            case 'BeginDate':

                expect(invalidmessage.get(1).isDisplayed()).toBe(true);
                expect(invalidmessage.get(1).getText()).toContain('Enter a valid date MM/DD/YYYY');
                break;

            case 'EndDate':

                expect(invalidmessage.get(2).isDisplayed()).toBe(true);
                expect(invalidmessage.get(2).getText()).toContain('Enter a valid date MM/DD/YYYY');
                break;

            case 'ApplyDate':

                expect(invalidmessage.get(3).isDisplayed()).toBe(true);
                expect(invalidmessage.get(3).getText()).toContain('Enter a valid date MM/DD/YYYY');
                break;
        }
    };

    this.future_msg = function(value1) {

        expect(invalidmessage.get(0).isDisplayed()).toBe(true);
        expect(invalidmessage.get(0).getText()).toContain('Date cannot be in the future.');

    };

    this.prior_msg = function(value1) {

        expect(invalidmessage.get(0).isDisplayed()).toBe(true);
        expect(invalidmessage.get(0).getText()).toContain('Enter a valid date MM/DD/YYYY');

    };


    this.outofwindow_msg = function(value1) {

        switch(value1) {

            case 'BeginDate':

                expect(invalidmessage.get(1).isDisplayed()).toBe(true);
                expect(invalidmessage.get(1).getText()).toContain('The date entered must be +1 or -1 years of the current date.');
                break;

            case 'EndDate':

                expect(invalidmessage.get(2).isDisplayed()).toBe(true);
                expect(invalidmessage.get(2).getText()).toContain('The date entered must be +1 or -1 years of the current date.');
                break;

            case 'ApplyDate':

                expect(invalidmessage.get(3).isDisplayed()).toBe(true);
                expect(invalidmessage.get(3).getText()).toContain('The date entered must be +1 or -1 years of the current date.');
                break;

        }


    };


};

module.exports = new AddlInfoPage();
