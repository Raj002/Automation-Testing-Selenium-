/**
 * Created by n0305595 on 6/20/2017.
 */

var Getting_StartedPage = require('./PageObject_GettingStarted.js');

var POAYP = function() {

    var Employer_Header =['Retrieve your information','Personal Information','Residential Information','Preferred Contact Information','Primary Work Location'];
    var Employee_Spanish = ['Recuperar su información','Información Personal','Información residencial','Información de contacto preferida','Lugar de trabajo principal'];

    var Aboutyoupage_Label = ['First Name','Middle Initial','Last Name','Date of Birth','Country','Residential Address 1','Residential Address 2','Residential City',
        'Residential State','Postal Code','Personal Phone','Personal Email','Country of Employment','State of Employment'];

    var Aboutyoupage_Label_Spanish = ['Primer Nombre','Inicial del Segundo Nombre','Apellido','Fecha de Nacimiento','Pais','Dirección Residencial 1','Dirección Residencial 2','Ciudad',
        'Estado de Residencia','Código Posta','Teléfono Personal','Correo electrónico personal','País de empleo','Estado de empleo'];

    var Aboutyoupage_Radio_label = ['Employee ID','Social Security Number'];
    var Aboutyoupage_Radio_label_Spanish = ['Identificación del Empleado','Número de Seguro Social'];

    var employeeid= element(by.css('[formcontrolname="empID"]'));
    var lastnamesearch= element(by.css('[formcontrolname="lastNameSearch"]'));
    var empssn = element(by.className('ui-inputtext ui-corner-all ui-state-default ui-widget'));
    var socialsecuritynumber = element(by.css('[formcontrolname="SSN"]'));
    var uniqueID = element.all(by.css('[formcontrolname="uniqueID"]'));
    var emailID = element(by.css('[formcontrolname="email"]'));
    var dateofbirth = element(by.css('[formcontrolname="dob"]'));
    var preferredphone = element(by.css('[formcontrolname="phone"]'));
    var deletebutton = element.all(by.className('lds-button lds-button--save'));
    var headerlink = element.all(by.className('nav-link'));
    var savebutton = element(by.className('lds-button lds-button--save'));
    var cancelbuttoner = element(by.className('lds-button lds-button--delete'));
    var secondarybutton = element(by.className('lds-button lds-button--secondary'));
    var lastname =   element(by.css('[formcontrolname="lastName"]'));
    var firstname =   element(by.css('[formcontrolname="firstName"]'));
    var prefemail =   element(by.css('[formcontrolname="email"]'));
    var resaddr1 =   element(by.css('[formcontrolname="residentialAdd1"]'));
    var resaddr2 =   element(by.css('[formcontrolname="residentialAdd2"]'));
    var rescity =   element(by.css('[formcontrolname="residentialCity"]'));
    var resstate =   element(by.css('[formcontrolname="selectedStateID"]'));
    var postalcode =   element(by.css('[formcontrolname="postalCode"]'));
    var gender  =   element.all(by.css('[formcontrolname="gender"]'));
    var uniqueID  =   element.all(by.css('[formcontrolname="empID"]'));
    var country = element(by.css('[formcontrolname="selectedCountryID"]'));
    var empState = element(by.css('[formcontrolname="selectedEmpStateID"]'));
    var textentries = element.all(by.className('ui-inputtext ui-corner-all ui-state-default ui-widget'));
    var errormessage = element.all(by.className('fieldset__feedback_label fieldset__feedback--invalid'));
    var cancelbutton = element(by.className('lds-button lds-button--cancel'));
    var primarybutton = element.all(by.className('lds-button lds-button--primary'));
    var popupheader =   element(by.className('modal-title'));
    var popupbody =   element(by.className('modal-body'));


    this.Validate_AboutYouPageHeader = function (value1) {

        var pageheader = element.all(by.tagName('h2'));
        if (value1 == 'Employee-Spanish'){

            pageheader.count().then(function (cnt) {
                var headercount = cnt;
                for (var i = 1; i < headercount; i++) {
                    expect(pageheader.get(i).getText()).toEqual(Employee_Spanish[i-1]);

                }

            });

        }
        else {
            pageheader.count().then(function (cnt) {
                var headercount = cnt;
                for (var i = 1; i < headercount; i++) {
                    expect(pageheader.get(i).getText()).toEqual(Employer_Header[i-1]);

                }

            });
        }


    };

    this.Validate_AboutYouPage_LabelName = function (value1) {

        var labelName = element.all(by.className('fieldLabel'));
        labelName.count().then(function (cnt) {
            var labelcount = cnt;

            if (value1=="Employee-Spanish")
            {
                for (var i = 0; i < labelcount; i++) {
                    expect(labelName.get(i).getText()).toEqual(Aboutyoupage_Label_Spanish[i]);

                }

            }
            else {
                for (var i = 0; i < labelcount; i++) {
                    expect(labelName.get(i).getText()).toEqual(Aboutyoupage_Label[i]);

                }
            }

        });

        var radiolabelName = element.all(by.className('fieldset__label--radio no-feedback'));
        radiolabelName.count().then(function (cnt) {
            labelcount = 0;
            labelcount = cnt;
            if (value1=="Employee-Spanish")
            {
                for (var i = 0; i < labelcount; i++) {
                    expect(radiolabelName.get(i).getText()).toEqual(Aboutyoupage_Radio_label_Spanish[i]);

                }
            }
            else {
                for (var i = 0; i < labelcount; i++) {
                    expect(radiolabelName.get(i).getText()).toEqual(Aboutyoupage_Radio_label[i]);

                }
            }

        });

    };

    this.ClickSaveforLater = function (){

        browser.executeScript("arguments[0].scrollIntoView()",savebutton.getWebElement());
        deletebutton.get(2).click();
        browser.sleep(20000);
        deletebutton.get(3).click();
    };
    this.VerifyEmployeeID = function(value1,value2){
        if (value1 =="Employer"){

            expect(employeeid.getAttribute('value')).toEqual("");

        }
        else
        {
            expect(employeeid.getAttribute('value')).toEqual(value2);
        }

    };


    this.UniqueID_EmpID_SSN = function(value1){
        if (value1 =="EmpID"){

            uniqueID.get(0).click();
        }
        else
        {
            uniqueID.get(1).click();
        }

    };

    this.ERheaderlink = function(value1) {
        switch (value1) {

            case 'Home':
                headerlink.get(0).click();
                browser.sleep(1000);
                break;

            case 'Service Team':
                headerlink.get(1).click();
                browser.sleep(1000);
                break;

            case 'Learning Center':
                headerlink.get(2).click();
                browser.sleep(1000);
                break;

            case 'Adminstration':
                headerlink.get(3).click();
                browser.sleep(1000);
                break;

            case 'Employee Home':
                headerlink.get(4).click();
                browser.sleep(1000);
                break;


        }
    };

    this.EEheaderlink = function(value1) {
        switch (value1) {

            case 'Home':
                headerlink.get(0).click();
                break;

            case 'Forms':
                headerlink.get(1).click();
                break;

            case 'Learn More':
                headerlink.get(2).click();
                break;


        }
    };

    this.popupvalidation = function() {

        //browser.executeScript("arguments[0].scrollIntoView()", popupheader.getWebElement());
        expect(popupheader.getText()).toContain(['Are you sure?']);
        expect(popupbody.getText()).toContain(['If you navigate away you will lose your progress']);
        expect(primarybutton.get(2).getText()).toContain(['Stay']);
        expect(cancelbutton.getText()).toContain(['Leave']);
        element(by.buttonText('Stay')).click();
        browser.sleep(1000);
    };


    this.Validate_PlaceHolderText = function () {

        expect(employeeid.getAttribute('placeholder')).toEqual('Enter Employee ID');
        expect(socialsecuritynumber.getAttribute('placeholder')).toEqual('Enter SSN(9 digits)');
        expect(emailID.getAttribute('placeholder')).toEqual('name@domain.com');
        expect(dateofbirth.getAttribute('placeholder')).toEqual('mm/dd/yyyy');
        expect(preferredphone.getAttribute('placeholder')).toEqual('(###) ###-####');


    };

    this.Validate_ButtonText_Color = function (value1) {

        switch (value1) {

            case 'Employee-English':

                 //   expect(primarybutton.get(0).getText()).toEqual('Find My Information');
                    expect(deletebutton.get(1).getText()).toEqual('Delete Application');
                    expect(deletebutton.get(1).getCssValue("color")).toEqual("rgba(27, 117, 187, 1)");
                    expect(primarybutton.getText()).toEqual('Continue');
                    expect(primarybutton.getCssValue("color")).toEqual("rgba(255, 255, 255, 1)");
                    expect(secondarybutton.getText()).toEqual('< Go Back');
                    expect(secondarybutton.getCssValue("color")).toEqual("rgba(27, 117, 187, 1)");
                    break;

            case 'Employer':

                   // expect(primarybutton.get(0).getText()).toEqual('Find Employee Information');
                   // expect(primarybutton.get(0).getCssValue("color")).toEqual("rgba(255, 255, 255, 1)");

                    expect(cancelbuttoner.getText()).toEqual('Cancel');
                    expect(cancelbuttoner.getCssValue("color")).toEqual("rgba(27, 117, 187, 1)");
                    expect(primarybutton.getText()).toEqual('Continue');
                    expect(primarybutton.getCssValue("color")).toEqual("rgba(255, 255, 255, 1)");
                    expect(secondarybutton.getText()).toEqual('< Go Back');
                    expect(secondarybutton.getCssValue("color")).toEqual("rgba(27, 117, 187, 1)");
                    break;

            case 'Employee-Spanish':

                //expect(primarybutton.get(0).getText()).toEqual('Find My Information');
                expect(deletebutton.get(1).getText()).toEqual('Eliminar solicitud');
                expect(deletebutton.get(1).getCssValue("color")).toEqual("rgba(27, 117, 187, 1)");
                expect(primarybutton.getText()).toEqual('Continuar');
                expect(primarybutton.getCssValue("color")).toEqual("rgba(255, 255, 255, 1)");
                expect(secondarybutton.getText()).toEqual('< Volver');
                expect(secondarybutton.getCssValue("color")).toEqual("rgba(27, 117, 187, 1)");
                break;
        }
    };

    this.Validate_ErrorMessage_MandatoryFields_NotEntered = function (value1) {

        browser.executeScript('window.scrollTo(1280,2500);');
        primarybutton.get(1).click();
        //primarybutton.get(2).click();
        browser.sleep(500);

        errormessage.count().then(function (cnt) {
            var errorcount = cnt;
            for (var i = 0; i < errorcount; i++) {

                if (value1 == "Employee-Spanish"){
                    if (i != 2 && i !=1 && i !=3) {
                        expect(errormessage.get(i).getText()).toEqual('Obligatorio');
                    }

                }


                if (value1 == "Employee-English"){
                    if (i != 2 && i !=1 && i !=3) {
                        expect(errormessage.get(i).getText()).toEqual('Required');
                    }

                }

                if (value1 == "Employer"){
                    if (i != 1 && i != 6) {
                        expect(errormessage.get(i).getText()).toEqual('Required');
                    }
                }

            }

        });

    };


    this.Validate_Prepop_Valid_EmpID_LastName = function (value1,value2) {
        employeeid.sendKeys(value1);
        lastname.sendKeys(value2);
        primarybutton.get(1).click();
        browser.sleep(500);

        expect(firstname.getText()).toEqual('SARIENA');
        expect(resaddr1.getAttribute('value')).toEqual("27 LAKEWOOD AVE");
        expect(rescity.getAttribute('value')).toEqual("BUFFALO");
        expect(postalcode.getAttribute('value')).toEqual("14220");
        expect(resstate.getAttribute('value')).toEqual("NY");
        expect(dateofbirth.getAttribute('value')).toEqual("03/09/1994");
        expect(country.getAttribute('value')).toEqual("USA");
        expect(gender.get(0).isSelected()).toBe(true);


    };

    this.Validate_Prepop_Valid_SSN_LastName = function (value1,value2) {

        deletebutton.click();
        element(by.className('lds-button lds-button--save')).click();
        Getting_StartedPage.clickStart();

        employeeid.sendKeys(value1);
        lastname.sendKeys(value2);
        primarybutton.click();
        browser.sleep(500);

        expect(firstname.getText()).toEqual('FEROZ');
        expect(resaddr1.getAttribute('value')).toEqual("3260 MILLERSPORT HWY");
        expect(resaddr2.getAttribute('value')).toEqual("APT #4");
        expect(rescity.getAttribute('value')).toEqual("GETZVILLE");
        expect(postalcode.getAttribute('value')).toEqual("14068");
        expect(resstate.getAttribute('value')).toEqual("NY");
        expect(dateofbirth.getAttribute('value')).toEqual("05/14/1977");
        expect(country.getAttribute('value')).toEqual("USA");
        expect(gender.get(1).isSelected()).toBe(true);


    };

    this.validate_first_last_NamesPrefill = function(){

        expect(firstname.getAttribute('value')).toEqual('THERESATest');
        expect(lastname.getAttribute('value')).toEqual('ALBERT');
        expect(lastname.isEnabled()).toBe(false);

    };

    this.Validate_Prepop_Valid_SSN_InvalidLastName = function (value1,value2) {

        deletebutton.click();
        element(by.className('lds-button lds-button--save')).click();
        Getting_StartedPage.clickStart();
        browser.executeScript("arguments[0].scrollIntoView()",uniqueID.get(1).getWebElement());
        uniqueID.get(1).click();


        employeeid.sendKeys(value1);
        lastname.sendKeys(value2);
        primarybutton.click();
        browser.sleep(500);

        var errorpopup = element(by.className('modal-body'));
        expect(errorpopup.getText()).toEqual('There was an error pre-populating your eligibility data.');
        element(by.buttonText('Close')).click();


    };

    this.EnterFirstName = function(value1){
        firstname.sendKeys(value1);
    };


    this.EnterLastName = function(value1){
        lastname.sendKeys(value1);

    };

    this.ValidateFirstNameEE = function(value1){
        expect(firstname.getAttribute('value')).toEqual("MICHELLE");

    };

    this.ValidateLastNameEE = function(value1){
        expect(lastname.getAttribute('value')).toEqual("Abbott");

    };

    this.ValidateFirstNameEE_Leaveonly = function(value1){
        expect(firstname.getAttribute('value')).toEqual("QACust");

    };

    this.ValidateLastNameEE_Leaveonly = function(value1){
        expect(lastname.getAttribute('value')).toEqual("Test");

    };

    this.ValidateFirstNameEE_Claimonly = function(value1){
        expect(firstname.getAttribute('value')).toEqual("Test");

    };

    this.ValidateLastNameEE_Claimonly = function(value1){
        expect(lastname.getAttribute('value')).toEqual("Bailey");

    };

    this.EnterEmployeeID = function(value1){

        browser.executeScript("arguments[0].scrollIntoView()",employeeid.getWebElement());
        employeeid.sendKeys(value1);

    };

    this.lastnamesearch = function(value1){

        browser.executeScript("arguments[0].scrollIntoView()",lastnamesearch.getWebElement());
        lastnamesearch.sendKeys(value1);

    };


    this.EnterSSN = function(value1){

        browser.executeScript("arguments[0].scrollIntoView()",socialsecuritynumber.getWebElement());
        socialsecuritynumber.sendKeys(value1);

    };

    this.SelectGender = function(value1){

        browser.executeScript("arguments[0].scrollIntoView()",gender.get(0).getWebElement());
        if (value1 == 'Female')
        {
            gender.get(0).click();
            browser.sleep(5000);
        }
        else
        {
            gender.get(1).click();
            browser.sleep(5000);
        }

    };

    this.EnterDateofBirth = function(value1){

        textentries.get(0).clear();
        textentries.get(0).sendKeys(value1);
        var dobvalue = textentries.get(0).getAttribute('value');

        return dobvalue;

    };

    this.InvalidErrorMessage_DateofBirth = function(value1){
        textentries.get(0).clear();
        textentries.get(0).sendKeys(value1);
        return errormessage.get(4).getText();
    };

    this.EnterResdentialAddress1 = function(value1){

        browser.executeScript("arguments[0].scrollIntoView()",resaddr1.getWebElement());
        resaddr1.sendKeys(value1);

    };

    this.EnterResdentialcity = function(value1){

        browser.executeScript("arguments[0].scrollIntoView()",rescity.getWebElement());
        rescity.sendKeys(value1);

    };

    this.EnterPostalCode = function(value1){
        browser.executeScript("arguments[0].scrollIntoView()",postalcode.getWebElement());
        postalcode.sendKeys(value1);

    };

    this.SelectState = function(value1){
        browser.executeScript("arguments[0].scrollIntoView()",resstate.getWebElement());
        resstate.$('[value = "'+ value1 +'"]').click();

    };

    this.SelectEmploymentState = function(value1){
        browser.executeScript("arguments[0].scrollIntoView()",empState.getWebElement());
        empState.$('[value = "'+ value1 +'"]').click();

    };

    this.EnterPersonalPhone = function(value1){
        textentries.get(1).sendKeys(value1);

    };


    this.EnterPersonalEmail = function(value1){
        prefemail.sendKeys(value1);
    };

    this.CancelExistingApplication = function(){

        browser.executeScript("arguments[0].scrollIntoView()",deletebutton.getWebElement());
        deletebutton.click();
        browser.sleep(3000);
        browser.executeScript("arguments[0].scrollIntoView()", deletebutton.get(2).getWebElement());
        deletebutton.get(2).click();


    };

    this.Display_GettingStartedPage_OnRefresh = function(value1) {

        browser.refresh();
        browser.sleep(25000);
        Getting_StartedPage.VerifyPageHeader(value1);
        Getting_StartedPage.clickStart(value1);

        expect(employeeid.getText()).toEqual('');
        expect(firstname.getText()).toEqual('');
        expect(lastname.getText()).toEqual('');
        expect(dateofbirth.getAttribute('value')).toEqual(null);
        expect(gender.get(0).isSelected()).toBe(false);
        expect(gender.get(1).isSelected()).toBe(false);
        expect(resaddr1.getAttribute('value')).toEqual("");
        expect(resaddr2.getAttribute('value')).toEqual("");
        expect(rescity.getAttribute('value')).toEqual("");
        expect(postalcode.getAttribute('value')).toEqual("");
        expect(resstate.getAttribute('value')).toEqual("0");
        expect(country.getAttribute('value')).toEqual("USA");


    };

    this.ClickContinue_ViewAboutYourAbsence = function() {

        browser.executeScript("arguments[0].scrollIntoView()", primarybutton.get(1).getWebElement());
        primarybutton.get(1).click();
        browser.sleep(10000);
        //var Aboutyourabsence = element(by.className('heading--beta--top'));
       // expect(Aboutyourabsence.getText()).toEqual('Details of Employee absence');

    };

    this.ClickContinue_button = function() {

        //browser.executeScript("arguments[0].scrollIntoView()", primarybutton.get(1).getWebElement());
        element(by.buttonText('Continue')).click();
        //primarybutton.get(1).click();
        browser.sleep(10000);


    };

    this.ClickDeleteApplication_ViewDeletePopup = function(){

        browser.executeScript("arguments[0].scrollIntoView()", deletebutton.get(0).getWebElement());
        deletebutton.get(1).click();
        browser.sleep(5000);
        expect(element(by.className('modal-content')).isDisplayed()).toBe(true);

    };

    this.Validate_DeletePopup_ButtonText_Header_Body = function(value1){

        switch (value1) {
            case "Employee-English" || "Employer":

                expect(deletebutton.get(3).getText()).toEqual('Ok');
                expect(cancelbutton.getText()).toEqual('Cancel');
                expect(element(by.className('modal-title')).getText()).toEqual('Delete Application');
                expect(element(by.className('modal-body')).getText()).toEqual('If you continue, all information you have entered will be removed. Would you like to continue?');
                break;
            case "Employee-Spanish":

                expect(deletebutton.get(3).getText()).toEqual('Aceptar');
                expect(cancelbutton.getText()).toEqual('Cancelar');
                expect(element(by.className('modal-title')).getText()).toEqual("'Eliminar solicitud");
                expect(element(by.className('modal-body')).getText()).toEqual('Si continúa, se eliminará toda la información que haya ingresado. ¿Te gustaria continuar?');
                break;
        }

    };

    this.Validate_DeletePopup_ClickCancel = function(){
        cancelbutton.click();

    };

    this.Validate_DeletePopup_ClickOk = function(){

        browser.executeScript("arguments[0].scrollIntoView()", deletebutton.get(1).getWebElement());
        deletebutton.get(1).click();
        deletebutton.get(3).click();
        browser.sleep(10000);

    };


};

    module.exports = new POAYP();
